<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansSetupMenus extends XiSetup
{
	public $_location = __FILE__;
	public $_message  = 'COM_PAYPLANS_SETUP_MENUS_DO_ENABLE';
	public $_type = 'INFORMATION';

	public $_componentId = null;

	public function __construct()
	{
		parent::__construct();

		// find component id
		$query 		= new XiQuery();
		$this->_componentId	= $query->select('id')->from('#__components')
									->where(array("`option`='com_payplans'"))
									->order(array('parent'))
									->dbLoadQuery()->loadResult();

	}

	function isRequired()
	{
		// migrate old menus if exists
		$this->_migrateOldMenus();

		$this->_status =  $this->_hasMenu('index.php?option=com_payplans&view=plan')
							&& $this->_hasMenu('index.php?option=com_payplans&view=order');

		if($this->_status){
			$this->_message = 'COM_PAYPLANS_SETUP_MENUS_DONE';
			return $this->_required=false;
		}

		return $this->_required=true;
	}

	function doApply()
	{

		$this->_addMenu('Subscribe', 'subscribe', 'index.php?option=com_payplans&view=plan');
		$this->_addMenu('My Orders', 'myorders', 'index.php?option=com_payplans&view=order');
		return true;
	}

	function _hasMenu($link)
	{
		$strQuery	= "SELECT `alias` FROM `#__menu` "
					  ." WHERE `link` LIKE '%$link%' AND `componentid`={$this->_componentId}"
					  ." AND `published`=1 "
					  ;
		$db = XiFactory::getDBO();
		$db->setQuery($strQuery);
		return $db->loadResult() ? true : false;
	}

	function _addMenu($title, $alias, $link, $menu='mainmenu')
	{
		// if link already exist
		if($this->_hasMenu($link)){
			return true;
		}

		$strQuery	= "INSERT INTO `#__menu` (`menutype`, `name`, `alias`, `link`, `type`, `published`, `parent`, `componentid`, `sublevel`, `ordering`, `checked_out`, `checked_out_time`, `pollid`, `browserNav`, `access`, `utaccess`, `params`, `lft`, `rgt`, `home`) "
					  ."VALUES ('$menu', '$title', '$alias', '$link', 'component', 1, 0, $this->_componentId, 0, 500, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', 0, 0, 0)"
					  ;
		$db = XiFactory::getDBO();
		$db->setQuery($strQuery);
		return $db->query();
	}
	
	function _migrateOldMenus()
	{
		$query = "UPDATE `#__menu`
				  SET `componentid` = ".$this->_componentId." 
				  WHERE `componentid` <> ".$this->_componentId." 
				  	AND `link` LIKE '%option=com_payplans%' ";
		
		$db = XiFactory::getDBO();
		$db->setQuery($query);
		return $db->query();
	}
}