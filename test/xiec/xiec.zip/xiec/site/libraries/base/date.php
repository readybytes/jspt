<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

//XITODO : Improve it for our purpose
class XiDate extends JDate
{
	const INVOICE_FORMAT = '%A %d %b, %Y';
	const SUBSCRIPTION_PAYMENT_FORMAT = '%d %b %Y';
	const SUBSCRIPTION_PAYMENT_FORMAT_HOUR = '%d %b %Y %R%p';
	/**
	 *
	 * @param integer $time unix-timestamp
	 */
	public function add($time)
	{
		XiError::assert(is_numeric($time));
		$this->_date += $time ;
		return $this;
	}
	
	/**
	 * 
	 * @param $expirationTime : this will be in formation of YYMMDDHHMMSS
	 * @return unknown
	 */
	public function addExpiration($expirationTime)
	{
		XiError::assert(is_string($expirationTime));
		
		$timerElements = array('year', 'month', 'day', 'hour', 'minute', 'second');
		$date = date_parse($this->toString());
		
		$count = count($timerElements);
		for($i=0; $i<$count ; $i++){
			//XITODO : convert to integer before adding
			$date[$timerElements[$i]] +=   JString::substr($expirationTime, $i*2, 2);
		}
		
		$this->_date = mktime($date['hour'], $date['minute'], $date['second'], $date['month'], $date['day'], $date['year']);
			
		return $this;
	}

	public function toArray()
	{
		return $this->toMySQL();
	}

	public function toString()
	{
		return $this->toMySQL();
	}

	public function bind($timestamp)
	{
		//XITODO : check if strinf or timetamp, and work accordingly
		$this->_date = strtotime($timestamp);
		return $this;
	}
	
	public function toFormat($format=XiDate::INVOICE_FORMAT)
	{
		return parent::toFormat($format) ;
	}
	
}