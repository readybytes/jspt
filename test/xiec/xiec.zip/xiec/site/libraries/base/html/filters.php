<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

require_once JPATH_LIBRARIES.DS.'joomla'.DS.'html'.DS.'html' . DS . 'grid.php';

class XiHtmlFilters extends JHTMLGrid
{
	function boolean($name, $view, Array $filters = array(), $prefix='filter_payplans')
	{
		$elementName  = $prefix.'_'.$view.'_'.$name;
		$elementValue = @array_shift($filters[$name]);
		
		$data[] = array('value' => '', 
		  				'text'  => XiText::_( 'COM_PAYPLANS_FILTERS_SELECT_'.JString::strtoupper($name).'_STATE'));
		$data[] = array('value' => 0, 
		  				'text'  => XiText::_( 'COM_PAYPLANS_FILTERS_OFF_'.JString::strtoupper($name)));
		$data[] = array('value' => 1, 
		  				'text'  => XiText::_( 'COM_PAYPLANS_FILTERS_ON_'.JString::strtoupper($name)));
		
		foreach($data as $d)
    		$options[] = JHTML::_('select.option', $d['value'], $d['text']);
    		
    	return JHTML::_('select.genericlist', $options, $elementName.'[]', 'onchange="document.adminForm.submit();"', 'value', 'text', $elementValue);

	}
	
	function text($name, $view, Array $filters = array(), $prefix='filter_payplans')
	{
		$elementName  = $prefix.'_'.$view.'_'.$name;
		$elementValue = @array_shift($filters[$name]);
		
		$html  = '<input id="'.$elementName.'" ' 
						.'name="'.$elementName.'[]" ' 
						.'value="'.$elementValue.'" '
						.'size="25" />';
						
		return $html;
	}
	
	function plan($name, $view, Array $filters = array(), $prefix='filter_payplans')
	{
		$elementName  = $prefix.'_'.$view.'_'.$name;
		$elementValue = @array_shift($filters[$name]);
		
		$attr['none']  = true;
		$attr['style'] = 'onchange="document.adminForm.submit();"';
		return XiHtml::_('elements.plans', $elementName.'[]', $elementValue, $attr);
	}
	
	function status($name, $view, Array $filters = array(), $entity, $prefix='filter_payplans')
	{
		$elementName  = $prefix.'_'.$view.'_'.$name;
		$elementValue = @array_shift($filters[$name]);
		
		$attr['none']  = true;
		$attr['style'] = 'onchange="document.adminForm.submit();"';
		return XiHtml::_('elements.status', $elementName.'[]', $elementValue, $entity, $attr);
	}
	
	function range($name, $view, Array $filters = array(), $type="date", $prefix='filter_payplans')
	{
		$elementName   = $prefix.'_'.$view.'_'.$name;
		$elementValue0 = @array_shift($filters[$name]);
		$elementValue1 = @array_shift($filters[$name]);
		
		$from  = XiText::_('COM_PAYPLANS_FILTERS_FROM');
		$to    = XiText::_('COM_PAYPLANS_FILTERS_TO');
		
		if(JString::strtolower($type)=="date"){
			$from .= XiHtml::_('calendar', $elementValue0, $elementName.'[0]', $elementName.'_0', '%Y-%m-%d');
			$to   .= XiHtml::_('calendar', $elementValue1, $elementName.'[1]', $elementName.'_1', '%Y-%m-%d');
		}
		elseif(JString::strtolower($type)=="text"){	
			$from .= '<input id="'.$elementName.'_0" ' 
						.'name="'.$elementName.'[0]" ' 
						.'value="'.$elementValue0.'" '
						.'size="25" class="filterRangeInput " />';
			$to   .= '<input id="'.$elementName.'_1" ' 
						.'name="'.$elementName.'[1]" ' 
						.'value="'.$elementValue1.'" '
						.'size="25" class="filterRangeInput " />';
		}	  
		
		return $from.$to;
	}
	
	function app($name, $view, Array $filters = array(), $type = '', $prefix='filter_payplans')
	{
		$elementName  = $prefix.'_'.$view.'_'.$name;
		$elementValue = @array_shift($filters[$name]);
		
		$attr['none']  = true;
		$attr['style'] = 'onchange="document.adminForm.submit();"';
		
		return XiHtml::_('elements.applist', $elementName.'[]', $elementValue, $type, $attr);
	}
	
	function order($name, $view, Array $filters = array(), $prefix='filter_payplans')
	{
		$elementName  = $prefix.'_'.$view.'_'.$name;
		$elementValue = @array_shift($filters[$name]);
		
		$attr['none']  = true;
		$attr['style'] = 'onchange="document.adminForm.submit();"';
		return XiHtml::_('elements.orders', $elementName.'[]', $elementValue, $attr);
	}
	
	function apptype($name, $view, Array $filters = array(), $prefix='filter_payplans')
	{
		$elementName  = $prefix.'_'.$view.'_'.$name;
		$elementValue = @array_shift($filters[$name]);
		
		$attr['none']  = true;
		$attr['style'] = 'onchange="document.adminForm.submit();"';
		return XiHtml::_('elements.apptype', $elementName.'[]', $elementValue, $attr);
	}
	
	function loglevel($name, $view, Array $filters = array(), $prefix='filter_payplans')
	{
		$elementName  = $prefix.'_'.$view.'_'.$name;
		$elementValue = @array_shift($filters[$name]);
		
		$attr['none']  = true;
		$attr['style'] = 'onchange="document.adminForm.submit();"';
		return XiHtml::_('elements.loglevel', $elementName.'[]', $elementValue, $attr);
	}
}
