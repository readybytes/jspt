<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Elements
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class XiElement extends JElement
{
	public function hasAttrib($node, $attrib)
	{
		// for php 5.3 specific
		if(is_object($node->_attributes) && isset($node->_attributes->$attrib))
			return true;

		if(isset($node->_attributes[$attrib]))
			return true;

		return false;
	}
	
	public function getAttrib($node, $attrib, $default = false)
	{
		// for php 5.3 specific
		if(is_object($node->_attributes) && isset($node->_attributes->$attrib))
			return $node->_attributes->$attrib;

		if(isset($node->_attributes[$attrib]))
			return $node->_attributes[$attrib];

		return $default;
	}
}