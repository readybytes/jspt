<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

abstract class XiRoute extends JRoute
{
	static protected $_prefix = false;
	/*
	 * just make default value of xhtml=false
	 */
	function _($url, $xhtml = false, $ssl = null)
	{		
		$url = parent::_($url, $xhtml);
		
		if(XiFactory::getApplication()->isAdmin() == false){
			$uri = JURI::getInstance();
			// Get additional parts
			
			if ( ! self::$_prefix ) {
				self::$_prefix = $uri->toString( array('host', 'port'));
			}
			
			// if view is payment
			// https is enable
			// and is site then enable ssl
			$scheme	= 'http';
			if(JString::strpos($url, 'view=payment') !== false 
				 && XiFactory::getConfig()->https ){
				$scheme	= 'https';
			}
				
			// 	Make sure our url path begins with a slash
			if ( ! preg_match('#^/#', $url) ) {
				$url	= '/' . $url;
			}
				
			$url	= $scheme . '://' . self::$_prefix . $url;	
		}
		
		return $url;
	}
}

