<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


abstract class XiController extends XiAbstractController
{
	protected 	$_defaultTask = 'display';

	function __construct($options = array())
	{
		parent::__construct($options);

		// Setup notask as default task to prevent meaningless errors
		$this->registerDefaultTask($this->_defaultTask);
	}

	/**
	 * Just a placeholder, rather then error of function not found
	 * it will display notask provided
	 */
	function notask()
	{
		echo XiText::_('COM_PAYPLANS_NO_TASK_PROVIDED');
		return false;
	}

	function display()
	{
		return $this->_display();
	}

	public function _display()
	{
		//no decision required from controller
		return true;
	}

	public function view()
	{
		//If user can access data
		if($this->_view())
		{
			$this->setTemplate('view');
			return;
		}
		else
			$this->display();
	}

	public function _view()
	{}

	/**
	 * Checks if an item is checked out, and if so, redirects to layout for viewing item
	 * Otherwise, displays a form for editing item
	 *
	 * @return void
	 */
	public function edit()
	{
		$itemId = null;
		$userId = XiFactory::getUser()->id;

		//set editing template
		$this->setTemplate('edit');

		//if it was a new task, simply return true
		// as we cannot checkout non-existing record
		if($this->_task ==='new' || $this->_task === 'newItem')
			return true;

		//user want to edit record
		if($this->_edit($itemId, $userId)===false){
			//XITODO : enqueue message that item is already checkedout
			$this->setRedirect(null,$this->getError());
			return false;
		}

		return true;
	}

	public function _edit($itemId=null, $userId=null)
	{
		//get the model
		$model 		= $this->getModel();

		//find the user, if nothing mentioned
		if($userId	=== null)
			$userId = XiFactory::getUser()->id;

		//if Item Id is given then set to model
		if($itemId !== null)
			$this->getModel()->setState('id',$itemId);

		//Checks if item is checkedout, and if so, redirects to view
		if($model->checkout($itemId, $userId))
			return true;

		//we need to set error message
		$this->setError($model->getError());
		return false;
	}

	/**
	 * Releases an item from being checked out for editing
	 */
	public function checkin()
	{
		//try to checkin
		if($this->_checkin()===false)
			$this->setMessage($this->getError());
		else
			$this->setMessage(XiText::_('COM_PAYPLANS_CHECKED_IN_SUCCESSFULLY'));

		//setup redirection
		$model 		= $this->getModel();
		$redirect = XiRoute::_("index.php?option=com_{$this->_component}&view={$this->getName()}"
							."&task=view&id={$model->getId()}");
		$this->setRedirect($redirect);
	}

	public function _checkin($itemId=null, $userId=null)
	{
		//get the model
		$model 		= $this->getModel();

		//find the user, if nothing mentioned
		if($userId	=== null)
			$userId 	= XiFactory::getUser()->id;

		//try to checkin
		if($model->checkin($itemId, $userId) )
			return true;

		//we need to set error message
		$this->setError($model->getError());
		return false;
	}

	/**
	 * Cancels current operation and returns list layout
	 * - If item is checked out, checkin it
	 */
	public function close()
	{
        //try to checkin
		if($this->_close()===false)
			$this->setMessage($this->getError());

		//setup redirection
		$this->setRedirect();
		//as we need redirection
		return false;
	}

	public function _close($itemId=null, $userId=null)
	{
		//get the model
		$model 		= $this->getModel();

		//Reset state b'coz we need to list all records
		//Itemid need to be collected for proper check-in

		$oldItemId = $this->getModel()->setState('id',null);
		//Do it : only if itemid was not given
		if($itemId===null)
			$itemId = $oldItemId;

		//try to checkin the open record
		if($this->_checkin($itemId, $userId)===true)
			return true;

		//some issue while checkin
		$this->setError($model->getError());
		return false;
	}

	public function save()
	{
		//XITODO : verify form token
		//try to save
		$post	=	JRequest::get('post');
		//Currently not required
		//$post   = $this->_filterPost($post);

		$msgType	=	'message';
		$itemId 	= $this->_getId();

		if($this->_save($post, $itemId)===false){
			$this->setMessage($this->getError());
			$msgType	=	'error';
		}
		else
			$this->setMessage(XiText::_('COM_PAYPLANS_ITEM_SAVED_SUCCESSFULLY'));

		//perform redirection
		$redirect  = "index.php?option=com_{$this->_component}&view={$this->getName()}";

		if(JRequest::getVar('task')==='apply'){
			$table		=	$this->getModel()->getTable();
			$keyName	=	$table->getKeyName();
			$redirect  .= "&task=edit&id={$table->$keyName}";
		}

	   if(JRequest::getVar('task')==='savenew'){
			$redirect  .= "&task=new";
		}
		
		$redirect = XiRoute::_($redirect);
		$this->setRedirect( $redirect , $this->_message , $msgType);
		return false;
	}

//	/**
//	 * This function filters variable for forms
//	 */
//	public function _filterPost($post)
//	{
//		$returnData = array();
//		//we need to remove the prefix
//		foreach($post as $key=>$data){
//			$r = null;
//			if (!preg_match('/'.XI_FORM_VARIABLE_PREFIX.'(.*)/i', $key, $r))
//				continue;
//
//			// xi_order_0 -> data[order][0]
//			$index = $r[1];
//			$pos=strrpos($index,'_');
//
//			$count = substr($index,$pos+1);
//			$index = substr($index,0, $pos);
//			$returnData[$index][$count] = $data;
//		}
//		return $returnData;
//	}
	/**
	 * Saves an item (new or old)
	 */
	public function _save(array $data, $itemId=null, $type=null)
	{
		//create new lib instance
		return XiLib::getInstance($this->getName(), $itemId, $type)
						->bind($data)
						->save();
	}

	/**
	 * Deletes record(s) and redirects to default layout
	 */
	function remove()
	{
		$errMsg				= '';
		$messagetype 	= 'message';
		$message 		= XiText::_('COM_PAYPLANS_ITEMS_DELETED');


		//ensure model state is blank, so no mishappening :-)
		$this->getModel()->setState('id',null);

		$cids = JRequest::getVar('cid', array (0), 'request', 'array');
		foreach (@$cids as $cid)
		{
			if($this->_remove($cid)===false)
				$errMsg .= $this->getError();
		}

		if(empty($errMsg)===false){
			$message	=	$errMsg;
			$messagetype	=	'error';
		}

		$this->setRedirect(null,$message,$messagetype);
		return false;
	}

	function _remove($itemId=null, $userId=null)
	{
		//get the model
		$model 		= $this->getModel();

		//find the user, if nothing mentioned
		if($userId	== null)
			$userId 	= XiFactory::getUser()->id;

		$item = XiLib::getInstance($this->getName(), $itemId, $type=null)
				->delete();

		if(!$item){
			//we need to set error message
			$this->setError($model->getError());
			return false;
		}
		return true;
	}

	/**
	 * Copy record(s)
	 */
	public function copy($cids = array())
	{
		$errMsg				= '';
		$messagetype 	= 'message';
		$message 		= XiText::_('COM_PAYPLANS_ITEMS_COPIED');
		
		$cids = JRequest::getVar('cid', $cids, 'request', 'array');
		foreach ($cids as $cid)
		{
			if($this->_copy($cid)===false)
				$errMsg .= $this->getError();
		}
		
		if(empty($errMsg)===false){
			$message		=	$errMsg;
			$messagetype	=	'error';
		}

		$this->setRedirect(null,$message,$messagetype);
		return false;
	}
	
	/**
	 * Works on table instance
	 */
	public function _copy($instance)
	{	
		$instance->setId(0);
		$instance->set('title', XiText::_("copy of ").$instance->getTitle());
		return $instance->save();
	}
	
	/**
	 * Reorders a single item either up or down (based on arrow-click in list)
	 * and redirects to default layout
	 * @return void
	 */
	function order()
	{
		$task	= JRequest::getVar('task', 'orderdown', 'post');
		$change = ($task === 'orderup') ? -1 : 1;

		$cids 	= JRequest::getVar('cid', array (0), 'post', 'array');

		//try to order
		if($this->_order($change, $cids[0])===false)
			$this->setMessage($this->getError());
		else
			$this->setMessage(XiText::_('COM_PAYPLANS_ITEM_ORDERED_SUCCESSFULLY'));

		//perform redirection
		$this->setRedirect();
		return false;
	}

	/**
	 * Reorders multiple items (based on form input from list)
	 * and redirects to default layout
	 * @return void
	 */
	function multiorder()
	{
		$errMsg				= '';
		$this->messagetype 	= 'notice';
		$this->message 		= XiText::_('COM_PAYPLANS_ITEMS_REORDERED');

		//XITODO : User proper variable names
		$ordering 	= JRequest::getVar('ordering', array(0), 'post', 'array');
		$cids 		= JRequest::getVar('cid', array (0), 'post', 'array');

		foreach ($cids as $cid)
		{
			if($this->_order($ordering[$cid], $cid)===false)
				$errMsg .= $this->getError();
		}

		//if we have error messages
		if(empty($errMsg)===false)
		{
			$this->message = $this->errMsg;
			$this->messagetype = 'error';
		}

		//IMP : reorder items to fill in the blanks
		$model->reorder();

		//redirect now
		$this->setRedirect();
		return false;
	}

	/*
	 * @return bool
	 */
	public function _order($change, $itemId=null)
	{
		//get the model
		$model 		= $this->getModel();

		//try to move
		if($model->order($itemId, $change) )
			return true;

		//we need to set error message
		$this->setError($model->getError());
		return false;
	}

	/*
	 * Implement enable/multienable methods
	 */
	public function dobool()
	{
		$task	= JRequest::getVar('task',	'enable');

		//setup error message, if no mapping exists
		if(array_key_exists($task, $this->_boolMap)===false)
		{
			$this->setRedirect(null, XiText::_('COM_PAYPLANS_NO_MAPPING_FOUND_FOR_CURRENT_ACTION'), 'error');
			return;
		}


		//find and trigger the call
		$mapping	= $this->_boolMap[$task];
		$switch		= $mapping['switch'];
		$column		= $mapping['column'];
		$value		= $mapping['value'];

		if($this->_doBool($column, $value, $switch)===false)
			$this->setMessage($this->getError());

		//redirect now
		$this->setRedirect();
		return false;
	}

	public function multidobool()
	{
		$errMsg				= '';
		$this->messagetype 	= 'notice';
		$this->message 		= XiText::_('COM_PAYPLANS_ITEMS_REORDERED');

		$task	= JRequest::getVar('task',	'enable');

		//setup error message, if no mapping exists
		if(array_key_exists($task, $this->_boolMap)===false)
		{
			$offpattern = '/^switchOff/';
			$onpattern = '/^switchOn/';
			if(!preg_match($onpattern, $task) && !preg_match($offpattern, $task)){
				$this->setRedirect(null, XiText::_('COM_PAYPLANS_NO_MAPPING_FOUND_FOR_CURRENT_ACTION'), 'error');
				return;
			}
			else{
				if(preg_match($onpattern, $task)){
					$switch		= false;
					//$columninfo = str_split($task,strlen('switchOn'));
					$columninfo = explode('switchOn',$task);
					$column		= array_key_exists(1,$columninfo) ? $columninfo[1] : '';
					$value		= 1;
				}
				else if(preg_match($offpattern, $task)){
					$switch		= false;
					//XITODO : Convert it to str_replace, so that code can be somewaht clean from magic numbers
					//$columninfo = str_split($task,strlen('switchOff'));
					$columninfo = explode('switchOff',$task);
					$column		= array_key_exists(1,$columninfo) ? $columninfo[1] : '';
					$value		= 0;
				}
			}

		}
		else{
			$mapping	= $this->_boolMap[$task];
			$switch		= $mapping['switch'];
			$column		= $mapping['column'];
			$value		= $mapping['value'];
		}

		$cids 	= JRequest::getVar('cid', array (0), 'post', 'array');

		foreach ($cids as $cid)
		{
			if($this->_doBool($column, $value, $switch, $cid)===false)
				$errMsg .= $this->getError();
		}

		//if we have error messages
		if(empty($errMsg)===false)
		{
			$this->message = $this->errMsg;
			$this->messagetype = 'error';
		}

		//redirect now
		$this->setRedirect();
		return false;
	}

	/**
	 * This function will modify the table boolean data
	 * @param $task = the related task : published
	 * @param $change = the value to change to, 1/0
	 * @param $switch = do we need to switch the value if field, default is false
	 * @param $itemId = The item to modify, if null, will be calculated from session
	 * @return bool
	 */
	public function _doBool($column, $change, $switch=false, $itemId=null)
	{
		//get the model
		$model 		= $this->getModel();

		//try to switch
		if($model->boolean($itemId, $column, $change, $switch)===true)
			return true;

		//we need to set error message
		$this->setError($model->getError());
		return false;
	}


	public function trigger($event=null,$args=null)
	{
		$event 		= JRequest::getVar('event', $event);
		XiError::assert($event,XiText::_('COM_PAYPLANS_ERROR_PAYPLANS_UNKNOWN_EVENT_TRIGGER_REQUESTED'));

		$args 	= JRequest::getVar('arg1',$args);

		//if it is an ajax request, decode the args
		if(JRequest::getBool('isAjax',	false)){
			$args	= json_decode($args);
		}

		//args must be an array
		return XiHelperPlugin::trigger($event, $args);
	}
}