<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

jimport( 'joomla.application.component.view' );

abstract class XiAbstractView extends JView
{
	/* Will be set by controller*/
	protected $_model 			= null;
	public    $_component		= XI_COMPONENT_NAME;
	protected $_tpl 			= null;
	public 	  $options 			= array('domObject'=>'xiWindowContent','domProperty'=>'innerHTML');

	function __construct($config = array())
	{
		//XITODO : we can add here multiple templates, so from global params
		// we will define the directory here
		$template	= 'default';

		// override the template path, so that default
		// templates will be picked from here
		$prefix	=	$this->getPrefix();
		
		//absolute prefix and payplans are equals		
		if($prefix == $this->_component.'admin')
			$templateBase = constant(JString::strtoupper($this->_component).'_PATH_TEMPLATE_ADMIN');
		else
			$templateBase = constant(JString::strtoupper($this->_component).'_PATH_TEMPLATE');

		if( JString::stristr($prefix,'admin'))
			$payplanstemplateBase = PAYPLANS_PATH_TEMPLATE_ADMIN;
		else
			$payplanstemplateBase = PAYPLANS_PATH_TEMPLATE;

		if(!isset($config['template_path']))
			$config['template_path']	=	array();

		//Always add base template path first and actual view path second
		//base _addPath function will automatically
		//give preference to last given path

		//VERY IMP : These order should be maintained
		$path1 = $templateBase.DS.JString::strtolower($template).DS.JString::strtolower($this->getName());
		array_unshift($config['template_path'],$path1);

		$path2	=	$templateBase.DS.JString::strtolower($template);
		array_unshift($config['template_path'],$path2);

//		$payplansdefaultpath1 = $payplanstemplateBase.DS.JString::strtolower($template).DS.JString::strtolower($this->getName());
//		array_unshift($config['template_path'],$payplansdefaultpath1);

		$payplansdefaultpath2	=	$payplanstemplateBase.DS.JString::strtolower($template);
		array_unshift($config['template_path'],$payplansdefaultpath2);
		
		// setup rendering system
		$this->_renderer = XiRender::getRenderer();

		parent::__construct($config);
	}

	/*
	 * We want to make error handling to common objects
	 * So we override the functions and direct them to work
	 * on a global error object
	 */
	public function getError($i = null, $toString = true )
	{
		$errObj	=	XiFactory::getErrorObject();
		return $errObj->getError($i, $toString);
	}

	public function setError($errMsg)
	{
		$errObj	=	XiFactory::getErrorObject();
		return $errObj->setError($errMsg);
	}

	/*
	 * We need to override joomla behaviour as they differ in
	 * Model and Controller Naming
	 * In Joomla -> JModelProducts, JProductsController
	 * In PayPlans	 -> PayplansModelProducts, PayplansControllerProducts
	 */
	function getName()
	{
		$name = $this->_name;

		if (empty( $name ))
		{
			$r = null;
			if (!preg_match('/View(.*)/i', get_class($this), $r)) {
				JError::raiseError (500, "XiView::getName() : Can't get or parse class name.");
			}
			$name = strtolower( $r[1] );
		}

		return $name;
	}

	/*
	 * Collect prefix auto-magically
	 */
	public function getPrefix()
	{
		if(isset($this->_prefix) && empty($this->_prefix)===false)
			return $this->_prefix;

		$r = null;
		XiError::assert(preg_match('/(.*)View/i', get_class($this), $r), XiText::sprintf('COM_PAYPLANS_ERROR_XIVIEW_GETPREFIX_CANT_GET_OR_PARSE_CLASSNAME', get_class($this)), XiError::ERROR);


		$this->_prefix  =  JString::strtolower($r[1]);
		return $this->_prefix;
	}

	function getModel()
	{
		return $this->_model;
	}

	function setModel($model)
	{
		 $this->_model = $model;
		 return $this;
	}

	function setTpl($tpl=null)
	{
		 $this->_tpl = $tpl;
		 return $this;
	}

	function getTpl($tpl=null)
	{
		 return $this->_tpl;
	}
	/*
	 * This function will be called from Controller
	 * after doTask, so it will be called after
	 * controller task have been completed
	 *
	 * So that there is one point contact for
	 * handling anything in view
	 */
	function showTask($task='',$tpl=null)
	{
 		//generate the data in view for template
		if(empty($task) || $task=='default')
			$task='display';

		//set are you in admin or site
		$app = XiFactory::getApplication();
		$this->_isAdmin    = $app->isAdmin();
		$this->_task	   = $task;
		$this->setTpl($tpl);

		// collect task specific data,
		// if some error, do not display the page and simply return
		// XITODO : controller will handle the error
		if(false === $this->$task())
			return false;

		//set the model state in view variable
		$this->_basicFormSetup();

		// Trigger behaviours before we load templates
		$args	= array(&$this, &$task);
		$pluginResult = PayplansHelperEvent::trigger('onPayplansViewBeforeRender',$args);
		$this->assign('plugin_result',$pluginResult);

		//load the template file
		$output = $this->loadTemplate($this->getTpl());
		if (XiError::isError($output)) {
			return $output;
		}

		//post template rendering load trigger
		$args	= array(&$this, &$task, &$output);
		$result =  PayplansHelperEvent::trigger('onPayplansViewAfterRender', $args, '', $this);

		//render output
		return $this->_render($output);
	}

	//Calls actual rendered object, to render output
	protected function _render($output)
	{
		// club data and send to renderer
		$data ['header'] = $this->_showHeader();
		$data ['output'] = $output;
		$data ['footer'] = $this->_showFooter();

		return $this->_renderer->render($this, $data, $this->options);
	}
	
	protected function _showHeader()
	{
		// add admin toolbar
		if($this->_isAdmin){
			$this->_adminToolbar();
			//$this->_adminSubmenu();
		}

		return '';
	}

	protected function _showFooter()
	{
		if((defined('PAYPLANS_PREMIUM_BUILD') && PAYPLANS_PREMIUM_BUILD)
			|| PAYPLANS_AJAX_REQUEST == true){
			return '';
		}
		
		ob_start();
		?>
		<div class="clr"></div>
		<div style="clear:both; text-align:center;" >Powered By <a id="payplansPowerdBy" href="http://www.jpayplans.com" target="_blank" >PayPlans</a>.</div>
		<?php 
		
		$contents = ob_get_contents();
		ob_end_clean();
		return $contents;
	}

	protected function _adminToolbar()
	{
		$this->_adminToolbarTitle();

		if($this->_task == 'edit' || $this->_task == 'new')
			$this->_adminEditToolbar();
		else
			$this->_adminGridToolbar();
	}

	protected function _adminToolbarTitle()
	{
		// Set the titlebar text
		XiHelperToolbar::title(XiText::_('COM_PAYPLANS_SM_'.JString::strtoupper($this->getName())), "xi-".$this->getName().".png");
	}

	protected function _adminGridToolbar()
	{
		XiHelperToolbar::publish();
		XiHelperToolbar::unpublish();
		XiHelperToolbar::divider();
		XiHelperToolbar::customX( 'copy', 'copy.png', 'copy_f2.png', 'Copy', true );
		XiHelperToolbar::deleteList();
		XiHelperToolbar::divider();
		XiHelperToolbar::editListX();
		XiHelperToolbar::addNewX('new');
	}

	protected function _adminEditToolbar()
	{
		XiHelperToolbar::save();
		XiHelperToolbar::savenew();
		XiHelperToolbar::apply();
		XiHelperToolbar::cancel();
	}


	function _adminSubmenu($selMenu = 'dashboard')
	{
		$selMenu	= JString::strtolower(JRequest::getVar('view',$selMenu));
		$menus 		= array('dashboard', 'config', 'plan', 'subscription',
								'order','payment','app','user', 'log'); 
		foreach($menus as $menu){
			XiHelperToolbar::addSubMenu($menu,$selMenu);
		}
		return $this;
	}


	protected function _basicFormSetup()
	{
		//setup the action URL
		$url 	= 'index.php?option=com_payplans&view='.$this->getName();
		$task	= JRequest::getVar('task');
		if($task){
			$url .= '&task='.$task;
		}
		
		$this->assign('uri', XiRoute::_($url));

		//setup state
		$this->assign( 'state', $this->getModel()->getState());

		//setup record id, if any
		$this->assign( 'record_id', $this->getModel()->getId());

		//also pass model if required
		$this->assign( 'model', $this->getModel());
	}
	
	public function get($tpl=null)
	{
		// for templates data is assigned to tplVars
		if(isset($this->_tplVars[$tpl])){
			return $this->_tplVars[$tpl];
		}
		
		return parent::get($tpl);
	}
	
	public function assign($key, $value)
	{
		$this->_tplVars[$key] = $value;
	}
	
	function loadTemplate( $tpl = null)
	{
		global $mainframe, $option;

		// clear prior output
		$this->_output = null;

		//create the template file name based on the layout
		$file = isset($tpl) ? $this->_layout.'_'.$tpl : $this->_layout;
		// clean the file name
		$file = preg_replace('/[^A-Z0-9_\.-]/i', '', $file);
		$tpl  = preg_replace('/[^A-Z0-9_\.-]/i', '', $tpl);

		// load the template script
		jimport('joomla.filesystem.path');
		$filetofind	= $this->_createFileName('template', array('name' => $file));
		$this->_template = JPath::find($this->_path['template'], $filetofind);

		if ($this->_template != false)
		{
			// unset so as not to introduce into template scope
			unset($tpl);
			unset($file);

			// never allow a 'this' property
			if (isset($this->this)) {
				unset($this->this);
			}

			// Support tmpl vars
	        // Extracting variables here
	        unset($this->_tplVars['this']);
	        unset($this->_tplVars['_tplVars']);
	        extract((array)$this->_tplVars,  EXTR_OVERWRITE);
			
			// start capturing output into a buffer
			ob_start();
			// include the requested template filename in the local scope
			// (this will execute the view logic).
			include $this->_template;

			// done with the requested template; get the buffer and
			// clear it.
			$this->_output = ob_get_contents();
			ob_end_clean();

			return $this->_output;
		}
		else {
			return JError::raiseError( 500, 'Layout "' . $file . '" not found' );
		}
	}
}