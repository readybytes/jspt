<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class XiFactory extends JFactory
{
// Uncomment when needed
//removed extending from factory for J1.6 compatibility
//	
/* Wrappers for Function of Joomla Factory */ 
//	static function getDBO()
//	{
//		return JFactory::getDBO();
//	}
//	
//	static function getUser($userid=null)
//	{
//		return JFactory::getUser($userid);
//	}
//	
//	static function getApplication($id = null, $config = array(), $prefix='J')
//	{
//		return JFactory::getApplication($id, $config, $prefix);
//	}
//	
//	static function getEditor($editor = null)
//	{
//		return JFactory::getEditor($editor);
//	}
//	
//	static function getMailer($editor = null)
//	{
//		return JFactory::getEditor($editor);
//	}
//	
//	static function getDocument()
//	{
//		return JFactory::getDocument();
//	}
//	
//	static function getXMLParser()
//	{
//		return JFactory::getXMLParser();
//	}
//	
//	/*Wrapper Complete*/
	
	
	//Returns a MVCT object
	static function getInstance($name, $type='', $prefix='Payplans', $refresh=false)
	{
		static $instance=array();

		//generate class name
		$className	= JString::ucfirst($prefix)
					. JString::ucfirst($type)
					. JString::ucfirst($name);

		// Clean the name
		$className	= preg_replace( '/[^A-Z0-9_]/i', '', $className );

		//if already there is an object
		if(isset($instance[$className]) && !$refresh)
			return $instance[$className];

		//class_exists function checks if class exist,
		// and also try auto-load class if it can
		if(class_exists($className, true)===false)
		{
			self::getErrorObject()->setError("Class $className not found");
			return false;
		}

		//create new object, class must be autoloaded
		$instance[$className]= new $className();

		return $instance[$className];
	}

	/**
	 * @return JObject
	 */
	function getErrorObject($reset=false)
	{
		static $instance=null;

		if($instance !== null && $reset===false)
			return $instance;

		$instance	= new JObject();

		return $instance;
	}

	/**
	 * @return session object
	 */
	function getSession($reset=false)
	{
		static $instance=null;

		if($instance !== null && $reset===false)
			return $instance;

		$instance	= new XiSession();

		return $instance;
	}

	/**
	 * @return XiAjaxResponse
	 */
	static public function getAjaxResponse()
  	{
  		//We want to send our DB object instead of Joomla Object
  		//so that we can check our sql performance on the fly.
 		static $response = null;

 		if ($response === null)
 			$response = XiAjaxResponse::getInstance();

  		return $response;
  	}
  	/**
	 * get all configuration parameter available
	 * @return stdClass object of configuration params
	 */
  	public function getConfig()
  	{
		//XITODO : Implement reset logic for whole component
  		static $config = null;

  		if($config && self::cleanStaticCache() != true)
  			return $config;

  		$records 	= self::getInstance('config', 'model')->loadRecords();

		// load parent global joomla configuration first
		$arr = JFactory::getConfig()->toArray();

		// load all configurations of Xi, and merge them
		foreach($records as $record){
			//IMP : by sending record we can reduce one query on each loop iteration
			$obj = PayplansConfig::getInstance($record->config_id, null, $record);
			$arr = array_merge($arr, $obj->getConfig()->toArray());
		}

		// Let plugin modify config
		$args = array(&$arr);
		PayplansHelperEvent::trigger('onPayplansConfigLoad', $args);

		// convert array of config to object
		return $config = (object)$arr;
  	}

	static function cleanStaticCache($set = null)
	{
		static $reset = false;

		if($set !== null)
			$reset = $set;

		return $reset;
	}

	/**
	 * @return XiRewriter
	 */
	public static function getRewriter($reset=false)
	{
		static $instance=null;

		if($instance !== null && $reset===false)
			return $instance;

		$instance	= new XiRewriter();

		return $instance;
	}
	
	/**
	 * @return XiEncryptor
	 */
	public static function getEncryptor($reset=false)
	{
		static $instance=null;

		if($instance !== null && $reset===false)
			return $instance;

		// XITODO : raise error if key is not defined
		$key = XiFactory::getConfig()->expert_encryption_key;
		$instance	= new XiEncryptor($key);

		return $instance;
	}
	
	/**
	 * @return XiLogger
	 */
	static protected $_logger = array();
	public static function getLogger($name='')
	{
		$className = 'XiLogger'.JString::ucfirst($name);
		if(isset(self::$_logger[$className])===false){
			self::$_logger[$className] = new $className();
		}
		
		return self::$_logger[$className];
	}
}
