<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class XiHelperPlugin extends JPluginHelper
{
	/**
	 *
	 * @param unknown_type $eventName
	 * @param array $data
	 * @return array
	 */

	static function trigger($eventName,array &$data =array(), $prefix='')
	{
		static $dispatcher = null;

		//load dispatcher if required
		if($dispatcher===null){
			$dispatcher = JDispatcher::getInstance();
		}

		//load payplans plugins
		self::loadPlugins();
		//$eventName = $prefix.JString::ucfirst($eventName);
		return $dispatcher->trigger($eventName, $data);
	}

	/**
	 * Loads plugin of given type
	 * @param $type
	 */
	static function loadPlugins($type='payplans')
	{
		static $loaded = array();

		//is already loaded
		if(isset($loaded[$type]))
			return true;

		//import plugins
		self::importPlugin($type);

		//set that plugins are already loaded
		$loaded[$type]= true;
		return true;
	}

	const ENABLE  = 1;
	const DISABLE = 0;
	public static function changeState($element, $folder = 'system', $state=self::ENABLE)
	{
		$db		=& JFactory::getDBO();
		$query	= 'UPDATE ' . $db->nameQuote('#__plugins' )
				. ' SET '   . $db->nameQuote('published').'='.$db->Quote($state)
		        . ' WHERE ' . $db->nameQuote('element').'='.$db->Quote($element)
		        . ' AND ' . $db->nameQuote('folder').'='.$db->Quote($folder)
		        ;
		$db->setQuery($query);
		return $db->query();
	}

	public static function getStatus($element, $folder = 'system')
	{
		$db		=& JFactory::getDBO();
		$query	= 'SELECT  ' . $db->nameQuote('published')
				. ' FROM   '.$db->nameQuote('#__plugins' )
		        . ' WHERE ' . $db->nameQuote('element').'='.$db->Quote($element)
		        . ' AND ' . $db->nameQuote('folder').'='.$db->Quote($folder)
		        ;
		$db->setQuery($query);
		return $db->loadResult();
	}
	
	public function getPluginInstance($type, $name)
	{
		
		$observers = JDispatcher::getInstance()->get('_observers');
				
		foreach ($observers as $observer){
			if (is_array($observer) && isset($observer['_type']) && $observer['_type'] == $type && $observer['_name'] == $name){
					return $observer;
			}
			elseif (is_object($observer) && isset($observer->_type) && $observer->_type == $type && $observer->_name == $name){
					return $observer;
			}
		}

		return null;	
	}
	
	public static function getPath($plugin)
	{
		$path  = JPATH_PLUGINS;
		$path .= DS.$plugin->get('_type').DS.$plugin->get('_name');
		return $path;
	}
}
