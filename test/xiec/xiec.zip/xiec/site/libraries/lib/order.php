<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansOrder extends XiLib
	implements PayplansIfaceApptriggerable, PayplansIfaceApiOrder, PayplansIfaceMaskable
{
	// Table fields
	protected $order_id;
	protected $buyer_id;
	protected $subtotal;
	protected $discount;
	protected $total;
	protected $currency;
	protected $status;
	protected $created_date;

	//secondary information
	protected $_subscriptions	= array();
	protected $_payments		= array();

	// Not used
	protected $shipping = 0.0000;
	protected $tax 	 	= 0.0000;
	protected $shipping_address = null;
	protected $billing_address	= null;


	/**
	 * @return PayplansOrder
	 */
	static public function getInstance($id=0, $type=null, $bindData=null)
	{
		return parent::getInstance('order',$id, $type, $bindData);
	}

	// 	not for table fields
	public function reset($config=array())
	{
		$this->order_id	= 0;
		$this->buyer_id	= 0;
		$this->subtotal	= 0.0000;
		$this->discount	= 0.0000;
		$this->total	= 0.0000;

		// Load default currency from configuration
		$this->currency 	= XiFactory::getConfig()->currency;
		$this->status		= XiStatus::NONE;

		//XITODO : Is it ok to store current timestamp ?
		$this->created_date = new XiDate();

		//clean all subscriptions stored
		$this->_subscriptions	= array();
		$this->_payments= array();
		return $this;
	}

	public function _loadSubscriptions($order_id)
	{
		// get all subscription records of this order
		$subRecords = XiFactory::getInstance('subscription','model')
								->loadRecords(array('order_id'=>$order_id));

		$this->_subscriptions   = array();
		$this->total 	= 0.0000;
		$this->subtotal = 0.0000;
		$this->discount = 0.0000;

		foreach($subRecords as $record){
			$subscription = PayplansSubscription::getInstance( $record->subscription_id, null, $record);
			$this->addSubscription($subscription);
		}

		return $this;
	}

	public function _loadPayments($order_id)
	{
		// get all subscription records of this order
		$records = XiFactory::getInstance('payment','model')
								->loadRecords(array('order_id'=>$order_id), array('limit'));

		$this->_payments	= array();

		foreach($records as $record){
			$this->addPayment(PayplansPayment::getInstance( $record->payment_id, null, $record));
		}

		return $this;
	}

	public function afterBind($id = 0)
	{
		if(!$id) return $this;

		//load dependent records
		return $this->_loadSubscriptions($id)->_loadPayments($id);
	}

	/**
	 * It will add subscription to the order.
	 * Item is orderable, so it will have all kind of function to get
	 * additional data
	 * @param Orderable $subscription
	 */
	public function addSubscription(PayplansIfaceOrderable $subscription)
	{
		// save it on _subscriptions list
		$this->_subscriptions[$subscription->getId()]=$subscription;

		//XITODO : subscription getTotal should work correctly
		// now update self record
//		$this->total 	+= $subscription->getTotal();
		$this->subtotal += $subscription->getPrice();
		$this->discount += $subscription->getDiscount();

		$this->total 	= $this->subtotal - $this->discount;
		return $this;
	}

	//Payment records of orders
	public function addPayment(PayplansPayment $item)
	{
		// save it on payment list
		$this->_payments[$item->getId()]=$item;
		return $this;
	}

	public function createPayment($appId)
	{
		// find a previous record with same orderId but status=0
		//	if any exist, return that
		//  else, return a new record
		$filter = array('status' => 0, 'order_id'=>$this->getId());

		//IMP : save is must to ensure new record get a ID
		$payment = PayplansPayment::getInstance()->loadIf($filter)
						->set('order_id',$this->getId())
						->set('app_id',$appId)
						->set('amount',$this->getTotal())
						->save();

		//also add into payment list of order
		$this->addPayment($payment);
		return $payment;
	}


	public function setBuyer($userId=0)
	{
		$this->buyer_id = $userId;

		// update all subscriptions
		foreach($this->_subscriptions as $subscription){
			$subscription->setBuyer($userId);
		}

		return $this;
	}

	public function getBuyer($instance=false)
	{
		if($instance == PAYPLANS_INSTANCE_REQUIRE){
			return PayplansUser::getInstance($this->buyer_id);
		}

		return $this->buyer_id;
	}

	public function refresh()
	{
		// get all subscription records of this order
		$this->_loadSubscriptions($this->getId());
		$this->_loadPayments($this->getId());

		// save update order
		return $this->save();
	}

	public function getStatus()
	{
		return $this->status;
	}

	public function setStatus($status)
	{
		$this->status = $status;
		return $this;
	}

	public function confirm($appId)
	{
		//create a new payment for this order_id
		$this->_payments = $this->createPayment($appId);

		$this->set('status', Xistatus::ORDER_CONFIRMED)
			 ->save();

		return $this;
	}

	public function getPayment()
	{
		return $this->_payments;
	}

	public function setTotal($total)
	{
		$this->total = $total;
		return $this;
	}

	public function setSubtotal($subtotal)
	{
		$this->subtotal = $subtotal;
		return $this;
	}
	
	public function getTotal()
	{
		return PayplansHelperFormat::price($this->total);
	}

	public function getSubtotal()
	{
		return PayplansHelperFormat::price($this->subtotal);
	}

	public function complete()
	{
		return $this->set('status', XiStatus::ORDER_COMPLETE)
			 		->save();
	}

	public function getDiscount()
	{
		return PayplansHelperFormat::price($this->discount);
	}

	public function getTax()
	{
		return PayplansHelperFormat::price($this->tax);
	}

	public function getShipping()
	{
		return PayplansHelperFormat::price($this->shipping);
	}

 	/**
 	 * Implementing interface Apptriggerable
 	 * @return array
 	 */
 	public function getPlans($requireInstance = false)
 	{
 		$ret = array();
 		//get all subscription's plans
 		foreach($this->_subscriptions as $subscription){
 			$ret = array_merge($ret, $subscription->getPlans($requireInstance));
 		}

 		return $ret;
 	}

 	/**
 	 * @return PayplansSubscription Array
 	 */
 	public function getSubscriptions()
 	{
 		return $this->_subscriptions;
 	}

	/**
 	 * @return PayplansPayment Array
 	 */
 	public function getPayments()
 	{
 		return $this->_payments;
 	}
 	
	public function getStatusName($version='')
	{
		return XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($this->status).$version);
	}
	
	public function getCurrency()
	{
		return $this->currency;
	}
	
	public function getCreatedDate()
	{
		return $this->created_date;
	}
	
	public function isRecurring()
	{
		return false;
	}
}

