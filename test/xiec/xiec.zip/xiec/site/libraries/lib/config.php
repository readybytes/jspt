<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * Base class for all payplans-apps who have multiple instances
 * @author Meenal Devpura
 *
 */
class PayplansConfig extends XiLib
{
	protected	$config_id	 = 0 ;
	protected	$title		 = '';
	protected	$key		 = '';
	protected	$componentname   = XI_COMPONENT_NAME;
	protected	$path		 = '';

	/**
	 * @var XiParameter
	 */
	protected $config	= 	null;

	/**
	 * @return PayplansConfig
	 */
	static public function getInstance($id=0, $type=null, $bindData=null)
	{
		return parent::getInstance('config',$id, $type, $bindData);
	}
	
	public function bind($data, $ignore=array())
	{
		if(is_object($data)){
			$data = (array) ($data);
		}

		// Only load when its not already set
		if($this->config === null){
			$xmlPath = JPATH_ROOT .DS. $data['path'];
			XiError::assert(isset($xmlPath), "$xmlPath NOT SET");
			$this->config = PayplansHelperParam::getParamObject($xmlPath);
		}

		return parent::bind($data, $ignore);
	}

	// Reset to construction time.
	public function reset($config=array())
	{
		$this->config_id	 = 0 ;
		$this->title		 = '';
		$this->key		 	 = '';
		$this->config		 = null;
		$this->componentname = XI_COMPONENT_NAME;
		$this->path	 	 	 = '';

		return $this;
	}
	
	public function getTitle()
	{
		return $this->title;
	}
	
	public function getKey()
	{
		return $this->key;
	}
	
	public function getPath()
	{
		return $this->path;
	}
	
	public function getConfig()
	{
		return $this->config;
	}
	
	public function getComponentname()
	{
		return $this->componentname;
	}
	
	public function renderToArray($key= null)
	{
		return $this->config->renderToArray($key);
	}
}