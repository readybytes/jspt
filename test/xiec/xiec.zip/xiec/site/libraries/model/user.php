<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * Class assumes that user should always be synched-up with
 * joomla core user system
 * This will not support those user who are not listed in payplans_user table
 * IMP : Will maintain synchup during installation and while visiting users in backend 
 * @author meenal
 *
 */
class PayplansModelUser extends XiModel
{
	/**
     * Builds FROM tables list for the query
     */
    protected function _buildQueryFrom(XiQuery &$query)
    {
    	$db			=	XiFactory::getDBO();
    	$table		=	$this->getTable();
    	$tname		=	$table->getTableName();
    	$query->from('( SELECT 
			    				joomlausertbl.`id` AS user_id, 
			    				joomlausertbl.`name` AS realname,
			    				joomlausertbl.`username` AS username,
			    				joomlausertbl.`email` AS email,
			    				joomlausertbl.`usertype` AS usertype,
			    				joomlausertbl.`registerDate` AS registerDate,			    				
			    				joomlausertbl.`lastvisitDate` AS lastvisitDate,			    				
			    				t.`params`			    				
						  FROM 
						  		`#__users` AS joomlausertbl
						  LEFT JOIN 
						  		`#__payplans_user` AS t 
						  		ON ( t.`user_id` = joomlausertbl.`id` )
					  )	AS tbl'
					);
    }
}

