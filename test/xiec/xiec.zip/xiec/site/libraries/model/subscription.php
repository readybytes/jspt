<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansModelSubscription extends XiModel
{
	// XITODO : HIGH : Apply validation when it is applied all over
	function validate(&$data, $pk=null,array $filter = array(),array $ignore = array())
	{
		return true;
	}

	/**
	 * find all active subscription
	 * which are expected to expire on given time
	 */
	public function getActiveSubscriptions(XiDate $time=null)
	{
		$query = $this->getQuery();

		//there might be no table and no query at all
		if($query === null )
			return array(null);

		if($time === null){
		 	$time = new XiDate();
		}

		$tmpQuery = unserialize(serialize($query));
		$tmpQuery->clear('where')
				 ->where("`tbl`.`expiration_date` < '".$time->toMySQL()."'")
				 ->where('`tbl`.`status` = '.XiStatus::SUBSCRIPTION_ACTIVE);

		return $tmpQuery->dbLoadQuery()->loadObjectList($this->getTable()->getKeyName());
	}
	
	public function buildFilterMatch()
	{
		$this->filterMatchOpeartor['plan_id'] 			= array('=');
		$this->filterMatchOpeartor['status'] 			= array('=');
		$this->filterMatchOpeartor['subscription_date'] = array('>=', '<=');
		$this->filterMatchOpeartor['expiration_date'] = array('>=', '<=');
	}
}