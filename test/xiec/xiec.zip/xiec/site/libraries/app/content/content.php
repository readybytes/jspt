<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage	Discount
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


/**
 * Content App
 * @author shyam
 */
class PayplansAppContent extends PayplansApp
{
	//inherited properties
	protected $_location	= __FILE__;
	
	/* some constants */
    const PREFIX  = 'prefix';
    const SUFFIX  = 'suffix';
    const REPLACE = 'replace';
    
	/**
	 * overirde isApplicable 
	 * @param $refObject must be an instance of XiView
	 */
	public function isApplicable($refObject = null, $eventName='')
	{
		// not applicable in admin panel
		if(XiFactory::getApplication()->isAdmin()){
			return false;
		}
		
		// if not with reference to payment then return
		if($refObject === null && !(($refObject instanceof XiView) || ($refObject instanceof XiController))){
			return false;
		}
		
		//if applicable to all is false then check plan v/s apps
		if($this->getParam('applyAll',false) == false){			

			$id = $refObject->getModel()->getId();
			$libInstance = XiLib::getInstance($refObject->getName(),$id);
			
			// if libInstance is not instance of PayplansIfaceApptriggerable, return false
			if(!($libInstance instanceof PayplansIfaceApptriggerable)){
				return false;
			}
			
			// if object is of interest as per plans selected
			$ret = array_intersect($this->getPlans(), $libInstance->getPlans());

			//no plan id is present on plan subscribe page and my order page
			//so count($ret) condition is checked only when the current page is neither plan subscribe nor my order
			//otherwise it will always return false when content app is applied on these pages
			$view = $refObject->getName();
			$task= JRequest::getVar('task','BLANK');
			
			if(!($view == 'plan' || $view == 'order') && $task != 'BLANK'){
				if(count($ret) <= 0 ){
					return false;
				}
			}
		}
		return true;
	}

	public function collectAppParams(array $data)
	{
		// encode editor content
		if(isset($data['app_params']) && isset($data['app_params']['custom_content'])){
			$data['app_params']['custom_content'] = base64_encode($data['app_params']['custom_content']);
		}

		return parent::collectAppParams($data);
	}
	
	protected function _processLocations(Array $locations)
	{
		foreach($locations as $location)
		{
			if(empty($location)){
				continue;
			}
			
			$temp = explode("&", $location);
			if(empty($temp[0])){
				continue;
			}	
			
			$flag = true;
			foreach($temp as $value){
				list($key, $val) = explode('=', $value);
				// IMP : using get method only
				//if key is not present in url then set default value of key
				// if deafult value is not set then set BLANK
				$defaultValue = isset($this->defaultValues[$key]) ? $this->defaultValues[$key] : 'BLANK';
				$actualValue = JRequest::getVar($key, $defaultValue);

				//exact match
				if($actualValue == $val){
					continue;
				}

				//when data is expected, any value will work except NON VALUE
				if($val === 'RANDOM' && $actualValue != 'BLANK'){
					continue;
				}
				
				$flag = false;
				break;				
			}
			
			// if flag is true, means match found return true
			if($flag){
				return true;
			}			
		}
		
		return false;
	}
	
	public function onPayplansViewAfterRender(XiView $view, $task, &$output)
	{
		$locations = array();
		$definedLocations = $this->getAppParam('defined_locations', null);
		if(!empty($definedLocations)){
			$locations[] = $definedLocations;
		}

//		$locations = array_merge($locations, explode(';', $this->getAppParam('custom_locations', null)));
		
		// if still locations are empty then return false
		if(empty($locations)){
			return false;
		}
		
		if(!$this->_processLocations($locations)){
			return false;
		}
		
		
		// add custom content  to output as 
		switch($this->getAppParam('position', self::PREFIX))
		{
			case self::SUFFIX :
				$output .= '<div class="payplansContentSuffix">'.$this->_getContent().'</div>';
				break;
					
			case self::REPLACE :
				$output = '<div class="payplansContentReplace">'.$this->_getContent().'</div>';
				break;
				
			case self::PREFIX :
			default : 
				$output = '<div class="payplansContentPrefix">'.$this->_getContent().'</div>' . $output;
		}
	}
	
	protected function _getContent()
	{
		return base64_decode($this->getAppParam('custom_content', ''));
	}
	
	public function onPayplansControllerAfterExecute($controller, $task)
	{
		//default view and task is saved in array 
		$this->defaultValues['view']   = $controller->getView()->getName();			
		$tempTask   = $task;
		if(empty($task)){
			$tempTask = $controller->getdoTask();
		}		
		$this->defaultValues['task']  = $tempTask;		
	}
}
