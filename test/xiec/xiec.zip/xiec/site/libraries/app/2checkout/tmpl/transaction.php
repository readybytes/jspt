<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die(); ?>

<?php if(!empty($transaction_html)):?>
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_2CHECKOUT_'.JString::strtoupper('testmode'));?></div>
			<?php if(isset($transaction_html['testmode'])):?>
				<?php if($transaction_html['testmode']==1):?>
				<div class="paramValue" style="color:Red;font-weight:bold;"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_2CHECKOUT_SANDBOX_TESTING_MODE');?></div>
				<?php else :?>
      			<div class="paramValue" style="font-weight:bold;"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_2CHECKOUT_SANDBOX_LIVE_MODE');?></div>
      			<?php endif;?>
      		<?php endif;?>
	      </div>
	      
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_2CHECKOUT_'.JString::strtoupper('sid'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['sid']) ? JString::ucfirst($transaction_html['sid']) : '';?>
      		</div>
	      </div>
	      
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_2CHECKOUT_'.JString::strtoupper('key'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['key']) ? JString::ucfirst($transaction_html['key']) : '';?>
      		</div>
	      </div>
	    
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_2CHECKOUT_'.JString::strtoupper('order_number'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['order_number']) ? JString::ucfirst($transaction_html['order_number']) : '';?>
      		</div>
	      </div>
	      
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_2CHECKOUT_'.JString::strtoupper('invoice_number'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['invoice_number']) ? JString::ucfirst($transaction_html['invoice_number']) : '';?>
      		</div>
	      </div>
	      
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_2CHECKOUT_'.JString::strtoupper('cart_order_id'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['cart_order_id']) ? JString::ucfirst($transaction_html['cart_order_id']) : '';?>
      		</div>
	      </div>
	      
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_2CHECKOUT_'.JString::strtoupper('total'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['total']) ? JString::ucfirst($transaction_html['total']).' '.$transaction_html['currency'] : '';?>
      		</div>
	      </div>
	      
	     <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_2CHECKOUT_'.JString::strtoupper('ip_country'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['ip_country']) ? JString::ucfirst($transaction_html['ip_country']) : '';?>
      		</div>
	      </div>
	      
	       <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_2CHECKOUT_BILLING_INFORMATION');?></div>
      		<div class="paramValue">
     	 		<?php echo empty($transaction_html['card_holder_name']) ? '' : JString::ucfirst($transaction_html['card_holder_name']).'<br/>';?>
       			<?php echo empty($transaction_html['street_address'])? '':JString::ucfirst($transaction_html['street_address']).', ';?>
      			<?php echo empty($transaction_html['street_address2'])? '': JString::ucfirst($transaction_html['street_address2']).',<br/>';?>
      			<?php echo empty($transaction_html['city'])? '':JString::ucfirst($transaction_html['city']);?>
      			<?php echo empty($transaction_html['zip'])? '':JString::ucfirst($transaction_html['zip']).'<br/>';?>
      			<?php echo empty($transaction_html['state'])? '': JString::ucfirst($transaction_html['state']).', ';?>
      			<?php echo empty($transaction_html['country'])? '':JString::ucfirst($transaction_html['country']).'<br/>';?>
      			<?php echo empty($transaction_html['phone'])? '':JString::ucfirst($transaction_html['phone']).' ( Mobile No. )';?>
  			 </div>
	      </div> 
<?php endif;?>
<?php 
      
	      