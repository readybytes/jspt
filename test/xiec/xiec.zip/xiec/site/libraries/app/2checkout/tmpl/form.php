<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

?>

<script>
window.onload = function() 
{	
	  setTimeout("checkoutSubmit()", 2000);
}

function checkoutSubmit()
{
	document.forms["site_app_<?php echo $this->getName(); ?>_form"].submit();
}
</script>
<div id="payment-2checkout">
<form action="<?php echo $post_url;?>" method="post"
	  name="site_app_<?php echo $this->getName(); ?>_form" >
	  
		<?php unset( $post_url );?>

		<input type="hidden" name="testmode" value="<?php echo $testmode;?>" />
		<input type="hidden" name="demo" value="<?php echo $demo;?>" />
		
		<input type="hidden" name="sid" value="<?php echo $sid;?>" />
		<input type="hidden" name="invoice_number" value="<?php echo $invoice_number;?>" />
		<input type="hidden" name="payment_key" value="<?php echo $payment_key;?>" />
		<input type="hidden" name="merchant_order_id" value="<?php echo $merchant_order_id;?>" />
		<input type="hidden" name="x_invoice_num" value="<?php echo $x_invoice_num;?>" />
		<input type="hidden" name="fixed" value="<?php echo $fixed;?>" />
		
		<input type="hidden" name="total" value="<?php echo $total;?>" />
		<input type="hidden" name="currency" value="<?php echo $currency;?>" />
		
		<input type="hidden" name="return_url" value="<?php echo $return_url;?>" />
		<input type="hidden" name="cust_id" value="<?php echo $cust_id;?>" />
		<input type="hidden" name="cart_order_id" value="<?php echo $cart_order_id;?>" />
		
		<input type="hidden" name="username" value="<?php echo $username;?>" />
		<input type="hidden" name="name" value="<?php echo $name;?>" />
		<input type="hidden" name="id_type" value="<?php echo $id_type;?>" />
		
		<input type="hidden" name="c_prod" value="<?php echo $c_prod;?>" />
		<input type="hidden" name="c_name" value="<?php echo $c_name;?>" />
		<input type="hidden" name="c_description" value="<?php echo $c_description;?>" />
		<input type="hidden" name="cart_brand_name" value="<?php echo $cart_brand_name;?>" />
		<input type="hidden" name="cart_version_name" value="<?php echo $cart_version_name;?>" />
		
			<div class="prepayment-message">
	        	<div id="payment-title"><h2 class="pageHeading"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_INSTRUCTIONS'); ?></h2></div>
			</div>
			
			<div id="payment-redirection">
				<div class="redirection-message">
					<?php echo XiText::_('COM_PAYPLANS_APP_2CHECKOUT_PAYMENT_REDIRECTION'); ?>
				</div>
				
				<p><img src="<?php echo JURI::root();?>components/com_payplans/media/images/loading.gif" alt="<?php echo XiText::_('COM_PAYPLANS_IMAGE_ALT_LOADING');?>" /></p>
			</div>
		
			<div id="payment-submit">
				<input type="submit" class="button white medium" id="payplans_checkout_btn" value="<?php echo XiText::_('COM_PAYPLANS_APP_2CHECKOUT_CHECKOUT');?>" />
			</div>
		
</form>
</div>
<?php 
