<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* 
* Highly Inspired from AEC micro integration for docman
*/
if(defined('_JEXEC')===false) die();

class PayplansAppDocman extends PayplansApp
{
	protected $_location	= __FILE__;
	
	// applicable only if docman exist
	public function _isApplicable(PayplansIfaceApptriggerable $refObject)
	{
		return JFolder::exists(JPATH_SITE .DS.'components'.DS.'com_docman');
	}
	

	public function onPayplansSubscriptionAfterSave($prev, $new)
	{
		// no need to trigger if previous and current state is same
		if($prev != null && $prev->getStatus() == $new->getStatus()){
			return true;
		}

		// check the status
		if($new->getStatus() != $this->getAppParam('on_status', XiStatus::NONE)){
			return true;
		}
		
		$addTo 		= $this->getAppParam('addToGroup');
		if($addTo){
			$this->_addToGroup($new->getBuyer(), $addTo);
		}
		
		$removeFrom = $this->getAppParam('removeFromGroup');
		if($removeFrom){
			$this->_removeFromGroup($new->getBuyer(), $removeFrom);
		}

		return true;
	}


	protected function _addToGroup( $userid, $groupid )
	{
		$users = $this->_getGroupMembers($groupid);

		if(in_array( $userid, $users ) ) {
			return false;
		} 
		
		// Make sure we have no empty value
		$search = 0;
		while ( $search !== false ) {
			$search = array_search( '', $users );
			if( $search !== false ){
				unset( $users[$search] );
			}
		}

		$users[] = $userid;
		
		return $this->_setGroupMembers($groupid, $users);
	}

	protected function _removeFromGroup( $userid, $groupid )
	{
		$users = $this->_getGroupMembers($groupid);

		if(!in_array($userid,$users)){
			return false;
		}
		
		$key = array_search( $userid, $users );
		unset( $users[$key] );

		// Make sure we have no empty value
		$search = 0;
		while ( $search !== false ) {
			$search = array_search( '', $users );
			if ( $search !== false ) {
				unset( $users[$search] );
			}
		}
		
		$this->_setGroupMembers($groupid, $users);
		return true;
	}
	
	protected function _getGroupMembers($groupid)
	{
		$db = JFactory::getDBO();

		$query = 'SELECT `groups_members`'
			. ' FROM #__docman_groups'
			. ' WHERE `groups_id` = \'' . $groupid . '\''
			;
		$db->setQuery( $query );
		return explode(',', $db->loadResult());
	}
	
	protected function _setGroupMembers($groupid, $users)
	{
		$db = JFactory::getDBO();
		$query = 'UPDATE #__docman_groups'
			. ' SET `groups_members` = \'' . implode( ',', $users ) . '\''
			. ' WHERE `groups_id` = \'' . $groupid . '\''
			;
		$db->setQuery( $query );
		return $db->query();
	}
	
	public static function getGroups()
	{
		$db = JFactory::getDBO();
		$query = 'SELECT groups_id, groups_name, groups_description'
			 	. ' FROM #__docman_groups'
			 	;
	 	$db->setQuery( $query );
	 	return $db->loadObjectList(); 
	} 
}