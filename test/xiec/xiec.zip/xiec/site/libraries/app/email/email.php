<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class  PayplansAppEmail extends PayplansApp
{
	protected $_location	= __FILE__;
	protected $_mailer		= null;

	public function __construct($config = array())
	{
		// Get a JMail instance
		if($this->_mailer === null){
			$this->_mailer = XiFactory::getMailer();
		}

		// let parent work
		return parent::__construct($config);
	}


	public function collectAppParams(array $data)
	{
		// encode editor content
		if(isset($data['app_params']) && isset($data['app_params']['content'])){
			$data['app_params']['content'] = base64_encode($data['app_params']['content']);
		}

		return parent::collectAppParams($data);
	}

	// Do not send false
	public function onPayplansOrderAfterSave($prev, $new)
	{
		return $this->_triggerEmail($prev,$new);
	}

	public function onPayplansPaymentAfterSave($prev, $new)
	{
		return $this->_triggerEmail($prev,$new);
	}

	public function onPayplansSubscriptionAfterSave($prev, $new)
	{
		return $this->_triggerEmail($prev,$new);
	}


	protected function _triggerEmail($prev, $new)
	{
		// no need to trigger if previous and current state is same
		if($prev != null && $prev->getStatus() == $new->getStatus()){
			return true;
		}

		// check the status
		if($new->getStatus() != $this->getAppParam('on_status', XiStatus::NONE)){
			return true;
		}

		// now try to findout the data and process the email
		$this->_sendEmail($new);

		//
		return true;
	}

	protected function _sendEmail($object)
	{
		// object is of payment/subscription/order type
		$userId = $object->getBuyer();

		//$mail->setSender(array($from, $fromname));
		//$mail->addAttachment($attachment);

		$subject = $this->getAppParam('subject', '');
		$subject = $this->_replaceToken($subject, $object);
		$this->_mailer->setSubject($subject);

		$body = base64_decode($this->getAppParam('content', ''));
		$body = $this->_replaceToken($body, $object);
		$this->_mailer->setBody($body);

		// send email always in HTML
		$this->_mailer->IsHTML(true);

		$this->_mailer->addRecipient(XiFactory::getUser($userId)->email);

//		Not required
//		$this->_addEmailAddress($this->getAppParam('send_to', ''));
		$this->_addEmailAddress($this->getAppParam('send_cc', ''),'addCC');
		$this->_addEmailAddress($this->getAppParam('send_bcc', ''),'addBCC');

		// restrict to send email in unit test case
		// in selenium test case mail will not be send because mail setting are not correct
		if(defined('PAYPLANS_UNIT_TEST_MODE')===true){
			return true;
		}
		
		return  $this->_mailer->Send();
	}

	public function _replaceToken($content, $object)
	{
		return XiFactory::getRewriter()->rewrite($content, $object);
	}

	/**
	 * Add given emails to TO/CC/BCC
	 *
	 * @param unknown_type $str Emails in Comma Seperated format
	 * @param unknown_type $function addRecipient / addCC / addBCC
	 */
	public function _addEmailAddress($str, $function='addRecipient')
	{
		// string is empty
		if(isset($str)==false || empty($str)){
			return false;
		}

		// explode and add one by one
		$emails = explode(',', $str);
		$count = 0;
		foreach($emails as $email){
			$this->_mailer->$function($email);
			$count++;
		}

		return $count;
	}
}