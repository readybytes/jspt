<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class  PayplansAppJsmultiprofile extends PayplansApp
{
	protected $_location	= __FILE__;

	public function onPayplansSubscriptionAfterSave($prev, $new)
	{
		return $this->_triggerJsmultiprofile($prev,$new);
	}


	protected function _triggerJsmultiprofile($prev, $new)
	{
		// no need to trigger if previous and current state is same
		if($prev != null && $prev->getStatus() == $new->getStatus()){
			return true;
		}

		// check the status
		if($new->getStatus() != $this->getAppParam('on_status', XiStatus::NONE)){
			return true;
		}

		// now try to findout the data and process the email
		$this->_setJsmultiprofile($new);

		//
		return true;
	}

	protected function _setJsmultiprofile($object)
	{
		// object is of subscription type
		$userId = $object->getBuyer();
		require_once(JPATH_ROOT.DS.'components'.DS.'com_community'.DS.'libraries'.DS.'core.php');
		
		$user = CFactory::getUser($userId);
		$user->set('_profile_id', $this->getAppParam('jsmultiprofile', 0));
		return $user->save();
	}
}