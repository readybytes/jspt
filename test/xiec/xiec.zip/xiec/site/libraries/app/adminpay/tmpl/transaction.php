<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>

	<?php foreach($transaction_html as $key => $value) :?>
			<div class="elementParams">
				<div class="paramTitle"> <?php echo XiText::_('COM_PAYPLANS_APP_ADMINPAY_TRANSACTION_RECORD_'.JString::strtoupper($key)); ?></div>
				<div class="paramValue"><?php echo $value;?></div>
			</div>
	<?php endforeach; ?>
<?php 