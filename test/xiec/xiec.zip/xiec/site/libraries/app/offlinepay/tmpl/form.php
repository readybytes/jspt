<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<?php //XITODO: clean javascript?>
<script type="text/javascript">
function offlineChangeAction()
{
	document.getElementById('payplans_payment_action').value = 'cancel';
	return true;
}
</script>
<h2 class="pageHeading"><?php echo XiText::_('COM_PAYPLANS_APP_OFFLINE_PAY');?></h2>
<div id="offlinePay">

<form action="<?php echo $posturl ?>" method="post" name="site<?php echo $this->getName(); ?>Form">
	<?php echo $transaction_html;?>
	<input type="hidden" name="payment_key" value="<?php echo $payment_key;?>" />
	<div id="offlineSubmitBtn">
		<input type="submit" id="payplans-payment" class="button white medium" name="payplans_payment_btn" value="<?php echo XiText::_('COM_PAYPLANS_PAYMENT')?>" />
		<input type="submit" id="payplans-payment-cancel" class="button white medium" name="payplans_payment_cancel_btn" value="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_CANCEL_BUTTON');?>" onClick="offlineChangeAction()"/>
		<input type="hidden" id="payplans_payment_action" name="action" value="success" />
	</div>
	
</form>
</div>
<?php
