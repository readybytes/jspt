<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die(); ?>

<?php if(!empty($transaction_html)):?>
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_AUTHORIZE_'.JString::strtoupper('testmode'));?></div>
			<?php if(isset($transaction_html['testmode'])):?>
				<?php if($transaction_html['testmode']==1):?>
				<div class="paramValue" style="color:Red;font-weight:bold;"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_AUTHORIZE_SANDBOX_TESTING_MODE');?></div>
				<?php else :?>
      			<div class="paramValue" style="font-weight:bold;"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_AUTHORIZE_SANDBOX_LIVE_MODE');?></div>
      			<?php endif;?>
      		<?php endif;?>
	      </div>
	      
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_AUTHORIZE_'.JString::strtoupper('transaction_id'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['transaction_id']) ? JString::ucfirst($transaction_html['transaction_id']) : '';?>
      		</div>
	      </div>
	      
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_AUTHORIZE_'.JString::strtoupper('transaction_type'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['transaction_type']) ? JString::ucfirst($transaction_html['transaction_type']) : '';?>
      		</div>
	      </div>
	    
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_AUTHORIZE_'.JString::strtoupper('authorization_code'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['authorization_code']) ? JString::ucfirst($transaction_html['authorization_code']) : '';?>
      		</div>
	      </div>
	      
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_AUTHORIZE_'.JString::strtoupper('amount'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['amount']) ? JString::ucfirst($transaction_html['amount']).'USD' : '';?>
      		</div>
	      </div>
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_AUTHORIZE_'.JString::strtoupper('card_type'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['card_type']) ? JString::ucfirst($transaction_html['card_type']) : '';?>
      		</div>
	      </div>
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_AUTHORIZE_'.JString::strtoupper('email_address'));?></div>
      		<div class="paramValue">
      			<?php echo isset($transaction_html['email_address']) ? JString::ucfirst($transaction_html['email_address']) : '';?>
      		</div>
	      </div>
	      
	       <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_AUTHORIZE_BILLING_INFORMATION');?></div>
      		<div class="paramValue">
     	 		<?php echo empty($transaction_html['first_name']) ? '' : JString::ucfirst($transaction_html['first_name']).' ';?>
       			<?php echo empty($transaction_html['last_name'])? '':JString::ucfirst($transaction_html['last_name']).',<br/>';?>
      			<?php echo empty($transaction_html['address'])? '': JString::ucfirst($transaction_html['address']).',<br/>';?>
      			<?php echo empty($transaction_html['city'])? '':JString::ucfirst($transaction_html['city']).', ';?>
      			<?php echo empty($transaction_html['zip_code'])? '':JString::ucfirst($transaction_html['zip_code']).'<br/>';?>
      			<?php echo empty($transaction_html['state'])? '': JString::ucfirst($transaction_html['state']).', ';?>
      			<?php echo empty($transaction_html['country'])? '':JString::ucfirst($transaction_html['country']).'<br/>';?>
      			<?php echo empty($transaction_html['phone'])? '':JString::ucfirst($transaction_html['phone']);?>
  			 </div>
	      </div> 
	      <!-- we dont ask for shipping information now..it may be needed in future 
	     
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_AUTHORIZE_SHIPPING_INFORMATION');?></div>
      		<div class="paramValue">
     	 		<?php echo empty($transaction_html['ship_to_first_name']) ? '' : JString::ucfirst($transaction_html['ship_to_first_name']).' ';?>
       			<?php echo empty($transaction_html['ship_to_last_name'])? '':JString::ucfirst($transaction_html['ship_to_last_name']).',<br/>';?>
      			<?php echo empty($transaction_html['ship_to_company'])? '': JString::ucfirst($transaction_html['ship_to_company']).',<br/>';?>
      			<?php echo empty($transaction_html['ship_to_address'])? '': JString::ucfirst($transaction_html['ship_to_address']).',<br/>';?>
      			<?php echo empty($transaction_html['ship_to_city'])? '':JString::ucfirst($transaction_html['ship_to_city']);?>
      			<?php echo empty($transaction_html['ship_to_zip_code'])? '':JString::ucfirst($transaction_html['ship_to_zip_code']).'<br/>';?>
      			<?php echo empty($transaction_html['ship_to_state'])? '': JString::ucfirst($transaction_html['ship_to_state']).'<br/>';?>
      			<?php echo empty($transaction_html['ship_to_country'])? '':JString::ucfirst($transaction_html['ship_to_country']);?>
  			 </div>
	      </div> 
--><?php endif;?>
<?php 
      
	      