<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansAppAuthorize extends PayplansAppPayment
{
	protected $_location	= __FILE__;
	
    function onPayplansPaymentForm(PayplansPayment $payment, $data = null)
	{		
		$this->assign('post_url', XiRoute::_("index.php?option=com_payplans&view=payment&task=notify"));
		$this->assign('payment_key', $payment->getKey());
	  	return $this->_render('form');
	}
	
	protected function _processRecurringRequest($payment, $data)
	{
		$sub 				= array_shift($payment->getSubscriptions(PAYPLANS_INSTANCE_REQUIRE));
		$durationInDays 	= $sub->getExpirationDate();
		$interval 			= date_diff($sub->getExpirationDate(), $sub->getSubscriptionDate());
		$unit				= 'days';   // days or months
		$totalOccurrences 	= 9999;
		$path 				= "/xml/v1/request.api";
		$host 				= "api.authorize.net";
		if($this->getAppParam('sandbox', 0)){
			$host = "apitest.authorize.net";
		}

        "<?xml version=\"1.0\" encoding=\"utf-8\"?>" .
        "<ARBCreateSubscriptionRequest xmlns=\"AnetApi/xml/v1/schema/AnetApiSchema.xsd\">" .
        "<merchantAuthentication>".
        "<name>" . AUTHORIZENET_API_LOGIN_ID . "</name>".
        "<transactionKey>" . AUTHORIZENET_TRANSACTION_KEY . "</transactionKey>".
        "</merchantAuthentication>".
		"<refId>" . $payment->getKey() . "</refId>".
        "<subscription>".
        //"<name>" . $name . "</name>".
        "<paymentSchedule>".
        "<interval>".
        "<length>". $interval->format('%R%a') ."</length>".
        "<unit>". $unit ."</unit>".
        "</interval>".
        "<startDate>" . $sub->getSubscriptionDate()->toString() . "</startDate>".
        "<totalOccurrences>". $totalOccurrences . "</totalOccurrences>".
        // "<trialOccurrences>". $trialOccurrences . "</trialOccurrences>".
        "</paymentSchedule>".
        "<amount>". $paymen->getAmount() ."</amount>".
        "<trialAmount>" . $trialAmount . "</trialAmount>".
        "<payment>".
        "<creditCard>".
        "<cardNumber>" . $data['x_card_num'] . "</cardNumber>".
        "<expirationDate>" . $data['x_exp_date'] . "</expirationDate>".
        "</creditCard>".
        "</payment>".
        "<billTo>".
        "<firstName>". $data['x_first_name'] . "</firstName>".
        "<lastName>" . $data['x_last_name'] . "</lastName>".
        "</billTo>".
        "</subscription>".
        "</ARBCreateSubscriptionRequest>";
		
		$response = $this->_sendRequestViaCurl($host, $path, $content);
		
		if ($response)
		{
			/*
			a number of xml functions exist to parse xml results, but they may or may not be avilable on your system
			please explore using SimpleXML in php 5 or xml parsing functions using the expat library
			in php 4
			parse_return is a function that shows how you can parse though the xml return if these other options are not avilable to you
			*/
			list ($refId, $resultCode, $code, $text, $subscriptionId) = $this->_parseReturn($response);
			$fp = fopen('data.log', "a");
			fwrite($fp, "$refId\r\n");
			fwrite($fp, "$subscriptionId\r\n");
			fwrite($fp, "$amount\r\n");
			fclose($fp);
			return array(); // ot errors
		}
		
			return array("Transaction Failed");
	}

	protected function _sendRequestViaCurl($host,$path,$content)
	{
		$posturl = "https://" . $host . $path;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $posturl);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_HTTPHEADER, Array("Content-Type: text/xml"));
		curl_setopt($ch, CURLOPT_HEADER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		$response = curl_exec($ch);
		return $response;
	}
 
	//function to parse Authorize.net response
	function _parseReturn($content)
	{
		$refId = substring_between($content,'<refId>','</refId>');
		$resultCode = substring_between($content,'<resultCode>','</resultCode>');
		$code = substring_between($content,'<code>','</code>');
		$text = substring_between($content,'<text>','</text>');
		$subscriptionId = substring_between($content,'<subscriptionId>','</subscriptionId>');
		return array ($refId, $resultCode, $code, $text, $subscriptionId);
	}

	function onPayplansPaymentNotify($payment, $data)
	{		
//		if($this->_isRecurring($payment)){
//			$this->_processRecurringRequest($payment, $data);
//		}
		
		$transactionData = array(
	        'amount' => $payment->getAmount(), 
	        'card_num' => $data['x_card_num'], 
	        'exp_date' => $data['x_exp_date'],
	        'first_name' => $data['x_first_name'],
	        'last_name' => $data['x_last_name'],
	        'address' => $data['x_address'],
	        'city' => $data['x_city'],
	        'state' => $data['x_state'],
	        'country' => $data['x_country'],
	        'zip' => $data['x_zip'],
	        'email' => $data['x_email'],
	        'card_code' => $data['x_card_code']
	        );
	        
		require_once 'AuthorizeNet.php'; 
		define("AUTHORIZENET_API_LOGIN_ID", $this->getAppParam('api_login_id', ''));    // Add your API LOGIN ID
		define("AUTHORIZENET_TRANSACTION_KEY", $this->getAppParam('transaction_key', '')); // Add your API transaction key
		define("AUTHORIZENET_SANDBOX", $this->getAppParam('sandbox', 0));       // Set to false to test against production
		define("TEST_REQUEST", "FALSE");           // You may want to set to true if testing against production
		
		$transaction = new AuthorizeNetAIM();
	    $transaction->setSandbox($this->getAppParam('sandbox', 0));
	    $transaction->setFields($transactionData);
	    
	    $response = $transaction->authorizeAndCapture();
	    
	    $transactionArray = $response->toArray();
	    // to identify it sis testing mode or not
	    $transactionArray['testmode'] = $this->getAppParam('sandbox', 0);
	    
	    // save transaction notification
	    $payment->set('transaction',PayplansHelperParam::arrayToIni($transactionArray));
	
	    $errors   = array();
	    // get controller instance and set redirect
		$controller = XiFactory::getInstance('payment', 'controller', 'Payplanssite');
		$url = 'index.php?option=com_payplans&view=payment&task=complete&payment_key='.$payment->getKey();

		if($response->approved){
			$payment->set('status',XiStatus::PAYMENT_COMPLETE)->save();
			$controller->setRedirect(XiRoute::_($url.'&action=success'));
		}		
		else{
			$payment->set('status',XiStatus::PAYMENT_PENDING)->save();
			$errors['response_reason_code'] = $response->response_reason_code;
			$errors['response_code']		= $response->response_code;
			$errors['response_reason_text'] = $response->response_reason_text;

			$message = XiText::_('COM_PAYPLANS_LOGGER_ERROR_IN_AUTHORIZE_PAYMENT_PROCESS');
			$log_id = PayplansHelperLogger::log(XiLogger::LEVEL_ERROR, $message, $payment, $errors);

			$controller->setRedirect(XiRoute::_($url.'&action=error&log_id='.$log_id));
		}
	}
	
	
//	/**
//	 *  Server Integration method
//	 */
//	protected function _authorizeSIM(PayplansPayment $payment, $data = null)
//	{
//		if ( $this->getAppParam('sandbox', 0)) {
//			$this->my->post_url	= "https://test.authorize.net/gateway/transact.dll";
//		} else {
//			$this->my->post_url	= "https://secure.authorize.net/gateway/transact.dll";
//		}
//
//		$this->my->x_login 	= $this->getAppParam('api_login_id', false);
//		$this->my->transaction_key  = $this->getAppParam('transaction_key', false);
//		$this->my->x_amount = $payment->getAmount();
//		$this->my->x_fp_timestamp = time();
//		$this->my->x_fp_sequence = $payment->getKey(); // Enter an invoice or other unique number.
//		$this->my->x_fp_hash = AuthorizeNetSIM_Form::getFingerprint($this->my->x_login, $this->my->transaction_key, 
//																	$this->my->x_amount, $this->my->x_fp_sequence, $this->my->x_fp_timestamp);
//  		
//  		
//  		$this->my->x_invoice_num			= $payment->getKey();
//		$this->my->x_receipt_link_method	= "POST";
//		$this->my->x_receipt_link_url		= 'http://2.local.readybytes.in/payplans3090/index.php?option=com_payplans&view=payment&task=notify';
//		$this->my->x_receipt_link_text		= "Activate Membership";
//		$this->my->x_show_form				= "PAYMENT_FORM";
//		$this->my->x_relay_response			= "True";
//		$this->my->x_relay_url				= 'http://2.local.readybytes.in/payplans3090/index.php?option=com_payplans&view=payment&task=notify';
//
//  		$this->my->payment_key = $payment->getKey();
//	}

//	/**
//	 * parse the notification to get the invoice number
//	 * @param array $post
//	 */
//	function parseNotification( $post )
//	{
//		$invoice = '';
//		if ( !empty( $post['invoice_number'] ) ) {
//			$invoice = $post['invoice_number'];
//		} elseif ( !empty( $post['merchant_order_id'] ) ) {
//			$invoice = $post['merchant_order_id'];
//		} else {
//			$invoice = $post['x_invoice_num'];
//		}
//
//		return $invoice;
//	}
//
//	/**
//	 * validate the key comes in the notification
//	 * @param PayplansPayment $payment
//	 * @param array $post
//	 */
//	function validateNotification($payment, $post)
//	{
//		if($this->getAppParam('sandbox', 0)) {
//			$string_to_hash	= $this->getAppParam('secret_word', '').$this->getAppParam('sid', '')."1".$post['total'];
//		} else {
//			$string_to_hash	= $this->getAppParam('secret_word', '').$this->getAppParam('sid', '').$post['order_number'].$post['total'];
//		}
//
//		$check_key = strtoupper(md5($string_to_hash));
//
//		return (strcmp($check_key, $post['key']) == 0);
//	}
	
//	function onPayplansPaymentNotify($payment, $data)
//	{
//		var_dump($data);
//	
//		$response = $data;
//		$errors = $this->_processNotification( $payment, $response);
//	
//		// check and update payment status
//        $payment->set('status',XiStatus::PAYMENT_COMPLETE);
//        if(!empty($errors)){
//        	$payment->set('status',XiStatus::PAYMENT_HOLD);
//        }
//        
//		$payment->set('transaction',PayplansHelperParam::arrayToIni($data))
//				->save();
//		
//		// XITODO : set errors to logger of lib instance  
//		//return count($errors) ? implode("\n", $errors) : ' No Errors';
//		
//		// get controller instance and set redirect
//		$controller = XiFactory::getInstance('payment', 'controller', 'Payplanssite');
//		$url = 'index.php?option=com_payplans&view=payment&task=complete&payment_key='.$payment->getKey();
//		
//		if(!empty($errors)){
//			$controller->setRedirect(XiRoute::_($url.'&action=error'));
//		}		
//		else{
//			$controller->setRedirect(XiRoute::_($url.'&action=success'));
//		}
//		
//		return true;
//	}	
//	
//	/**
//	 * 
//	 * Process the notification for different parameters
//	 * @param PayplansPayment $payment
//	 * @param array $data
//	 */
//    function _processNotification(PayplansPayment &$payment, array $data)
//    {
//    	$errors = array();
//    	$order =  PayplansOrder::getInstance($payment->getOrder());
//
//    	// check reciever sid must be same.
//    	if(1 != $data['x_response_code']) {
//            $errors[] = $data['x_response_reason_code']." : ".$data['x_response_reason_text'];
//        }
//
//        // check payment key
//    	if($payment->getKey() != $data['x_invoice_num']) {
//            $errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_PAYMENT_KEY');
//    	}
//    	        
//        // check the stored amount against the payment amount
//        if ((float) number_format($order->getTotal(), 2) !== (float) number_format($data['x_amount'], 2)) {
//            $errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_PAYMENT_TOTAL');
//        }
//        // update the payment amount
//        $payment->set('amount', (float) $data['x_amount']);
//
//        return $errors;
//    }

}
