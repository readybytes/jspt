<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();?>
<div id="authorize">
	<h2 class="pageHeading"> 
		<?php echo XiText::_('COM_PAYPLANS_PAYMENT_DETAIL');?> 
	</h2>

	<form method="post" action="<?php echo $post_url;?>" id="checkout_form">

      <fieldset>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_CREDIT_CARD_NUMBER')?></label>
          <input type="text" class="required creditcard" size="15" name="x_card_num" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_EXPIRATION_DATE')?></label>
          <input type="text" class="required" size="4" name="x_exp_date" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_CCV')?></label>
          <input type="text" class="required" size="4" name="x_card_code" value=""></input>
        </div>
      </fieldset>
      <fieldset>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_FIRST_NAME')?></label>
          <input type="text" class="required" size="15" name="x_first_name" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_LAST_NAME')?></label>
          <input type="text" class="required" size="14" name="x_last_name" value=""></input>
        </div>
         <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_EMAIL')?></label>
          <input type="text" class="email" size="14" name="x_email" value=""></input>
        </div>

        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_ADDRESS')?></label>
          <input type="text" class="required" size="26" name="x_address" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_CITY')?></label>
          <input type="text" class="required" size="15" name="x_city" value=""></input>
        </div>

        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_STATE')?></label>
          <input type="text" class="required" size="4" name="x_state" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_ZIP_CODE')?></label>
          <input type="text" class="required" size="9" name="x_zip" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_COUNRTY')?></label>
          <input type="text" class="required" size="22" name="x_country" value=""></input>
        </div>
      </fieldset>
      <input type="hidden" name="payment_key" value="<?php echo $payment_key;?>" />
      
      <div class="buy-button">
      <input type="submit" name="buy" value="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_BUY')?>" class="submit buy button white medium" />
  	  <a class="button white medium" id="authorize-pay-cancel" href="<?php echo XiRoute::_("index.php?option=com_payplans&view=payment&task=complete&payment_key=".$payment_key."&action=cancel"); ?>"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_CANCEL')?></a>
      </div>
	</form>
</div>