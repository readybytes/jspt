<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
defined('_JEXEC') or die('Restricted access');
?>
<div id="payment_paypal">
                    <div class="prepayment_message">
                        <?php echo JText::_( "Tienda Google CheckOut Preparation Message" ); ?>
                    </div>
                    <div class="prepayment_action">
                   	     <?php echo $cart->CheckoutButtonCode("SMALL"); ?>
                   	     <div style="float: left; padding: 10px;"><?php echo "<b>".JText::_( "Checkout Amount").":</b> ".$orderpayment_amount; ?></div>
                       <div style="clear: both;"></div>
                    </div>
                </div>
<?php 