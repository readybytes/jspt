<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<?php if(!empty($transaction_html)):?>
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_'.JString::strtoupper('test_ipn'));?></div>
			<?php if(isset($transaction_html['test_ipn'])):?>
				<?php if($transaction_html['test_ipn']==1):?>
				<div class="paramValue" style="color:Red;font-weight:bold;"><?php echo "Sandbox Testing Mode";?></div>
				<?php else :?>
      			<div class="paramValue" style="font-weight:bold;"><?php echo "Live";?></div>
      			<?php endif;?>
      		<?php endif;?>
	      </div>
	       <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_'.JString::strtoupper('business'));?></div>
      		<div class="paramValue">
      			<?php if(isset($transaction_html['business'])):?>
      				<?php echo JString::ucfirst($transaction_html['business']);?>
      			<?php endif;?></div>
	      </div>
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_'.JString::strtoupper('parent_txn_id'));?></div>
      		<div class="paramValue">
      			<?php if(isset($transaction_html['parent_txn_id'])):?>
      				<?php echo $transaction_html['parent_txn_id'];?>
      			<?php endif;?></div>
      		</div>		
	       <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_'.JString::strtoupper('txn_id'));?></div>
      		<div class="paramValue">
      			<?php if(isset($transaction_html['txn_id'])):?>
      				<?php echo $transaction_html['txn_id'];?></div>
      			<?php endif;?>
	      </div>
	       <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_'.JString::strtoupper('payment_type'));?></div>
      		<div class="paramValue">
      			<?php if(isset($transaction_html['payment_type'])):?>
      				<?php echo JString::ucfirst($transaction_html['payment_type']);?></div>
      			<?php endif;?>
	      </div>
	       <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_'.JString::strtoupper('payment_status'));?></div>
      		<div class="paramValue">
      			<?php if(isset($transaction_html['payment_status'])):?>
      				<?php echo JString::ucfirst($transaction_html['payment_status']);?></div>
      			<?php endif;?>
	      </div>
	       <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_'.JString::strtoupper('payment_date'));?></div>
      		<div class="paramValue">
      		<?php if(isset($transaction_html['payment_date'])):?>
      			<?php echo JString::ucfirst($transaction_html['payment_date']);?></div>
      		<?php endif;?>
	      </div>
	       <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_'.JString::strtoupper('invoice'));?></div>
      		<div class="paramValue">
      		<?php if(isset($transaction_html['invoice'])):?>
      			<?php echo JString::ucfirst($transaction_html['invoice']);?></div>
      		<?php endif;?>
	      </div>
	       <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_'.JString::strtoupper('mc_gross'));?></div>
      		<div class="paramValue">
      		<?php if(isset($transaction_html['mc_gross']) && isset($transaction_html['mc_currency'])):?>
      			<?php echo JString::ucfirst($transaction_html['mc_gross']).' '.JString::ucfirst($transaction_html['mc_currency']);?></div>
      		<?php endif;?>
	      </div>
	      <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_'.JString::strtoupper('shipping'));?></div>
      		<div class="paramValue">
      		<?php if(isset($transaction_html['shipping'])):?>
      			<?php echo JString::ucfirst($transaction_html['shipping']);?></div>
      		<?php endif;?>
	      </div>
	       <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_'.JString::strtoupper('tax'));?></div>
      		<div class="paramValue">
      		<?php if(isset($transaction_html['tax'])):?>
      			<?php echo JString::ucfirst($transaction_html['tax']);?></div>
      		<?php endif;?>
	      </div>
	       <div class="elementParams">
			<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYPAL_ADDRESS');?></div>
      		<div class="paramValue">
      			<?php echo empty($transaction_html['address_name'])? '':JString::ucfirst($transaction_html['address_name']).'<br/>';?>
      			<?php echo empty($transaction_html['address_street'])? '': JString::ucfirst($transaction_html['address_street']).', ';?> 
      			<?php echo empty($transaction_html['address_city'])? '':JString::ucfirst($transaction_html['address_city']).', ';?>
      			<?php echo empty($transaction_html['address_zip'])? '':JString::ucfirst($transaction_html['address_zip']).', ';?>
      			<?php echo empty($transaction_html['address_state'])? '': JString::ucfirst($transaction_html['address_state']).', ';?>
      			<?php echo empty($transaction_html['address_country'])? '':'<br/>'.JString::ucfirst($transaction_html['address_country']);?> 
      			<?php echo empty($transaction_html['address_status'])? '':' ( '.JString::ucfirst($transaction_html['address_status']).' )';?>
  			 </div>
	      </div> 
<?php endif;?>
<?php 
      
	      