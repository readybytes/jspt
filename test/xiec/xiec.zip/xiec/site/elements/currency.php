<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementCurrency extends XiElement
{
	/**
	 * Element name
	 *
	 * @access	protected
	 * @var		string
	 */
	var	$_name = 'Currency';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$attr = array();
		// for php 5.3 specific
		if($this->hasAttrib($node, 'global')){
			$value = XiFactory::getConfig()->currency;
			$attr['readonly'] = true;
		}

		return XiHtml::_('elements.currency', $control_name.'['.$name.']', $value, $attr);
	}
}