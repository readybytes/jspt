<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementJusertype extends XiElement
{
	/**
	 * Element name
	 *
	 * @access	protected
	 * @var		string
	 */
	var	$_name = 'Jusertype';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$group 	= $this->getJoomlaGroups();
		return XiHTML::_('select.genericlist', $group, $control_name.'['.$name.']', null, 'value', 'value', $value);
	}

	function getJoomlaGroups()
	{
		$db= & JFactory::getDBO();
		$sql = ' SELECT * FROM '.$db->nameQuote('#__core_acl_aro_groups')
				.' WHERE '.$db->nameQuote('name').' NOT LIKE "%USERS%"'
				.' AND '.$db->nameQuote('name').' NOT LIKE  "%ROOT%"'
				.' AND '.$db->nameQuote('name').' NOT LIKE  "%Public%"'
				.' AND '.$db->nameQuote('name').' NOT LIKE  "%Super Administrator%"' ;
		$db->setQuery($sql);
		return $db->loadObjectList();
	}
}