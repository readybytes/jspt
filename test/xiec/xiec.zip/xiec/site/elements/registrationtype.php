<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementRegistrationtype extends XiElement
{
	/**
	 * Element name
	 *
	 * @access	protected
	 * @var		string
	 */
	var	$_name = 'Registrationtype';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$path = JPATH_ROOT.DS.'plugins'.DS.'payplansregistration';

		$html   = '<select id="'.$control_name.'['.$name.']" name="'.$control_name.'['.$name.']" title="' . XiText::_('COM_PAYPLANS_REGISTRATION_TYPE') . '">';
		
        foreach(JFolder::files($path,'php$') as $file ){
        	$file = JFile::stripExt($file);
        	
        	if(XiHelperPlugin::getStatus($file, 'payplansregistration') == false){
        		continue;
        	}
        	
            $selected   = ( JString::trim($file) == $value ) ? ' selected="true"' : '';
            $html   .= '<option value="' . $file . '"' . $selected . '>' . XiText::_('COM_PAYPLANS_REGISTRATION_TYPE_'.JString::strtoupper($file)) . '</option>';
        }

        $html   .= '</select>';
        return $html;
	}
}