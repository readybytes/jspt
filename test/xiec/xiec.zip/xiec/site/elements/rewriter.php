<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementRewriter extends XiElement
{
	/**
	 * Element name
	 *
	 * @access	protected
	 * @var		string
	 */
	var	$_name = 'Rewriter';

	function fetchElement($name, $value, &$node, $control_name)
	{
		jimport('joomla.html.pane');
		ob_start();
		
        $libs = array('plan', 'subscription', 'order', 'payment', 'user');
        $tabs = JPane::getInstance('tabs', array('startOffset'=>0));
        echo $tabs->startPane('rewriter-right-tabs');
        	
        // first tab which shows the config params
        // XITODO : Title should be in XiText or not
        echo $tabs->startPanel('Config','Config');
        $rewriter = new XiRewriter();
        $rewriter->setConfigMapping();
		foreach($rewriter->get('mapping') as $key => $val){
			echo '[['.$key.']]<br/>';
		}
        echo $tabs->endPanel();
        
        // tokens for lib instance plan, order, subscription and payment
        foreach($libs as $lib){	
			$libInstance = XiLib::getInstance($lib); 
			
			$rewriter = new XiRewriter();
			$rewriter->setMapping($libInstance, false);
		    
			echo $tabs->startPanel(JString::ucfirst($lib), JString::ucfirst($lib));
			foreach($rewriter->get('mapping') as $key => $val){			
				echo '[['.$key.']]<br/>';			
			}
			echo $tabs->endPanel();
        }
		echo $tabs->endPane();
		
		
		$content = ob_get_contents();
		ob_end_clean();
		return $content;
	}
}