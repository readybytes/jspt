<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementPrice extends XiElement
{
	/**
	 * Element name
	 *
	 * @access	protected
	 * @var		string
	 */
	var	$_name = 'Price';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$size = ( $node->attributes('size') ? 'size="'.$node->attributes('size').'"' : '' );
		$class = ( $node->attributes('class') ? 'class="'.$node->attributes('class').'"' : 'class="text_area"' );
       
		$html = '';
		if($class=='class="readonly"'){
			$html = '<input type="hidden" name="'.$control_name.'['.$name.']'.'" value="'.$value.'">';
		}
		return $html.XiHtml::_('elements.price', $control_name.'['.$name.']', $control_name.'['.$name.']_0', $value, $class, $size, array());
	}
}