<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

//xitodo : rename all elements to use payplans prefix e.g. JElementPayplansstatus
class JElementStatus extends XiElement
{
	/**
	 * Element name
	 *
	 * @access	protected
	 * @var		string
	 */
	var	$_name = 'Status';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$entity = $this->getAttrib($node, 'entity', '');

		return XiHtml::_('elements.status', $control_name.'['.$name.']', $value, $entity);
	}
}