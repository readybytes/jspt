<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<div id="login">
<form action="<?php echo $uri; ?>" method="post" name="site<?php echo $this->getName(); ?>Form">

<h2 class="pageHeading"><?php echo XiText::_('COM_PAYPLANS_PLAN_LOGIN_TO_SUBSCRIBE_THIS_PLAN');?></h2>
	
	<!-- LOGIN FORM -->
		<?php echo $this->loadTemplate('selected_plan');?>
		<div id="userLogin">
				<h4 class="divHeading"><?php echo XiText::_('COM_PAYPLANS_LOGIN_HEADING'); ?></h4>
			<div class="labelInputRow">
				<div class="loginLabel"><?php echo XiText::_('COM_PAYPLANS_LOGIN_USERNAME');?></div>
				<div class="loginInput"><input type="text" name="payplansLoginUsername"/><span class="required">*</span></div>
			</div>
			
			<div class="labelInputRow">
				<div class="loginLabel"><?php echo XiText::_('COM_PAYPLANS_LOGIN_PASSWORD');?></div>
				<div class="loginInput"><input type="password" name="payplansLoginPassword"/><span class="required">*</span></div>
			</div>
			
			<div class="labelInputRow">
			<div class="loginLabel">&nbsp;</div>
			<div class="loginInput"><input type="submit" class="button white medium" id= "payplansLoginSubmit" name="payplansLoginSubmit" value="<?php echo XiText::_('COM_PAYPLANS_LOGIN_BUTTON'); ?>" /></div>
			</div>
		<?php echo $this->loadTemplate('triggered'); ?>
		
		</div>
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="task" value="login"/>
</form>
</div>
<?php 