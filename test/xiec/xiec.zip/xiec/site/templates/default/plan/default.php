<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<div id="payplanssubdiv">
	<form action="<?php echo $uri; ?>" method="post" name="site<?php echo $this->getName(); ?>Form">	
	
		<!-- LOAD PLAN TMPL -->
		<?php echo $this->loadTemplate('plan'); ?>

		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="task" value="subscribe"/>
	</form>
</div>
<?php 
