<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<input type="hidden" name="plan_id" id="payplans_subscription_plan" value="<?php echo $plan->getId();?>" />

<?php //XITODO : Clean and format the code ?>
<div id="plan">
	<div id="planDetail">
	<h4 class="divHeading"><?php echo XiText::_('COM_PAYPLANS_PLAN_SELECTED_PLAN'); ?></h4>
		<div class="title">
		<div class="titleLable"><?php echo XiText::_('COM_PAYPLANS_PLAN_SUBSCRIPTION_FOR');?></div> 
		<div class="titleValue"><?php echo JString::ucfirst($plan->getTitle()); ?></div>
		</div>
		
		<div class="priceAndTime">
			<div class="priceTimeLable"><?php echo XiText::_('COM_PAYPLANS_PLAN_PRICE_AND_TIME');?></div> 
			<div class="priceTimeValue">
				<span class="price">
					<?php echo $plan->getPrice().' '.$plan->getCurrency(); ?>
				</span>
					<?php echo XiText::_('COM_PAYPLANS_PLAN_PRICE_TIME_SEPERATOR');?>
				<span class="time">
					<?php echo PayplansHelperFormat::planTime($plan->getExpiration()); ?>
				</span>
			</div>
		</div>
		
		<div class="teaserText">
			<div class="teaserTextLable"><?php echo XiText::_('COM_PAYPLANS_PLAN_TEASER_TEXT');?></div>
			<div class="teaserTextValue">
				<?php echo JString::ucfirst($plan->getTeasertext());?>
			</div>
		</div>
		
		<div class="descriptionText">
			<div class="descriptionTextLable"><?php echo XiText::_('COM_PAYPLANS_PLAN_DESCRIPTION');?></div>
			<div class="descriptionTextValue">
				<?php echo JString::ucfirst($plan->getDescription());?>
			</div>
		</div>
	</div>
	
	<!--<div class="plandescription">
		<?php echo $plan->getDescription(); ?>
	</div>
-->
	</div>


<?php 