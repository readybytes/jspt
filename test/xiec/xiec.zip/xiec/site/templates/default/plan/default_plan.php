<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();?>

<div id="payplans-plan-select-bottom">
<?php echo implode($this->_renderModules('payplans-plan-select-top', array('style'=>'xhtml'))); ?>
</div>

<div id="planSelection">
<h2 class="pageHeading"><?php echo XiText::_('COM_PAYPLANS_PLAN_SELECT_PLAN_HEADING');?></h2>
	<?php $count=0; ?>
	<!-- START Echo All Plans -->
	<?php	$plan_count = count($records);

	foreach ($records as $record):
		$plan = PayplansPlan::getInstance($record->plan_id, null, $record);

		$selected = '';
		if($record->plan_id == $plan_id):
			$selected = ' checked ';
		endif;
		?>

		<div class="payplansPlan">
			<?php if($plan_count>1): ?>
			<?php endif; ?>
			<div class="payplansPlanHeader">
				<div class="payplansPlanSelect">
					<input type="radio" name="plan_id" id="payplans_subscription_plan" value="<?php echo $plan->getId();?>" <?php echo $selected;?>/>
				</div>
				<?php //XITODO : Clean and format the code ?>
				<div class="payplansPlanTitle"><?php echo JString::ucfirst($plan->getTitle()); ?></div>
				<div class="payplansTeaser"><?php echo JString::ucfirst($plan->getTeasertext());?></div>

				<div class="planPriceAndTime">
					<span class="planPrice"><?php echo $plan->getPrice().' '.$plan->getCurrency(); ?></span>
					<?php echo XiText::_('COM_PAYPLANS_PLAN_PRICE_TIME_SEPERATOR');?>
					<span class=planTime>
						<?php echo PayplansHelperFormat::planTime($plan->getExpiration()); ?>
					</span>
				</div>
				<div class="separator"></div>
			</div>



			<div class="payplansPlanDescription"><?php echo $plan->getDescription(); ?>
		</div>
		
		<div class="payplansPlanSubmit">
			<a id="testPlan<?php echo $plan->getId();?>" href="<?php echo XiRoute::_('index.php?option=com_payplans&view=plan&task=subscribe&plan_id='.$record->plan_id);?>" class="button white"><?php echo XiText::_('COM_PAYPLANS_PLAN_SUBSCRIBE_BUTTON')?></a>
		</div>
		</div>

		<?php $count++; ?>
	<?php endforeach;?>
	<!-- END Echo All Plans -->
</div>
<div id="payplans-plan-select-bottom">
<?php echo implode($this->_renderModules('payplans-plan-select-bottom', array('style'=>'xhtml'))); ?>
</div>