<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die(); ?>
<div id="usersOrderDetails">
	<h2 class="pageHeading"> 
		<?php echo XiText::_('COM_PAYPLANS_ORDER_DETAIL');?> 
	</h2>
	<div class="subscriptionAndPayment">
		<?php echo $this->loadTemplate('view_subscription'); ?>
		<?php echo $this->loadTemplate('view_payment'); ?>
	</div>
	<?php echo $this->loadTemplate('view_order'); ?>
</div>
<?php 