<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<div id="usersOrder">
<!--
		<div class="record">
			<div class="recordLabel">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_ID');?>
			</div>
			
			<div class="recordValue">
				<?php $key = $order->getKey();
				echo XiText::_('COM_PAYPLANS_REFERENCE_ID'). $key; ?>
			</div>
		</div>
-->
		<div class="record">
			<div class="recordLabel">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_STATUS'); ?>
			</div>
			<div class="recordValue">
				<span id="payplans-order-status-<?php echo $order->getStatusName()?>"><?php echo $order->getStatusName();?></span>
			</div>
		</div>
		
		<div class="record">
			<div class="recordLabel">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_SUBTOTAL');?>
			</div>
			<div class="recordValue">
				<?php echo $order->getSubtotal(); ?>
			</div>
		</div>
		
		<div class="record">
			<div class="recordLabel">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_DISCOUNT');?>
			</div>
			<div class="recordValue">
				<?php echo $order->getDiscount();	?>
			</div>
		</div>
		
		<div class="record user-order-total-amount">
			<div class="recordValue" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_TOTAL'); ?>">
				<?php echo $order->getTotal(); ?>
			</div>
		</div>
		<!-- when order is not confirmed then display confirm order option to user at order display page -->
		<?php if($order->getStatus()==XiStatus::NONE):?>
			<div id="confirm-order">
				<a id="payplans-confirm-order-<?php echo $order->getKey()?>" href="<?php echo XiRoute::_('index.php?option=com_payplans&view=order&task=confirm&order_key='.$key); ?>"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_HEADING')?></a>
			</div>
		<?php endif;?>

</div>