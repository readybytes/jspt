<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<div id="payplanorder" >
<h2 class="pageHeading"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_HEADING');?></h2>
<form action="<?php echo $uri; ?>" method="post" name="site<?php echo $this->getName(); ?>Form">

	<div id="orderid">
		<label><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_ID');?></label>
		<span><?php echo $order->getKey();?></span>
	</div>
	
	<div id="details">
		<div id="userdetails">
			<div id="yourdetails"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_YOUR_DETAILS');?></div>
			<div class = "detaillabel"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_USER_ID');?></div><div class = "detaildec"><?php echo $user->getId(); ?></div>
			<div class = "detaillabel"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_EMAIL');?></div><div class = "detaildec"><?php echo $user->getEmail(); ?></div>
			<div class = "detaillabel"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_NAME');?></div><div class = "detaildec"><?php echo $user->getRealname(); ?></div>
		</div>
		<div id="productdetails">
		<div id="detailsheading"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_PRODUCT_DETAILS');?></div>
		<div class = "detaillabel"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_PRODUCT_NAME');?></div><div class = "detaildec"><?php echo $plan->getTitle(); ?></div>
		</div>
	</div>


		<div id="apphtml">
			<?php
			if(!empty($plugin_result) && is_array($plugin_result)):
				echo implode($plugin_result,'\n');
			endif;
			?>
		</div>

		<div id="ordercalculation">
			<div id="subtotal">
				<label><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_SUBTOTAL');?></label>
				<span class="amount"><?php echo $order->getSubtotal();?></span>
			</div>

			<div id="discount">
				<label><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_DISCOUNT');?></label>
				<span class="amount"><?php echo $order->getDiscount();?></span>
			</div>


			<div id="totalamount">
				<span class="amount"><?php echo $order->getTotal();?></span>
				<span class="currency"><?php  $order->getCurrency();?></span>

			</div>
		</div>

	

	<div id="orderfooter">
		<div id="makepayment">
			<label><?php echo XiText::_('COM_PAYPLANS_ORDER_MAKE_PAYMENT_FROM');?></label>
			<span><?php echo JHTML::_('select.genericlist', $payment_apps, 'app_id', '' , 'id', 'title');?></span>
		</div>

		<!-- HIDDEN VARIBALE REQUIRED -->
		<input type="hidden" name="order_key" value="<?php echo $order->getKey();?>" />

		<div id="confirmbtn"><input type="submit" id="payplans-order-confirm" class="button white medium" name="payplans_order_confirm_btn" value="<?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_BTN')?>"/></div>
	</div>

	<input type="hidden" name="boxchecked" value="0" />
</form>
</div>
<?php
