<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<div id="usersSubscription">
<h4 class="divHeading"><?php echo XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTIONS');?></h4>
<?php $count = 1;?>
	<?php if(is_array($subscription)):?>
		<?php foreach($subscription as $record): ?>
	<div class="subscription-params">
		<div class="subscription-params-summary">
			<div class="subscription-sno" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTION_SERIAL_NO'); ?>"><?php echo "#". $count; ?></div>
			<div class="subscription-name" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTIONS_NAME');?>"><?php echo $record->getTitle(); ?></div>
			<div class="subscription-status" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTIONS_STATUS');?>"><?php echo $record->getStatusName(); ?></div>
		</div>
		<div class="subscription-params-detail">
			<div class="subscription-id" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTIONS_ID');?>"><?php $orderId = $record->getOrder();
					echo "#".$record->getKey();?>
			</div>
			<!-- when plan expiration time includes hours only then display hours -->
			<?php $plan = array_shift($record->getPlans(true));?>
			<?php $exp_time = $plan->getExpiration();?>
				<?php if($exp_time['hour']=="00"):?>
					<?php $format = XiDate::SUBSCRIPTION_PAYMENT_FORMAT;?>
				<?php else:?> 
					<?php $format = XiDate::SUBSCRIPTION_PAYMENT_FORMAT_HOUR;?>
				<?php endif;?>

			<div class="subscription-price" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTIONS_AMOUNT');?>"><?php echo $record->getPrice().' '.XiFactory::getConfig()->currency; ?></div>
			<div class="subscription-time" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTION_TIME'); ?>"><?php echo $record->getSubscriptionDate()->toFormat($format).' <span class="separator">'.XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTIONS_TO').'</span> '.$record->getExpirationDate()->toFormat($format); ?></div>

		</div>	
		

		

	</div>
				<?php
				$count++;
	endforeach; 
endif;
?>
</div>
<?php 
