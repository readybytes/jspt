<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>

<h2 class="pageHeading"><?php echo XiText::_('COM_PAYPLANS_ORDERS');?></h2>
<?php 
if(is_array($order_records)):
	foreach($order_records as $record):
		$order = PayplansOrder::getInstance($record->order_id,null,$record);
		?>
		<div id="usersOrder">
		<div class="order-default-col1">
		<div class="record">
			<div class="recordLabel">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_KEY');?>
			</div>
			
			<div class="recordValue">
				<?php $key = $order->getKey();
				echo XiHtml::link('index.php?option=com_payplans&view=order&task=display&order_key='.$key, $key); ?>
			</div>
		</div>
		
		<div class="record">
			<div class="recordLabel">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_STATUS'); ?>
			</div>
			<div class="recordValue">
				<?php echo $order->getStatusName();?>
			</div>
		</div>
		
		
		
		</div>
		
		<div class="order-default-col2">
		<div class="record">
			<div class="recordLabel">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_SUBTOTAL');?>
			</div>
			<div class="recordValue">
				<?php echo $order->getSubtotal(); ?>
			</div>
		</div>
		
		<div class="record">
			<div class="recordLabel">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_DISCOUNT');?>
			</div>
			<div class="recordValue">
				<?php echo $order->getDiscount();	?>
			</div>
		</div>
		
		<div class="record">
			<div class="recordLabel">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_TOTAL'); ?>
			</div>
			<div class="recordValue">
				<?php echo $order->getTotal(); ?>
			</div>
		</div>
		</div>
		
		<div class="viewSubscriptionBtn" >
		<a id="payplans-order-detail-<?php echo $order->getKey()?>" href="<?php echo 'index.php?option=com_payplans&view=order&task=display&order_key='.$key;?>" class="button white">View Details</a>
		</div>
</div>
	<?php endforeach;?> 
<?php endif; ?>

<?php if(!empty($order_records)):?>
	<form action="<?php echo $uri; ?>" method="post" name="site<?php echo $this->getName(); ?>Form">
		<?php echo $this->getModel()->getPagination()->getListFooter(); ?>
		<input type="hidden" name="view" value="order" />
	</form>
<?php endif;?>
