<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die(); ?>
<div id="usersPayment">
<h4 class="divHeading"><?php echo XiText::_('COM_PAYPLANS_PAYMENT'); ?></h4>
<?php $count = 1;?>
<?php if(is_array($payment)):?>
	<?php foreach($payment as $record):	?>
	<div class="user-payment-params">
	
			<div class="payment-sno" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTION_SERIAL_NO'); ?>"><?php echo "#",$count;?></div>
			
			<div class="payment-app-name" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_DISPLAY_APP_NAME');?>">
				<?php echo $record->getAppName();?>
			</div>
			
			<div class="payment-status" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_DISPLAY_STATUS');?>">
				<span id="payplans-order-detail-<?php echo $record->getStatusName();?>"><?php echo $record->getStatusName();?></span>
			</div>	
			
					<!-- display view invoice button only when payment status complete -->
					<?php if($record->getStatus() == XiStatus::PAYMENT_COMPLETE):?>
						<div id="payment-view-invoice">
							<a id="payplans-invoice-view-invoice" href="<?php echo XiRoute::_('index.php?option=com_payplans&view=payment&task=invoice&payment_key='.$record->getKey());?>" ><?php echo XiText::_('COM_PAYPLANS_VIEW_INVOICE_BUTTON')?></a>
						</div>
					<?php endif; ?>
					
					<!-- when payment status is None or pending and Payment Method is not Admin Payment then display make payment button -->
					<?php if(($record->getStatus() == XiStatus::NONE || $record->getStatus() == XiStatus::PAYMENT_PENDING) && ($record->getApp(true)->getName()!='adminpay')):?>
						<div id="payment-view-invoice">
							<a id="payplans-invoice-make-payment" href="<?php echo XiRoute::_('index.php?option=com_payplans&view=payment&task=pay&payment_key='.$record->getKey()); ?>" ><?php echo XiText::_('COM_PAYPLANS_INVOICE_MAKE_PAYMENT')?></a>
						</div>	
				<?php endif;?>
			
			
			<div class="payment-key"  title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_DISPLAY_PAYMENT_KEY');?>">
				<?php echo "#". $record->getKey();?>
			</div>
			
			<div class="payment-amount" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_DISPLAY_AMOUNT');?>">
				<?php echo $record->getAmount().' '.$record->getCurrency();?>
			</div>
			
			<div class="payment-modified-date" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_DISPLAY_MODIFIED_DATE');?>">
				<?php echo $record->getModifiedDate()->toFormat(XiDate::SUBSCRIPTION_PAYMENT_FORMAT);?>
			</div>
			
	

		
		<?php
		//XITODO : How to show transaction
		//$app = PayplansApp::getInstance( $record->getId());
		//echo $app->onPayplansPaymentRecord($record);
		?></div>
		<?php endforeach;?> 
<?php endif;?>
<!--if order and its subscription has been created by admin then make payment button should be made available to the user-->
<?php if(empty($payment)):?>	
    <?php if(($order->getTotal()!=0) && ($order->getStatus()!=XiStatus::NONE)):?> 
		<div class="view-invoice-btn">
			<a id="payplans-invoice-make-payment" href="<?php echo XiRoute::_('index.php?option=com_payplans&view=order&task=confirm&order_key='.$order->getKey()); ?>" class="cvbv"><?php echo XiText::_('COM_PAYPLANS_INVOICE_MAKE_PAYMENT')?></a>
		</div>	
	<?php else :?>
		<?php echo XiText::_('COM_PAYPLANS_PAYMENT_SCREEN_BLANK_MSG');?>
	<?php endif;?>
<?php endif;?>
</div>
<?php 
