<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
XiHtml::stylesheet('invoice.css', PAYPLANS_URL_MEDIA."/css/", false);
?>
<div id="invoice">
	<div id="companyDetail">
		<div id="blank">&nbsp;</div>
		<div id="companylogo"><img src="<?php echo JURI::base().XiFactory::getConfig()->companyLogo; ?>" /><!--<h1><?php echo "Your Logo"; ?></h1>--></div>
		<div id="description">
			<div id="name"><?php echo XiFactory::getConfig()->companyName; ?></div>
			<div id="address"><?php echo XiFactory::getConfig()->companyAddress;?></div>
			<div id="cityCountry"><?php echo XiFactory::getConfig()->companyCityCountry; ?></div>
			<div id="cellNo"><?php echo XiFactory::getConfig()->companyPhone; ?></div>
		</div>
	</div>
	
	<div id="billDetail">
	
		<div id="otherDetail">
			<div id="invoceId"><?php echo XiText::_('COM_PAYPLANS_INVOICE_TEXT_INVOICE'); ?></div>
			<div id="paymentKey"><?php echo "#".$payment->getKey(); ?></div>
			<div id="dateAndStatus"><?php echo XiText::_('COM_PAYPLANS_INVOICE_PAID_ON') .' '.$payment->getModifiedDate()->toFormat(); ?></div>
		</div>
		
		<div id="userDetail">
			<div id="billTo"><?php echo XiText::_('COM_PAYPLANS_INVOICE_BILL_TO'); ?></div>
			<div id="userName"><?php echo $user->getRealname(); ?></div>
			<div id="userMail"><?php echo $user->getEmail(); ?></div>
		</div>
		
	</div>
	
	<div id="invoiceText"><?php echo XiText::_('COM_PAYPLANS_INVOICE_TEXT_INVOICE'); ?></div>
	
	<div id="productDetails">
		<div id="productDetailsKey">
			<div id="productNameKey"><?php echo XiText::_('COM_PAYPLANS_INVOICE_ITEM'); ?></div>
			<!--<div id="productQtykey"><?php echo XiText::_('COM_PAYPLANS_INVOICE_QUANTITY'); ?></div>
			--><div id="productRateKey"><?php echo XiText::_('COM_PAYPLANS_INVOICE_PRICE'); ?></div>
<!--			<div id="productSubTotalKey"><?php echo XiText::_('COM_PAYPLANS_INVOICE_SUB_TOTAL'); ?></div>-->
			<div id="productRateKey"><?php echo XiText::_('COM_PAYPLANS_INVOICE_RATE_DISCOUNT'); ?></div>
			<!-- <div id="productTaxKey"><?php echo XiText::_("Taxes"); ?></div>-->
		</div>
		
		<?php //foreach($foo as $bar): 
		foreach($subscriptions as $subscription):?>
		<div class="productDetailsValue">
			<div class="productNameValue"><?php echo $subscription->getTitle(); ?></div>
			<!--<div class="productQtyValue"><?php echo "One"; ?></div>
			--><div class="productRateValue"><?php echo $subscription->getPrice(); ?></div>
			<!--<div class="productTaxValue"><?php echo "0%"; ?></div>-->
<!--		<div class="productSubTotalValue"><?php echo $subscription->getPrice(); ?></div>-->
			<div class="productRateValue"><?php echo $subscription->getDiscount(); ?></div>
		</div>
		<?php endforeach; ?>
	</div>
	
	<div id="invoiceFooter">
		<div id="productSubTotalKey"><?php echo XiText::_('COM_PAYPLANS_INVOICE_TOTAL'); ?></div>
		<div class="productSubTotalValue"><?php echo $order->getCurrency().' '.$order->getTotal(); ?></div>
	</div>
	<?php //print_r($this->plan); ?>
	
	
</div>



<?php 