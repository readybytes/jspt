<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<div class="thanks">
<?php echo XiText::_('COM_PAYPLANS_PAYMENT_ERROR'); ?>

<a id="payplans-confirm-order" href="<?php echo XiRoute::_('index.php?option=com_payplans&view=payment&task=pay&payment_key='.$payment->getKey()); ?>"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_RETRY')?></a>
</div>
<?php echo $this->loadTemplate('triggered'); ?>
<?php 
