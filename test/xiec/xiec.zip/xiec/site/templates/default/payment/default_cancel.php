<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<div class="thanks">
	<?php echo XiText::_('COM_PAYPLANS_PAYMENT_CANCEL');?>
</div>
<div id="confirm-order">
		<a id="payplans-confirm-order" href="<?php echo XiRoute::_('index.php?option=com_payplans&view=order&task=confirm&order_key='.$order->getKey()); ?>"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYNOW')?></a>
		<span style="font-size:15px;"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_PAYNOW_MSG'); ?></span>
</div>
<div style="text-align: center">
	<?php echo "<br/>".XiText::_('COM_PAYPLANS_PAYMENT_CANCEL_NOTE');?>
</div>
<?php 
