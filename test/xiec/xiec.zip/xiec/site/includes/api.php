<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	API
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

require_once  dirname(__FILE__).DS.'includes.php';

class PayplansApi
{
	/**
	 * @param integer $userid : User Id
	 * @return PayplansUser Object, on which you can call many functions 
	 *  You can call all function defined in PayplansIfaceApiUser
	 */
	static public function getUser($userid)
	{
		return PayplansUser::getInstance($userid);
	}
	
	/**
	 * @param integer $planid : Plan number
	 * @return PayplansPlan Object,
	 *  You can call all function defined in PayplansIfaceApiPlan
	 */
	static public function getPlan($planid)
	{
		return PayplansPlan::getInstance($planid);
	}
	
	/**
	 * Creates a new plan object and return it.
	 * 
	 * @return PayplansPlan
	 * IMP : To save Plan permanently, call save() on returned object.
	 */
	static public function createPlan()
	{
		return PayplansPlan::getInstance(0);
	}
	
	
	
	
	/**
	 * @param integer $orderid : Order number
	 * @return PayplansOrder Object,
	 *  You can call all function defined in PayplansIfaceApiOrder
	 */
	static public function getOrder($orderid)
	{
		return PayplansOrder::getInstance($orderid);
	}
	
	/**
	 * Creates a new Order object and return it.
	 * 
	 * @return PayplansOrder
	 * IMP : To save order permanently, call save() on returned object.
	 */
	static public function createOrder()
	{
		return PayplansOrder::getInstance(0);
	}
	
	
	/**
	 * Get the subscription object of given ID
	 * @param integer $subscriptionid : Subscription number
	 * @return PayplansSubscription Object,
	 * 
	 * You can call all function defined in PayplansIfaceApiSubscription
	 * over the object returned.
	 */
	static public function getSubscription($subscriptionid)
	{
		return PayplansSubscription::getInstance($subscriptionid);
	}
	
	/**
	 * Creates a new Subscription object and return it.
	 * 
	 * @return PayplansSubscription
	 * IMP : To save Subscription permanently, call save() on returned object.
	 */
	static public function createSubscription()
	{
		return PayplansSubscription::getInstance(0);
	}
	
	/**
	 * @param integer $paymentid : Payment number
	 * @return PayplansPayment Object,
	 *  You can call all function defined in PayplansIfaceApiPayment
	 */
	static public function getPayment($paymentid)
	{
		return PayplansPayment::getInstance($paymentid);
	}
	
	/**
	 * @return stdClass Object
	 * If you update configuration here, it will NOT be saved 
	 * into database. The updated configuration will only work 
	 * for current execution cycle
	 */
	static public function getConfig()
	{
		return XiFactory::getConfig();
	}
	
	
	/**
	 * Check If given user have subscription to given plan.
	 * 
	 * @param $userid : user id
	 * @param $planid : the plan to check against
	 * @param $staus  : Status can be one of below 3. 
	 *        XiStatus::SUBSCRIPTION_ACTIVE
	 *        XiStatus::SUBSCRIPTION_HOLD
	 *        XiStatus::SUBSCRIPTION_EXPIRED
	 *        
	 * Imp: By default it checks subscription status = active 
	 *
	 * @return : false
	 */
	static function haveSubscription($userid, $planid, $staus=XiStatus::SUBSCRIPTION_ACTIVE)
	{
		$subscriptions = XiFactory::getInstance('subscription','model')
								->loadRecords(array('user_id'=>$userid, 'plan_id' => $planid, 'status'=>$status));
								
		return count($subscriptions);
	}
}