<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

//include basic required files
jimport('joomla.utilities.string');
jimport('joomla.utilities.date');
jimport('joomla.html.pane');

//load language file
$filename = 'com_payplans';
$language = JFactory::getLanguage();
$language->load($filename, JPATH_SITE);
$language->load($filename.'_override', JPATH_SITE);


//load basic defines
require_once dirname(__FILE__).DS.'defines.php'	;

//load basic helpers
require_once PAYPLANS_PATH_HELPER .DS.'loader.php'	;

//autoload helpers
PayplansHelperLoader::addAutoLoadFolder(PAYPLANS_PATH_HELPER,	'Helper',	'Payplans');

//autoload library
PayplansHelperLoader::addAutoLoadFolder(PAYPLANS_PATH_LIBRARY.DS.'model',	'Model');
PayplansHelperLoader::addAutoLoadFolder(PAYPLANS_PATH_LIBRARY.DS.'table',	'Table');
PayplansHelperLoader::addAutoLoadFolder(PAYPLANS_PATH_LIBRARY.DS.'base',	'',		'Xi');
PayplansHelperLoader::addAutoLoadFolder(PAYPLANS_PATH_LIBRARY.DS.'lib',		'');
PayplansHelperLoader::addAutoLoadFolder(PAYPLANS_PATH_SETUP,				'Setup');
PayplansHelperLoader::addAutoLoadFolder(PAYPLANS_PATH_INTERFACE,			'Iface');
PayplansHelperLoader::addAutoLoadFolder(PAYPLANS_PATH_EVENT, 'Event');
// setup autoloading for classes
$format	= JRequest::getCmd('format','html');
PayplansHelperLoader::addAutoLoadViews(PAYPLANS_PATH_VIEW, $format, 'Payplanssite');
PayplansHelperLoader::addAutoLoadFolder(PAYPLANS_PATH_CONTROLLER, 'Controller', 'Payplanssite');

PayplansHelperLoader::addAutoLoadFolder(PAYPLANS_PATH_ELEMENTS, 'Element', 'J');

//Other folders should be added here as we need those
//PayplansHelperLoader::addAutoLoadFolder(PAYPLANS_PATH_COMPONENT_SITE.DS.'libraries'.DS.'payments', 'XiModel');

//Include admin classes also
require_once PAYPLANS_PATH_COMPONENT_ADMIN.DS.'includes'.DS.'includes.php';

//trigger system start event
if(defined('PAYPLANS_DEFINE_ONSYSTEMSTART')==false){
	// bug in php, subclass having issue with autoloading multiple chained classes
	// http://bugs.php.net/bug.php?id=51570
	class_exists('XiPlugin', true);
	
	XiHelperPlugin::trigger('onPayplansSystemStart');
	define('PAYPLANS_DEFINE_ONSYSTEMSTART', true);
}
