function PayplansAdminJS()
{
	//default submit function
	this.submit = function( view, action, validActions){
		
		// try views function if exist
		funcName = view+'_'+ action ; 
		if(this[funcName] instanceof Function) {
			if(this[funcName].apply(this) == false)
				return false;
		}
		
		// then lastly submit form
		//submitform( action );
		if (action) {
	        document.adminForm.task.value=action;
	    }
		
		// validate actions
		//XITODO : send values as key of array , saving a loop
		validActions = eval(validActions);
		var isValidAction = false;
		for(var i=0; i < validActions.length ; i++){
			if(validActions[i] == action){
				isValidAction = true;
				break;
			}
		}
		
		result = true;
	    if (document.adminForm.onsubmit instanceof Function) {
		    result = document.adminForm.onsubmit.apply(this, Array(isValidAction));
			// below code is not working on IE7+, so added above line
	        //result=document.adminForm.onsubmit(isValidAction);
	    }
	    if(result){
	    	document.adminForm.submit();
	    }
	}

	//redirect to some url
	this.redirect = function( url ){
		window.location.href = url;
		xiWindowHide();
	}
	
	this.resetFilters = function(form){
		 // loop through form elements
	    var str = new Array();
	    for(i=0; i<form.elements.length; i++)
	    {
	        var string = form.elements[i].name;
	        if (string && string.substring(0,6) == 'filter' && (string!='filter_reset' && string!='filter_submit'))
	        {
	            form.elements[i].value = '';
	        }
	    }
		this.submit(view,null,validActions);
	}
	
	this.showAdvanceSettings = function(){
		xi.jQuery("div.payplans_advance").css("display","block");
		if(xi.jQuery("div.payplans_expert").css("display")=="block")
			xi.jQuery("div.payplans_expert").css("display","none");
	}
	
	this.showExpertSettings = function(){
		xi.jQuery("div.payplans_expert").css("display","block");
		if(xi.jQuery("div.payplans_advance").css("display")=="block")
			xi.jQuery("div.payplans_advance").css("display","none");
	}
	
	
	
}

var payplansAdmin = new PayplansAdminJS();
