if (typeof(xi)=='undefined')
{
	xi = {
		jQuery: window.jQuery,
		extend: function(obj){
			this.jQuery.extend(this, obj);
		}
	}
}

xi.extend({
	plugins:{
		extend: function (obj){
			xi.jQuery.extend(xi.plugins, obj);
		},

		initialize: function()
		{
			xi.jQuery.each(xi.plugins, function(index, value) {
				try{
				    value.initialize();
				}
				catch(err)
				{
					//Handle errors here
				}
			});
		}
	},
	
	fetchpage : function( theurl ){
		xiajax.call(theurl+"&tmpl=component&xiAjaxDomObject=payplans&xiAjaxDomProperty=replaceWith");
	},

	
	url:{
		openInModal: function( theurl ){
			var ajaxCall = "xiajax.call('"+theurl+"');";
			xiWindowShow(ajaxCall, '', 650, 300);
		}
	},
	
	submitAjaxForm: function(action){
		xi.jQuery('input#'+action).parents('form').submit();
	},
	
	
	apps : {
		inithelp: function(){
				xi.jQuery('#type')
				.live('change', function(){
					var appd = xi.jQuery('select#type option:selected').val();
					xi.jQuery('#appsDescription').children('div').css("display","none");
					xi.jQuery('#'+appd).css("display","block");
					}
				);
			}
		},
		
	order:{
		discount:{
			apply: function(orderId){
				var discountCode = xi.jQuery('#app_discount_code_id').val();
				var url = "index.php?option=com_payplans&view=order&task=trigger&event=onPayplansDiscountRequest&id="+orderId;
				var args= Array(orderId, discountCode);
				//remove the error message
				xi.order.discount.displayError('');
				xiajax.call(url, args);
			},
			
			displayError: function(message){
				xi.jQuery('#app-discount-apply-error').html(message);
				if(message !== ''){
					xi.jQuery('#app-discount-apply-error').css('display','block');
				}
				else{
					xi.jQuery('#app-discount-apply-error').css('display','none');
				}
			}
		}
	},
		
	install:{
		sampleData: function(){
			var url = "index.php?option=com_payplans&view=dashboard&task=installsample";
			xi.jQuery('#install-sample-data-msg').css('display','block');
			xiajax.call(url);
		}
	},
	
	dashboard:{
		modsearch: function(){
			var searchText = xi.jQuery('#payplans_search_text').val();
			var url = "index.php?option=com_payplans&view=dashboard&task=modsearch&headerFooter=0&xiAjaxDomObject=payplans-search-results&searchText="+searchText;
			xi.jQuery('#payplans-search-results').css('display','block');
			xiajax.call(url);
		},
		
		preMigration: function(plugin){
			var url = "index.php?option=com_payplans&view=dashboard&task=migrate&plugin="+plugin+'&action=pre';;
			xi.url.openInModal(url);
			return false;
		},
		
		doMigration: function(plugin){
			var url = "index.php?option=com_payplans&view=dashboard&task=migrate&plugin="+plugin+'&action=Do';
			xi.url.openInModal(url);
		},
		
		updateMigration: function(plugin, progress){
			var url = "index.php?option=com_payplans&view=dashboard&task=migrate&plugin="+plugin+'&action=Do';
			// update the progressbar length
			xi.jQuery('#dashboard-migrate-progress-bar').css('width',progress+'%');
			xiajax.call(url);
		},
		
		postMigration: function(plugin){
			var url = "index.php?option=com_payplans&view=dashboard&task=migrate&plugin="+plugin+'&action=post';
			xi.url.openInModal(url);
		}
	},
	
	addTooltip : function(){
		// tooltip for labels
		 xi.jQuery('.hasTip').not('input,select,textarea').addClass('hasTooltip').removeClass('hasTip');
		 xi.jQuery('.hasTooltip').tipsy({ 
			 							gravity: function(){ return xi.jQuery(this).attr('payplans-tipsy-gravity') ? xi.jQuery(this).attr('payplans-tipsy-gravity') : 'sw';},// nw | n | ne | w | e | sw | s | se 
			 							fade :   function(){ return xi.jQuery(this).attr('payplans-tipsy-fade') ? xi.jQuery(this).attr('payplans-tipsy-fade') : true;},
			 							html : true
		 								}); 
		 
		 // get parent tooltip for DOM objects
		 xi.jQuery('#payplans input,select,textarea').each(function(){
			 if(!xi.jQuery(this).attr('title')){
				 xi.jQuery(this).attr('title', xi.jQuery(this).parent().parent().find('.hasTooltip').attr('original-title'));
			 }
		 });
		 
		 xi.jQuery('#payplans input,select,textarea').tipsy({
			 												trigger:  function(){ return xi.jQuery(this).attr('payplans-tipsy-trigger')? xi.jQuery(this).attr('payplans-tipsy-trigger') : 'focus';}, 
			 												gravity:  function(){ return xi.jQuery(this).attr('payplans-tipsy-gravity') ? xi.jQuery(this).attr('payplans-tipsy-gravity') : 'w';}, 
			 												fade :    function(){ return xi.jQuery(this).attr('payplans-tipsy-fade') ? xi.jQuery(this).attr('payplans-tipsy-fade') : true;},
			 												html : true
			 												});		 
	},
	
	linkback : function(){
		xi.jQuery('#payplansPowerdBy').click(
				function(){
					var href = xi.jQuery(this).attr('href')
								+'?utm_source='+xi_url_base
								+'&utm_medium=link&utm_campaign=linkback';
					xi.jQuery(this).attr('href', href);
					return true;
				}
		);
		
	}
});

// Document ready
xi.jQuery(document).ready(function (){
	xi.plugins.initialize();

     // for disable property of elements
	 //XITODO : use css if possible
    xi.jQuery('#payplans .readonly').attr("disabled", true);

    // trigger jquery valid-val plugin for validation, for admin panel
    xi.jQuery('form').validVal();
    xi.addTooltip();
    xi.linkback();
});