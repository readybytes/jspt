
jQuery.noConflict();