<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplanssiteViewPayment extends XiView
{
	public function complete()
	{
		$payment_id  = $this->getModel()->getId();
		$payment = XiLib::getInstance('payment',$payment_id);
		
		//if action is cancel then provide option for retry and redirect to order confrim page
		$action = $this->getTpl();
		if($action == 'cancel')
		{
			$order      = PayplansOrder::getInstance( $payment->getOrder());
			$this->assign('order', $order);
		}
		if($action == 'error'){
			//$app = $payment->getApp(true);
			//$this->assign('app', $app);
			$this->assign('payment', $payment);
		}
		
		
		// XITODO :show a thanks of cancel message
		return true;
	}
	
	function pay(){

		return true;
	}
	
	function invoice(){
			$paymentId  = $this->getModel()->getId();
			$payment	= PayplansPayment::getInstance( $paymentId);
			$order      = PayplansOrder::getInstance( $payment->getOrder());		
			$subscription = $order->getSubscriptions('order_id');

				$this->assign('user', 	PayplansUser::getInstance($order->getBuyer()));
				$this->assign('order',  $order);
				$this->assign('payment',  $payment);
				$this->assign('subscriptions',  $subscription);
				return true;
	}

}