<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplanssiteViewOrder extends XiView
{
	public function confirm()
	{
		//Only one order will be confirmed at a time
		$itemId = $this->getModel()->getId();

		//now record is always an array, pick the first only
		$record 	= $this->getModel()->loadRecords(array('id'=>$itemId),array(), true);
		$record 	= array_shift($record);

		// get library instcance of order
		$order	= PayplansOrder::getInstance();
		$order->bind($record);

		// get subscription instance
		$subs = PayplansSubscription::getInstance()
					->loadIf(array('order_id'=>$order->getId()));

		$plan = PayplansPlan::getInstance( array_shift($subs->getPlans()));

		// get payment all application, application on this plan
		$paymentAppsInstance = array();
		// trigger apps
		if($plan instanceof PayplansIfaceApptriggerable){
			$paymentAppsInstance = PayplansHelperApp::getApplicationApps('payment', $plan);
		}

		// assert when no payment application is available
		XiError::assert(!empty($paymentAppsInstance), XiText::_('COM_PAYPLANS_NO_APPLICATION_AVAILABLE_FOR_PAYMENT'));

		// XITODO : move to helper
		$paymentApps = array();
		foreach($paymentAppsInstance as $appId => $app){
			$paymentApp['id'] 	  = $appId;
			$paymentApp['title'] = $app->getTitle();
			array_push($paymentApps, $paymentApp);
		}

		// assign required variables
		$this->assign('payment_apps',  	$paymentApps);
		$this->assign('order', 	$order);
		$this->assign('user', 	PayplansUser::getInstance($order->getBuyer()));
		$this->assign('plan',	$plan);

		return true;
	}

	public function complete()
	{
		return true;
	}

	public function display($userId=null)
	{
		$userId = ($userId === null) ? XiFactory::getUser($userId)->id : $userId;

		if($id=$this->getModel()->getId()){
			$order = PayplansOrder::getInstance()->load($id);
			$this->assign('subscription', $order->getSubscriptions());
			$this->assign('payment', $order->getPayment());
			$this->assign('order', $order);
			$this->setTpl('view');
		}else{
			$orderRecords = $this->getModel()->loadRecords(array('buyer_id' => $userId));
			$this->assign('order_records', $orderRecords);
		}
		return true;
	}
}

