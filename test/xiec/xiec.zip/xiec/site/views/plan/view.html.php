<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplanssiteViewPlan extends XiView
{
	public function subscribe()
	{
		$itemId = $this->getModel()->getState('id');

		// load only published and visible plans
		$queryFilters = array('published'=>1, 'visible'=>1 );
		$records	  = $this->getModel()->loadRecords($queryFilters);

		$this->assign('userId', XiFactory::getUser()->id);
		$this->assign('records', $records);
		$this->assign('plan_id', $itemId);
		
		// trigger the event so that plaugins can add their html also if needed
		$this->assign('triggered_html', XiHelperPlugin::trigger('onPayplansBeforeRenderPlans'));
		return true;
	}

    public function login()
    {
		// XITODO : no need to trigger the event , onBeforeRender{ViewName} trigger is called eachtime
		$planId = $this->getModel()->getState('id');
    	$this->assign('plan', PayplansPlan::getInstance($planId));
    	$this->assign('triggered_html', XiHelperPlugin::trigger('onPayplansBeforeRenderLoginForm'));
		return true;
    }
}