<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansHelperSearch
{
	static public function addSearchFunction($func=null, $class = 'PayplansHelperSearch')
	{
		static $funcs = null;
		
		
		if($func !==null){
			$funcs[md5($class.$func)] = array($class,$func);
		}
		
		return $funcs;
	}
	
	static public function doSearch($text)
	{
		//add all functions required
		self::addSearchFunction('searchOPS');
		self::addSearchFunction('searchUsers');
		
		// do search
		$results = array();
		foreach(self::addSearchFunction() as $func){
			$results = array_merge($results, call_user_func($func,$text));
		}
		
		return $results;
	}
	
	
	static public function searchOPS($text)
	{
		$results = array();
		
		$id = $text;
		if(!is_numeric($text)){
			$id =  XiFactory::getEncryptor()->decrypt($text);
		}
		
		// if its blank
		if($id == 0){
			return array();
		}
		
		// if order exist add it to results
		$order = PayplansOrder::getInstance($id);
		if($order !== false){
			$config = array('prefix'=>true, 'link'=>true, 'admin'=>true, 'attr'=>'');
			$results[] = PayplansHelperFormat::order($order, $config);
		}
		
		$payment = PayplansPayment::getInstance($id);
		if($payment !== false){
			$config = array('prefix'=>true, 'link'=>true, 'admin'=>true, 'attr'=>'');
			$results[] = PayplansHelperFormat::payment($order, $config);
		}
		
		$subscription = PayplansSubscription::getInstance($id);
		if($subscription !== false){
			$config = array('prefix'=>true, 'link'=>true, 'admin'=>true, 'attr'=>'');
			$results[] = PayplansHelperFormat::subscription($subscription, $config);
		}
		
		
		return $results;
	}
	
	static public function searchUsers($text)
	{
		// no need to search if text is empty
		if(empty($text)){
			return true;
		}
		
		$config = array('prefix'=>true, 'link'=>true, 'admin'=>true, 'attr'=>'');
		
		// if $test is numeric than search for user id
		if(is_numeric($text) && $text){
			$user = PayplansUser::getInstance($text);
			if($user !== false){
				return array(PayplansHelperFormat::user($user, $config));
			}
			
			return array();
		}
		
		$user  = array();
		$model = XiFactory::getInstance('user', 'model');
		
		$query = $model->getQuery();
		$tmpQuery = unserialize(serialize($query));
		$tmpQuery->clear('where')
				 ->where("`tbl`.`username` LIKE '%".$text."%' ","OR")
				 ->where("`tbl`.`email` = '$text'", "OR");
				 
		$users = $tmpQuery->dbLoadQuery()->loadObjectList($model->getTable()->getKeyName());
		
		$result= array();
		foreach($users as $user){
			$result[] = PayplansHelperFormat::user(PayplansUser::getInstance($user->user_id, null, $user), $config);
		}
		
		return $result;
	}
	
}