<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansHelperCron
{
	static function doCronEvents()
	{
		// do subscription expiry
		self::doSubscriptionExpiry();

		//XITODO : HIGH : trigger pre-expiry events
		//XITODO : LOW  : trigger expiry for discount

	}

	/*
	 * Expire all
	 */
	static function doSubscriptionExpiry(XiDate $time=null)
	{
		//get all records which need to be marked expired now
		$subscriptions = XiFactory::getInstance('subscription','model')
							->getActiveSubscriptions($time);

		//XITODO : LOW : how we can improve performance here
		foreach($subscriptions as $sub_id => $subscription){

			//XITODO : LOW : if subscription is recurring, then charge user instead of expiring
			PayplansSubscription::getInstance($sub_id, null, $subscription)
					->setStatus(XiStatus::SUBSCRIPTION_EXPIRED)
					->save();
		}

		return true;
	}
}