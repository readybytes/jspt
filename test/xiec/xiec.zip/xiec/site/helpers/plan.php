<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

//XITODO : Remove this file and  merege functions with LibPlan
class PayplansHelperPlan
{
	static function isValidPlan($planId)
	{
		// is exist and published
		$record = XiFactory::getInstance('plan', 'model')
							->loadRecords(array('plan_id'=>$planId, 'published'=>1), array('limit'));
		
		// is accessible to current user
		if(isset($record[$planId]) && !empty($record[$planId]))
			return true;

		return false;
	}

	// returns plan details
	static function getDetails($planId)
	{
		return array();
	}
	
	static function getName($planId)
	{		
		return PayplansPlan::getInstance($planId)->getTitle(); 
	}
	
	static function convertExpirationTime($period, $unit)
	{
		$days = $months= $years = 0;
		switch($unit)
		{
			case 'Y':
				$years	= $period ;
				break;

			case 'M' :
				if($period >= 12 ){
					$years	= $period / 12 ;
					$period = $period % 12 ;
				}
				
				$months  = $period % 12 ;
				break;
				
			case 'W' :
				//convert into number of days
				// let days system handle it.
				$period = $period * 7 ;
			
			case 'D' :	
				if($period >= 365 ){
					$years	= $period / 365 ;
					$period = $period % 365 ;
				}
				
				if($period >= 30 ){
					$months = $period / 30 ;
					$period = $period % 30 ;
				}
				
				$days 	= $period % 30 ;

				break;				 
		}
		
		$time =  ($years<10  ? '0':'').number_format($years, 0)
				.($months<10 ? '0':'').number_format($months, 0)
				.($days<10   ? '0':'').number_format($days, 0)
				."000000";
		return $time;
	}
}