<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * Class will help tp instantiate multiple joomla xiapps plugin with different paramter
 * @author meenal
 *
 */
class PayplansHelperApp
{

	/**
	 * Add a path from where we can load Apps
	 * @param string $path
	 */
	static function addAppsPath($path=null)
	{
		static $paths = array(PAYPLANS_PATH_APPS);

//		// This cache cleaning create issue, for non-core apps
//		if(XiFactory::cleanStaticCache()){
//			$paths = array(PAYPLANS_PATH_APPS);
//		}

		if($path != null){
			//XITODO : prepend new path
			$paths[]= $path;
		}

		return $paths;
	}

	/**
	 * Load Apps from various folders
	 * @return Array of Apps
	 */
	static function getApps()
	{
		static $apps= null;

//		if(XiFactory::cleanStaticCache()){
//			$apps= null;
//		}

		//already loaded
		if($apps){
			return $apps;
		}

		//load apps from file systems
		$apps = array();
		foreach(self::addAppsPath() as $path){
			$newApps = JFolder::folders($path);
			$apps = array_merge($apps, $newApps);
			//also mark them autoload
			foreach($newApps as $app){
				PayplansHelperLoader::addAutoLoadFile($path.DS.$app.DS.$app.'.php',
								'PayplansApp'.JString::ucfirst($app));
			}
		}

		// also sort for consistent behaviour
		sort($apps);
		return $apps;
	}

	/**
	 * return Apps of given purpose e.g. payment
	 * In Default value return all apps
	 * @param string purpose
	 * @return Array of particular Purpose Apps
	 */
	static function getPurposeApps($purpose='')
	{
		static $purposeApps = array();

		$allApps 	 = self::getApps();

		// Return all apps
		if($purpose == ''){
			return $allApps;
		}

		//XITODO : implement cache clean
		// if already cached
		if(isset($purposeApps[$purpose]))
			return $purposeApps[$purpose];

		// not cached, add all classes
		$purposeApps[$purpose] = array();
		$purposeClass	= 'PayplansApp'.JString::ucfirst($purpose);
		foreach($allApps as $app){
			$appClass 		= 'PayplansApp'.JString::ucfirst($app);

			// bug in php, subclass having issue with autoloading multiple chained classes
			// http://bugs.php.net/bug.php?id=51570
			class_exists($appClass, true);

			if(is_subclass_of($appClass, $purposeClass)){
				$purposeApps[$purpose][] = $app;
			}
		}

		return $purposeApps[$purpose];
	}

	/**
	 * Load all the apps in the system
	 * means creating object of every app in table
	 * @return Array PayplansApp
	 */
	static function loadApps()
	{
		static $instances = null;

		//clean cache if required, required during testing
		if(XiFactory::cleanStaticCache()){
			$instances = null;
		}

		if($instances === null)
		{
			//at least load all classes
			self::getApps();

			//now load all records
			$queryFilters = array('published'=>1);
			$apps = XiFactory::getInstance('app', 'model')->loadRecords($queryFilters);

			//XITODO trigger on before load apps event to plugin

			$instances = array();
			foreach($apps as $app){
				//IMP : $app should be given, so it can bind with it rather then loading the data
				$instance = PayplansApp::getInstance( $app->app_id, $app->type, $app);
				if($instance === FALSE){
					continue;
				}
				
				$instances[$app->app_id] = $instance; 
			}

			//trigger on after load apps event to plugin
			$args	= array(&$instances);
			XiHelperPlugin::trigger('onPayplansAppsAfterLoad',$args);
		}

		return $instances;
	}

	/**
	 * Trigger all apps instances
	 * @param String $eventName
	 * @param array $args
	 * @param String $purpose
	 * @param unknown_type $refObject
	 * @return Array
	 */
	static function trigger($eventName, array &$args=array(), $purpose='',  $refObject=null)
	{
		//get Plugins objects
		$apps = self::loadApps();

		$results = array();

		//trigger all apps if they serve the purpose
		foreach($apps as $app)
		{
			if($app->hasPurpose($purpose) && $app->isApplicable($refObject, $eventName)
					&& method_exists($app, $eventName)){
				$results[$app->getId()] = call_user_func_array(array($app,$eventName), $args);
			}
		}

		return $results;
	}

	static function getXmlData($what = 'name')
	{
		$what = JString::strtolower($what);
		$apps = self::getApps();
		$xmlData = array();

		foreach($apps as $app){
			$appInstance = PayplansApp::getInstance( null, $app);
			$xml = $appInstance->getLocation() . DS . $appInstance->getName() . '.xml';

			$parser		= XiFactory::getXMLParser('Simple');
			$parser->loadFile($xml);
			$childrens = $parser->document->children();

			foreach($childrens as $child){
				if(JString::strtolower($child->_name) == $what)
					$xmlData[$appInstance->getName()] = $child->_data;
			}
		}

		return $xmlData;
	}

	static function getApplicationApps($purpose='', PayplansIfaceApptriggerable $refObject=null)
	{
		//get Plugins classes names
		$apps = self::loadApps();

		$results = array();

		//trigger all apps if they serve the purpose
		foreach($apps as $app)
		{
			if($app->hasPurpose($purpose) && $app->isApplicable($refObject)){
				$results[$app->getId()] = $app;
			}
		}

		return $results;
	}
}
