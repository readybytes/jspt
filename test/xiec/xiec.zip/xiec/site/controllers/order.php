<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplanssiteControllerOrder extends XiController
{
	protected 	$_defaultTask = 'display';
	
	/*
	 * expects key instead of id
	 */
    protected   $_requireKey  = true;
    
	function display($userId = null)
	{
		$userId = ($userId === null) ? XiFactory::getUser($userId)->id : $userId;

		//if user is not logged in
		// currently sending to login page
		if(!$userId){
			$return	= JURI::getInstance()->toString();
			$url    = 'index.php?option=com_user&view=login';
			$url   .= '&return='.base64_encode($return);
			$this->setRedirect($url, XiText::_('COM_PAYPLANS_ORDER_YOU_MUST_LOGIN_FIRST'));
			return false;
		}

		$this->setTemplate('display');
		return true;
	}

	/**
	 * Show confirmation page.
	 * Generally send to Cart of Payplans
	 */
 	public function confirm()
       {
               $orderId = $this->getModel()->getId();
               $order         = PayplansOrder::getInstance( $orderId);
               
               // if order is not valid then redirect to plan page
               if(!$orderId){
                       $this->setMessage(XiText::_('COM_PAYPLANS_ORDER_PLEASE_SELECT_A_VALID_PLAN'));
                       $this->setRedirect(XiRoute::_("index.php?option=com_payplans&view=plan"));
                       return false;
               }
                       
               //if order is for free plan then redirect to complete order page
               if(0 == $order->getSubtotal()){
                       $this->setRedirect(XiRoute::_('index.php?option=com_payplans&view=order&task=complete&order_key='.$order->getKey()),false);
                       return false;
               }

               // data is not post then show order details
               if(JRequest::getVar('payplans_order_confirm_btn', 'BLANK', 'POST') === 'BLANK'){
                       //else get order confirmation page
                       $this->setTemplate(__FUNCTION__);
                       return true;
               }

               // if order is confirmed then redirect to app
               // with orderid, appid, and function name which is to be called for app
               $appId   = JRequest::getVar('app_id', 0);
               XiError::assert($appId, XiText::_('COM_PAYPLANS_ERROR_INVALID_APP_ID'));

               //confirm order and create payment
               $order->confirm($appId);
               // get payemnt created
               $payment = $order->getPayment();

               $url = 'index.php?option=com_payplans&view=payment&task=pay&payment_key='.$payment->getKey();
               $this->setRedirect(XiRoute::_($url, false));
               return false;
       }
	

	function complete()
	{
		$orderId = $this->getModel()->getId();
		$order 	= PayplansOrder::getInstance( $orderId)
						->complete();

		$this->setTemplate('complete');
		return true;
	}
}

