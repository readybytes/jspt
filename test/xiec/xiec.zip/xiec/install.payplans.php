<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

if (com_payplans_install() === false) {
	$this->parent->abort(JText::_('Component').' '.JText::_('Install').': '.JText::_('Custom install routine failure'));
	return false;
}

function com_payplans_install()
{
	//it is called during installation, so we should not autoload
	require_once dirname(__FILE__).DS.'installer'.DS.'installer.php';

	$installer	= new PayplansInstaller();

	return $installer->install();
}
