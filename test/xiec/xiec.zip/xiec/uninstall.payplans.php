<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

function com_uninstall()
{
	//it is called during installation, so we should not autoload
	require_once dirname(__FILE__).DS.'installer'.DS.'installer.php';

	$installer	= new PayplansInstaller();

	return $installer->uninstall();
}
