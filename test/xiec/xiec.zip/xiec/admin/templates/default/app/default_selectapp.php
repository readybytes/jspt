<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<div id="appPopup">
<form action="<?php echo $uri; ?>" method="post" name="adminForm">

	<div class="selectApps">
		<?php $app = array('adminpay', 'googlecheckout');?>
		<?php echo XiHtml::_('elements.apptype', 'type', '', array('none'=>true), $app);?>
		<span class="required">*</span>
	</div>
	<div id="appsDescription" >
			<?php foreach($app_descriptions as $appname=> $appsDesc): ?> 
				<div id="<?php echo $appname;  ?>" class="appDesc">
				<?php echo $appsDesc; ?>
				</div>
			<?php  endforeach; ?>					
	</div>
	<div  class="submitApps">
	<input id="payplans-app-new-next" class="submitButton" type="submit" name="appnext" value="<?php echo XiText::_('NEXT');?>" />
	<input type="hidden" name="task" value="new" />
	</div>
</form>
</div>
<?php 
