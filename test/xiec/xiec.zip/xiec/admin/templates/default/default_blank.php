<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<div id="blankPage">
<form action="<?php echo $uri; ?>" method="post" name="adminForm">
<?php echo $this->loadTemplate('filter'); ?>
<h1> <?php echo XiText::_("$heading"); ?></h1>
<p class="blank-page-msg"><?php echo XiText::_("$msg"); ?></p>
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
</form>
</div>
<?php 
