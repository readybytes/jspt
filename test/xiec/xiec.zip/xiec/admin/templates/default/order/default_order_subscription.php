<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die(); ?>

<div class="subscriptiondetails">
	<fieldset class="adminform">
		<legend> <?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_SUBSCRIPTION' ); ?> </legend>

		<!-- LOAD SCRIPT FOR ADDING NEW SUBSCRIPTION -->
		<?php echo $this->loadTemplate('script');?>
		<?php if($order->getId()) :?>
			<div class="actionWrapper order-edit-add-subscription">
				<span class="payplansubstext button white medium" id="<?php echo $order->getId(); ?>">
					<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_SUBSCRIPTION_ADD_SUBSCRIPTION'); ?>
				</span>
			</div>
		<?php else:?>
			<div class="info-msg">
			<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_SUBSCRIPTION_NEW_SUBSCRIPTION_CAN_BE_ADDED_AFTER_SAVE');?>
			</div>
		<?php endif; ?>


		<!-- PLAN LIST WILLL BE SHOWN -->
		<span id="planSelecter">
			<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_SUBSCRIPTION_SELECT_A_PLAN_FOR_SUBSCRIPTION');?>
			<?php echo XiHtml::_('elements.plans','order_'.$order->getId(),0,array('none'=>true)); ?>
		</span>

		<div class="order-edit-display-subscription">
		<!-- OTHER SUBSCRIPTION RECORDS -->
		<?php if(is_array($subscr_records) && !empty($subscr_records)) : ?>
			<?php echo $this->loadTemplate('order_subscription_table');?>
		<?php else :?>
			<div class="admin-edit-small-blank">
			<h3><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_NO_SUBSCRIPTION');?></h3>
			<p><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_NO_SUBSCRIPTION_DESC');?></p>
			</div>
		<?php endif;?>
		</div>
	</fieldset>
</div>