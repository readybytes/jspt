<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<div id="order">
<div class="xippElements">
<form action="<?php echo $uri; ?>" method="post" name="adminForm">

	<div class="elementColumn">
		<fieldset class="adminform">
			<legend> <?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_DETAILS' ); ?> </legend>

			<div>
				<input type="hidden" name="order_id" value="<?php echo $order->getId(); ?>" />
			</div>

			<div class="elementParams">
				<div class="paramTitle">  
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_TOOLTIP_BUYER') ?>" >
					<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_BUYER') ?>
					</span>  
				</div>
				<div class="paramValue"><?php echo XiHtml::_('elements.users', 'buyer_id', $order->getBuyer());?><span class="required">*</span></div>
			</div>

			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_TOOLTIP_SUBTOTAL') ?>" >
						<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_SUBTOTAL') ?> 
					</span>
				</div>
						
				<div class="paramValue"><input type="text" class="readonly" name="subtotal" value="<?php echo $order->getSubtotal(); ?>" /></div>
			</div>

			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_TOOLTIP_DISCOUNT') ?>" >
				 		<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_DISCOUNT') ?> 
				 	</span>
				 </div>
				<div class="paramValue"><input type="text" class="readonly" name="discount" value="<?php echo $order->getDiscount(); ?>" /></div>
			</div>

<!--			<div class="elementParams">-->
<!--			<div class="paramTitle"> <?php //echo XiText::_('COM_PAYPLANS_ORDER_EDIT_SHIPPING') ?> </div>-->
<!--			<div class="paramValue">-->
				<input type="hidden" name="shipping" value="<?php echo $order->getShipping(); ?>" />
<!--			</div>-->
<!--			</div>-->

<!--			<div class="elementParams">-->
<!--			<div class="paramTitle">  <?php //echo XiText::_('COM_PAYPLANS_ORDER_EDIT_TAX') ?> </div>-->
<!--			<div class="paramValue">-->
				<input type="hidden" name="tax" value="<?php echo $order->getTax(); ?>" />
<!--			</div>-->
<!--			</div>-->

			<div class="elementParams">
				<div class="paramTitle"> 
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_TOOLTIP_TOTAL') ?>" >
				 		<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_TOTAL') ?> 
				 	</span>
				 </div>
			<div class="paramValue"><input type="text" class="readonly" name="total" value="<?php echo $order->getTotal(); ?>" /></div>
			</div>

			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_TOOLTIP_STATUS') ?>" >
						<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_STATUS') ?> 
					</span>
				</div>
			<div class="paramValue"><?php echo XiHtml::_('elements.status', 'status', $order->getStatus(), 'ORDER');?></div>
			</div>
		</fieldset>
	</div>
	<div class="elementColumn">
	<!-- USER DETAILS START -->
	<div class="userdetail">
		<fieldset class="adminform">
			<legend> <?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_USER' ); ?> </legend>
			<?php
			if(!empty($user_record)) :
				echo $this->loadTemplate('order_user');
			else :
				echo XiText::_('COM_PAYPLANS_ORDER_EDIT_NO_USER');
			endif;?>
		</fieldset>
	</div>
	<!-- USER DETAILS END -->

	<!-- PAYMENT DETAILS START -->
	<?php echo $this->loadTemplate('order_payment'); ?>
	<!-- PAYMENT DETAILS END -->


	<!-- SUBSCRIPTION DETAILS START -->
	<?php echo $this->loadTemplate('order_subscription'); ?>
	<!-- SUBSCRIPTION DETAILS END -->


</div>
	<input type="hidden" name="task" value="save" />
</form>
</div>
</div>
<?php
