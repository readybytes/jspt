<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>

<form action="<?php echo $uri; ?>" method="post" name="adminForm">
	<table id="payplans_grid" class="payplans_grid adminlist" style="clear: both;">
		<thead>
		<!-- TABLE HEADER START -->
			<tr>
				<th class="default-grid-sno">
					<?php echo XiHtml::_('grid.sort', "NUM", 'user_id', $filter_order_Dir, $filter_order);?>
				</th>
			    <th class="default-grid-chkbox">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($records); ?>);" />
				</th>
				<th><?php echo XiHtml::_('grid.sort', "COM_PAYPLANS_USER_GRID_USER_ID", 'user_id', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "COM_PAYPLANS_USER_GRID_USER_NAME", 'name', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "COM_PAYPLANS_USER_GRID_USER_USERNAME",'username', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "COM_PAYPLANS_USER_GRID_USER_USERTYPE", 'usertype', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiText::_("COM_PAYPLANS_USER_GRID_USER_SUBSCRIPTION");?></th>				
			</tr>
		<!-- TABLE HEADER END -->
		</thead>
		
		<tbody>
		<!-- TABLE BODY START -->
			<?php $count= $limitstart;
			$cbCount = 0;
			foreach ($records as $record):?>
				<tr class="<?php echo "row".$count%2; ?>">
					<td> <?php echo $count+1; ?> </td>				
					<th class="default-grid-chkbox">
				    	<?php echo XiHtml::_('grid.id', $cbCount++, $record->{$record_key} ); ?>
				    </th>				
					<td><?php echo $record->user_id;?></td>
					<td><?php echo XiHtml::link($uri.'&task=edit&id='.$record->{$record_key}, $record->realname);?></td>
					<td><?php echo $record->username;?></td>
					<td><?php echo $record->usertype;?></td>
					<td><?php foreach($record->subscriptions as $sub):?>
								<div class="user-grid-subscription-values">									
									<div class="user-grid-subscription-value1">
										<?php echo XiHtml::link(XiRoute::_('index.php?option=com_payplans&view=subscription&task=edit&id='.$sub->subscription_id, false), PayplansHelperPlan::getName($sub->plan_id));?>
									</div>
									<div class="user-grid-subscription-value2">
										<?php echo XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($sub->status));?></div>
								</div>
								<div class='clr'></div>								
						<?php endforeach;?>
					</td>
				</tr>
			<?php $count++;?>
			<?php endforeach;?>
		<!-- TABLE BODY END -->
		</tbody>
		
		<tfoot>
			<tr>
				<td colspan="7">
					<?php echo $pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
	</table>

	<input type="hidden" name="filter_order" value="<?php echo $filter_order;?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $filter_order_Dir;?>" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
</form>
<?php 
