<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<div id ="user">
<div class="xippElements">
<form action="<?php echo $uri; ?>" method="post" name="adminForm">
	<div class="elementColumn">
		<fieldset class="adminform">
			<legend> <?php echo XiText::_('COM_PAYPLANS_USER_EDIT_USER_DETAILS' ); ?> </legend>
			
			<div class="elementParams">
				<div class="paramTitle"> <?php echo XiText::_('COM_PAYPLANS_USER_EDIT_USER_ID') ?> </div>
				<div class="paramValue"><?php echo $user->getId(); ?>
				<input type="hidden" name="user_id" value="<?php echo $user->getId(); ?>" />
				</div>
			</div>
			
			<div class="elementParams">
				<div class="paramTitle"> <?php echo XiText::_('COM_PAYPLANS_USER_EDIT_USERNAME') ?> </div>
				<div class="paramValue"><?php echo XiHtml::link(XiRoute::_("index.php?option=com_users&view=user&task=edit&cid=".$user->getId(), false), $user->getUsername()); ?>	</div>				
			</div>

	<div class="elementParams">
				<div class="paramTitle"><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_USER_NAME') ?> </div>
				<div class="paramValue"><?php echo $user->getRealname(); ?></div>				
			</div>
			
	<div class="elementParams">
				<div class="paramTitle"> <?php echo XiText::_('COM_PAYPLANS_USER_EDIT_USER_EMAIL') ?> </div>
				<div class="paramValue"><?php echo $user->getEmail(); ?>	</div>				
			</div>
			
	<div class="elementParams">
				<div class="paramTitle"> <?php echo XiText::_('COM_PAYPLANS_USER_EDIT_USER_USERTYPE') ?> </div>
				<div class="paramValue"><?php echo $user->getUsertype(); ?></div>				
			</div>
			
	<div class="elementParams">
				<div class="paramTitle"> <?php echo XiText::_('COM_PAYPLANS_USER_EDIT_USER_REGISTERDATE') ?> </div>
				<div class="paramValue"><?php echo $user->getRegisterDate(); ?></div>				
			</div>
			
	<div class="elementParams">
				<div class="paramTitle"> <?php echo XiText::_('COM_PAYPLANS_USER_EDIT_USER_LASTVISITDATE') ?> </div>
				<div class="paramValue"><?php echo $user->getLastvisitDate(); ?>	</div>				
			</div>
		</fieldset>
	</div>

	<div class="elementColumn">
		<fieldset class="adminform">
			<legend> <?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER'); ?> </legend>
			<?php 
			if(is_array($order_records) && !empty($order_records)) : 
				echo $this->loadTemplate('user_order');
			else :
				echo XiText::_('COM_PAYPLANS_USER_EDIT_USER_NO_SUBSCRIPTION');
			endif;?>
		</fieldset>		
	</div>
	
	<input type="hidden" name="task" value="save" />
</form>
</div>
</div>
<?php 
