<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>

<div id="subscription">
<div class = "xippElements">
<form action="<?php echo $uri; ?>" method="post" name="adminForm">
	<div class="elementColumn">
		<fieldset class="adminform">
			<legend> <?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_DETAILS' ); ?> </legend>
	
				<input type="hidden" name="subscription_id" value="<?php echo $subscription->getId(); ?>" />
	
			<div class="elementParams">
				<div class="paramTitle"> 
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_TOOLTIP_USER') ?>">
						<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_USER') ?>  
					</span>		
				</div>
				<div class="paramValue"><?php echo PayplansHelperUser::getName($subscription->getBuyer()); ?>				
				<input type="hidden" name="user_id" value="<?php echo $subscription->getBuyer(); ?>" /></div>	
			</div>

			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_TOOLTIP_PLAN') ?>">
						<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_PLAN') ?>  
					</span>
				</div>				
				<div class="paramValue"><?php echo PayplansHelperPlan::getName(array_shift($subscription->getPlans())); ?>				
				<input type="hidden" name="plan_id" value="<?php echo array_shift($subscription->getPlans()); ?>" /></div>	
			</div>
			
			<div class="elementParams">
				<div class="paramTitle"> 
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_TOOLTIP_ORDER_ID') ?>">
						<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_ORDER_ID') ?>  
					</span>		
				</div>				
				<div class="paramValue"><?php echo $subscription->getOrder(); ?>				
				<input type="hidden" name="order_id" value="<?php echo $subscription->getOrder(); ?>" /></div>	
			</div>
			
			<div class="elementParams">
				<div class="paramTitle"> 
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_TOOLTIP_STATUS') ?>">
						<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_STATUS') ?>  
					</span>
				</div>
				<div class="paramValue"><?php echo XiHtml::_('elements.status', 'status', $subscription->getStatus(), 'SUBSCRIPTION');?>
				</div>				
			</div>
			
			
			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_TOOLTIP_DATE') ?>">
						<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_SUBSCRIPTION_DATE') ?>  
					</span>
				</div>
				<div class="paramValue"><?php echo XiHtml::_('calendar', $subscription->getSubscriptionDate()->toMySql(), 'subscription_date', 'subscription_date');?>
				</div>		
			</div>
			

			<div class="elementParams">
				<div class="paramTitle"> 
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_TOOLTIP_EXPIRATION_DATE') ?>">
						<?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_EXPIRATION_DATE') ?>  
					</span>
				</div>
				<div class="paramValue"><?php echo XiHtml::_('calendar', $subscription->getExpirationDate()->toMySql(), 'expiration_date', 'expiration_date');?></div>		
			</div>					
		</fieldset>


	
	
		<fieldset class="adminform">
			<legend> <?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_PARAMETERS'); ?> </legend>
			<div><?php echo $subscription->getParamsHtml('params');?></div>
		</fieldset>			
	</div>
	
	<div class="elementColumn">
		<!-- USER DETAILS START -->
		<div class="userDetail">
			<fieldset class="adminform">
				<legend> <?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_USER_DETAILS' ); ?> </legend>
					<?php 
					if(!empty($user)) : 
						echo $this->loadTemplate('subscription_user');
					else :
						echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_NO_USER');
					endif;?>
			</fieldset>
		</div>
		<!-- USER DETAILS END -->
		
		<!-- ORDER DETAILS START -->
		<div class="orderDetail">
			<fieldset class="adminform">
				<legend> <?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_ORDER' ); ?> </legend>
				<?php 
				if(!empty($user)) : 
					echo $this->loadTemplate('subscription_order');
				else :
					echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_NO_ORDER');
				endif;?>
			</fieldset>
		</div>
		<!-- ORDER DETAILS END -->
	</div>
	<input type="hidden" name="task" value="save" />
</form>
</div>
</div>
<?php 
