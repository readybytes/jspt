<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansadminViewPayment extends XiView
{
	protected function _adminGridToolbar()
	{
		//XiHelperToolbar::customX( 'copy', 'copy.png', 'copy_f2.png', 'Copy', true );

		// can not trash the payment,
		// XITODO : if mistake is done in filling then edit and correct or set status to Reverse
		// XiHelperToolbar::deleteList();
		XiHelperToolbar::deleteList();
		XiHelperToolbar::divider();
		XiHelperToolbar::editListX();
		XiHelperToolbar::openPopup('newPayment','preview','Create Plugin');
	}
	
	protected function _adminEditToolbar()
	{
		XiHelperToolbar::save();
		XiHelperToolbar::apply();
		XiHelperToolbar::cancel();
	}

	function edit($tpl=null, $itemId=null)
	{
		$itemId  = ($itemId === null) ? $this->getModel()->getState('id') : $itemId;

		$payment = PayplansPayment::getInstance( $itemId);

		// if new payment is created the get data from post
		if(!$itemId){
			$orderId = JRequest::getVar('order_id',0);
			$adminApps = array_shift(XiFactory::getInstance('app', 'model')
											->loadRecords(array('type'=>'adminpay', 'published'=> 1)));

			$appId = $adminApps->app_id;

			XiError::assert($appId, XiText::_('COM_PAYPLANS_ERROR_INVALID_APPLICATION_ID'));

			$payment->set('order_id', $orderId);
			$payment->set('app_id',   $appId);
		}

		// get order
		$order = PayplansOrder::getInstance($payment->getOrder());
		// set amount in payment, whic can be used with payment app
		if(!$itemId){
			$payment->set('amount', $order->getTotal());
		}

		// get app transaction record html
		$results = PayplansHelperEvent::trigger('onPayplansPaymentRecord', $args = array($payment),'payment',$payment);

		$this->assign('transaction_html', implode(' ',$results));
		$this->assign('payment', $payment);
		$this->assign('order', $order);
		$this->assign('user', PayplansUser::getInstance($payment->getBuyer()));
		return true;
	}

	public function _getDynamicJavaScript()
	{
		$url		 =	"index.php?option=com_{$this->_component}&view={$this->getName()}";

		ob_start(); ?>

		payplansAdmin.payment_newPayment = function()
		{
			xi.url.openInModal("<?php echo "$url&task=newPayment";?>");
			return false;
		}

		<?php
		$js = ob_get_contents();
		ob_end_clean();
		return $js;
	}

	public function newPayment()
	{
		$this->_setAjaxWinTitle('Create A New Payment');

		$onClick = "xi.submitAjaxForm('payplans-payment-new-next');";
		//$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_AJAX_NEXT_BUTTON'),$onClick );
		$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_AJAX_CANCEL_BUTTON'),'xiWindowHide();');
		$this->_setAjaxWinAction();
		$this->_setAjaxWinHeight('150');
		return true;
	}
}