<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansadminViewApp extends XiView
{
	public function _displayGrid($records)
	{
		$this->assign('app_names', PayplansHelperApp::getXmlData('name'));
		return parent::_displayGrid($records);
	}
	
	public function selectApp()
	{
		$this->_setAjaxWinTitle(XiText::_('COM_PAYPLANS_APP_SELECT_APP_TITLE'));
		$onClick = "xi.submitAjaxForm('payplans-app-new-next');";
		$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_AJAX_NEXT_BUTTON'),$onClick );
		$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_AJAX_CANCEL_BUTTON'),'xiWindowHide();');

		$this->_setAjaxWinAction();
		$this->_setAjaxWinHeight('150');
		//ON load init show help functionality
		XiFactory::getAjaxResponse()->addScriptCall('xi.apps.inithelp();');
		$this->assign('apps', PayplansHelperApp::getApps());

		$this->assign('app_names', PayplansHelperApp::getXmlData('name'));
		$this->assign('app_descriptions', PayplansHelperApp::getXmlData('description'));
		return true;
	}

	function edit($tpl=null,$appType=null, $itemId=null)
	{
		$itemId = ($itemId === null) ? $this->getModel()->getState('id') : $itemId;

		//now record is always an array, pick the first only
		$record 	= $this->getModel()->loadRecords(array('id'=>$itemId),array(), true);
		$record 	= array_shift($record);
		$recordKey 	= $this->getModel()->getTable()->getKeyName();

		// If it is new record to add, then we need to collect apptype from request
		if(!$itemId){
			$appType =	JRequest::getVar('type',$appType);
			XiError::assert(($appType), XiText::_('COM_PAYPLANS_ERROR_APP_NO_APPLICATION_TYPE_PROVIDED'));
			$record->type = $appType;
		}

		// Call PayplansApp GetInstance as it will autoload all apps
		$appObj	= PayplansApp::getInstance($itemId, $record->type);

		$this->assign('app_names', PayplansHelperApp::getXmlData('name'));
		
		$helpMessage = PayplansHelperApp::getXmlData('help');
		$this->assign('help_message', $helpMessage[$appObj->getType()]);
		$this->assign('app', $appObj);
		return true;
	}

	protected function _adminGridToolbar()
	{
		XiHelperToolbar::publish();
		XiHelperToolbar::unpublish();
		XiHelperToolbar::divider();
		XiHelperToolbar::customX( 'copy', 'copy.png', 'copy_f2.png', 'Copy', true );
		XiHelperToolbar::deleteList();
		XiHelperToolbar::divider();
		XiHelperToolbar::editListX();
		XiHelperToolbar::openPopup('selectApp','preview','New Application Instance');
	}

	protected function _adminEditToolbar()
	{
		XiHelperToolbar::save();
		XiHelperToolbar::apply();
		XiHelperToolbar::cancel();
	}
	
	public function _getDynamicJavaScript()
	{
		$url	=	"index.php?option=com_payplans&view={$this->getName()}";
		ob_start(); ?>

		payplansAdmin.app_selectApp = function()
		{
			xi.url.openInModal("<?php echo "$url&task=selectApp"; ?>");
			// do not submit form
			return false;
		}

		<?php
		$js = ob_get_contents();
		ob_end_clean();
		return $js;
	}
}

