<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansadminViewSubscription extends XiView
{
	protected function _adminGridToolbar()
	{
		//XiHelperToolbar::customX( 'copy', 'copy.png', 'copy_f2.png', 'Copy', true );
		XiHelperToolbar::deleteList();
		XiHelperToolbar::divider();
		XiHelperToolbar::editListX();
		XiHelperToolbar::openPopup('newSubscription','new','Create Subscription');
	}

	protected function _adminEditToolbar()
	{
		XiHelperToolbar::save();
		XiHelperToolbar::apply();
		XiHelperToolbar::cancel();
	}
	
	function edit($tpl=null)
	{
		$subscription = $this->get('subscription');		
		$this->assign('order', PayplansOrder::getInstance($subscription->getOrder()));
		$this->assign('user', PayplansUser::getInstance( $subscription->getBuyer()));

		return true;
	}

	public function _getDynamicJavaScript()
	{
		$url	=	"index.php?option=com_{$this->_component}&view={$this->getName()}";
		ob_start(); ?>

		payplansAdmin.subscription_newSubscription = function()
		{
			xi.url.openInModal("<?php echo "$url&task=newSubscription"; ?>");
			return false;
		}

		<?php
		$js = ob_get_contents();
		ob_end_clean();

		// atttach jquery file with document
		$url	=	"administrator/components/com_payplans/templates/default/subscription/";
		XiHtml::script('subscription.js', $url);

		return $js;
	}

	public function newSubscription()
	{
		$this->_setAjaxWinTitle('Create a New Subscription');
		$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_AJAX_CANCEL_BUTTON'),'xiWindowHide();');
		$this->_setAjaxWinAction();
		$this->_setAjaxWinHeight('100');

		return true;
	}
}