<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansadminViewOrder extends XiView
{
	protected function _adminGridToolbar()
	{
		//XiHelperToolbar::customX( 'copy', 'copy.png', 'copy_f2.png', 'Copy', true );
		XiHelperToolbar::deleteList();
		XiHelperToolbar::divider();
		XiHelperToolbar::editListX();
		XiHelperToolbar::addNewX('new');
	}
	
	function edit($tpl=null, $itemId=null)
	{
		$itemId = ($itemId === null) ? $this->getModel()->getState('id') : $itemId;
		$order	= PayplansOrder::getInstance( $itemId);
			
		// get all subscription/payment of this order id
		$subsRecords 	= XiFactory::getInstance('subscription', 'model')
									->loadRecords(array('order_id'=>$itemId));
		$paymentRecords = XiFactory::getInstance('payment', 'model')
									->loadRecords(array('order_id'=>$itemId));
		$userRecord 	= XiFactory::getInstance('user', 'model')
									->loadRecords(array('user_id'=>$order->getBuyer()), array('limit'));
									
		// get lib instance of subscription/payment
		$user		  = PayplansUser::getInstance();
		$payment	  = PayplansPayment::getInstance();
		$subscription = PayplansSubscription::getInstance();		
		
		$this->assign('user', 		  	$user);
		$this->assign('order', 		  	$order);
		$this->assign('payment', 		$payment);
		$this->assign('subscription', 	$subscription);
		
		$this->assign('user_record',  	array_shift($userRecord));
		$this->assign('subscr_records',  	$subsRecords);
		$this->assign('payment_records', $paymentRecords);
		return true;
	}
}

