<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


 class PayplansadminViewUser extends XiView
{
	protected function _adminGridToolbar()
	{
		XiHelperToolbar::editListX();	
	}
	
	protected function _adminEditToolbar()
	{
		XiHelperToolbar::save();
		XiHelperToolbar::apply();
		XiHelperToolbar::cancel();
	}
	
	function _displayGrid($records)
	{
		parent::_displayGrid($records);

		$subRecords   = array();
		$orderRecords = array();
		// get subscription of each user
		foreach($records as $record){
			$record->subscriptions = XiFactory::getInstance('subscription', 'model')
												->loadRecords(array('user_id'=>$record->user_id));			
		}

		return true;
	}
	
	function edit($tpl=null,$itemId = null)
	{
		$itemId  = ($itemId === null) ?  $this->getModel()->getState('id') : $itemId;
		
		// assert if user id is not available
		XiError::assert($itemId, XiText::_('COM_PAYPLANS_ERROR_INVALID_USER_ID'));
		
		// get all subscription/payment of this order id
		$subsRecords = XiFactory::getInstance('subscription', 'model')
									->loadRecords(array('user_id'=>$itemId));
		$orderRecords = XiFactory::getInstance('order', 'model')
									->loadRecords(array('buyer_id'=>$itemId));
		
		$user 		  = PayplansUser::getInstance( $itemId);
		$order 		  = PayplansOrder::getInstance();
		$payment	  = PayplansPayment::getInstance();		
		$subscription = PayplansSubscription::getInstance();

		$this->assign('user', 			$user);
		$this->assign('order', 			$order);
		$this->assign('payment', 		$payment);
		$this->assign('subscription', 	$subscription);
		
		$this->assign('subscr_records',  	$subsRecords);
		$this->assign('order_records',  	$orderRecords);
		
		$pane	= JPane::getInstance('sliders');
		$this->assignRef( 'pane'		, $pane );
		return true;
	}
}

