<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();

class PayplansadminControllerSubscription extends XiController
{

	/**
	 * Saves an item (new or old)
	 */
	public function _save(array $data, $itemId=null)
	{
		$data['params'] 	= PayplansHelperParam::collectParams($data,'params');

		/*
		 * #1 : Check for order_id
		 * #2 : If order_id is not set then create new order and set order_id in data
		 * #3 : creat or update subscription
		 * #4 : load order with $data['order_id']
		 * #5 : refresh order, so that it will have correct data of all subscription
		 */

		// if order id is not in data, create instance order
		$order = PayplansOrder::getInstance();
		if(!isset($data['order_id']) || ! $data['order_id']){
			XiError::assert(isset($data['user_id']) && !empty($data['user_id']), XiText::_('COM_PAYPLANS_ERROR_INVALID_USER_TO_CREATE_ORDER'));
			$order->set('buyer_id', $data['user_id'])->save();
			$data['order_id'] = $order->getId();
		}

		XiError::assert(isset($data['order_id']) && !empty($data['order_id']), XiText::_('COM_PAYPLANS_ERROR_INVALID_OPTION_FOR_ORDER_SELECTION'));
		// save subscription
		$subscription = PayplansSubscription::getInstance( $itemId)
							->setPlan(PayplansPlan::getInstance( $data['plan_id']))
							->bind($data)
							->save();

		// and update Subscription
		// load order and Refresh order
		$order->load($data['order_id'])->refresh();

		return $subscription;
	}

	public function newSubscription()
	{
		$this->setTemplate('newsubscription');
		return true;
	}

	/*
	 * Attach plan with subscription
	 *
	 * If createNewOrder is true
	 *    1.a) user_id must be in post data
	 *    1.b) set this user id to user_id of subscription
	 * else
	 * 	  2.a) get order id  and load order
	 * 	  2.b) set buyer_id of order to user_id or subscription
	 *
	 * 3) create a plan for subscription
	 */

	public function edit($itemId = null)
	{
		$itemId = ($itemId === null) ? $this->getModel()->getId() : $itemId;
		$subscription = PayplansSubscription::getInstance( $itemId);
		$order 		  = PayplansOrder::getInstance();

		if(!$itemId){
			$planId = JRequest::getVar('plan_id',0);
			$subscription->setPlan(PayplansPlan::getInstance( $planId));

			$orderId = JRequest::getVar('order_id',0);
			$subscription->set('order_id', $orderId);
			$subscription->set('user_id', PayplansOrder::getInstance( $orderId)->getBuyer());
		}

		$this->getView()->assign('subscription', $subscription);

		//set editing template
		$this->setTemplate('edit');
		return true;
	}
}