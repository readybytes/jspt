<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();

// Get installer libraries
jimport( 'joomla.installer.installer' );
jimport('joomla.installer.helper');
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');


//load helper
require_once dirname(__FILE__).DS.'helper.php';

class PayplansInstaller extends JObject
{
	function uninstall()
	{
		$this->disableExtensions();
	}

	function install()
	{
		//#1 : file have already copied

		//#2 : Now apply version to verion db updates
		$this->applyPatches();

		//#3 : Install additional extensions
		//These are in upgrade mode.
		$this->installExtensions();

		$this->enableExtensions();
		//check if error occured
		$errors = PayplansInstallHelper::addError(null,true);

		include_once dirname(__FILE__).DS.'message.php';
		//if no errors simply return
		if(empty($errors)){
			return true;
		}

		//some errors are there display them and write into errlog
		$buffer	= "Installation logs on ". date('D, d M Y H:i:s',time()) . '\n';
		foreach($errors as $err)
			$buffer = $buffer.$err.'\n';

		$logFileName = "install.".time().".log";
		$res = JFile::write(dirname(__FILE__).DS.$logFileName, $buffer);

		//put error message
		$app = XiFactory::getApplication();
		$app->enqueueMessage(JText::sprintf('INSTALLATION ERROR. PLEASE SEE LOG FILE FOR DETAILS %s', $logFileName));

		//if we were not able to write file show permission error
		if(!$res)
			$app->enqueueMessage(JText::sprintf('NOT ABLE TO WRITE LOG FILE - %s', $logFileName));

		return true;
	}

	/**
	 * @param string  $zipfile : file to install
	 * @return boolean : success or failed
	 */
	function installExtensions($appsPath=null,$delFolder=true)
	{
		//if no path defined, use default path
		if($appsPath==null)
			$appsPath = dirname(__FILE__).DS.'apps';

		//get instance of installer
		$installer =  new JInstaller();
		//$installer->setOverwrite(true);

		$apps	= JFolder::folders($appsPath);

		//no apps there to install
		if(empty($apps))
			return true;

		//install all apps
		foreach ($apps as $app)
		{
			$msg = " ". $app . ' : Installed Successfully ';

			// Install the packages
			if($installer->install($appsPath.DS.$app)==false)
				$msg = " ". $app . ' : Installation Failed. Please try to reinstall. [Supportive plugin/module for PayPlans]';

			//enque the message
			JFactory::getApplication()->enqueueMessage($msg);

			//XITODO : delete the folder of successfull installed files
		}

		if($delFolder)
			JFolder::delete($appsPath);
		return true;
	}

	/*
	 * We might want to do some code/db modification
	 * whenever we install the component
	 *
	 * Here we will maintain, what have been patched,
	 * and what needs to be patched
	 * We will apply patches in order,
	 * so solving lots of complex problems
	 */
	function applyPatches($lastPatch=null)
	{
		//include patcher class
		require_once dirname(__FILE__).DS.'patches'.DS.'patches.php';

		//get patch to be applied from database
		$lastPatch = PayplansInstallHelper::queryPatch();
		return PayplansPatch::applyPatches($lastPatch);
	}

	function enableExtensions()
	{
		return $this->updateExtensions(1);
	}

	function disableExtensions()
	{
		return $this->updateExtensions(0);
	}

	function updateExtensions($enable)
	{
		$plugins	= array( 
						array('system',		'payplans'),
					 	array('payplans',	'discount'),
					 	array('payplansmigration',	'acctexp'),
					 	array('payplansmigration',	'ambrasubs'),
					 	array('payplansmigration',	'sample'),
						array('payplansregistration', 'joomla'),
					    array('payplansregistration', 'jomsocial'),
					    array('payplansregistration', 'auto')
					  );
					  
		$modules	= array(
					'mod_payplans_about'  		=> 'payplans-admin-dashboard',
					'mod_payplans_setup'  		=> 'payplans-admin-dashboard',
					'mod_payplans_migration'  	=> 'payplans-admin-dashboard',
					'mod_payplans_search' 		=> 'payplans-admin-dashboard-bottom'
				);
						
		foreach($plugins as $plugin){
			$folder = $plugin[0];
			$pluginName = $plugin[1];
			PayplansInstallHelper::changePluginState($pluginName, $enable, $folder);
		}

		foreach($modules as $module=>$position)
			PayplansInstallHelper::changeModuleState($module, $position, $enable);


		// special case order mod_payplans_setup at least order
		$db		=& JFactory::getDBO();
		$query	= ' UPDATE ' . $db->nameQuote( '#__modules' )
			. ' SET '    . $db->nameQuote('ordering').'='.$db->Quote(-100)
		        . ' WHERE '  . $db->nameQuote('module').'='.$db->Quote('mod_payplans_setup');
		$db->setQuery($query);
		$db->query();
	}
}

