INSERT IGNORE INTO `#__payplans_app` (`app_id`, `title`, `type`, `core_params`, `app_params`, `ordering`, `published`) 
VALUES
(101, 'Activation Email', 'email', 'applyAll=1\n\n', 'send_to=\nsend_cc=\nsend_bcc=\nsubject=Thanks for subscribing at [[CONFIG_SITE_NAME]]\ncontent=PHA+SGkgW1tVU0VSX1JFQUxOQU1FXV0sPC9wPg0KPHA+VGhhbmsgeW91IGZvciBzdWJzY3JpYmluZyBhdCBbW0NPTkZJR19TSVRFX05BTUVdXSAhPC9wPg0KPHA+WW91ciBwdXJjaGFzZSBvZiBbW1BMQU5fVElUTEVdXSBoYXZlIGJlZW4gY29tcGxldGVkLiBXZSBhcmUgYSB0ZWFtIG9mIHByb2Zlc3Npb25hbCB3ZWIgZGV2ZWxvcGVycyBkZWRpY2F0ZWQgdG8gZGVsaXZlciBoaWdoLXF1YWxpdHkgZXh0ZW5zaW9ucywgdW5pcXVlIHNvbHV0aW9ucyBhbmQgYWR2YW5jZWQgc2VydmljZXMgZm9yIEpvb21sYSEsIHRoZSBtb3N0IHBvcHVsYXIgb3BlbiBzb3VyY2UgQ29udGVudCBNYW5hZ2VtZW50IFN5c3RlbSAoQ01TKSB3b3JsZHdpZGUuPC9wPg0KPHA+PHN0cm9uZz4gWW91ciBkZXRhaWxzIGF0IG91ciB3ZWJzaXRlIDwvc3Ryb25nPjwvcD4NCjxwPsKgPC9wPg0KPHVsPg0KPGxpPlVzZXJuYW1lIDogW1tVU0VSX1VTRVJOQU1FXV08L2xpPg0KPGxpPkFjdGl2YXRpb24gRGF0ZSA6IFtbU1VCU0NSSVBUSU9OX1NVQlNDUklQVElPTl9EQVRFXV08L2xpPg0KPGxpPkV4cGlyYXRpb24gRGF0ZSA6IFtbU1VCU0NSSVBUSU9OX0VYUElSQVRJT05fREFURV1dPC9saT4NCjwvdWw+DQo8ZGl2PkZvciBhbnkgZnVydGhlciBxdWVyeSB5b3UgY2FuIHJlcGx5IHRvIHRoaXMgZW1haWwgb3IgY2FuIGNvbnRhY3QgdXMgYXQgeHh4eEB5eXl5LmNvbTwvZGl2Pg0KPGRpdj5UaGFua3MgYWdhaW48L2Rpdj4NCjxkaXY+W1tDT05GSUdfU0lURV9OQU1FXV08L2Rpdj4NCjxkaXY+W1tDT05GSUdfU0lURV9VUkxdXTwvZGl2Pg0KPHA+PHN0cm9uZz4gPC9zdHJvbmc+PC9wPg0KPHA+wqA8L3A+\nhtml_format=1\non_status=1601\n\n', 2, 1),
(102, 'Expiration Email', 'email', 'applyAll=1\n\n', 'send_to=\nsend_cc=\nsend_bcc=\nsubject=Subscription for [[PLAN_TITLE]] expired at [[CONFIG_SITE_NAME]]\ncontent=PHA+wqA8L3A+DQo8cD5IaSBbW1VTRVJfUkVBTE5BTUVdXSw8L3A+DQo8cD5UaGFuayBZb3Ugc28gbXVjaCBmb3IgeW91ciBwYXN0IHN1YnNjcmlwdGlvbiBvZiBbW1BMQU5fVElUTEVdXSBhdCBbW0NPTkZJR19TSVRFX05BTUVdXS48L3A+DQo8cD5XZSBhcHByZWNpYXRlZCB0aGUgb3Bwb3J0dW5pdHkgdG8gc2VydmUgeW91IGFzIGEgdmFsdWVkIGN1c3RvbWVyLiBIb3dldmVyIEkgbm90aWNlIHlvdXIgc3Vic2NyaXB0aW9uIGV4cGlyZWQgb24gwqBbW1NVQlNDUklQVElPTl9FWFBJUkFUSU9OX0RBVEVdXSAsIGFuZCB5b3UgaGF2ZSBub3QgeWV0IHJlbmV3ZWQgeW91ciBzZXJ2aWNlLjwvcD4NCjxwPklmIHlvdSBleHBlcmllbmNlZCBhbnkgcHJvYmxlbSBkdXJpbmcgeW91ciBzdWJzY3JpcHRpb24sIHBsZWFzZSBsZXQgdXMga25vdyAoeHh4eEB5eXl5LmNvbSkgc28gdGhhdCB3ZSBjYW4gY29ycmVjdCBpdCBpbW1lZGlhdGVseS48L3A+DQo8cD48c3Ryb25nPllvdXIgZGV0YWlscyBhdCBvdXIgd2Vic2l0ZTwvc3Ryb25nPjwvcD4NCjxwPjxzdHJvbmc+PHNwYW4gc3R5bGU9ImZvbnQtd2VpZ2h0OiBub3JtYWw7Ij4gDQo8dWw+DQo8bGk+VXNlcm5hbWUgOiBbW1VTRVJfVVNFUk5BTUVdXTwvbGk+DQo8bGk+QWN0aXZhdGlvbiBEYXRlIDogW1tTVUJTQ1JJUFRJT05fU1VCU0NSSVBUSU9OX0RBVEVdXTwvbGk+DQo8bGk+RXhwaXJhdGlvbiBEYXRlIDogW1tTVUJTQ1JJUFRJT05fRVhQSVJBVElPTl9EQVRFXV08L2xpPg0KPC91bD4NCjwvc3Bhbj48L3N0cm9uZz48L3A+DQo8cD5Gb3IgYW55IFF1ZXJ5IHlvdSBjYW4gcmVwbHkgdG8gdGhpcyBFLW1haWwuPC9wPg0KPHA+VGhhbmtzIGFnYWluPC9wPg0KPHA+wqA8L3A+\nhtml_format=1\non_status=1603\n\n', 3, 1),
(103, 'Offline Payment', 'offlinepay', '', 'merchant_email=\n\n', 3, 1),
(104, 'Paypal Payments', 'paypal', '', 'merchant_email=enter_your_email_here@paypal.com\nmerchant_id=YS812092\ncurrency=USD\nsandbox=0\nsandbox_merchant_email=\nsandbox_customer_email=\n\n', 4, 1),
(105, 'Create Author', 'jusertype', '', 'on_status=1601\njusertype=Author\n\n', 5, 1),
(106, 'Create Editor', 'jusertype', '', 'on_status=1601\njusertype=Editor\n\n', 6, 1),
(107, 'Create Publisher', 'jusertype', '', 'on_status=1601\njusertype=Publisher\n\n', 7, 1)
;


INSERT IGNORE INTO `#__payplans_plan` (`plan_id`, `title`, `published`, `visible`, `ordering`, `description`, `time`, `payment`) 
VALUES
(101, 'Community', 1, 1, 1, '<p>Easy to use, burstable power when you need it. Clustered reliability meets entry-level web hosting.</p>\r\n<p class="meta"><strong>Great for:</strong> Start-ups, Newbies, Devs, Designers</p>', 'expiration=010000000000\n\n', 'price=200\n\n'),
(102, 'Professional', 1, 1, 2, '<p>New to Linux? Need a control panel VPS? Manage your websites with dedicated resources and unmatched flexibility.</p>\r\n<p><strong> Great for:</strong> Small Businesses, Resellers, Devs, Designers</p>', 'expiration=010000000000\n\n', 'price=500\n\n'),
(103, 'Premium', 1, 1, 3, '<p>Developer inspired utility VPS, with high-end hardware, top-tier connectivity and superior virtualization technology.</p>\r\n<p><strong>Great for: </strong>Devs, Admins, Linux geeks, Root Access, SaaS</p>', 'expiration=010000000000\n\n', 'price=300\n\n'),
(104, 'Enterprise', 1, 0, 4, '<p>A high-performance server with control panel that has quickly become the go-to platform for high-end hosting.</p>\r\n<p><strong>Great for:</strong> Big traffic, big projects, single tenant needs</p>', 'expiration=010000000000\n\n', 'price=2000\n\n')
;


INSERT IGNORE INTO `#__payplans_planapp` (`planapp_id`,`plan_id`, `app_id`) VALUES
(501, 104, 103),
(502, 103, 104),
(503, 102, 104),
(504, 101, 104),
(505, 102, 105),
(506, 103, 106),
(507, 104, 107)
;
