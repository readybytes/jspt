<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage	Discount
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Payplans Discount Plugin
 *
 * @author shyam
 */
class plgPayplansDiscount extends XiPlugin
{

	public function onPayplansSystemStart()
	{
		//add discount app path to app loader
		$appPath = dirname(__FILE__).DS.'discount'.DS.'app';
		PayplansHelperApp::addAppsPath($appPath);

		return true;
	}


	// on render of order, display output
	public function onPayplansViewBeforeRender(XiView $view, $task)
	{
		if(!($view instanceof PayplanssiteViewOrder)){
			return true;
		}

		if($task != 'confirm'){
			return true;
		}

		$this->_assign('orderId', $view->getModel()->getId());
		return $this->_render('orderconfirm');
	}

	// on render of order, display output
	public function onPayplansDiscountRequest($orderId, $discountCode)
	{
		//trigger the discount
		$order = PayplansOrder::getInstance($orderId);
		$args  = array($order, $discountCode);
		$results = PayplansHelperEvent::trigger('onPayplansApplyDiscount', $args, '', $order);

		$error = '';
		$allFalse = true;
		foreach($results as $result){
			// check if app returned true/false OR error string
			if(is_bool($result)==false){
				$error .= $result . ' ';
			}

			if($result !== false){
				$allFalse = false;
			}
		}

		if($allFalse){
			$error = XiText::_('COM_PAYPLANS_APP_DISCOUNT_ERROR_INVALID_CODE');
		}

		// order have been updated
		$response = XiFactory::getAjaxResponse();
		// if error = '', then no error will be shown
		$response->addScriptCall('xi.order.discount.displayError',$error);
		$response->addScriptCall('xi.jQuery(\'#discount\').find(\'.amount\').html', $order->getDiscount());
		$response->addScriptCall('xi.jQuery(\'#totalamount\').find(\'.amount\').html',$order->getTotal());

		$response->sendResponse();
	}
}
