<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage	Discount
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


/**
 * Discount System
 * @author shyam
 */
class PayplansAppDiscount extends PayplansApp
{
	//inherited properties
	protected $_location	= __FILE__;

	public function _isApplicable(PayplansIfaceApptriggerable $refObject = null)
	{
		// if not with reference to order then return
		if(!($refObject instanceof PayplansOrder)){
			return false;
		}

		//if coupon is published as per dates
		$publish_start 	= $this->getAppParam('publish_start', '');
		$publish_end	= $this->getAppParam('publish_end','');

		$now = new XiDate();
		if($publish_start != ''){
			$start = new XiDate($publish_start);
			if($start->toUnix() > $now->toUnix()){
				return false;
			}
		}

		if($publish_end != ''){
			$end = new XiDate($publish_end);
			if($end->toUnix() < $now->toUnix()){
				//also disable the discount
				$this->published = false;
				$this->save();
				return false;
			}
		}
		return parent::_isApplicable($refObject);
	}

	public function onPayplansApplyDiscount(PayplansOrder $order, $discountCode)
	{
		// is equal to my discount code
		if($discountCode != $this->getAppParam('coupon_code', false)){
			return false;
		}

		//order already have discount
		if(floatval($order->getDiscount())){
			return XiText::_('COM_PAYPLANS_APP_DISCOUNT_ERROR_ORDER_ALREADY_HAVE_DISCOUNT');
		}

		// if coupon have been used completely
		$usedBy = $this->getAppParam('used_quantity','');
		$usedBy = ($usedBy == '') ? array() : explode(',', $usedBy);
		
		
		// unlimited usage if allowed quantity is ''
		$allowedQuantity = $this->getAppParam('allowed_quantity', '');
		if($allowedQuantity !== '' 
				&& $allowedQuantity <= count($usedBy)){
			return XiText::_('COM_PAYPLANS_APP_DISCOUNT_ERROR_CODE_ALLOWED_QUANTITY_CONSUMED');
		}

		//Only required : if we have multiple discount per order
		//used_quantity : csv of order_id
		//if(in_array($order->getId(), $usedBy)){
		//	return true;
		//}

		//if order have multiple subscriptions, we need apply discount on each
		$discountUsed = false;
		foreach($order->getSubscriptions() as $subscription){
			$price 		= $subscription->getPrice();
			$discount 	= $subscription->getDiscount();

			if($this->_checkAllowed($subscription, $order) ==false){
				continue;
			}

			//calculate discount
			$actualDiscount = $this->_calculateDiscount($price);
			$actualDiscount = ($price < $actualDiscount ) ? $price : $actualDiscount ;

			//update the subscription with discount, old discount will be lapsed
			$subscription->setDiscount($actualDiscount)->save();
			$discountUsed = true;
		}

		// if discount have been used then update self
		if($discountUsed){
			$usedBy[] = $order->getId();
			$this->setAppParam('used_quantity',implode(',',$usedBy));
			$this->save();
		}

		$order->refresh()->save();
		return true;
	}

	public function _checkAllowed(PayplansSubscription $subscription, PayplansOrder $order)
	{
		// required to check : if we allow multiple discount per order
		//subscription already have discount
		//if($subscription->getDiscount())
		//	return false;

		//Check if not applicable on given subscription
		if($this->getParam('applyAll',false)){
			return true;
		}

		$subPlan = array_shift($subscription->getPlans());
		return in_array($subPlan,$this->getPlans());
	}

	public function _calculateDiscount($price=0)
	{
		if($price <= 0){
			return 0;
		}

		//calculate discount
		if($this->getAppParam('coupon_amount_type','fixed') === 'percentage'){
			return $this->getAppParam('coupon_amount')*$price/100;
		}

		return $this->getAppParam('coupon_amount');
	}
}