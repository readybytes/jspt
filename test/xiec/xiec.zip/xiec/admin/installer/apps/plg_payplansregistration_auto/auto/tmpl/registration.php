<?php
?>
<div id="autoRegister">
	<h4 class="divHeading">
		<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTERATION_EMAIL');?>
	</h4>

	<input type="text" name="payplansRegisterAutoEmail" class="placeholder" placeholder="<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTERATION_ENTER_EMAIL');?>"/><span class="required">*</span>
	
	<input type="submit" class="button white medium" id="payplansRegisterAuto" name="payplansRegisterAuto" value="<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTER_AUTO')?>"/>
</div>