<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Payplans Registration Plugin
 *
 * @package		Payplans
 * @subpackage	Plugin
 */
class  plgPayplansregistrationAuto extends XiPluginRegistration
{
	protected $_registrationUrl = 'index.php?option=com_payplans&view=plan&task=login';

	function _isRegistrationUrl()
	{
		$vars = $this->_getVars();
		if($vars['option'] == 'com_payplans' && $vars['view'] == 'plan' && $vars['task'] == 'login'){
			return true;
		}
		
		return false;
	}
	
	function _isRegistrationCompleteUrl()
	{
		return true;
	}
	
	/** 
	 * @see XiPluginRegistration::_doStartRegistration()
	 * 
	 */
	protected function _doStartRegistration()
	{
		$planId = $this->_getPlan();

		$email  = JRequest::getVar('payplansRegisterAutoEmail', false);
		
		// if email is not post then redirect to login page again
		if(!$email){
			$this->_app->redirect(XiRoute::_('index.php?option=com_payplans&view=plan&task=login&plan_id='.$planId));
		}
		
		$userId = $this->_autoRegister($email);
		
		if($userId){
			// registration is completed here so call afterRegistrationComplete
			$this->_setUser($userId);
			return $this->_doCompleteRegistration();
		}
		
		return true;
	}
	
	function _autoRegister($email)
	{
		jimport('joomla.mail.helper');
		jimport('joomla.user.helper');
		require_once  JPATH_ROOT.DS.'components'.DS.'com_user'.DS.'controller.php';
		JFactory::getLanguage()->load('com_user');
		
		if(!JMailHelper::isEmailAddress($email)){
			$this->_app->enqueueMessage(XiText::_('COM_PAYPLANS_INVALID_EMAIL_ADDRESS'));
			return false;
		}
		
		if($this->_isAlreadyExists($email)){
			$this->_app->enqueueMessage(XiText::_('COM_PAYPLANS_EMAIL_ALREADY_REGISTERED'));
			return false;
		}
		
		$user 		= clone(JFactory::getUser());
		$authorize	= JFactory::getACL();
		$newUsertype = 'Registered';

		//Update user values
		$user->set('id', 0);
		$user->set('usertype', $newUsertype);
		$user->set('gid', $authorize->get_group_id( '', $newUsertype, 'ARO' ));
		$password = JUserHelper::genRandomPassword();
		
		$data = array(	'username'=>$email,
						'name'=>$email,
						'email'=>$email,
						'password'=>$password,
						'password2'=>$password,
						'block'=>1
					 );
					 
		// Bind the post array to the user object
		if (!$user->bind($data)) {
			XiError::raiseError( 500, $user->getError());
		}
		
		jimport('joomla.user.helper');
		// If user activation is turned on, we need to set the activation information
		$usersConfig = JComponentHelper::getParams( 'com_users' );
		$useractivation = $usersConfig->get( 'useractivation' );
		$user->set('block', '0');
		if ($useractivation == '1')
		{
			jimport('joomla.user.helper');
			$user->set('activation', JUtility::getHash( JUserHelper::genRandomPassword()) );
			$user->set('block', '1');
		}
		

		if (!$user->save()){
			$this->_app->enqueueMessage(XiText::_('COM_PAYPLANS_ERROR_IN_SAVING_USER_TABLE'));
			return false;
		}

		$this->_sendMail($user, $password);
		return $user->id;
	}
	
	function _isAlreadyExists($email)
	{
		// Initialize some variables
		$db = JFactory::getDBO();
		$query = 'SELECT id FROM #__users WHERE email = ' . $db->Quote( $email );
		$db->setQuery($query, 0, 1);
		return $db->loadResult();
	}
	
	function _sendMail(&$user, $password)
	{
		$mainframe = XiFactory::getApplication();
		$db		= JFactory::getDBO();

		$name 		= $user->get('name');
		$email 		= $user->get('email');
		$username 	= $user->get('username');

		$usersConfig 	= &JComponentHelper::getParams( 'com_users' );
		$sitename 		= $mainframe->getCfg( 'sitename' );
		$useractivation = $usersConfig->get( 'useractivation' );
		$mailfrom 		= $mainframe->getCfg( 'mailfrom' );
		$fromname 		= $mainframe->getCfg( 'fromname' );
		$siteURL		= JURI::base();

		$subject 	= sprintf ( XiText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_ACCOUNT_DETAILS_FOR' ), $name, $sitename);
		$subject 	= html_entity_decode($subject, ENT_QUOTES);

		if ( $useractivation == 1 ){
			$message = sprintf ( JText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG_ACTIVATE' ), $name, $sitename, $siteURL."index.php?option=com_user&task=activate&activation=".$user->get('activation'), $siteURL, $username, $password);
		} else {
			$message = sprintf ( JText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG' ), $name, $sitename, $siteURL, $username, $password);
		}

		$message = html_entity_decode($message, ENT_QUOTES);

		//get all super administrator
		$query = 'SELECT name, email, sendEmail' .
				' FROM #__users' .
				' WHERE LOWER( usertype ) = "super administrator"';
		$db->setQuery( $query );
		$rows = $db->loadObjectList();

		// Send email to user
		if ( ! $mailfrom  || ! $fromname ) {
			$fromname = $rows[0]->name;
			$mailfrom = $rows[0]->email;
		}

		JUtility::sendMail($mailfrom, $fromname, $email, $subject, $message);

		// Send notification to all administrators
		$subject2 = sprintf ( XiText::_('PLG_PAYPLANSREGISTRATION_AUTO_ACCOUNT_DETAILS_FOR' ), $name, $sitename);
		$subject2 = html_entity_decode($subject2, ENT_QUOTES);

		// get superadministrators id
		foreach ( $rows as $row )
		{
			if ($row->sendEmail)
			{
				$message2 = sprintf ( JText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG_ADMIN' ), $row->name, $sitename, $name, $email, $username);
				$message2 = html_entity_decode($message2, ENT_QUOTES);
				JUtility::sendMail($mailfrom, $fromname, $row->email, $subject2, $message2);
			}
		}
	}
}
