<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Payplans Registration Joomla Plugin
 *
 * @package		Payplans
 * @subpackage	Plugin
 */
class  plgPayplansregistrationJoomla extends XiPluginRegistration
{	
	protected $_registrationUrl = 'index.php?option=com_user&view=register';

	function _isRegistrationUrl()
	{
		$vars = $this->_getVars();
		if($vars['option'] == 'com_user' && $vars['view'] == 'register'){
			return true;
		}
		
		return false;	 
	}
	
	function _isRegistrationCompleteUrl()
	{
		return true;	 
	}
}
