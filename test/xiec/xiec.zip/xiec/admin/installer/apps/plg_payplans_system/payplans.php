<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );


// check if Payplans installed or not
jimport('joomla.filesystem.file');

// Load particular autoloading required
$app = JFactory::getApplication();
$basepath	= $app->isAdmin() ? JPATH_ADMINISTRATOR : JPATH_SITE ;
$fileName 	= $basepath . DS . 'components'.DS.'com_payplans'.DS.'includes'.DS.'includes.php';

if(!JFile::exists($fileName))
{
	return true;
}
else
{

	require_once $fileName;

	/**
	 * Payplans System Plugin
	 *
	 * @package	Payplans
	 * @subpackage	Plugin
	 */
	class  plgSystemPayplans extends XiPlugin
	{
		public $_app = null;

		function __construct(& $subject, $config = array())
		{
			parent::__construct($subject, $config);
			$this->_app = JFactory::getApplication();
		}

		function onAfterRoute()
		{
			$option	= JRequest::getVar('option');
			$view 	= JRequest::getVar('view');
			$task	= JRequest::getVar('task');


			$document =& JFactory::getDocument();
			if($document->getType() != 'html')
				return;

			if(JRequest::getVar('option',null, 'GET') != 'com_payplans')
				return;

			// Load Mootools first : It is done automatically by script function
			XiHtml::stylesheet('window.css');
			XiHtml::stylesheet('tipsy.css');
			XiHtml::stylesheet('humane.css');

			// Load JQuery
			XiHtml::script('jquery-1.4.2.js');
			XiHtml::script('xi.noconflict.js');
			//already added to JQuery file
			ob_start();
			?>
			var xi_url_base = '<?php echo JURI::base();?>';
			<?php
			$script = ob_get_contents();
			ob_end_clean();
			$document->addScriptDeclaration($script);

			// Load XI Scripts
			XiHtml::script('xi.script.js');
			XiHtml::script('xi.ajax.js');
			XiHtml::script('xi.window.js');

			// for validation
			XiHtml::script('xi.validval.js');
			XiHtml::script('xi.tooltip-tipsy.js');
			XiHtml::script('xi.alert-humane.js');
			return true;
		}

		/**
		 * Add a image just before </body> tag
		 * which will href to cron trigger.
		 */
		function onAfterRender()
		{
			//V. IMP. : During uninstallation of Payplans
			// after uninstall this function get executed
			// so prevent it
			$option = JRequest::getVar('option');
			if($option == 'com_installer')
			{
				return true;
			}

			$document	=& JFactory::getDocument();
			$doctype	= $document->getType();

			// Only render for HTML output
			if ( $doctype !== 'html' ) { return; }

			$url = JURI::root().'index.php?option=com_payplans&view=cron&task=trigger&'.JUtility::getToken().'=1';
			$cron = '<img src="'.$url.'" />';
			$body = JResponse::getBody();
			$body = str_replace('</body>', $cron.'</body>', $body);
			JResponse::setBody($body);
		}

		function onAfterInitialise()
		{
			/// load registration polugin of payplans
			XiHelperPlugin::loadPlugins('payplansregistration');
		}
		

		/*
		 * XITODO : MED : Remove these functions and move to some testing plugins
		 * as these are for testing only
		 * */
		function prefixJustForTestTrue()
		{
			return true;
		}

		function justForTestFalse()
		{
			return false;
		}

		function xiTestingTriggerGiven($given)
		{
			return $given;
		}

		function prefixTestingTriggerVisibility()
		{
			return false;
		}
		
		function onAfterDeleteUser($user)
		{
			$db = JFactory::getDBO();
			$userId = $user['id'];

			$orderRecords =  XiFactory::getInstance('order', 'model')
									->loadRecords(array('buyer_id'=>$userId));

			if(!empty($orderRecords)){
				foreach($orderRecords as $record){
					$order = PayplansOrder::getInstance($record->order_id)
											->delete();
				}
			}	
		}

	}
}

