<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Payplans Registration JomSocial Plugin
 *
 * @package		Payplans
 * @subpackage	Plugin
 */
class  plgPayplansregistrationJomsocial extends XiPluginRegistration
{
	protected $_registrationUrl = 'index.php?option=com_community&view=register';

	function _isRegistrationUrl()
	{
		$vars = $this->_getVars();
		if($vars['option'] == 'com_community' && $vars['view'] == 'register'){
			return true;
		}
		
		return false;
	}
	
	function _isRegistrationCompleteUrl()
	{
		$vars = $this->_getVars();
		if($vars['option'] == 'com_community' && $vars['view'] == 'register' && $vars['task'] == 'registerSucess'){
			return true;
		}
		
		return false;
	}
	
	function onAfterRoute()
	{
		parent::onAfterRoute();
		
		if(!XiFactory::getConfig()->registrationType == $this->_name){
			return true;
		}
		
		$vars = $this->_getVars(array('option', 'view', 'task', 'profileType'));
		if($this->params->get('skip_ptype', 0) && $this->params->get('jsmultiprofile', 0)
			&& $vars['option'] == 'com_community' && $vars['view'] == 'register' 
			&& $vars['task'] == 'registerProfileType'){	
		
			$this->_app->redirect(XiRoute::_('index.php?option=com_community&view=register&task=registerProfile&profileType='.$this->params->get('jsmultiprofile', 0)));
		}
	}
}
