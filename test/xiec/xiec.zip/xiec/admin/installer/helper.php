<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();

class PayplansInstallHelper
{
	static function isTableExist($tableName)
	{
		$db		 	=&	JFactory::getDBO();
		$tables	= $db->getTableList();
		//if table name consist #__ replace it.
		$tableName	=	$db->replacePrefix($tableName);

		//check if table exist
		return in_array($tableName, $tables ) ? true : false;
	}

	/*
	 * This function adds all errors and
	 * return the error object
	 * */
	static function addError($mesg = null, $ret = false)
	{
		static $error = null;

		if($error == null)
			$error = new JObject();

		//if we need to set msg
		if($mesg != null)
			$error->setError($mesg);

		//if we need to return errors.
		if($ret == true)
			return $error->getErrors();

		return true;
	}

	static function _filterComments($sql)
	{
		return preg_replace("!/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+/!s","",$sql);
	}

	/*
	 * Filter Unneccessary characters from a query to identify empty query
	 */
	static function _filterWhitespace($sql)
	{
		//query need trimming
		$sql	=  trim($sql,"\n\r\t");

		//remove leading, trailing and "more than one" space in between words
		$pat[0] = "/^\s+/";
		$pat[1] = "/\s+\$/";
		$rep[0] = "";
		$rep[1] = "";
		$sql = preg_replace($pat,$rep,$sql);

		return $sql;
	}

	static function applySqlFile($fileName)
	{

		//XITODO : return error log $errorLog
		$db	= JFactory::getDBO();
		//read file
		if(!($sql = JFile::read($fileName)))
			return false;

		//clean comments from files
		$sql = self::_filterComments($sql);

		//break into queries
		$queries	= $db->splitSql($sql);

		//run queries
		foreach($queries as $query)
		{
			//filter whitespace
			$query = self::_filterWhitespace($query);

			//if query is blank
			if(empty($query))
				continue;

			//run our query now
			$db->setQuery($query);

			//if error add it
			if($db->query()===FALSE)
				self::addError($db->getError());
		}

		return true;
	}

	static function changePluginState($name, $newState = 1, $folder = 'system')
	{
		$db		=& JFactory::getDBO();
		$query	= 'UPDATE ' . $db->nameQuote('#__plugins' )
				. ' SET '   . $db->nameQuote('published').'='.$db->Quote($newState)
		        . ' WHERE ' . $db->nameQuote('element').'='.$db->Quote($name)
		        . ' AND ' . $db->nameQuote('folder').'='.$db->Quote($folder)
		        ;
		$db->setQuery($query);
		if(!$db->query())
			return false;

		return true;
	}

	static function changeModuleState($name,$position,$newState = 1)
	{
		$db		=& JFactory::getDBO();
		$query	= ' UPDATE ' . $db->nameQuote( '#__modules' )
				. ' SET '    . $db->nameQuote('published').'='.$db->Quote($newState)
				. ',  '    . $db->nameQuote('position').'='.$db->Quote($position)
		        . ' WHERE '  . $db->nameQuote('module').'='.$db->Quote($name);
		$db->setQuery($query);
		if(!$db->query())
			return false;

		return true;
	}
	
	/*
	 * Functsion to get and update already applied patch info 
	 * */
	static function queryPatch()
	{
		if(self::isTableExist('#__payplans_support'))
		{
			$db		=& JFactory::getDBO();
			$query	= ' SELECT `value` ' 
					. ' FROM  `#__payplans_support`'
			        . ' WHERE `key`= "lastDbPatch" ';
			$db->setQuery($query);
			$result = $db->loadResult();
			//secondpatch, because table exist means first patch already installed
			return $result ? $result : 'secondPatch';
		}
		//if table does not exist then start from first patch
		return 'START';
		
	}
	
	static function updatePatch($patch)
	{
		if(self::isTableExist('#__payplans_support'))
		{
			$db		=& JFactory::getDBO();
			$query	= ' UPDATE ' . $db->nameQuote( '#__payplans_support' )
					. ' SET '    . $db->nameQuote('value').'='.$db->Quote($patch)
			        . ' WHERE '  . $db->nameQuote('key').'='.$db->Quote('lastDbPatch');
			$db->setQuery($query);
			if(!$db->query())
				return false;
	
			return true;
		}
	}
	
	static function uninstallPlugin($name, $folder)
	{
		$db		=& JFactory::getDBO();
		$query	= 'SELECT  `id` FROM ' . $db->nameQuote('#__plugins' )
		        . ' WHERE ' . $db->nameQuote('element').'='.$db->Quote($name)
		        . ' AND ' . $db->nameQuote('folder').'='.$db->Quote($folder)
		        ;
		$db->setQuery($query);
		$identifier = $db->loadResult();
		
		
		if(!$identifier){
			return true;
		}		
		
		return self::uninstallExtension('plugin', $identifier, $cid=0);
	}
	
	static function uninstallModule($name, $cid)
	{
		$db		=& JFactory::getDBO();
		$query	= 'SELECT  `id` FROM ' . $db->nameQuote('#__modules' )
		        . ' WHERE ' . $db->nameQuote('module').'='.$db->Quote($name)
		        . ' AND ' . $db->nameQuote('client_id').'='.$db->Quote($cid)
		        ;

		$db->setQuery($query);
		$identifier = $db->loadResult();
		
		if(!$identifier){
			return true;
		}	
		
		return self::uninstallExtension('module', $identifier, $cid);
	}
	
	static function uninstallExtension($type, $identifier, $cid=0)
	{
		//type = component / plugin / module
		// $id = id of ext
		// cid = client id (admin : 1, site : 0) 
		$installer =  new JInstaller();
		return $installer->uninstall($type, $identifier, $cid);
	}

}

