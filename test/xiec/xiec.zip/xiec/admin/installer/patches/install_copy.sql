/*
IMP : Only use C-Style comments only

Every ID field should have this convention "tableName_id" , 
where tableName is the name of table, whom this id refers

*/

/*
It stores the system wide information 
we need at the time of updates or debugging.
*/
CREATE  TABLE IF NOT EXISTS `#__payplans_support` (
  `support_id` INT NOT NULL AUTO_INCREMENT,
  `key`           VARCHAR(45) NOT NULL ,
  `value`         TEXT NULL,
  PRIMARY KEY (`support_id`) ,
  UNIQUE INDEX `idx_key` (`key` ASC) 
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ; 


CREATE  TABLE IF NOT EXISTS `#__payplans_config` (
  `config_id`	INT NOT NULL AUTO_INCREMENT,
/*name of tab*/
  `title`    	VARCHAR(255) NOT NULL,
  `key` 	VARCHAR(255) NOT NULL,
  `config`  	TEXT NULL ,
  `componentname` VARCHAR(255) NULL,
/* xml and default ini path */
  `path` TEXT NULL,
  PRIMARY KEY (`config_id`) ,
  INDEX `idx_key` (`key` ASC)
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ; 


/*
 Enity and Item table will help us to know exactly to which any id is related
 to which entity.
 Item table will help to recognize an item over multiple tables
 products / subscription / listing OR anything salable item
*/
CREATE  TABLE IF NOT EXISTS `#__payplans_entity` (
  `entity_id` 	INT NOT NULL AUTO_INCREMENT ,
  `title`  	VARCHAR(255) NOT NULL,
/* itemap is CLASSNAME which can be called to collect some data from payplans*/    
  `classapi` 	VARCHAR( 255 ) NOT NULL, 
  `saleable`  	INT NOT NULL,
  PRIMARY KEY (`entity_id`),
  UNIQUE INDEX `idx_title` (`title` ASC)
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ; 


CREATE  TABLE IF NOT EXISTS `#__payplans_user` (
  `user_id` INT NOT NULL, /*we cannot setit as autoincrement*/
  `params`  	TEXT NULL ,
  PRIMARY KEY (`user_id`)
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ; 



CREATE  TABLE IF NOT EXISTS `#__payplans_order` (
  `order_id` INT NOT NULL AUTO_INCREMENT ,
  `buyer_id` INT NOT NULL,
  `subtotal` 	 DECIMAL(15,5) NULL DEFAULT '0.00000' ,
  `discount` 	 DECIMAL(15,5) NOT NULL DEFAULT '0.00000' ,
  `shipping` 	 DECIMAL(15,5) NULL DEFAULT '0.00000',
  `tax` 	 DECIMAL(15,5) NULL DEFAULT '0.00000',
  `total` 	 DECIMAL(15,5) NOT NULL DEFAULT '0.00000',  
  `currency` 	 CHAR(3) DEFAULT NULL,
  `status` 	 INT NOT NULL DEFAULT 0,
  `shipping_address` 	 INT NOT NULL DEFAULT 0,  
  `billing_address` 	 INT NOT NULL DEFAULT 0,    
  `checked_out`  INT NULL DEFAULT 0,
  `checked_out_time` DATETIME NULL ,
  `created_date`  DATETIME NOT NULL,
  `modified_date` DATETIME NOT NULL,
  PRIMARY KEY (`order_id`) ,
  INDEX `idx_buyer_id` (`buyer_id` ASC) 
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ; 

/* XITODO : Discounts will be implemented in 1.0
CREATE  TABLE IF NOT EXISTS `#__payplans_orderdiscount` (
  `orderdiscount_id` INT NOT NULL AUTO_INCREMENT ,
  `order_id` 	   INT NOT NULL,
  `item_id`   INT NULL DEFAULT 0,
  `discount_id`    INT NOT NULL,
  `amount` 	   DECIMAL(15,5) NOT NULL DEFAULT '0.00000' ,
  PRIMARY KEY (`orderdiscount_id`) 
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ; 

CREATE  TABLE IF NOT EXISTS `#__payplans_discount` (
  `discount_id` INT NOT NULL AUTO_INCREMENT,
  `code` 	      VARCHAR(32) NOT NULL DEFAULT '',
  `amount`      DECIMAL(15,5) NOT NULL DEFAULT '0.00000',
  `percent`     DECIMAL(2,2) NOT NULL DEFAULT '00.00',
  `created_date`  DATETIME NOT NULL,
  `modified_date` DATETIME NOT NULL,
  `from_date`  	DATETIME NOT NULL,
  `to_date` 	DATETIME NOT NULL,
  `params`  	TEXT NULL,
PRIMARY KEY (`discount_id`) 
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ; 
*/

CREATE  TABLE IF NOT EXISTS `#__payplans_payment` (
  `payment_id`   INT NOT NULL AUTO_INCREMENT,
  `order_id` 	 INT NOT NULL,
  `app_id`		 INT NOT NULL,
  `payment_key`    VARCHAR(255) NOT NULL DEFAULT '' ,  
  `amount` 	      DECIMAL(15,5) DEFAULT '0.00000',
  `currency` 	 CHAR(3) DEFAULT NULL,
  `status`       INT(3) NOT NULL DEFAULT 0,
  `is_refund` 	 INT(1) NULL DEFAULT 0,
  `transaction` 	 TEXT NULL,
 
  `checked_out`       INT NULL DEFAULT 0 ,
  `checked_out_time`  DATETIME NULL ,
  `created_date`      DATETIME NOT NULL,
  `modified_date`     DATETIME NOT NULL ,
  PRIMARY KEY (`payment_id`) ,
  INDEX `idx_order_id` (`order_id` ASC), 
  INDEX `idx_payment_id` (`payment_id` ASC) 
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ; 


CREATE  TABLE IF NOT EXISTS `#__payplans_currency` (
  `currency_id` 	char(3) NOT NULL,
  `title` 		VARCHAR(255) DEFAULT NULL,
  `published` 		TINYINT(1) NULL DEFAULT 1 ,
  `params`  TEXT NULL ,
  PRIMARY KEY (`currency_id`)
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ; 


CREATE  TABLE IF NOT EXISTS `#__payplans_country` (
  `country_id`  INT(11) NOT NULL AUTO_INCREMENT ,
  `title` 	VARCHAR(255) NOT NULL,
  `isocode2` 	CHAR(2) NULL DEFAULT NULL ,
  `isocode3` 	CHAR(3) NULL DEFAULT NULL ,
  `isocode3n` 	INT(3) NULL DEFAULT NULL , /*numeric code of country as per ISO*/
  PRIMARY KEY (`country_id`)
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ; 

/*
Store multiple address for one user
*/
CREATE TABLE  IF NOT EXISTS `#__payplans_address` (
  `address_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id`     INT(11) NOT NULL,
  `street1`    VARCHAR(64) NOT NULL DEFAULT '',
  `street2`    VARCHAR(64) DEFAULT NULL,
  `zipcode`    VARCHAR(10) NOT NULL DEFAULT '',
  `city`       VARCHAR(32) NOT NULL DEFAULT '',
  `state`      VARCHAR(32) DEFAULT NULL,
  `country_id`  int(11) NOT NULL DEFAULT '0',
  `zone_id`     int(11) NULL DEFAULT '0',
  `created_date`  DATETIME NOT NULL,
  `modified_date` DATETIME NOT NULL ,
  `is_personal`     int(1) NOT NULL DEFAULT  '1',
  `is_buisness`     int(1) NOT NULL DEFAULT  '1',
  `is_shipping`     int(1) NOT NULL DEFAULT  '1',
  PRIMARY KEY  (`address_id`),
  INDEX `idx_address_user_id` (`user_id`)
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ; 


CREATE TABLE IF NOT EXISTS `#__payplans_app` (
  `app_id` int(11) NOT NULL AUTO_INCREMENT,
  `title`  varchar(255) NULL DEFAULT '',
  `type` varchar(255) NOT NULL,
  `description`	varchar(255) NULL DEFAULT '',
  `core_params` text,
  `app_params` text,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`app_id`)
) ENGINE=MyISAM
DEFAULT CHARACTER SET = utf8;




/*SUBSCRIPTION SQL */
/* IMP : Use C Style Comment Only */

/* 
Subscription tables
  `subscription_id` INT NOT NULL AUTO_INCREMENT,
  `userid` 	  	User-ID, always required
  `planid` 	  	Subscription is related to Plan x
  `status` 	 	Status ID, it will be stored in payplans_status table
  `subscription_date` 	The start date
  `expiration_date`    	End date of subscription
  `cancel_date`        	Cacnel date
  `planobject`	  	Plan's setting when Plan was applied, it will not change when plan settings is changed.
			It will only change when resetAll activity request occurs for existing customer
*/
CREATE TABLE IF NOT EXISTS `#__payplans_subscription` (
  `subscription_id` 	INT NOT NULL AUTO_INCREMENT,
  `order_id` 	  	INT NOT NULL,
  `user_id` 	  	INT NOT NULL,
  `plan_id` 	  	INT NOT NULL,
  `status` 	 	INT NOT NULL DEFAULT 0,
  `total` 	      	DECIMAL(15,5) DEFAULT '0.00000',
  `subscription_date`  	DATETIME  DEFAULT '0000-00-00 00:00:00',
  `expiration_date`  	DATETIME  DEFAULT '0000-00-00 00:00:00',
  `cancel_date`  	DATETIME  DEFAULT '0000-00-00 00:00:00',
  `checked_out`  	INT 	  DEFAULT 0,
  `checked_out_time` 	DATETIME  DEFAULT '0000-00-00 00:00:00',
  `modified_date` 	DATETIME  DEFAULT '0000-00-00 00:00:00',
  `params`	  TEXT NOT NULL,
  PRIMARY KEY (`subscription_id`)
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ;


/*
Subscription plans
*/
CREATE TABLE IF NOT EXISTS `#__payplans_plan` (
  `plan_id`		INT 		NOT NULL 	AUTO_INCREMENT,
  `title`		VARCHAR(255) 	NOT NULL,
  `published` 		TINYINT(1) 	DEFAULT 1,
  `visible` 		TINYINT(1) 	DEFAULT 1,
  `ordering` 		INT 		DEFAULT 0,
  `checked_out`  	INT NULL 	DEFAULT 0,
  `checked_out_time`	DATETIME 	DEFAULT '0000-00-00 00:00:00',
  `modified_date`	DATETIME  	DEFAULT '0000-00-00 00:00:00',
  `description`		TEXT 		DEFAULT NULL,
  `time` 		TEXT 		DEFAULT NULL,
  `payment` 		TEXT 		DEFAULT NULL,
  `params`		TEXT 		DEFAULT NULL,  
  PRIMARY KEY (`plan_id`)
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ;

/**
*/
CREATE TABLE IF NOT EXISTS `#__payplans_planapp` (
  `planapp_id` 	INT NOT NULL AUTO_INCREMENT,
  `plan_id` 	INT NOT NULL,
  `app_id` 	INT NOT NULL,
  PRIMARY KEY (`planapp_id`)
)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8 ;

