<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();

jimport('joomla.filesystem.file');

class PayplansPatch
{
	static function getMapper()
	{
		$_mapper = array();
		// when add new patch update the definition
		$_mapper['START'] 		= 'firstPatch';
		$_mapper['firstPatch'] 	= 'secondPatch';
		$_mapper['secondPatch'] = 'patch_001_log_table';
		$_mapper['patch_001_log_table'] = 'patch_002_remove_oldplugins';
		$_mapper['patch_002_remove_oldplugins'] = 'END';
		
		
		return $_mapper;
	}
	
	static function applyPatches($nextPatch='START', $class='PayplansPatch', $mapper=null)
	{
		if($mapper === null){
			$mapper = self::getMapper();
		}
		// as we will get the previous patch applied
		$nextPatch= $mapper[$nextPatch]; 
		
		//apply patches
		while($nextPatch !== 'END')
		{
			if(method_exists($class, $nextPatch)===false){
				return false;
			}
			
			$result = call_user_func(array($class, $nextPatch));
			//update current patch to database
			PayplansInstallHelper::updatePatch($nextPatch);
			
			//if some error return false
			if($result === false){
				return false;
			}
			
			//get next patch
			$nextPatch = $mapper[$nextPatch];
		}

		return true;
	}

	//do install install.sql
	static function firstPatch()
	{
		return PayplansInstallHelper::applySqlFile(dirname(__FILE__).DS.'install.sql');
	}


	//install system data
	static function secondPatch()
	{
		return PayplansInstallHelper::applySqlFile(dirname(__FILE__).DS.'system-data.sql');
	}

	// add log table
	static function patch_001_log_table()
	{
		//add log table
		return PayplansInstallHelper::applySqlFile(dirname(__FILE__).DS.'sql'.DS.__FUNCTION__.'.sql');
	}
	
	// Remove obsolete plugins to reduce the errors.
	static function patch_002_remove_oldplugins()
	{
		// 4 payplans plugins (core/ambrasubs/acctexp/sample)
		PayplansInstallHelper::uninstallPlugin('core','payplans');
		PayplansInstallHelper::uninstallPlugin('sample','payplans');
		PayplansInstallHelper::uninstallPlugin('ambrasubs','payplans');
		PayplansInstallHelper::uninstallPlugin('acctexp','payplans');
	}
}