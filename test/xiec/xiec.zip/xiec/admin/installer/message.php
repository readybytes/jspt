<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Installer
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?>
  <script type="text/javascript" src="../components/com_payplans/media/js/jquery-1.4.2.js"></script>
  <script type="text/javascript" src="../components/com_payplans/media/js/xi.noconflict.js"></script>
  <script type="text/javascript" src="../components/com_payplans/media/js/xi.script.js"></script>
  <script type="text/javascript" src="../components/com_payplans/media/js/xi.ajax.js"></script>
  <script type="text/javascript" src="../components/com_payplans/media/js/xi.validval.js"></script>


<style type="text/css">
.installnote {
	width: 92%;
	margin: 6px 24px;
}

.installnote h3 {
	padding: 0 12px;
	text-align:center;
}

.installnote p {
	padding: 0 50px;
}

.pay a{
background: none repeat scroll 0 0 #FF8400;
border: 0px solid #E05F26;
color: #FFFFFF;
padding: 5px;
line-height:25px;
cursor:pointer;
letter-spacing:1px;
text-decoration:none;
}

.pay{
overflow:hidden;
border:1px solid #666
}

.msg{
float:left;
width:55%;
text-align:center;
}

.whtNext{
float:left;
width:43%;
}

#install-sample-data-msg{
font-weight:bold;
border:1px solid #ffc98f;
padding:3px;
background:#FFC98F;
display:none;
}

</style>

<div class="pay">

<div class="msg">

<div class="installnote">
<h3>PayPlans : Subscription / Membership System for Joomla!</h3>
<p>Team JoomlaXi wanted to take a moment to thank you for trying PayPlans.
We greatly apperciate your business and the opportunity to assist you. </p>

<!--<p> You satisfaction is the greatest recognition we could have, so we ask-->
<!--you to inform us if there is ever anything we can do to improve our service;-->
<!--we will do everything in our power to satisfy you.</p>-->
<p>Sincerly</p>
<p>Team JoomlaXi<br />
Ready Bytes Software Labs Pvt. Ltd.
</p>
</div>
</div>

<div class="whtNext">
<h4>What's Next ?</h4>
<p>
	<a href="index.php?option=com_payplans">Dive-in to PayPlans</a>
</p>

</div>
</div>