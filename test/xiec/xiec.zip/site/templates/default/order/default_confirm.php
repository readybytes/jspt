<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<div id="payplan-order" >
<h2 class="page-heading primary color border background"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_HEADING');?></h2>
<form action="<?php echo $uri; ?>" method="post" name="site<?php echo $this->getName(); ?>Form">

	<div id="order-id" class="order-confirm-id primary reverse light color border background ">
		<label><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_ID');?></label>
		<span><?php echo $order->getKey();?></span>
	</div>
	
	<div id="details"  class="details secondary color border background" >
		<div id="user-details" class="user-details secondary color border background">
			<div id="your-details"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_YOUR_DETAILS');?></div>
			<div class = "detail-label"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_USER_ID');?></div><div class = "detail-dec"><?php echo $user->getId(); ?></div>
			<div class = "detail-label"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_EMAIL');?></div><div class = "detail-dec"><?php echo $user->getEmail(); ?></div>
			<div class = "detail-label"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_NAME');?></div><div class = "detail-dec"><?php echo $user->getRealname(); ?></div>
		</div>
		<div id="product-details">
		<div id="details-heading"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_PRODUCT_DETAILS');?></div>
		<div class = "detail-label"><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_PRODUCT_NAME');?></div><div class = "detail-dec"><?php echo $plan->getTitle(); ?></div>
		</div>
	</div>


		<div id="app-html">
			<?php
			if(!empty($plugin_result) && is_array($plugin_result)):
				echo PayplansHelperUtils::ignoreImplode($plugin_result,'\n');
			endif;
			?>
		</div>

		<div id="order-calculation">
			<div id="sub-total" class="sub-total" >
				<label><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_SUBTOTAL');?></label>
				<span class="amount"><?php echo $order->getSubtotal();?></span>
			</div>

			<div id="discount" class="discount">
				<label><?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_DISCOUNT');?></label>
				<span class="amount"><?php echo $order->getDiscount();?></span>
			</div>


			<div id="total-amount" class="total-amount secondary color border background">
				<div class="amount"><?php echo $order->getTotal();?></div>
				<span class="currency"><?php  $order->getCurrency();?></span>

			</div>
		</div>

	

	<div id="order-footer" class="order-footer primary reverse light color border background ">
		<div id="make-payment">
			<label><?php echo XiText::_('COM_PAYPLANS_ORDER_MAKE_PAYMENT_FROM');?></label>
			<span><?php echo JHTML::_('select.genericlist', $payment_apps, 'app_id', '' , 'id', 'title');?></span>
		</div>

		<!-- HIDDEN VARIBALE REQUIRED -->
		<input type="hidden" name="order_key" value="<?php echo $order->getKey();?>" />

		<div id="confirm-btn"><input type="submit" id="payplans-order-confirm" class="button button-color medium" name="payplans_order_confirm_btn" value="<?php echo XiText::_('COM_PAYPLANS_ORDER_CONFIRM_BTN')?>"/></div>
	</div>

	<input type="hidden" name="boxchecked" value="0" />
</form>
</div>
<?php
