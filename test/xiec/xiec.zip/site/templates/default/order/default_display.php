<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>

<h2 class="page-heading primary color border background"><?php echo XiText::_('COM_PAYPLANS_ORDERS');?></h2>
<?php 
if(is_array($order_records)):
	foreach($order_records as $record):
		$order = PayplansOrder::getInstance($record->order_id,null,$record);
		?>
		<div id="users-order" class="users-order secondary color border background">
		<div class="order-default-col1">
		<div class="record">
			<div class="record-label">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_KEY');?>
			</div>
			
			<div class="record-value">
				<?php $key = $order->getKey();
				echo XiHtml::link('index.php?option=com_payplans&view=order&task=display&order_key='.$key, $key); ?>
			</div>
		</div>
		
		<div class="record">
			<div class="record-label">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_STATUS'); ?>
			</div>
			<div class="record-value">
				<?php echo $order->getStatusName();?>
			</div>
		</div>
		
		
		
		</div>
		
		<div class="order-default-col2">
		<div class="record">
			<div class="record-label">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_SUBTOTAL');?>
			</div>
			<div class="record-value">
				<?php echo $order->getSubtotal(); ?>
			</div>
		</div>
		
		<div class="record">
			<div class="record-label">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_DISCOUNT');?>
			</div>
			<div class="record-value">
				<?php echo $order->getDiscount();	?>
			</div>
		</div>
		
		<div class="record">
			<div class="record-label">
				<?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_TOTAL'); ?>
			</div>
			<div class="record-value">
				<?php echo $order->getTotal(); ?>
			</div>
		</div>
		</div>
		
		<div class="view-subscription-btn" >
		<a id="payplans-order-detail-<?php echo $order->getKey()?>" href="<?php echo 'index.php?option=com_payplans&view=order&task=display&order_key='.$key;?>" class="button button-color"><?php echo XiText::_('COM_PAYPLANS_ORDER_DISPLAY_VIEW_DETAILS');?></a>
		</div>
</div>
	<?php endforeach;?> 
<?php endif; ?>

<?php if(!empty($order_records)):?>
	<form action="<?php echo $uri; ?>" method="post" name="site<?php echo $this->getName(); ?>Form">
		<?php echo $this->getModel()->getPagination()->getPagesLinks(); ?>
		<input type="hidden" name="view" value="order" />
	</form>
<?php endif;?>
