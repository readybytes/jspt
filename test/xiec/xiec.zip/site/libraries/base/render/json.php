<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class XiRenderJson extends XiRender
{
	public $headerFooters = false;
	protected function _render(XiView $view, $html, $options = array('domObject'=>'xiWindowContent','domProperty'=>'innerHTML'))
	{
		$domObject	=	JRequest::getVar('xiAjaxDomObject',$options['domObject']);
		$domProperty = JRequest::getVar('xiAjaxDomProperty',$options['domProperty']);

		$response	= XiFactory::getAjaxResponse();
		$response->addAssign( $domObject , $domProperty , $html );

		//XITODO : remove this send response, let the start file do it
		return $response->sendResponse();
	}

}