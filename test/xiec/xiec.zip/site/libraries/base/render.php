<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class XiRender
{
	public $headerFooters = true;
	
	public function __construct()
	{
		$this->headerFooters = JRequest::getVar('headerFooter', true);
	}
	
	final public function render(XiView $view, $data, $options)
	{
		XiError::assert($this);
		
		ob_start();
		if($this->headerFooters){
			echo "<div id='payplans' class='payplans'>";
			echo $data['header'];
		}
		
		echo "<div id='payplans-notification' class='notice'>".$this->_getSystemMessages()."</div>";
		echo $data['output'];
		
		if($this->headerFooters){
			echo $data['footer'];
			echo '</div>';
		}
		
		$html = ob_get_contents();
		ob_end_clean();
		
		return $this->_render($view, $html, $options);
	}
	
	protected function _render(XiView $view, $html, $options)
	{
		echo $html;
		return true;
	}
	
	static function getRenderer()
	{
		$format	= JString::ucfirst(JString::strtolower(JRequest::getCmd('format',	'html')));
		if(JRequest::getBool('isAjax',false)!==false){
			$format	= 'Json';
		}
		
		$className = 'XiRender'.$format; 
		if(class_exists($className, true)===false)
		{
			self::getErrorObject()->setError("Class $className not found");
			return false;
		}
		
		return new $className();
	}
	
	protected function _injectTokens($output)
	{
		// Form security via token injection
		if(JString::stristr($output, "</form>")){
			$output = preg_replace('#</form>#', XiHtml::_('form.token').'</form>', $output);
		}
		
		return $output;
	}
	
	protected function _getSystemMessages()
	{
		// Initialize variables
		$contents	= null;
		$lists		= null;

		// Get the message queue
		$app = XiFactory::getApplication();
		$messages = $app->getMessageQueue();
		$app->set('_messageQueue', array());

		// Build the sorted message list
		if (is_array($messages) && count($messages)) {
			foreach ($messages as $msg)
			{
				if (isset($msg['type']) && isset($msg['message'])) {
					$lists[$msg['type']][] = $msg['message'];
				}
			}
		}

		// If messages exist render them
		if (is_array($lists))
		{
			// Build the return string
			$contents .= "\n<dl id=\"payplans-system-message\">";
			foreach ($lists as $type => $msgs)
			{
				if (count($msgs)) {
					$contents .= "\n<dt class=\"".strtolower($type)."\">".JText::_( $type )."</dt>";
					$contents .= "\n<dd class=\"".strtolower($type)." message fade\">";
					$contents .= "\n\t<ul>";
					foreach ($msgs as $msg)
					{
						$contents .="\n\t\t<li>".$msg."</li>";
					}
					$contents .= "\n\t</ul>";
					$contents .= "\n</dd>";
				}
			}
			$contents .= "\n</dl>";
		}
		
		return $contents;
	}
}