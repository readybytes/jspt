<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

abstract class XiView extends XiAbstractView
{
	public function getDynamicJavaScript()
	{
		// get valid actions for validation submission
		$validActions = $this->getJSValidActions();
		if(!is_array($validActions)){
			$validActions = (array)$validActions;
		}
		
		//common js code to trigger
		ob_start(); ?>

		// current view
		var view = '<?php echo $this->getName();?>' ;
        var validActions = '<?php echo json_encode($validActions);?>' ;

		<?php if(PAYPLANS_JVERSION_16): ?>
		Joomla.submitbutton = function(action) {
		<?php else : ?> 
		function submitbutton(action) {
		<?php endif; ?>
			payplansAdmin.submit(view, action, validActions);
		}

		<?php
		$js = ob_get_contents();
		ob_end_clean();

		return $this->_getDynamicJavaScript().$js;
	}

    public function getJSValidActions()
    {
    	return array('apply', 'save', 'edit', 'delete');
    }

	public function _getDynamicJavaScript()
	{
		return '';
	}

	//Available Task for views, these should only
	//we will later override this
	function display($tpl=null)
	{
		//IMP : If load records is already done before rendering the page
		// then it will not add pagination into it
		// so always clean the query for displaying it on grid views
		$model = $this->getModel();
		$model->clearQuery();
		
		$records = $model->loadRecords(array(), array());

		// if total of records is more than 0
		if($model->getTotal() > 0)
			return $this->_displayGrid($records);

		return $this->_displayBlank();
	}

	function _displayBlank()
	{
		$model = $this->getModel();
		$heading = "COM_PAYPLANS_ADMIN_BLANK_".JString::strtoupper($this->getName());
		$msg = "COM_PAYPLANS_ADMIN_BLANK_".JString::strtoupper($this->getName())."_MSG";
		$this->assign('heading', $heading);
		$this->setTpl('blank');
		$this->assign('msg', $msg);
		$this->assign('filters', $model->getState(XiHelperContext::getObjectContext($model)));
		return true;
	}

	function _displayGrid($records)
	{
		$this->setTpl('grid');

		//do processing for default display page
		$model = $this->getModel();
		$recordKey =  $model->getTable()->getKeyName();
		$this->assign('records', $records);
		$this->assign('record_key', $recordKey);
		$this->assign('pagination', $model->getPagination());
		$this->assign('filter_order', $model->getState('filter_order'));
		$this->assign('filter_order_Dir', $model->getState('filter_order_Dir'));
		$this->assign('limitstart', $model->getState('limitstart'));
		$this->assign('filters', $model->getState(XiHelperContext::getObjectContext($model)));
		return true;
	}



	function view($tpl=null)
	{
		//do processing for default disply page
	}

	function edit($tpl=null)
	{
		$this->setTpl('edit');
		return true;
	}

	public function _renderModules($position, $attribs = array())
    {
    	jimport( 'joomla.application.module.helper' );

		$modules 	= JModuleHelper::getModules( $position );
		$modulehtml = array();

		// If style attributes are not given or set,
		// we enforce it to use the xhtml style
		// so the title will display correctly.
		if(!isset($attribs['style']))
			$attribs['style']	= 'xhtml';

		foreach($modules as $module){
				$modulehtml[$module->title]=JModuleHelper::renderModule($module, $attribs);
		}

		return $modulehtml;
    }

    //this will set popup window title
    function _setAjaxWinTitle($title){
    	$response	= XiFactory::getAjaxResponse();
		$response->addAssign('xiwin_logo','innerHTML',$title);
    }

    //this will set action/submit button on bottom of popup window
	function _addAjaxWinAction($text, $onButtonClick=null){
		static $actions = array();

		if($onButtonClick !== null){
			$actions[] = '<button onclick="'.$onButtonClick.'"> '.$text.'</button>';
		}
    	return $actions;
    }

	function _setAjaxWinAction(){
    	$actions = $this->_addAjaxWinAction('',null);

    	if(count($actions)===0){
    		return false;
    	}

    	$actionHtml = implode(' ', $actions);
    	XiFactory::getAjaxResponse()->addScriptCall('xiWindowActions',$actionHtml);
    	//XiFactory::getAjaxResponse()->addScriptCall('xiWindowResize','200');
    	return true;
    }

    function _setAjaxWinHeight($height){
    	XiFactory::getAjaxResponse()->addScriptCall('xiWindowResize',$height);
    	return true;

    }
}