<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

require_once JPATH_LIBRARIES.DS.'joomla'.DS.'html'.DS.'html' . DS . 'grid.php';

class XiHtmlGrid extends JHTMLGrid
{
	function switchBool( &$row,$what , $i, $imgY = 'tick.png', $imgX = 'publish_x.png', $prefix='' )
	{
		$img 	= $row->$what ? $imgY : $imgX;
		$task 	= $row->$what ? 'switchOff'.$what : 'switchOn'.$what;
		$alt 	= $row->$what ? XiText::_( 'COM_PAYPLANS_SWITCH_ON_'.$what ) : XiText::_( 'COM_PAYPLANS_SWITCH_OFF_'.$what);
		$action = $row->$what ? XiText::_( 'COM_PAYPLANS_SWITCH_OFF_'.$what.'_ITEM' ) : XiText::_( 'COM_PAYPLANS_SWITCh_ON_'.$what.'_ITEM' );

		$href = '
		<a href="javascript:void(0);" onclick="return listItemTask(\'cb'. $i .'\',\''. $prefix.$task .'\')" title="'. $action .'">
		<img src="images/'. $img .'" border="0" alt="'. $alt .'" /></a>'
		;

		return $href;
	}

	function app($app_id)
	{
		$apps = XiFactory::getInstance('app', 'model')->loadRecords(array('id'=>$app_id));
		$app = array_shift($apps);
		if(!$app) return XiText::_('COM_PAYPLANS_INVALID_APP_TYPE');
		return $app->title;
	}
	
	function loglevel($name, $value, $attr = null)
	{
		$levels = XiLogger::getLevels();
		return $levels[$value];
	}
}
