<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

require_once JPATH_LIBRARIES.DS.'joomla'.DS.'html'.DS.'html' . DS . 'select.php';
//XITODO : Move all JHTML::_ to XiHTML::
class XiHtmlElements extends JHTMLSelect
{
	/**
	 * @return select box html of all available plans
	 * @param $name - name for the html element
	 * @param $value- selected value of plan
	 * @param $attr - other attributes of select box html
	 */
	function plans( $name, $value, $attr=null )
	{
		$plans = XiFactory::getInstance('plan', 'model')->loadRecords();

		if(isset($attr['multiple']))
			return  XiHtml::_('elements.xifbselect',$plans, $name, null, 'plan_id', 'title', $value);

		$options = array();
		if(isset($attr['none']))
			$options[] = JHTML::_('select.option', '', XiText::_('COM_PAYPLANS_PLAN_SELECT'));

		foreach($plans as $p)
    		$options[] = JHTML::_('select.option', $p->plan_id, $p->title);

    	$style = (isset($attr['style'])) ? $attr['style'] : '';
    	return JHTML::_('select.genericlist', $options, $name, $style, 'value', 'text', $value);
	}

	/**
	 * @return select box html of all available users
	 * @param $name - name for the html element
	 * @param $value- selected value of user which is user id
	 * @param $attr - other attributes of select box html
	 */
	function users( $name, $value, $attr=null )
	{
		$users = XiFactory::getInstance('user', 'model')->loadRecords();

		$options = array();
		foreach($users as $u)
    		$options[] = JHTML::_('select.option', $u->user_id, PayplansHelperFormat::user($u));

		return JHTML::_('select.genericlist', $options, $name, $attr, 'value', 'text', $value);
	}

	/**
	 * @return select box html of all available status
	 * @param $name - name for the html element
	 * @param $value- selected value of status
	 * @param $entity : for which entity id, status are asked
	 * @param $attr - other attributes of select box html
	 */
	function status($name, $value, $entity, $attr = null)
	{
		$status = XiStatus::getStatusOf($entity);

		$options = array();
		
		if(isset($attr['none']))
			$options[] = JHTML::_('select.option', '', XiText::_('COM_PAYPLANS_SELECT_STATUS'));

		foreach($status as $key => $val)
    		$options[] = JHTML::_('select.option', $key, XiText::_('COM_PAYPLANS_STATUS_'.$val));

    	$style = (isset($attr['style'])) ? $attr['style'] : '';
    	return JHTML::_('select.genericlist', $options, $name, $style, 'value', 'text', $value);
	}

	/**
	 * @return select box html of all available apps
	 * @param $name - name for the html element
	 * @param $value- selected value of app
	 * @param $type - type of app needed
	 * @param $attr - other attributes of select box html
	 */
	// XITODO : rename it to apps
	function applist($name, $value, $types ='', $attr=null )
	{
		$purposeApps = PayplansHelperApp::getPurposeApps($types);

		$queryFilter = isset($attr['queryFilter']) ? $attr['queryFilter'] : array();
		$apps = XiFactory::getInstance('app', 'model')->loadRecords($queryFilter);

		$readonly = isset($attr['readonly']);
		if($readonly){
			$html = '<lable>'.$apps[$value]->title.'</label>';
			$html.=	'<input type="hidden" name="'.$name.'" value="'.$value.'" />';
			return $html;
		}
		
		if(isset($attr['multiple']))
			return  XiHtml::_('elements.xifbselect',$apps, $name, null, 'app_id', 'title', $value);

		$options = array();
		if(isset($attr['none']))
			$options[] = JHTML::_('select.option', '', XiText::_('COM_PAYPLANS_SELECT_APP'));
		
		foreach($apps as $app){
			if(!($app->published))
				continue;

			if(!in_array($app->type, $purposeApps))
				continue;

			$options[] = JHTML::_('select.option', $app->app_id, PayplansHelperFormat::app($app));
		}
		// XITODO : clean attr concept
		$style = isset($attr['style']) ? $attr['style'] : '';
		return JHTML::_('select.genericlist', $options, $name, $style, 'value', 'text', $value);
	}

	function apptype($name, $value, $attr=null, $ignore=array())
	{
		$apps = PayplansHelperApp::getApps();
		
		$options = array();
		if(isset($attr['none']))
			$options[] = JHTML::_('select.option', '', XiText::_('COM_PAYPLANS_SELECT_APPTYPE'));
	
		$appTypes =	PayplansHelperApp::getXmlData('name');
			
		foreach($apps as $app){
			// XITODO : remove this line if googlecheckout app is ready to use

			if(in_array($app, $ignore))
				continue;
			$options[] = JHTML::_('select.option', $app, $appTypes[$app]);	
		}

		$style = isset($attr['style']) ? $attr['style'] : '';
		return JHTML::_('select.genericlist', $options, $name, $style, 'value', 'text', $value);
	}
	
	/**
	 * @return select box html of all available currency
	 * @param $name - name for the html element
	 * @param $value- selected value of currency
	 * @param $attr - other attributes of select box html
	 */
	function currency($name, $value, $attr=null )
	{
		$items = XiFactory::getInstance('currency', 'model')->loadRecords();

		// check for read only
		// XITODO : use disable property
		$readonly = isset($attr['readonly']);
		if($readonly){
			$html = '<lable>'.PayplansHelperFormat::currency($items[$value]).'</label>';
			$html.=	'<input type="hidden" name="'.$name.'" value="'.$value.'" />';
			return $html;
		}

		$options = array();
		foreach($items as $currency){
			$options[] = JHTML::_('select.option', $currency->currency_id, PayplansHelperFormat::currency($currency));
		}

		$style = isset($attr['style']) ? $attr['style'] : '';
		return JHTML::_('select.genericlist', $options, $name, $style, 'value', 'text', $value);
	}

	/**
	 * @return select box html of all available orders
	 * @param $name - name for the html element
	 * @param $value- selected value of order
	 * @param $attr - other attributes of select box html
	 */
	function orders($name, $value, $attr=null )
	{
		$orders = XiFactory::getInstance('order', 'model')->loadRecords();

		$options = array();
		if(isset($attr['none']))
			$options[] = JHTML::_('select.option', '', XiText::_('COM_PAYPLANS_ORDER_SELECT'));
		
		foreach($orders as $order)
    		$options[] = JHTML::_('select.option', $order->order_id, $order->order_id);

    	$style = isset($attr['style']) ? $attr['style'] : '';
    	return JHTML::_('select.genericlist', $options, $name, $style, 'value', 'text', $value);
	}

	/**
	 * @return multiselect html
	 * @param $name - name for the html element
	 * @param $value- selected value of order
	 * @param $attr - other attributes of select box html
	 */
	function xifbselect($arr, $name, $attribs = null, $key = 'value', $text = 'text', $selected = NULL)
	{
		// IMP : the giver $arr must be indexed by field given in $key

		$scriptPath = 'components/com_payplans/libraries/base/html/xifbselect/';
		XiHtml::script('jquery.tokeninput.js', 	$scriptPath);
		XiHtml::stylesheet('token.input.facebook.css', $scriptPath);
		
		$options = array();
		foreach($arr as $option){
			if(is_array($option)){
				$option = (object)$option;
			}

			$options[] = array('id' => $option->$key,
							   'name'  => $option->$text);
		}

		$selectedOptions = array();
		foreach($selected as $value){
			if(is_array($arr[$value])){
				$selectedOptions[] = array('id'=>$value, 'name'=>$arr[$value][$text]);
			}
			else{
				$selectedOptions[] = array('id'=>$value, 'name'=>$arr[$value]->$text);
			}
		}

		// define some variables so that these can be used in javascript
		$url = JURI::root().$scriptPath;
		$js  = 'var xiFbselectPath	= "'.$url.'"; ';         	// url contain the uurl path for image/other files
		$js .= 'var xiFbData'.$name.'  		= '.json_encode($options).';';         	// contains the data
		$js .= 'var xiFbName'.$name.'  		= "'.$name.'" ;';			// will give the text
		$js .= 'var xiFbSelected'.$name.' 	= '.json_encode($selectedOptions).';';				// and it will give the value

		$js .= 'xi.jQuery(document).ready(function() {'
						.'xi.jQuery("#xiFb'.$name.'").tokenInput("/tokeninput/tvshows.php", {'
						.'classes: {'
							.'tokenList: "token-input-list-facebook",'
							.'token: "token-input-token-facebook",'
							.'tokenDelete: "token-input-delete-token-facebook",'
							.'selectedToken: "token-input-selected-token-facebook",'
							.'highlightedToken: "token-input-highlighted-token-facebook",'
							.'dropdown: "token-input-dropdown-facebook",'
							.'dropdownItem: "token-input-dropdown-item-facebook",'
							.'dropdownItem2: "token-input-dropdown-item2-facebook",'
							.'selectedDropdownItem: "token-input-selected-dropdown-item-facebook",'
							.'inputToken: "token-input-input-token-facebook",'
							.'jsonContainer: xiFbData'.$name.','
        					.'prePopulate: xiFbSelected'.$name.','
        					.'inputTokenName: xiFbName'.$name
						.'}'
					.'});'
				.'});';

		$doc = XiFactory::getDocument();
		$doc->addScriptDeclaration($js);

		// the hidden varileb will override the post in nothing is selected
		// for this fb select element
		$content = '<div>'
					.'<input type="hidden" name="'.$name.'" />'
					.'<input type="text" id="xiFb'.$name.'" name="blah2" />'
					.'</div>';

		return $content;
	}
	
	/**
	 * @return text box formated price
	 * @param $name - name for the html element
	 * @param $value- selected value of price
	 * @param $attr - other attributes of price text box
	 */
	function price($name, $id, $value, $class='', $size='', $attr=null )
	{
		$value = PayplansHelperFormat::price($value);
		
		if(isset($attr['readonly'])){
			return $value.'<input type="hidden" name="'.$name.'" id="id_'.$name.'" value="'.$value.'" />';
		}
		
		$style = isset($attr['style']) ? $attr['style'] : '';
		
		return '<input type="text" name="'.$name.'" id="'.$name.'_0" value="'.$value.'" '.$class.' '.$size.' '.$attr.'/>';
	}
	
	function loglevel($name, $value, $attr = null)
	{
		$options = array();
		
		if(isset($attr['none']))
			$options[] = JHTML::_('select.option', '', XiText::_('COM_PAYPLANS_LOGGER_SELECT_LOGLEVEL'));

		foreach(XiLogger::getLevels() as $key => $val)
    		$options[] = JHTML::_('select.option', $key, $val);

    	$style = (isset($attr['style'])) ? $attr['style'] : '';
    	return JHTML::_('select.genericlist', $options, $name, $style, 'value', 'text', $value);
	}
	
	function logclass($name, $value, $attr = null)
	{
		$options = array();
		$options[] = JHTML::_('select.option', '', XiText::_('COM_PAYPLANS_LOGGER_SELECT_LOGCLASS'));
		$classes = array('SYSTEM', 'PayplansSubscription', 'PayplansOrder', 'PayplansConfig', 'PayplansPayment', 'PayplansUser', 'PayplansPlan');
		foreach($classes as $key)
    		$options[] = JHTML::_('select.option', $key, $key);

    	$style = (isset($attr['style'])) ? $attr['style'] : '';
    	return JHTML::_('select.genericlist', $options, $name, $style, 'value', 'text', $value);
	}
	
	function jusertype($name, $value, $attr=null, $ignore=array())
	{
		$groups = XiHelperJoomla::getUsertype();
		$options = array();
		if(isset($attr['none']))
			$options[] = JHTML::_('select.option', '', XiText::_('COM_PAYPLANS_SELECT_USERTYPE'));
			
		foreach($groups as $group=>$val){
			$options[] = JHTML::_('select.option', $val, $val);	
		}

		$style = isset($attr['style']) ? $attr['style'] : '';
		return JHTML::_('select.genericlist', $options, $name, $style, 'value', 'text', $value);

	}	
}
