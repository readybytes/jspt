<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

jimport('joomla.plugin.plugin');

/**
 * VERY IMP :
 * While adding functions into plugin, we should keep in mind
 * that all function not starting with _ (under-score), will be
 * added into plugins event functions. So while adding supportive
 * function, always start them with underscore
 */


class XiPlugin extends JPlugin
{
	protected $_tplVars = array();

	function __construct(& $subject, $config = array())
	{
		parent::__construct($subject, $config);

		//init the plugin
		$this->_initalize();
		
		//load language file
		$path = XiHelperJoomla::getPluginPath($this);
		$this->loadLanguage('', $path);
	}

	/**
	 * Check the plugin type
	 */
	public function _hasType($type="Unknown")
	{
		$type = JString::ucfirst(JString::strtolower($type));

		//simply check if I am instance of plugin type
		return is_a($this, 'XiPlugin'.$type);
	}

	protected function _initalize(Array $options= array())
	{}

	/**
	 * Plugin is available :
	 * If current plugin can be used ir-respective
	 * of conditions
	 */
	public function _isAvailable(Array $options= array())
	{}

	/**
	 * Plugin is available but check if
	 * It should be used for given conditions
	 */
	public function _isApplicable(Array $conditions= array())
	{}


	/**
	 * Render plugins template
	 */
	protected function _render($layout)
	{
		return $this->_loadTemplate($layout, $this->_name, $this->_type);
	}

	protected function _assign($key, $value)
	{
		$this->_tplVars[$key] = $value;
	}

	protected function _loadTemplate($layout, $plugin = null, $group = 'payplans' )
    {
        if($plugin===null){
            $plugin = $this->_name;
        }

        //find template file
        $layoutFile = $this->_getTemplatePath($plugin, $group, $layout);
        if($layoutFile===false){
        	XiError::raiseError(500, "Layout file : $layout missing for plugin $plugin");
        	return null;
        }

        ob_start();
        // Support tmpl vars
        // Extracting variables here
        unset($this->_tplVars['this']);
        unset($this->_tplVars['_tplVars']);
        extract((array)$this->_tplVars,  EXTR_OVERWRITE);

        include($layoutFile);
        $html = ob_get_contents();
        ob_end_clean();

        return $html;
    }


    protected function _getTemplatePath($plugin=null, $group='payplans', $layout = 'default')
    {
    	if($plugin===null)
            $plugin = $this->_name;

        $app = XiFactory::getApplication();

        //Security Checks : clean paths
        $plugin = preg_replace('/[^A-Z0-9_\.-]/i', '', $plugin);
        $layout = preg_replace('/[^A-Z0-9_\.-]/i', '', $layout);

        //XITODO : Move paths to addPath function, so that it can be extended.
        // get the template and default paths for the layout
        $paths[] = JPATH_THEMES.DS.$app->getTemplate().DS.'html'
        					 .DS.'plugins'.DS.$group.DS.$plugin;

        $paths[] = XiHelperJoomla::getPluginPath($this).DS.'tmpl';

        //find the path and return
        return JPath::find($paths, $layout.'.php');
    }
}
