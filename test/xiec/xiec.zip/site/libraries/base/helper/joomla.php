<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class XiHelperJoomla extends XiAbstractHelperJoomla  
{
	/**
	 *
	 * @param unknown_type $eventName
	 * @param array $data
	 * @return array
	 */
	static function triggerPlugin($eventName,array &$data =array(), $prefix='')
	{
		static $dispatcher = null;

		//load dispatcher if required
		if($dispatcher===null){
			$dispatcher = JDispatcher::getInstance();
		}

		//load payplans plugins
		self::loadPlugins();
		//$eventName = $prefix.JString::ucfirst($eventName);
		return $dispatcher->trigger($eventName, $data);
	}

	/**
	 * Loads plugin of given type
	 * @param $type
	 */
	static function loadPlugins($type='payplans')
	{
		static $loaded = array();

		//is already loaded
		if(isset($loaded[$type]))
			return true;

		//import plugins
		JPluginHelper::importPlugin($type);

		//set that plugins are already loaded
		$loaded[$type]= true;
		return true;
	}

	public static function getPluginStatus($element, $folder = 'system')
	{
		return JPluginHelper::isEnabled($folder, $element);
	}
	
	public function getPluginInstance($type, $name)
	{
		
		$observers = JDispatcher::getInstance()->get('_observers');
				
		foreach ($observers as $observer){
			if (is_array($observer) && isset($observer['_type']) && $observer['_type'] == $type && $observer['_name'] == $name){
					return $observer;
			}
			elseif (is_object($observer) && isset($observer->_type) && $observer->_type == $type && $observer->_name == $name){
					return $observer;
			}
		}

		return null;	
	}
}
