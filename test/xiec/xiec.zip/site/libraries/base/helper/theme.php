<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class XiHelperTheme
{
	/**
	 * @param string $path
	 */
	static public $paths = array(PAYPLANS_PATH_THEMES);
	static function addThemePath($path=null)
	{
		if($path != null){
			self::$paths[]= $path;
		}

		return self::$paths;
	}

	/**
	 * Load Apps from various folders
	 * @return Array of Apps
	 */
	static public $themes = null;
	static public function getThemes()
	{
		//already loaded
		if(self::$themes){
			return self::$themes;
		}

		//load themes from file systems
		self::$themes = array();
		foreach(self::addThemePath() as $path){
			$folders = JFolder::folders($path);
			
			if(!is_array($folders)){
				continue;
			}
			
			//theme-name v/s path
			//IMP : 3PD should name there theme as your_brand_name + theme_nature 
			// e.g. nestleblue, pepsiblue, it will ensure no un-intentional overwrite
			foreach($folders as $folder){
				self::$themes[$folder] = $path.DS.$folder;
			}
		}
		
		// also sort for consistent behaviour
		//sort(self::$themes);
		return self::$themes;
	}

	static $xmlData = null;
	static function getXml()
	{
		if(self::$xmlData !== null){
			return self::$xmlData;
		}			
		
		$attributes = array('name', 'title', 'author', 'thumbnail');
		foreach(self::getThemes() as $theme => $path){
			$xml = $path.DS.'theme.xml';
			$parser		= XiFactory::getXMLParser('Simple');

			// if document not loaded then skip it 
			if($parser->loadFile($xml) != true){
				continue;
			}
			$childrens = $parser->document->children();

			foreach($childrens as $child){
				$attribute = JString::strtolower($child->_name);
				
				if(in_array($attribute, $attributes)){
					self::$xmlData[$theme][$attribute] = $child->_data;
				}
			}
			
			//also store path
			self::$xmlData[$theme]['path']=$path;
			self::$xmlData[$theme]['urlpath']=XiHelperTheme::getThemeCssPath($theme);
		}

		return self::$xmlData;
	}
	
	static public function getThemeCssPath($theme, $path=null)
	{
		$themes 	= XiHelperTheme::getThemes();
		$themePath  = $path ? $path : $themes[$theme];

		// get reference path from root
		$themePath	= XiHelperUtils::str_ireplace(JPATH_ROOT.DS, '', $themePath);
		
		// replace all DS to URL-slash
		$themePath	= JPath::clean($themePath, '/');
		
		// prepend URL-root
		return JURI::root().$themePath;
	}
	
}
