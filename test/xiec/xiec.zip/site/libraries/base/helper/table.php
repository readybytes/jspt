<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


/**
 * Check the database and tells if table exist or not
 * @param $tableName : table name to test (with or without prefix)
 * @return boolean
 */
class XiHelperTable
{
	static $tables = null;
	
	static function isTableExist($tableName, $prefix='#__')
	{
		$db		 	=&	JFactory::getDBO();

		//clean cache if required
		if(XiFactory::cleanStaticCache()){
			self::$tables = null;
		}

		// load tables if required
		if(self::$tables == null){
			self::$tables	= $db->getTableList();
		}


		//if table name consist #__ replace it.
		$tableName = str_replace($prefix, $db->getPrefix(), $tableName);

		//check if table exist
		return in_array($tableName, self::$tables ) ? true : false;
	}

}