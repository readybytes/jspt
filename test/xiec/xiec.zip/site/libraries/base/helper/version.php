<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class XiHelperVersion
{
	static function getJoomlaVersion()
	{
		static $version=null;

		if($version===null){
			$version	= new JVersion();
		}
		
		$major=$version->RELEASE;
		$minor=$version->DEV_LEVEL;
		return array('major'=>$major , 'minor'=>$minor);
	}
}