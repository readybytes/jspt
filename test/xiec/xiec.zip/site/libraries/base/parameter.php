<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

jimport('joomla.html.parameter');
class XiParameter extends JParameter
{

	// overrride it to addElementPath
	function __construct($data='', $path = '')
	{
		parent::__construct($data, $path);
		
		// Set base path, this way other paths can be added automatically
		$this->addElementPath(PAYPLANS_PATH_ELEMENTS);
	}
	
	function render($name = 'params', $group = '_default')
	{
		if (!isset($this->_xml[$group])) {
			return false;
		}
		//XITODO : render form name as div id
		$params = $this->getParams($name, $group);
		ob_start();?>
		<?php XiHTML::_('behavior.tooltip'); ?>
		<div class="xiParameter">

		<?php if ($description = $this->_xml[$group]->attributes('description')) : ?>
			<div class="xiParameter xiRow" >
				<div class="xiParameter xiCol">
				<?php echo XiText::_($description) ; ?>
				</div>
			</div>
		<?php endif;?>

		<?php foreach ($params as $param) : ?>
			<div class="xiParameter xiRow <?php echo JString::str_ireplace('_', '-', $name.'-'.$param[5]);?>">
				<?php if ($param[0] && $param[0] != '&nbsp;'): ?>
					<div class="xiParameter xiCol xiColKey">
						<?php echo $param[0]; ?>
					</div>
					<div class="xiParameter xiCol xiColValue">
						<?php echo $param[1]; ?>
					</div>
				<?php else: ?>
					<div class="xiParameter xiCol xiColDescription">
						<?php echo $param[1]; ?>
					</div>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>

		<?php if(count($params) < 1) : ?>
			<div class="xiParameter xiRow">
				<div class="xiParameter xiCol"><i>
				<?php XiText::_('COM_PAYPLANS_THERE_ARE_NO_PARAMETER_FOR_THIS_ITEM'); ?>
				</i></div>
			</div>
		<?php endif; ?>

		</div>

		<?php
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
	
	function renderToArray($name = 'params', $group = '_default')
	{
		XiHTML::_('behavior.tooltip');
		if (!isset($this->_xml[$group])) {
			return array();
		}
		$results = array();
		$params = $this->getParams($name, $group);
		foreach($params as $result) {
			//$result = $this->getParam($param, $name);
			$result[2] = XiText::_($result[2]);
			$result[3] = XiText::_($result[3]);
			$results[$result[5]] = $result;
		}
		return $results;
	}
	
	public function loadINI($data, $namespace = null, $options = array())
	{
		//for 1.5 no change in behavior
		if(PAYPLANS_JVERSION_15){
			return parent::loadINI($data, $namespace, $options);
		}
		
		//for 1.6+ we will use our own writer
		return $this->loadString($data, 'XiINI', $options);
	}
	
	//need to use it as binding forwards to loadJSON, rathern then INI
	function bind($data, $group = '_default')
	{
		if ( is_array($data) ) {
			return $this->loadArray($data, $group);
		} elseif ( is_object($data) ) {
			return $this->loadObject($data, $group);
		} else {
			return $this->loadINI($data, $group);
		}
	}
	
	
	/**
	 * @over-ride : add multiple path of elements
	 * Sets the XML object from custom xml files
	 * 
	 * @access	public
	 * @param	object	An XML object
	 * @since	1.5
	 */
	function setXML( &$xml )
	{
		if (is_object( $xml ))
		{
			if ($dir = $xml->attributes( 'addpath' )) {
				foreach(explode(',', $dir) as $d){
					$this->addElementPath( JPATH_ROOT . str_replace('/', DS, trim($d)) );
				}
			 	$xml->removeAttribute('addpath');
			}
		}
		
		parent::setXML($xml);
	}
}