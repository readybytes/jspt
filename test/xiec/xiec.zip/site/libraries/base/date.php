<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

//XITODO : Improve it for our purpose
class XiDate extends XiAbstractDate
{
	const INVOICE_FORMAT = '%A %d %b, %Y';
	const SUBSCRIPTION_PAYMENT_FORMAT = '%d %b %Y';
	const SUBSCRIPTION_PAYMENT_FORMAT_HOUR = '%d %b %Y %R%p';
	
	/**
	 * @param $expirationTime : this will be in formation of YYMMDDHHMMSS
	 * @return unknown
	 */
	public function addExpiration($expirationTime)
	{
		XiError::assert(is_string($expirationTime), XiError::ERROR, "Expiration time is not as string");
		
		$timerElements = array('year', 'month', 'day', 'hour', 'minute', 'second');
		$date = date_parse($this->toString());
		
		$count = count($timerElements);
		if($expirationTime != 0){
			for($i=0; $i<$count ; $i++){
				$date[$timerElements[$i]] +=   intval(JString::substr($expirationTime, $i*2, 2), 10);
			}
			$this->_date = mktime($date['hour'], $date['minute'], $date['second'], $date['month'], $date['day'], $date['year']);
		}
		else{ 
			$this->_date=false;
		}

		return $this;
	}
	
	public function subtractExpiration($expirationTime)
	{
		XiError::assert(is_string($expirationTime), XiError::ERROR, "Expiration time is not as string");
		
		$timerElements = array('year', 'month', 'day', 'hour', 'minute', 'second');
		$date = date_parse($this->toString());
		
		$count = count($timerElements);
		for($i=0; $i<$count ; $i++){
			//XITODO : convert to integer before adding
			$date[$timerElements[$i]] -=   JString::substr($expirationTime, $i*2, 2);
		}
		
		$result= mktime($date['hour'], $date['minute'], $date['second'], $date['month'], $date['day'], $date['year']);
		XiError::assert($result);
		$this->_date = $result; 
						
		return $this;
	}
	
	
	public function toFormat($format=XiDate::INVOICE_FORMAT, $user=null, $config=null)
	{
		//$user and $config is for testing purpose only
		$config = ($config==null) ? XiFactory::getConfig() 	: $config;
		$my		= ($user==null)   ? XiFactory::getUser() 	: $user;
		
		//default offset
		$offset = $config->offset;
		
		//if user is logged in, then do it as per him
		if($my->id){
			$offset = $my->getParam('timezone', $offset);
		}

		// set the offset
		$this->setOffset($offset);
		
		// now format it
		return parent::toFormat($format) ;
	}

	
	static public function timeago($time)
	{	//XITODO : setting up timestamp
		//XITODO : check if user timzone was considered or not
		$date = new XiDate($time);
		$str  = $date->toISO8601();
		if($time=='0000-00-00 00:00:00'){
			return 'Never';
		}
		return "<span class='timeago' title='{$str}'>$time</span>"; 
	}
}