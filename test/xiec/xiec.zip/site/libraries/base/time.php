<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

//XITODO : Improve XiTime class for our purpose
class XiTime extends XiDate
{
	// constants
	const SECONDS 	= 1;
	const MINUTES 	= 2;
	const HOURS 	= 3;
	const DAYS		= 4;
	const MONTHS 	= 5;
	const YEARS 	= 6;

	public function __construct($time = '0000-00-00 00:00:00')
	{
		return parent::__construct($time,0);
	}

	//XITODO : implement it
	public function add()
	{

	}
}