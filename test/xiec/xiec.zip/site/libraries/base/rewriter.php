<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class XiRewriter extends JObject
{
	protected $mapping = array();
	
	public function setConfigMapping()
	{
		static $configMapping = false;
		if($configMapping){
			return true;
		}
		
		// initialize it with some hard coded tokens
		
		$ppConfig 						= XiFactory::getConfig();
		$config->site_name  			= rtrim($ppConfig->sitename, '/');
		$config->company_name   		= $ppConfig->companyName;
		$config->company_address 		= $ppConfig->companyAddress;
		$config->company_city_country 	= $ppConfig->companyCityCountry;
		$config->company_phone   		= $ppConfig->companyPhone;
		$config->site_url   			= rtrim(JURI::root(), '/');
		$config->name  					= 'config';
		$config->plan_renew_url			= '';
		
		$this->setMapping($config, false);
		$configMapping = true;
		return true;
	}

	/**
	 * @param string $str
	 * @param XiLib $refObject
	 * @param boolean $requireRelative set to false if do not need to get relative lib instance
	 */
	function rewrite($str, $refObject, $requireRelative = true)
	{
		//XITODO : remove setmapping here, do not mix two functions
		$this->setMapping($refObject, $requireRelative);
		
		// set config mapping
		$this->setConfigMapping();
		
		foreach($this->mapping as $key => $value){
			// XITODO : Support for array also
			if(!is_array($value)){
				$str =  preg_replace('/\[\['.$key.'\]\]/', $value, $str);
			}
		}
		
		return $str;
	}
	
	function setMapping($refObject, $requireRelative = true)
	{
		$refObjects = array();
		$refObjects = ($requireRelative) ? PayplansHelperRewriter::getRelativeObjects($refObject) : array($refObject);

		foreach($refObjects as $object){
			if(!$object){
				continue;
			}
			
			if(method_exists($object, 'getName')){
				$name = $object->getName();
			}
			else{
				$name = $object->name;
				unset($object->name);
			}

			$props = (method_exists($object, 'toArray')) ? $object->toArray(true) : (array)$object;
			$map   = array();

			foreach($props as $key => $value){
				// if key name starts with _ then continue
				if('_' == JString::substr(JString::trim($key), 0, 1)){
					continue;
				}

    			// JParameter will be an array, so handle it
				if(is_array($value)){
					foreach($value as $childKey => $childValue){
						$map[JString::strtoupper($name.'_'.$key.'_'.$childKey)] = $childValue;
					}
				}
				else{
					if(($object instanceOf PayplansIfaceMaskable) &&  JString::Strtolower($name.'_id') === JString::strtolower($key)){
						$value = $object->getKey();
					}
					$map[JString::strtoupper($name.'_'.$key)] = $value;
				}
			}
			
			$this->mapping = array_merge($this->mapping, $map);
		}
		//Assign subscription Renew Link.
		if (isset($this->mapping['ORDER_ORDER_ID'])){
			$this->mapping['CONFIG_PLAN_RENEW_URL'] = JURI::root()."/index.php?option=com_payplans&view=order&task=confirm&order_key=".$this->mapping['ORDER_ORDER_ID'];
		}
		return $this;
	}
	
	public function reset()
	{
		$this->mapping = array();
		return $this;
	}
}