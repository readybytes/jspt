<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class XiAbstractJ15HelperJoomla extends XiAbstractHelperJoomlaBase
{
	public static function changePluginState($element, $folder = 'system', $state=parent::ENABLE)
	{
		$db		= JFactory::getDBO();

		$query	= 'UPDATE ' . $db->nameQuote('#__plugins' )
				. ' SET '   . $db->nameQuote('published').'='.$db->Quote($state)
		        . ' WHERE ' . $db->nameQuote('element').'='.$db->Quote($element)
		        . ' AND ' . $db->nameQuote('folder').'='.$db->Quote($folder)
		        ;

		$db->setQuery($query);
		return $db->query();
	}
	
	public static function getPluginPath($plugin)
	{
		$path  = JPATH_PLUGINS.DS.$plugin->get('_type').DS.$plugin->get('_name');
		return $path;
	}
	
	public static function isMenuExist($link, $cid, $published=null, $alias=null)
	{
		$strQuery	= "SELECT `alias` FROM `#__menu` "
					  ." WHERE `link` LIKE '%$link%' AND "
					  ."`componentid`={$cid}"
					  . ( ($published !==null) ? " AND `published`= $published " : " ")
					  . ( ($alias !==null) ? " AND `alias`= '$alias' " : " ") 
					  ;
		$db = XiFactory::getDBO();
		$db->setQuery($strQuery);
		return $db->loadResult() ? true : false;
	}
	
	public static function addMenu($title, $alias, $link, $menu='mainmenu', $cid)
	{
		if(self::isMenuExist($link, $cid)){
			return true;
		}
		
		$db = XiFactory::getDBO();	
		$strQuery	= "INSERT IGNORE INTO `#__menu` (`menutype`, `name`, `alias`, `link`, `type`, `published`, `parent`, `componentid`, `sublevel`, `ordering`, `checked_out`, `checked_out_time`, `pollid`, `browserNav`, `access`, `utaccess`, `params`, `lft`, `rgt`, `home`) "
					  ."VALUES ('$menu', '$title', '$alias', '$link', 'component', 1, 0, $cid, 0, 500, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', 0, 0, 0)"
					  ;
		
		$db->setQuery($strQuery);
		return $db->query();
	} 
	
	public static function getUsertype()
	{
		$db= & JFactory::getDBO();
		$sql = ' SELECT `name` FROM '.$db->nameQuote('#__core_acl_aro_groups')
				.' WHERE '.$db->nameQuote('name').' NOT LIKE "%USERS%"'
				.' AND '.$db->nameQuote('name').' NOT LIKE  "%ROOT%"'
				.' AND '.$db->nameQuote('name').' NOT LIKE  "%Public%"';
		$db->setQuery($sql);
		return $db->loadResultArray();
	}
	
	public static  function isAdmin($userId)
	{
		$userType = XiFactory::getUser($userId)->usertype;
		if( $userType == 'Administrator' || $userType == 'Super Administrator'){
			return true;
		}
		return false;
	}
}

class XiAbstractHelperJoomla extends XiAbstractJ15HelperJoomla{}
