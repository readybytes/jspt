<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class XiAbstractJ16HelperJoomla extends XiAbstractHelperJoomlaBase
{
	public static function changePluginState($element, $folder = 'system', $state=parent::ENABLE)
	{
		$db		= XiFactory::getDBO();
		$query	= 'UPDATE '. $db->nameQuote( '#__extensions' )
				. ' SET   '. $db->nameQuote('enabled').'='.$db->Quote($newState)
				. ' WHERE '. $db->nameQuote('element').'='.$db->Quote($name)
				. ' AND ' . $db->nameQuote('folder').'='.$db->Quote($folder) 
				. " AND `type`='plugin' ";
		
		$db->setQuery($query);
		return $db->query();
	}
	
	public static function getPluginPath($plugin)
	{
		return  JPATH_PLUGINS.DS.$plugin->get('_type').DS.$plugin->get('_name').DS.$plugin->get('_name');
	}
	
	public static function isMenuExist($link, $cid, $published=null, $alias=null)
	{
		$strQuery	= "SELECT `alias` FROM `#__menu` "
					  ." WHERE `link` LIKE '%$link%' AND "
					  ." `component_id`={$cid}"
					  . ( ($published !==null) ? " AND `published`= $published " : " ")
					  . ( ($alias !==null) ? " AND `alias`= '$alias' " : " ") 
					  ;

		$db = XiFactory::getDBO();
		$db->setQuery($strQuery);
		return $db->loadResult() ? true : false;
	}
	
	public static function addMenu($title, $alias, $link, $menu, $cid)
	{
		if(self::isMenuExist($link, $cid, null, $alias)){
			return true;
		}
		
		jimport('joomla.application.application');
		$defaultMenuType	= JApplication::getInstance('site')->getMenu()->getDefault('workaround_joomla_bug')->menutype;
	
		//find order
		$db = XiFactory::getDBO();
		$query 	= 'SELECT ' . $db->nameQuote( 'ordering' ) . ' '
				. 'FROM ' . $db->nameQuote( '#__menu' ) . ' '
				. 'ORDER BY ' . $db->nameQuote( 'ordering' ) . ' DESC LIMIT 1';
		$db->setQuery( $query );
		$order 	= $db->loadResult() + 1;
	
		// Update the existing menu items.
		$row		= JTable::getInstance ( 'menu', 'JTable' );
		
		$row->id = null; 
		$row->menutype 		= $defaultMenuType;
		$row->title 		= $title;
		$row->alias 		= $alias;
		$row->link 			= $link;
		$row->type 			= 'component';
		$row->published 	= '1';
		$row->component_id 	= $cid;
		$row->ordering 		= $order;
//		$row->parent_id		= 1; // gives segmentation fault
		
				
		if(!$row->check() || !$row->store()){
			return false;
		}

		//update parent id
		$query =   ' UPDATE '. $db->nameQuote( '#__menu' ) 
				 . ' SET `parent_id` = '.$db->quote(1).', `level` = ' . $db->quote(1) 
				 . ' WHERE `id` = '.$db->quote($row->id) ;
		$db->setQuery( $query );
		return $db->query();

		return true;
	} 
	
	public static function getUsertype()
	{
		$db= & JFactory::getDBO();
		$sql = ' SELECT `title` FROM '.$db->nameQuote('#__usergroups')
				.' WHERE '.$db->nameQuote('title').' NOT LIKE "%Public%"';
		$db->setQuery($sql);
		return $db->loadResultArray();
	}
}

class XiAbstractHelperJoomla extends XiAbstractJ16HelperJoomla{}