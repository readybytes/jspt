<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class XiAbstractJ16Html extends XiAbstractHtmlBase
{
	public static function _($key)
	{
		$prefix = '';
		if(preg_match('/^grid/i', $key) || preg_match('/^filters/i', $key) || preg_match('/^elements/i', $key)){
			$prefix= 'XiHtml.';
			self::addIncludePath(PAYPLANS_PATH_LIBRARY.DS.'html');
		}

		$extraArgs = func_get_args();
		$extraArgs[0] = $prefix.$extraArgs[0];
		return call_user_func_array( array( 'JHTML', '_' ), $extraArgs );
	}
	
	public static function stylesheet($filename, $path = 'components/com_payplans/media/css/', $attribs = array())
	{
		return parent::_stylesheet($filename, $path, $attribs);
	}

	/**
	 * Singnificant changes in 1.6 inclusion.
	 */
	public static function script($filename, $path ='components/com_payplans/media/js/', $relative = false,  $path_only = false, $detect_browser = true)
	{
		$config =  XiFactory::getConfig();
		if(isset($config->expert_useminjs) && $config->expert_useminjs){
			$filename = self::minFile($filename, $path);
		}
		
		return parent::script($filename, $path, $relative, $relative = false,  $path_only = false, $detect_browser = true);
	}

}

class XiAbstractHtml extends XiAbstractJ16Html
{}