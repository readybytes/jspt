<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class XiAbstractHtmlBase extends JHtml
{
	function _stylesheet($filename, $path = 'components/com_payplans/media/css/', $attribs = array())
	{
			return JHTML::stylesheet($filename, $path, $attribs);
	}


	function minFile($filename, $path, $ext='js')
	{
		//use minified scripts
		$newFilename = JFile::stripExt($filename) . '-min.'.$ext;

		// no need to add path
		if(strpos($path, 'http') === 0) {
			return $filename;
		};
		
		// add absolute root path
		if(strpos($path, JPATH_ROOT) !== 0) {
			$path =  JPATH_ROOT.DS.$path;
		};
		
		// use minified only if it exists
		if(JFile::exists("$path/$newFilename")){
			return $newFilename;
		}
		
		return $filename;
	}
}


// Include the Joomla Version Specific class, which will ad XiAbstractHtml class automatically
XiError::assert(class_exists('XiAbstractJ'.PAYPLANS_JVERSION_FAMILY.'Html',true), XiError::ERROR);