<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansModelPayment extends XiModel
{

	public function buildFilterMatch()
	{
		$this->filterMatchOpeartor['status'] 			= array('=');
		$this->filterMatchOpeartor['order_id'] 			= array('=');
		$this->filterMatchOpeartor['app_id'] 			= array('=');
		$this->filterMatchOpeartor['amount'] 			= array('>=', '<=');
		$this->filterMatchOpeartor['created_date']		= array('>=', '<=');
		$this->filterMatchOpeartor['modified_date']		= array('>=', '<=');
	}
}

