<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansModelSubscription extends XiModel
{
	// XITODO : HIGH : Apply validation when it is applied all over
	function validate(&$data, $pk=null,array $filter = array(),array $ignore = array())
	{
		return true;
	}

	/**
	 * find all active subscription
	 * which are expected to expire on given time
	 */
	public function getActiveSubscriptions(XiDate $time=null)
	{
		$query = $this->getQuery();

		//there might be no table and no query at all
		if($query === null )
			return array(null);

		if($time === null){
		 	$time = new XiDate();
		}

		$tmpQuery = unserialize(serialize($query));
		$tmpQuery->clear('where')
				 ->where("`tbl`.`expiration_date` < '".$time->toMySQL()."' AND `tbl`.`expiration_date` <> '0000-00-00 00:00:00'")
				 ->where('`tbl`.`status` = '.XiStatus::SUBSCRIPTION_ACTIVE);

		return $tmpQuery->dbLoadQuery()->loadObjectList($this->getTable()->getKeyName());
	}
	
	public function getPreExpirySubscriptions(Array $plans, $preExpiryTime)
	{
		//get query
		$query = $this->getQuery();
		$tmpQuery = unserialize(serialize($query));

		// E1 : preexpiry time as per last cron run
		// E2 : preexpiry time as per current cron run
		// if expiration time is between E1 & E2
		// we will trigger PreExpiry event for subcsription
		$e1 = new XiDate(XiFactory::getConfig()->cronAcessTime);
		$e2	= new XiDate('now');
	
		$e1->addExpiration($preExpiryTime);
		$e2->addExpiration($preExpiryTime);

		$tmpQuery->clear('where')
				 ->where("`tbl`.`expiration_date` > '".$e1->toMySQL()."'" )
				 ->where("`tbl`.`expiration_date` < '".$e2->toMySQL()."'" )
				 ->where("`tbl`.`plan_id` in ( ". implode(',', $plans)." )" )					 
				 ->where('`tbl`.`status` = '.XiStatus::SUBSCRIPTION_ACTIVE);

		return $tmpQuery->dbLoadQuery()->loadObjectList($this->getTable()->getKeyName());
	}
	
	public function buildFilterMatch()
	{
		$this->filterMatchOpeartor['plan_id'] 			= array('=');
		$this->filterMatchOpeartor['status'] 			= array('=');
		$this->filterMatchOpeartor['subscription_date'] = array('>=', '<=');
		$this->filterMatchOpeartor['expiration_date'] = array('>=', '<=');
	}
}