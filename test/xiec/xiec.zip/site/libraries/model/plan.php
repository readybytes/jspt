<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansModelPlan extends XiModel
{
	// XITODO : Apply validation when it is applied all over
	function validate(&$data, $pk=null,array $filter = array(),array $ignore = array())
	{
		return true;
	}
	
	public function delete($pk)
	{
		if(!parent::delete($pk))
		{
			$db = JFactory::getDBO();
			XiError::raiseError(500, $db->getErrorMsg());
		}
		// delete plans from planapp table
		return XiFactory::getInstance('planapp', 'model')
						 	 ->deleteMany(array('plan_id' => $pk));
	}

	public function buildFilterMatch()
	{
		$this->filterMatchOpeartor['title'] 	= array('LIKE');
		$this->filterMatchOpeartor['published'] = array('=');
		$this->filterMatchOpeartor['visible'] 	= array('=');
	}
}

