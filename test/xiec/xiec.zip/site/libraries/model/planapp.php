<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansModelPlanapp extends XiModel
{
	// XITODO : Apply validation when it is applied all over
	function validate(&$data, $pk=null,array $filter = array(),array $ignore = array())
	{
		return true;
	}

	function getPlanApps($planId)
	{
		XiError::assert($planId, "INVALID PLAN ID $planId");

		// XITODO :needs to be improved
		// 	load extra data we need
		$query = clone($this->getQuery());
		$query->clear('select');

		$app = $query->select('app_id')
					 ->where(" plan_id  = $planId ")
					 ->dbLoadQuery()
					 ->loadResultArray();

		return $app;
	}

	function getAppPlans($appId)
	{
		XiError::assert($appId, XiText::_('COM_PAYPLANS_INVALID_APP_ID'));

		// XITODO :needs to be improved
		$query = clone($this->getQuery());
		$query->clear('select');

		return $query->select('plan_id')
					 ->where("app_id  = $appId")
					 ->dbLoadQuery()
					 ->loadResultArray();
	}
}

