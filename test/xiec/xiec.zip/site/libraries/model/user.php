<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * Class assumes that user should always be synched-up with
 * joomla core user system
 * This will not support those user who are not listed in payplans_user table
 * IMP : Will maintain synchup during installation and while visiting users in backend 
 * @author meenal
 *
 */
class PayplansModelUser extends XiModel
{
	/**
     * Builds FROM tables list for the query
     */
    protected function _buildQueryFrom(XiQuery &$query)
    {
    	$db			=	XiFactory::getDBO();
    	$table		=	$this->getTable();
    	$tname		=	$table->getTableName();

    	if(PAYPLANS_JVERSION_15){
	    	$query->from('( SELECT 
				    				joomlausertbl.`id` AS user_id, 
				    				joomlausertbl.`name` AS realname,
				    				joomlausertbl.`username` AS username,
				    				joomlausertbl.`email` AS email,
				    				joomlausertbl.`usertype` AS usertype,
				    				joomlausertbl.`registerDate` AS registerDate,			    				
				    				joomlausertbl.`lastvisitDate` AS lastvisitDate,			    				
				    				t.`params`			    				
							  FROM 
							  		`#__users` AS joomlausertbl
							  LEFT JOIN 
							  		`#__payplans_user` AS t 
							  		ON ( t.`user_id` = joomlausertbl.`id` )
						  )	AS tbl'
						);
    	}
    	
    	else
    	{
			//XITODO : proper handling when there are multiple usergroups
    		$query->from('( SELECT 
			    				joomlausertbl.`id` AS user_id, 
			    				joomlausertbl.`name` AS realname,
			    				joomlausertbl.`username` AS username,
			    				joomlausertbl.`email` AS email,
			    				joomlausertype.`usertype` AS usertype,
			    				joomlausertbl.`registerDate` AS registerDate,			    				
			    				joomlausertbl.`lastvisitDate` AS lastvisitDate,			    				
			    				t.`params`			    				
						  FROM 
						  		`#__users` AS joomlausertbl
						  LEFT JOIN 
						  		`#__payplans_user` AS t 
						  		ON ( t.`user_id` = joomlausertbl.`id` )
						  LEFT JOIN
						         	(SELECT
						         		 usergroupmap.`user_id`, usergroupmap.`group_id`, groups.`title` AS usertype 
									FROM
										 `#__user_usergroup_map` AS usergroupmap
									LEFT JOIN 
										`#__usergroups` AS groups
										ON (groups.`id` = usergroupmap.`group_id`)) AS joomlausertype
										ON (joomlausertype.`user_id` = joomlausertbl.`id`)	
					  )	AS tbl'
					);
    	}
    }

	public function buildFilterMatch()
	{
		$this->filterMatchOpeartor['username'] = array('LIKE');
		$this->filterMatchOpeartor['usertype'] = array('=');
	}
	
	//added filter for user so it is necessary to override _buildQueryFilter function here 
	//so that proper query can be build corresponding to applied filter
	protected function _buildQueryFilter(XiQuery &$query, $key, $value)
    {
    	// Only add filter if we are working on bulk records
		if($this->getId()){
			return $this;
		}
		
    	XiError::assert(isset($this->filterMatchOpeartor[$key]), "OPERATOR FOR $key IS NOT AVAILABLE FOR FILTER");
    	XiError::assert(is_array($value), XiText::_('COM_PAYPLANS_VALUE_FOR_FILTERS_MUST_BE_AN_ARRAY'));

    	$cloneOP    = $this->filterMatchOpeartor[$key];
    	$cloneValue = $value;
    	
    	while(!empty($cloneValue) && !empty($cloneOP)){
    		$op  = array_shift($cloneOP);
    		$val = array_shift($cloneValue);

			// discard empty values
    		if(!isset($val) || '' == JString::trim($val))
    			continue;

			
    		if(JString::strtoupper($op) != 'LIKE'){
				$query->where("`$key` $op '$val'");
				continue;
			}
		
			// filter according to username, realname and email
   			if($key == 'username'){
    	  		$query->where("( `$key` $op '%{$val}%' || `realname` $op '%{$val}%' || `email` $op '%{$val}%' )");
    	  	}
	    	else {
	    	  	$query->where("`$key` $op '%{$val}%'");			
	    	}
		}
    }
}