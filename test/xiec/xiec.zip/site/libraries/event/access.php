<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Loggers
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansEventAccess
{
	public function onPayplansAccessCheck(PayplansUser $user)
	{
		if(!$user->getId()){
			return true;
		}
		
		// Block if user don't have active subscription
		if(!XiFactory::getConfig()->accessLoginBlock){
			return true;
		}

		$option = JRequest::getVar('option', false);
		$task 	= JRequest::getVar('task', false);
		$view 	= JRequest::getVar('view', false);
		if($option == 'com_payplans'){
			return true;
		}
		
		// Do not block login attempt, we will capture on next page
		if($option == PAYPLANS_COM_USER){ // && ($task== false || $task== 'login' || $task== 'logout')){
			return true;
		}
			
		$subs  = $user->getSubscriptions(XiStatus::SUBSCRIPTION_ACTIVE);
			
		//block user if no active subscription
		if(count($subs) <= 0){
			//XITODO : Handle ajax also
			XiFactory::getApplication()->redirect(XiRoute::_('index.php?option=com_payplans&view=dashboard&task=noaccess'));
		}
		
		return true;
	}
}
