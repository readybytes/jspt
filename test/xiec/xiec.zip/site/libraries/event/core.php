<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Loggers
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansEventCore
{
//	/**
//	 * this event is triggered before saving order
//	 */
//	function onPayplansOrderBeforeSave($previous, $current)
//	{
//		return true;
//	}
//
//	/**
//	 * this event is triggered before saving plan
//	 */
//	function onPayplansPlanBeforeSave($previous, $current)
//	{
//		return true;
//	}
//
//	/**
//	 * this event is triggered before saving payment
//	 */
//	function onPayplansPaymentBeforeSave($previous, $current)
//	{
//		return true;
//	}
//
//	/**
//	 * this event is triggered before saving subscription
//	 */
//	function onPayplansSubscriptionBeforeSave($previous, $current)
//	{
//		return true;
//	}


	/* trigger of On After Save */

	/**
	 * this event is triggered After saving order
	 */
	function onPayplansOrderAfterSave($previous, $current)
	{
		// Consider Previous State also
		if(isset($previous) && $previous->getStatus() == $current->getstatus())
			return true;
			
		// if there is change in status of order
		switch($current->getStatus()){
			case Xistatus::NONE 			:
								$subsStatus = XiStatus::NONE;
								break;

			case Xistatus::ORDER_CONFIRMED	:
								$subsStatus = XiStatus::NONE;
								break;

			case Xistatus::ORDER_COMPLETE	:
								$subsStatus = XiStatus::SUBSCRIPTION_ACTIVE;
								break;

			case Xistatus::ORDER_HOLD		:
								$subsStatus = XiStatus::SUBSCRIPTION_HOLD;
								break;
								
			case Xistatus::ORDER_EXPIRED		:
								$subsStatus = XiStatus::SUBSCRIPTION_EXPIRED;
								break;

			case Xistatus::ORDER_PAID		:
			default 						:
								$subsStatus = XiStatus::NONE;
		}

		$subs = $current->getSubscriptions();
		foreach($subs as $s){
			//$subscription = PayplansSubscription::getInstance($s->subscription_id);
			$s->load($s->getId());

			// no change in status then need not to update
			if($s->getStatus() == $subsStatus || !$subsStatus)
				continue;
			
			$s->setStatus($subsStatus)->save();
		}

		return true;
	}

//	/**
//	 * this event is triggered After saving Plan
//	 */
//	function onPayplansPlanAfterSave($previous, $current)
//	{
//		return true;
//	}

	/**
	 * this event is triggered After saving payment
	 */
//	function onPayplansPaymentAfterSave($previous, $current)
//	{
//		$order = PayplansOrder::getInstance( $current->getOrder());
//
//		// if there is change in status of order
//		switch($current->getStatus()){
//			case Xistatus::NONE 			:
//							$orderStatus = XiStatus::NONE;
//							break;
//
//			case Xistatus::PAYMENT_COMPLETE	:
//							// check for new recurring payment
//							// #1 : if its a new payment, means previous object is null
//							// #2 : if attached order has any master payment ( for recurring)
//							// #3 : if this order has more than 2 payments 
//							// then we should renew subscription
//							
//							$masterPayment = XiFactory::getInstance('payment', 'model')
//													->loadRecords(array('order_id' => $order->getId(), 'status' => XiStatus::PAYMENT_RECURRING_SIGNUP));
//							$totalPayment  = XiFactory::getInstance('payment', 'model')
//													->loadRecords(array('order_id' => $order->getId()));
//							
//							if( ($previous == null || $previous->getStatus() != $current->getStatus())
//									 && !empty($masterPayment) && count($totalPayment) > 2){
//								$order->renewSubscriptions();
//								$orderStatus = XiStatus::ORDER_COMPLETE;
//								break;
//							}
//							
//							$orderStatus = XiStatus::ORDER_COMPLETE;
//							if(XiFactory::getconfig()->autoCompleteOrder == false){
//								$orderStatus = XiStatus::ORDER_PAID;
//							}
//							break;
//
//			case Xistatus::PAYMENT_HOLD		:
//							$orderStatus = XiStatus::ORDER_HOLD;
//							break;
//
//			case Xistatus::PAYMENT_PENDING  :
//			case Xistatus::PAYMENT_INITIATED:
//							$orderStatus = XiStatus::ORDER_CONFIRMED;
//							break;
//
//			default 						:
//							$orderStatus = XiStatus::NONE;
//		}
//
//
//		if($order->getStatus() != $orderStatus && $orderStatus){
//			$order->set('status', $orderStatus)
//						 ->save();
//		}

//		return true;
//	}

//	/**
//	 * this event is triggered After saving subscription
//	 */
//	function onPayplansSubscriptionAfterSave($previous, $current)
//	{
//		return true;
//	}

//	/**
//	 * A global cron trigger
//	 * we need to trigger few function to work on
//	 * scheduled tasks
//	 */
//	public function onPayplansCron()
//	{
//		return true;
//	}
	
	public function onPayplansOrderBeforeDelete($order)
	{	
		$subscriptions = $order->getSubscriptions();

		  // delete all the subscriptions linked with this order
		  if(!empty($subscriptions)){
				foreach($subscriptions as $subscription){
					$subscription->delete();
				}
			}

			$payments = $order->getPayments();
			
		  // delete all the payment linked with this order
			if(!empty($payments)){
				foreach($payments as $payment){
					$payment->delete();
				}
			}

			return true;
	}
	
	// Mark subscription expire
	public function onPayplansCron()
	{
		$message = XiText::_('COM_PAYPLANS_LOGGER_CRON_START');
		PayplansHelperLogger::log(XiLogger::LEVEL_INFO, $message, null, $message, 'XiFormatter', 'Payplans_Cron');
		return PayplansHelperCron::doSubscriptionExpiry();
	}
	
	// remove logs records if it is a standard version
	public function onPayplansViewBeforeRender(XiView $view, $task)
	{
		if(!PAYPLANS_PREMIUM_BUILD){
			// for standard version block log_records
			if($view->getName() != 'log' && $view->get('log_records')){
				$view->assign('log_records',array());
			}
		}
		return true;
	}
	
	// Add Premium themes if exists
	public function onPayplansSystemStart()
	{
		if(PAYPLANS_PREMIUM_BUILD){
			//add app paths to app loader
			$path = PAYPLANS_PATH_MEDIA.DS.'premium_themes';
			XiHelperTheme::addThemePath($path);
		}
		return true;
	}
	
	// Add Module at header n footer of payplan screens.
	public function onPayplansViewAfterRender(XiView $view, $task, $output)
	{
		// only for front end
		if(XiFactory::getApplication()->isAdmin()==true){
			return '';
		}
		
		jimport( 'joomla.application.module.helper' );
		
		$value = new JRequest();
		$position = 'payplans' . "-";
		
		if(isset($view->_name))
			$position .=  $view->_name . "-";
		
		if(isset($task))
			$position.= $task . "-";
		
		if(!isset($attribs['style']))
			$attribs['style']	= 'xhtml';
		
		//Display module at header position	
		$modules 	= JModuleHelper::getModules( $position."top" );
		$modulehtmlTop = '';
		foreach($modules as $module){
				$modulehtmlTop .= JModuleHelper::renderModule($module, $attribs);				
		}
		
		//Display module at footer position
		$modules 	= JModuleHelper::getModules( $position."bottom" );
		$modulehtmlBottom = '';
		foreach($modules as $module){
				$modulehtmlBottom .= JModuleHelper::renderModule($module, $attribs);				
		}
		
		$output = $modulehtmlTop . $output . $modulehtmlBottom;
		
		return true;
	}
	
	//before deleting subscription changed its status to expired
	//so as to trigger all the app which are set on status "Subscription-expired" 
	//and do what thay are expected to on subscription expired status before the subscription gets deleted
	public function onPayplansSubscriptionBeforeDelete($object)
	{
		// Expire only when it is already active
		if($object->getStatus() == XiStatus::SUBSCRIPTION_ACTIVE){
			$object->setStatus(XiStatus::SUBSCRIPTION_EXPIRED)
					->save();
		}
		return true;
	}

}