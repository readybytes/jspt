<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Loggers
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansEventCore
{
//	/**
//	 * this event is triggered before saving order
//	 */
//	function onPayplansOrderBeforeSave($previous, $current)
//	{
//		return true;
//	}
//
//	/**
//	 * this event is triggered before saving plan
//	 */
//	function onPayplansPlanBeforeSave($previous, $current)
//	{
//		return true;
//	}
//
//	/**
//	 * this event is triggered before saving payment
//	 */
//	function onPayplansPaymentBeforeSave($previous, $current)
//	{
//		return true;
//	}
//
//	/**
//	 * this event is triggered before saving subscription
//	 */
//	function onPayplansSubscriptionBeforeSave($previous, $current)
//	{
//		return true;
//	}


	/* trigger of On After Save */

	/**
	 * this event is triggered After saving order
	 */
	function onPayplansOrderAfterSave($previous, $current)
	{
		// Consider Previous State also
		if(isset($previous) && $previous->getStatus() == $current->getstatus())
			return true;
			
		// if there is change in status of order
		switch($current->getStatus()){
			case Xistatus::NONE 			:
								$subsStatus = XiStatus::NONE;
								break;

			case Xistatus::ORDER_CONFIRMED	:
								$subsStatus = XiStatus::NONE;
								break;

			case Xistatus::ORDER_COMPLETE	:
								$subsStatus = XiStatus::SUBSCRIPTION_ACTIVE;
								break;

			case Xistatus::ORDER_HOLD		:
								$subsStatus = XiStatus::SUBSCRIPTION_HOLD;
								break;
								
			case Xistatus::ORDER_EXPIRED		:
								$subsStatus = XiStatus::SUBSCRIPTION_EXPIRED;
								break;

			case Xistatus::ORDER_PAID		:
			default 						:
								$subsStatus = XiStatus::NONE;
		}

		$subs = XiFactory::getInstance('subscription', 'model')
							->loadrecords(array('order_id' => $current->getId()), array('limit'));

		$subscription = PayplansSubscription::getInstance();
		foreach($subs as $s){
			$subscription->load($s->subscription_id);

			// no change in status then need not to update
			if($subscription->getStatus() == $subsStatus || !$subsStatus)
				continue;

			//XITODO : This should be done via lib itself.
			// Nobody should update status from outside world
			$subscription->set('status', $subsStatus)
						 ->save();
		}

		return true;
	}

//	/**
//	 * this event is triggered After saving Plan
//	 */
//	function onPayplansPlanAfterSave($previous, $current)
//	{
//		return true;
//	}

	/**
	 * this event is triggered After saving payment
	 */
	function onPayplansPaymentAfterSave($previous, $current)
	{
		$order = PayplansOrder::getInstance( $current->getOrder());

		// if there is change in status of order
		switch($current->getStatus()){
			case Xistatus::NONE 			:
							$orderStatus = XiStatus::NONE;
							break;

			case Xistatus::PAYMENT_COMPLETE	:
							// check for new recurring payment
							// #1 : if its a new payment, means previous object is null
							// #2 : if attached order has any master payment ( for recurring)
							// #3 : if this order has more than 2 payments 
							// then we should renew subscription
							
							$masterPayment = XiFactory::getInstance('payment', 'model')
													->loadRecords(array('order_id' => $order->getId(), 'status' => XiStatus::PAYMENT_RECURRING_SIGNUP));
							$totalPayment  = XiFactory::getInstance('payment', 'model')
													->loadRecords(array('order_id' => $order->getId()));
							
							if( ($previous == null || $previous->getStatus() != $current->getStatus())
									 && !empty($masterPayment) && count($totalPayment) > 2){
								$order->renewSubscriptions();
								$orderStatus = XiStatus::ORDER_COMPLETE;
								break;
							}
							
							$orderStatus = XiStatus::ORDER_COMPLETE;
							if(XiFactory::getconfig()->autoCompleteOrder == false){
								$orderStatus = XiStatus::ORDER_PAID;
							}
							break;

			case Xistatus::PAYMENT_HOLD		:
							$orderStatus = XiStatus::ORDER_HOLD;
							break;

			case Xistatus::PAYMENT_PENDING  :
			case Xistatus::PAYMENT_INITIATED:
							$orderStatus = XiStatus::ORDER_CONFIRMED;
							break;

			default 						:
							$orderStatus = XiStatus::NONE;
		}


		if($order->getStatus() != $orderStatus && $orderStatus){
			$order->set('status', $orderStatus)
						 ->save();
		}

		return true;
	}

//	/**
//	 * this event is triggered After saving subscription
//	 */
//	function onPayplansSubscriptionAfterSave($previous, $current)
//	{
//		return true;
//	}

//	/**
//	 * A global cron trigger
//	 * we need to trigger few function to work on
//	 * scheduled tasks
//	 */
//	public function onPayplansCron()
//	{
//		return true;
//	}
	
	public function onPayplansOrderAfterDelete($order_id)
	{	
			$subscrRecords = XiFactory::getInstance('subscription','model')
										->loadRecords(array('order_id'=>$order_id));

			if(!empty($subscrRecords)){
				foreach($subscrRecords as $record){
					$subscription = PayplansSubscription::getInstance($record->subscription_id)
														->delete();
				}
			}
			
			$payments = XiFactory::getInstance('payment','model')
										->loadRecords(array('order_id'=>$order_id));

			if(!empty($payments)){
				foreach($payments as $record){
					$payment = PayplansPayment::getInstance($record->payment_id)
														->delete();
				}
			}
	}
	
	// Mark subscription expire
	public function onPayplansCron()
	{
		$message = XiText::_('COM_PAYPLANS_LOGGER_CRON_START');
		PayplansHelperLogger::log(XiLogger::LEVEL_INFO, $message, null, $message);
		return PayplansHelperCron::doSubscriptionExpiry();
	}
	
	// remove logs records if it is a standard version
	public function onPayplansViewBeforeRender(XiView $view, $task)
	{
		if(!PAYPLANS_PREMIUM_BUILD){
			// for standard version block log_records
			if($view->getName() != 'log' && $view->get('log_records')){
				$view->assign('log_records',array());
			}
		}
		return true;
	}

}