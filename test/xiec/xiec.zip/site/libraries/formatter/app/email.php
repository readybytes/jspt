<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansFormatterAppEmail extends XiFormatter
{
	function reader($content)
	{
		$content = unserialize(base64_decode(array_shift($content)));

		if(is_array($content))
			return $content;

		return false;
	}
	
	function formatter($content)
	{
		$ignore   = array('_trigger', '_tplVars', '_mailer', '_location', '_errors', '_component', '_appplans', 'app_params');
		
		$previous = array_key_exists('previous', $content)  ?  $content['previous']  : array();
		$current  = array_key_exists('current', $content)   ?  $content['current']   : array();

		$prev = $previous;
		$curr = $current;

		// XITODO : move it to a function
		if(isset($prev['app_params'])){
			$prev_param = PayplansHelperParam::iniToArray($prev['app_params']);
			foreach($prev_param as $param=>$value){
				if($param == 'content'){
					$prev[$param] = base64_decode($prev_param[$param]);
					continue;
				}
				$prev[$param] = $value;
			}
		}
		
		if(isset($curr['app_params'])){
			$curr_param = PayplansHelperParam::iniToArray($curr['app_params']);
			foreach($curr_param as $param=>$value){
				if($param == 'content'){
					$curr[$param] = base64_decode($curr_param[$param]);
					continue;
				}
				$curr[$param] = $value;
			}
		} 

		foreach($ignore as $key){
			unset($prev[$key]);
			unset($curr[$key]);
		}
		$data['previous'] = $prev;
		$data['current']  = $curr;
		return $data;
	}
}