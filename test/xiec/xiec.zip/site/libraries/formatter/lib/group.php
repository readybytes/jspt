<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansFormatterLibGroup extends XiFormatter
{
	function reader($content)
	{
		$content = unserialize(base64_decode(array_shift($content)));
		
		if(is_array($content) && (array_key_exists('previous', $content) || array_key_exists('current', $content)))
			return $content;
			
		return $content;
	}

	function getIgnoredata()
	{
		$ignore = array('_component', '_errors', '_name', '_tplVars', '_trigger');
		return $ignore;
	}
}