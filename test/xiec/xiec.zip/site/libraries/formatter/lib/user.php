<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansFormatterLibUser extends XiFormatter
{
	function reader($content)
	{
		
		$content = unserialize(base64_decode(array_shift($content)));
		
		if(is_array($content) && (array_key_exists('previous', $content) || array_key_exists('current', $content)))
			return $content;
		
		return false;
	}

	function getIgnoredata()
	{
		$ignore = array('_trigger', '_component', '_errors', '_name', '_subscriptions', 'name');
		return $ignore;
	}
	
    function formatter($content)
	{   
	   $data=parent::formatter($content);
		
       //change country id to country name
	   $prev_country=PayplansHelperFormat::country(XiFactory::getCountry($data['previous']['country']));
	   $curr_country=PayplansHelperFormat::country(XiFactory::getCountry($data['current']['country']));
       
	   if(($prev_country === true) || ($prev_country == "Select Country"))
           $data['previous']['country'] = XiText::_('COM_PAYPLANS_LOG_COUNTRY_NONE');
		 else 
		   $data['previous']['country'] = $prev_country;
				        
	   if(($curr_country === true) || ($curr_country == "Select Country"))
	       $data['current']['country'] = XiText::_('COM_PAYPLANS_LOG_COUNTRY_NONE');	
       else 
		   $data['current']['country'] = $curr_country;
	
	   return $data;
	}
}