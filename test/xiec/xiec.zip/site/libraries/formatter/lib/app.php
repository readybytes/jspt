<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansFormatterLibApp extends XiFormatter
{
	function reader($content)
	{
		$content = unserialize(base64_decode(array_shift($content)));
		
		if(is_array($content) && (array_key_exists('previous', $content) || array_key_exists('current', $content)))
			return $content;
		
		return $content;
	}
	
	function formatter($content, $type)
	{
		if($type == 'PayplansAppEmail')
		{
			if(class_exists('PayplansFormatterAppEmail')){
				return PayplansFormatterAppEmail::formatter($content);
			}
		}
		
		return parent::formatter($content);
	}
	
	function getIgnoredata()
	{
		$ignore = array('_trigger', '_component', '_name', '_errors', '_tplVars','_location');
		return $ignore;
	}
}