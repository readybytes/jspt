<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansFormatterLibConfig extends XiFormatter
{
	function reader($content)
	{
		$content = unserialize(base64_decode(array_shift($content)));
		
		if(is_array($content) && (array_key_exists('previous', $content) || array_key_exists('current', $content)))
		{
			return $content;
		}
		
		return false;
	}

	function getIgnoredata()
	{
		$ignore = array('dbtype', 'host', 'user', 'password', 'db', 'dbprefix', 'ftp_host', 'ftp_port',
						 'ftp_user', 'ftp_pass', 'ftp_root', 'ftp_enable', 'tmp_path', 'log_path', 'mailer', 
						 'mailfrom', 'fromname', 'sendmail', 'smtpauth', 'smtpsecure', 'smtpport', 'smtppass', 
						 'smtpuser', 'smtphost', 'debug', 'caching', 'cachetime', 'language', 'secret', 'editor',
						 'offset', 'lifetime', 'offline', 'offline_message', 'sitename', 'list_limit', 'legacy', 
						 'debug_lang', 'live_site', 'gzip', 'error_reporting', 'helpurl', 'xmlrpc_server', 'force_ssl',
						 'offset_user', 'cache_handler', 'MetaDesc', 'MetaTitle', 'MetaKeys' ,'MetaAuthor', 'sef', 
						 'sef_rewrite', 'sef_suffix', 'feed_limit', 'feed_email', 'session_handler', 'memcache_settings' );
		return $ignore;
	}
}