<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansFormatterEmail extends XiFormatter
{
	function reader($content)
	{
		$content = unserialize(base64_decode(array_shift($content)));

		if(is_array($content))
			return $content;

		return false;
	}
	
	function formatter($content)
	{
		$data['previous'] = $content;
		$data['current']  = array();
		return $data;
	}
}