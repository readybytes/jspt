<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * Saleable interface for classes
 * @author shyam
 *
 */
interface PayplansIfaceOrderable
{
	// basic functions
	public function getId();
	public function getClassname();

	// attributes
	public function getTitle();
	public function getStatus();

	//payments
	public function getPrice();
	public function getTotal();
	public function getDiscount();

//	public function getCurrency();

	//buyers
	public function setBuyer($userId=0);
}
