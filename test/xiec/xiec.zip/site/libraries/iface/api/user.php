<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	API
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


interface PayplansIfaceApiUser
{
	public function getSubscriptions($status=NULL);
	
	/**
	 * @return zipcode of the user's country
	 */
	public function getZipcode();
	
	/**
	 * @return PayplansUser instance
	 * @param  integer $zipcode The zipcode of the user's country
	 */
	public function setZipcode($zipcode ='');
	
	/**
	 * @return user's country
	 */
	public function getCountry();
	
	/**
	 * @return PayplansUser instance
	 * @param interger $country The country of user
	 */
	public function setCountry($country = '');
	
	/**
	 * @return user's city
	 */
	public function getCity();
	
	/**
	 * @return PayplansUser instance
	 * @param  string $city The city user belongs to
	 */
	public function setCity($city = '');
	
	/**
	 * @return user's state 
	 */
	public function getState();
	
	/**
	 * @return PayplansUser instance
	 * @param  string $state The state user belongs to
	 */
	public function setState($state ='');
	
	/**
	 * @return user's address
	 */
	public function getAddress();
	
		/**
	 * @return PayplansUser instance
	 * @param  string $address The address of the user
	 */
	public function setAddress($address ='');
	
	/**
	 * @return joomla usertype of the user 
	 */
	public function getUsertype();
	
	/**
	 * @return user's email address
	 */
	public function getEmail();
	
	/**
	 * @return username of the user
	 */
	public function getUsername();
	
	/**
	 * @return register date of the user
	 */
	public function getRegisterDate();
	
	/**
	 * @return preference of the user 
	 * @param string $key The name of the key
	 * @param $default false
	 */
	public function getPreference($key = null, $default = false);
	
	/**
	 * @return PayplansUser instance
	 * @param string $key The name of the key
	 * @param mixed  $value The value of the key to set
	 */
	public function setPreference($key, $value);
	
	/**
	 * @return true when user is Super Administrator
	 * else return false
	 */
	public function isAdmin();
}