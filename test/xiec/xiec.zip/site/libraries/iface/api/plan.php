<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	API
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


/**
 * These functions are listed 
 * @author ssv445
 *
 */
interface PayplansIfaceApiPlan
{

	/**
	 * @return title of the plan
	 */
	public function getTitle();
	
	/**
	 * @return price of the plan
	 */
	public function getPrice();
	
	/**
	 * @return expiration time of the plan
	 */
	public function getExpiration();
	
	/**
	 * @return PayplansPlan instance
	 * @param $time value to set as expiration time of plan
	 */
	public function setExpiration($time);
	
	/**
	 * @return currency set in the configuration for Payment processor
	 */
	public function getCurrency();
	
	/**
	 * Setup an Order and subscription object for the User id
	 * It will update Buyer = $userId 
	 * For Subscription object, it will update
	 * Plan = current plan
	 * Order = order created for this subscription
	 * @return PayplansOrder instance
	 * @param integer $userId
	 */
	public function subscribe($userId);
	
	/**
	 * @return array of group id this plan is attached with
	 */
	public function getGroups();
	
	/**
	 * @return integer 1 when plan is published
	 */
	public function getPublished();
	
	/**
	 * @return integer when plan is visible
	 */
	public function getVisible();
	
	/**
	 * @return description of the plan
	 */
	public function getDescription();
	
	/**
	 * @return array of app id this plan is attached with
	 */
	public function getPlanapps();
	
	/**
	 * @return teaser text of the plan
	 */
	public function getTeasertext();
	
	/**
	 * @return payment related parameter of the plan i.e. price
	 */
	public function getPayment();
	
	/**
	 * @return boolean
	 * when plan is recurring : True 
	 * 	else : False
	 */
	public function getRecurring();
	
	/**
	 * @return recurrence count set for the current plan
	 */
	public function getRecurrenceCount();
	
	/**
	 * @return First Price set for the plan in case of recurring
	 * if plan is not recurring or first price is not set then returns constant PAYPLANS_UNDEFINED
	 */
	public function getFirstPrice();
	
	/**
	 * @return expiration type of the plan that is 
	 * whether plan is of fixed type, recurring type or forever(unlimited)
	 */
	public function getExpirationType();
	
	/**
	 * @return url where the user is redirected to after completing subscription
	 */
	public function getRedirecturl();
	
	/**
	 * @return recurring and time related parameters of the plan
	 * i.e. expirationtype, expiration, recurrence_count, first_price
	 */
	public function getTime();
	
	/**
	 * @return css-class applied on the current plan
	 */
	public function getCssClasses();
}