<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	API
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


/**
 * Enter description here ...
 * @author ssv445
 *
 */
interface PayplansIfaceApiSubscription
{
	
	/**
	 * @example  
	 * 	PayplansSubscription::getInstance(5)->isActive();
	 * 
	 * @return boolean 
	 * 		Subscription is Active : True 
	 * 		else : False
	 */
	public function isActive();
	
	
	/**
	 * Setup the subscription object for given plan
	 * It will Update -
	 * 	1. Price  = Equal to Plan price
	 * 	2. Discount = reset to Zero 
	 *  3. Status = None
	 *  4. Subscription Date = current date
	 *  5. Expiration Date	 = current date + expiration time of plan
	 *  
	 * @param Integer/PayplansPlan $plan
	 */
	public function setPlan($plan);
}