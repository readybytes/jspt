<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	API
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


/**
 * Enter description here ...
 * @author ssv445
 *
 */
interface PayplansIfaceApiSubscription
{
	
	/**
	 * @example  
	 * 	PayplansSubscription::getInstance(5)->isActive();
	 * 
	 * @return boolean 
	 * 		Subscription is Active : True 
	 * 		else : False
	 */
	public function isActive();
	
	
	/**
	 * Setup the subscription object for given plan
	 * It will Update -
	 * 	1. Price  = Equal to Plan price
	 * 	2. Discount = reset to Zero 
	 *  3. Status = None
	 *  4. Subscription Date = current date
	 *  5. Expiration Date	 = current date + expiration time of plan
	 *  
	 * @param Integer/PayplansPlan $plan
	 */
	public function setPlan($plan);
	
	/**
	 * @return user(buyer) of the subscription
	 * @param if $requireinstance is PAYPLANS_INSTANCE_REQUIRE then return user instance 
	 * else return user id 
	 */
	public function getBuyer($requireinstance=false);
	
	/**
	 * Update the PayplansSubscription object
	 * It will update
	 * 1. buyer Id = equal to buyer id of the order
	 * 2. order id = equal to the id of the $order
	 * @return PayplansSubscription instance
	 * @param PayplansOrder $order
	 */
	public function setOrder(PayplansOrder $order);

	/**
	 * @return order this subscription is linked with
	 * if $requireInstance is PAYPLANS_INSTANCE_REQUIRE then return order's instance
	 * else order id
	 */
	public function getOrder($requireinstance=false);
}