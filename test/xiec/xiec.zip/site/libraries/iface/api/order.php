<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	API
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


interface PayplansIfaceApiOrder
{	
	/**
	 * @return buyer(user) of the order
	 * @param if $requireinstance is PAYPLANS_INSTANCE_REQUIRE then return user instance 
	 * else return userid 
	 **/
	public function getBuyer($requireinstance=false);
	
	/**
	 * @return the status of order
	 * available order status are  
	 * XiStatus::NONE, XiStatus::ORDER_CONFIRMED,XiStatus::ORDER_PAID,
	 * XiStatus::ORDER_COMPLETE, XiStatus::ORDER_HOLD, XiStatus::ORDER_EXPIRED
	 */
	public function getStatus();
	
	/**
	 * @return PayplansPayment Array 
	 * array of the payments attached with the current order
	 */
	public function getPayments();
	
	/**
 	 * @return PayplansSubscription Array
 	 * subscriptions attached with current order
 	 */
 	public function getSubscriptions();
 	
 	/**
 	 * @return total amount of the order
 	 */
 	public function getTotal();
 	
 	/**
 	 * @return subtotal amount of the order
 	 * subtotal amount does not include discount and tax applicable on the current order
 	 */
 	public function getSubtotal();
 	
 	/**
 	 * @return discount amount applicable on the current order
 	 */
 	public function getDiscount();
 	
 	/**
 	 * @return the order created date
 	 */
 	public function getCreatedDate();
 	
 	/**
 	 * @return tax rate applicable on the current order
 	 */
 	public function getTaxRate();
 	
 	/**
 	 * @return tax amount application on the current order
 	 */
 	public function getTaxAmount();
}