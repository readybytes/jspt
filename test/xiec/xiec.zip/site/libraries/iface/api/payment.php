<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	API
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


interface PayplansIfaceApiPayment
{
	
	/**
	 * @return payment status
	 * available payment status are 
	 * XiStatus::NONE - When Order is not confirmed or payment process yet not started. 
	 * XiStatus::PAYMENT_INITIATED - When Order is confirmed and Payment process is started. 
	 * XiStatus::PAYMENT_COMPLETE - When Order is paid or complete. 
	 * XiStatus::PAYMENT_HOLD - When payment is completed by the user but transaction is blocked due to some reason. 
	 * XiStatus::PAYMENT_PENDING -  When payment is started but it is still uncleared.For example- when Actual payment done by user is different from the expected payment or the electronic check submitted by user can not be cleared. 
	 * XiStatus::PAYMENT_RECURRING_SIGNUP - When user's profile has been created at the payment gateway and recurring payement is started at that gateway. 
	 * XiStatus::PAYMENT_RECURRING_CANCEL - When Order is cancelled by the user. 
	 * XiStatus::PAYMENT_RECURRING_EOT - When Recurring time duration is ended. 
	 * XiStatus::PAYMENT_RECURRING_FAILED - When recurring payment is started but failed due to some reasons such as child payments are not done correctly. 
	 * XiStatus::PAYMENT_RECURRING_START - When Order is confirmed and Payment process is started in case of recurring plan. 
	 */
	public function getStatus();
	
	/**
	 * @return buyer(user) linked with the current payment
	 * if $instance is PAYPLANS_INSTANCE_REQUIRE then return user instance
	 * else return userid 
	 */
	public function getBuyer($instance=false);
	
	/**
	 * @return order this payment is linked with
	 * if $requireInstance is PAYPLANS_INSTANCE_REQUIRE then return order's instance
	 * else order id
	 */
	public function getOrder($requireInstance = false);
	
	/**
	 * @return amount of the payment
	 */
	public function getAmount();
	
	/**
	 * @return currency in which the payment has made
	 */
	public function getCurrency($format = null);
	
	/**
	 * @return created date of payment
	 */
	public function getCreatedDate();
	
	/**
	 * @return date when payment is last modified
	 */
	public function getModifiedDate();
	
	/**
	 * @return payment app this payment has made from
	 * if $requireInstance is PAYPLANS_INSTANCE_REQUIRE then return instance of payment app
	 * else payment app id
	 */
	public function getApp($instance = false);
	
	/**
	 * @returns PayplansSubscription Array
	 * subscriptions attached with the same order this payment is linked with
	 */
	public function getSubscriptions();
	
}