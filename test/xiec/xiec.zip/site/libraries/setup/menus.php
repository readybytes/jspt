<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

define('MENU_TABLE_COMPONENT_ID_STR', PAYPLANS_JVERSION_15 ? 'componentid' : 'component_id') ;
class PayplansSetupMenus extends XiSetup
{
	public $_location = __FILE__;
	public $_message  = 'COM_PAYPLANS_SETUP_MENUS_DO_ENABLE';
	public $_type = 'INFORMATION';

	public $_componentId = null;

	public function __construct()
	{
		parent::__construct();

		// find component id
		$cmp = JComponentHelper::getComponent('com_payplans');
		$this->_componentId	 = $cmp->id;
	}

	function isRequired()
	{
		// migrate old menus if exists
		$this->_migrateOldMenus();

		$this->_status =  $this->_hasMenu('index.php?option=com_payplans&view=plan')
							&& $this->_hasMenu('index.php?option=com_payplans&view=order');

		if($this->_status){
			$this->_message = 'COM_PAYPLANS_SETUP_MENUS_DONE';
			return $this->_required=false;
		}

		return $this->_required=true;
	}

	function doApply()
	{

		$this->_addMenu('Subscribe', 'subscribe', 'index.php?option=com_payplans&view=plan');
		$this->_addMenu('My Orders', 'myorders', 'index.php?option=com_payplans&view=order');
		return true;
	}

	function _hasMenu($link)
	{
		return XiHelperJoomla::isMenuExist($link, $this->_componentId, 1);
	}

	function _addMenu($title, $alias, $link, $menu='mainmenu')
	{
		// if link already exist
		if($this->_hasMenu($link)){
			return true;
		}

		return XiHelperJoomla::addMenu($title, $alias, $link, $menu, $this->_componentId);
	}
	
	function _migrateOldMenus()
	{
		$query = "UPDATE `#__menu`
				  SET `".MENU_TABLE_COMPONENT_ID_STR."` = ".$this->_componentId." 
				  WHERE `".MENU_TABLE_COMPONENT_ID_STR."` <> ".$this->_componentId." 
				  	AND `link` LIKE '%option=com_payplans%' ";
		
		$db = XiFactory::getDBO();
		$db->setQuery($query);
		return $db->query();
	}
}