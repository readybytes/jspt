<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansSetupAdminpay extends XiSetup
{
	public $_location = __FILE__;
	public $_message  = 'COM_PAYPLANS_SETUP_CREATE_ADMINPAY';

	function isRequired()
	{
		$apps = XiFactory::getInstance('app','model')
							->loadRecords(array('type' => 'adminpay'));
							
		if(count($apps)){
			$this->_message = 'COM_PAYPLANS_SETUP_ADMINPAY_CREATED';
 			return $this->_required=false;
 		}

 		return $this->_required=true;
	}

	function doApply()
	{
		// do not create adminpay app many times
		if($this->isRequired()!==true){
			return true;
		}
		
		$db = XiFactory::getDBO();
		$sql =  "INSERT INTO ".$db->nameQuote('#__payplans_app')
		       ."( "
		       .$db->nameQuote('title').", "
		       .$db->nameQuote('type').", "
		       .$db->nameQuote('description').", "
		       .$db->nameQuote('core_params').", "
		       .$db->nameQuote('published')." "
		       .") VALUES ("
		       .$db->Quote('Admin Pay').", "
		       .$db->Quote('adminpay').", "
		       .$db->Quote(XiText::_('COM_PAYPLANS_APP_ADMINPAY_DESCRIPTION')).", "
		       .$db->Quote('applyAll=1\n\n').", "
		       .$db->Quote(1).") ";
		       
		$db->setQuery($sql);
		
		$app = XiFactory::getApplication();
		if($db->query()){
			$app->enqueueMessage(XiText::_('COM_PAYPLANS_APP_ADMINPAY_CREATED'));
		}
		else{
			XiError::assert(0, XiText::_('COM_PAYPLANS_APP_ADMINPAY_CREATION_ERROR'), XiError::WARNING);
		}		       
	}
}
