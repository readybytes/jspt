<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class  PayplansAppJsmultiprofile extends PayplansApp
{
	protected $_location	= __FILE__;

	public function isApplicable($refObject = null, $eventName='')
	{
		if($eventName === 'onPayplansAccessCheck'){
			return true;
		}
		
		return parent::isApplicable($refObject, $eventName);
	}
	
	public function onPayplansSubscriptionAfterSave($prev, $new)
	{
		return $this->_triggerJsmultiprofile($prev,$new);
	}


	protected function _triggerJsmultiprofile($prev, $new)
	{
		// no need to trigger if previous and current state is same
		if($prev != null && $prev->getStatus() == $new->getStatus()){
			return true;
		}

		// check the status
		if($new->getStatus() != $this->getAppParam('on_status', XiStatus::NONE)){
			return true;
		}

		// now try to findout the data and process the email
		$this->_setJsmultiprofile($new);

		//
		return true;
	}

	protected function _setJsmultiprofile($object)
	{
		// object is of subscription type
		$userId = $object->getBuyer();
		require_once(JPATH_ROOT.DS.'components'.DS.'com_community'.DS.'libraries'.DS.'core.php');
		
		$user = CFactory::getUser($userId);
		$user->set('_profile_id', $this->getAppParam('jsmultiprofile', 0));
		return $user->save();
	}
	
	// to restrict user to change profile type from front-end
	public function onPayplansAccessCheck(PayplansUser $user)
	{
		if(!$user->getId()){
			return true;
		}
		
		// Is user Admin/SuperAdmin
		if($user->isAdmin()){
			return true;
		}
		
		// should we block user to change ptype 
		if($this->getAppParam('block_ptype_change', true) == false){
			return true;
		}

		$option = JRequest::getVar('option', false);
		$task 	= JRequest::getVar('task', false);
		$view 	= JRequest::getVar('view', false);
		
		if($option !== 'com_community' || $view !== 'multiprofile' || $task !== 'changeprofile'){
			return true;
		}
			
		$msg = XiText::_('COM_PAYPLANS_APP_JSPROFILETYPE_UPDATE_PLAN_TO_CHANGE_DESC');
		XiFactory::getApplication()->redirect(XiRoute::_('index.php?option=com_payplans&view=plan&task=subscribe'), $msg);
			
		return true;
	}
}