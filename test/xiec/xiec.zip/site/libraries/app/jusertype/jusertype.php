<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class  PayplansAppJusertype extends PayplansApp
{
	protected $_location	= __FILE__;
	protected $_resource	= 'com_user.usergroup';

	public function onPayplansSubscriptionAfterSave($prev, $new)
	{
		return $this->_triggerJusertype($prev,$new);
	}


	protected function _triggerJusertype($prev, $new)
	{
		// no need to trigger if previous and current state is same
		if($prev != null && $prev->getStatus() == $new->getStatus()){
			return true;
		}

		$defaultUserGroup = 'Registered';
		$subid 		=  $new->getId();
		
		if(PAYPLANS_JVERSION_FAMILY == 16){
			jimport('joomla.application.component.helper');
			$config	= JComponentHelper::getParams('com_users');
			// Default to Registered.
			$defaultUserGroup = $config->get('new_usertype', 2);
		}
		
		$active	    = $this->getAppParam('jusertypeOnActive', $defaultUserGroup);
		$hold 	    = $this->getAppParam('jusertypeOnHold', $defaultUserGroup);
		$expire		= $this->getAppParam('jusertypeOnExpire', $defaultUserGroup);
		
		$newstatus  =  $new->getStatus();
		$userid		=  $new->getBuyer();
		
		if(PAYPLANS_JVERSION_FAMILY == 16){		
			$active	= (is_array($active)) ? $active : array($active);
			$hold	= (is_array($hold)) ? $hold : array($hold);
			$expire	= (is_array($expire)) ? $expire : array($expire);
			
			//if subscription is active
			if($newstatus == XiStatus::SUBSCRIPTION_ACTIVE){
				$this->_unsetJusertype($userid, $hold, $subid);
				$this->_unsetJusertype($userid, $expire, $subid);
				return $this->_setJusertype($userid, $active, $subid);
			}
			
			//if subscription is hold			
			if($newstatus == XiStatus::SUBSCRIPTION_HOLD){
				$this->_unsetJusertype($userid, $active, $subid);
				$this->_unsetJusertype($userid, $expire, $subid);
				return $this->_setJusertype($userid, $hold, $subid);
			}
			
			//if subscription is expire			
			if ($newstatus == XiStatus::SUBSCRIPTION_EXPIRED){
				$this->_unsetJusertype($userid, $active, $subid);
				$this->_unsetJusertype($userid, $hold, $subid);
				return $this->_setJusertype($userid, $expire, $subid);
			}

			return true;
		}
		
		if($newstatus == XiStatus::SUBSCRIPTION_ACTIVE){
			return $this->_setJusertype($userid, $active, $subid);
		}
		
		if($newstatus == XiStatus::SUBSCRIPTION_HOLD){
			return $this->_setJusertype($userid, $hold, $subid);
		}
		
		if ($newstatus == XiStatus::SUBSCRIPTION_EXPIRED){
			return $this->_setJusertype($userid, $expire, $subid);
		}

		return true;
	}

	protected function _setJusertype($userid, $group, $subid)
	{
		if(PAYPLANS_JVERSION_FAMILY == 16){
			if(!is_array($group)){
				return true;
			}
			
			jimport('joomla.user.helper');
			foreach ($group as $groupid){
				XiHelperJoomla::addUserToGroup($userid, $groupid);
				$this->_addToResource($subid, $userid, $groupid, $this->_resource);
			}

			return true;
		}
		
		return XiHelperJoomla::addUserToGroup($userid, $group);
	}
	
	protected function _unsetJusertype($userid, $jusertype, $subid)
	{
		if(!is_array($jusertype)){
			return true;
		}
		
		foreach ($jusertype as $group){
			if($this->_removeFromResource($subid, $userid, $group, $this->_resource)){
				XiHelperJoomla::removeUserFromGroup($userid, $group);
			}
		}
		return true;
	}
	
	//render Widget
	public function renderWidgetHtml()
	{
		//get user id
		$userid     = XiFactory::getUser()->id;
		//get joomla Usertype
		$jusertype  = XiHelperJoomla::getJoomlaUserGroups($userid);
		if(empty($jusertype)){
			return '' ;
		}
		$this->assign('joomla_usertypes',$jusertype);
		$data = $this->_render('widgethtml');
	    return $data;
	}
	
	function getNameFromResourceValue($resource, $value)
	{
		// if its a different resource
		if($resource != $this->_resource){
			return false;
		}
		
		// no resource in Joomla 1.5
		if(PAYPLANS_JVERSION_FAMILY == '15'){
			return JString::ucfirst($value);
		}
		
		$groups = XiHelperJoomla::getJoomlaGroups();
		return $groups[$value]->name;
	}
}