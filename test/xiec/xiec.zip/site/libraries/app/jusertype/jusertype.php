<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class  PayplansAppJusertype extends PayplansApp
{
	protected $_location	= __FILE__;

	public function onPayplansSubscriptionAfterSave($prev, $new)
	{
		return $this->_triggerJusertype($prev,$new);
	}


	protected function _triggerJusertype($prev, $new)
	{
		// no need to trigger if previous and current state is same
		if($prev != null && $prev->getStatus() == $new->getStatus()){
			return true;
		}

		// check the status
		if($new->getStatus() != $this->getAppParam('on_status', XiStatus::NONE)){
			return true;
		}

		// now try to findout the data and process jusertype
		$this->_setJusertype($new);

		//
		return true;
	}

	protected function _setJusertype($object)
	{
		// object is of subscription type
		$userId = $object->getBuyer();
		
		// get user type from app params
		$jusertype = $this->getAppParam('jusertype', 'Registered');
		
		$user = XiFactory::getUser($userId);		
		$usertype = $user->get('usertype');
		// when subscriber is super administrator do not change its usertype and gid
		if($usertype != 'Super Administrator'){
			$authorize	= XiFactory::getACL();
			$user->set('usertype', $jusertype);
			$user->set('gid', $authorize->get_group_id( '', $jusertype, 'ARO' ));
		}

		return $user->save();
	}
}