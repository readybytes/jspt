<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class  PayplansAppEmail extends PayplansApp
{
	protected $_location	= __FILE__;
	protected $_mailer		= null;

	public function __construct($config = array())
	{
		// Get a JMail instance
		if($this->_mailer === null){
			$this->_mailer = XiFactory::getMailer();
		}

		// let parent work
		return parent::__construct($config);
	}


	public function isApplicable($refObject = null, $eventName='')
	{
		// if not with reference to payment then return
		if($eventName === 'onPayplansCron'){
			return true;
		}
		
		return parent::isApplicable($refObject, $eventName);
	}
	
	public function collectAppParams(array $data)
	{
		// encode editor content
		if(isset($data['app_params']) && isset($data['app_params']['content'])){
			$data['app_params']['content'] = base64_encode($data['app_params']['content']);
		}

		return parent::collectAppParams($data);
	}

	// Do not send false
	public function onPayplansOrderAfterSave($prev, $new)
	{
		return $this->_triggerEmail($prev,$new);
	}

	public function onPayplansPaymentAfterSave($prev, $new)
	{
		return $this->_triggerEmail($prev,$new);
	}

	public function onPayplansSubscriptionAfterSave($prev, $new)
	{
		return $this->_triggerEmail($prev,$new);
	}


	protected function _triggerEmail($prev, $new)
	{
		// we need to send pre-expiry email
		if($this->getAppParam('when_to_email') == 'on_preexpiry'){
			return true;
		}
		
		// 	we need to send post-expiry email
		if($this->getAppParam('when_to_email') == 'on_postexpiry'){
			return true;
		}
		
		//we need to send post-activation email
		if($this->getAppParam('when_to_email') == 'on_postactivation'){
			return true;
		}
		
		// no need to trigger if previous and current state is same
		if($prev != null && $prev->getStatus() == $new->getStatus()){
			return true;
		}

		// check the status
		if($new->getStatus() != $this->getAppParam('on_status', XiStatus::NONE)){
			return true;
		}

		// now try to findout the data and process the email
		$this->_sendEmail($new);

		//
		return true;
	}

	protected function _sendEmail($object)
	{
		// object is of payment/subscription/order type
		$userId = $object->getBuyer();

		//$mail->setSender(array($from, $fromname));
		//$mail->addAttachment($attachment);

		$subject = $this->getAppParam('subject', '');
		$subject = $this->_replaceToken($subject, $object);
		$this->_mailer->setSubject($subject);

		$body = base64_decode($this->getAppParam('content', ''));
		$body = $this->_replaceToken($body, $object);
		$this->_mailer->setBody($body);

		// send email always in HTML
		$this->_mailer->IsHTML(true);

		$this->_mailer->addRecipient(XiFactory::getUser($userId)->email);

		$this->_addEmailAddress($this->getAppParam('send_cc', ''),'addCC');
		$this->_addEmailAddress($this->getAppParam('send_bcc', ''),'addBCC');

		// restrict to send email in unit test case
		// in selenium test case mail will not be send because mail setting are not correct
		if(defined('PAYPLANS_UNIT_TEST_MODE')===true){
			return true;
		}

		$content = array( 'user_id'=>$userId, 'subject'=>$subject, 'body'=>$body);
		//XITODO : we need to apply it everywhere
		if($this->_mailer->Send()){
			$message=XiText::_('COM_PAYPLANS_EMAIL_SEND_SUCCESSFULLY');
			PayplansHelperLogger::log(XiLogger::LEVEL_INFO, $message, $this, $content, 'PayplansFormatterEmail');
			return true;
		}else
		{
			$message=XiText::_('COM_PAYPLANS_EMAIL_SENDING_FAILED');
			$content['current'] = $this->toArray();
			PayplansHelperLogger::log(XiLogger::LEVEL_INFO, $message, $this, $content, 'PayplansFormatterEmail');
			return false;
		}
	}

	public function _replaceToken($content, $object)
	{
		return XiFactory::getRewriter()->rewrite($content, $object);
	}

	/**
	 * Add given emails to TO/CC/BCC
	 *
	 * @param unknown_type $str Emails in Comma Seperated format
	 * @param unknown_type $function addRecipient / addCC / addBCC
	 */
	public function _addEmailAddress($str, $function='addRecipient')
	{
		// string is empty
		if(isset($str)==false || empty($str)){
			return false;
		}

		// explode and add one by one
		$emails = explode(',', $str);
		$count = 0;
		foreach($emails as $email){
			$this->_mailer->$function($email);
			$count++;
		}

		return $count;
	}
	
	public function onPayplansCron()
	{
		$sentmail = 0;
		$subscriptions = array();

		$plans = $this->getPlans();
		
		$onAllPlan = ($this->getParam('applyAll',false) == true) ? true : false;
		
		//get the parameter when to email to check whether 
		//pre -expiry or post expiry email is to be send
		$whenToEmail = $this->getAppParam('when_to_email', 'on_status');
		$expiry  = $this->getAppParam($whenToEmail);
	
		if($whenToEmail == 'on_preexpiry'){
			$event = 'preExpiry';
			$subscriptions  = XiFactory::getInstance('subscription','model')->getPreExpirySubscriptions($plans, $expiry, $onAllPlan);
		}
		
		if($whenToEmail == 'on_postexpiry'){
			$event = 'postExpiry';
			$subscriptions = XiFactory::getInstance('subscription','model')->getPostExpirySubscriptions($plans, $expiry, $onAllPlan);
		}
		
		if($whenToEmail == 'on_postactivation'){
			$event = 'postActivation';
			$subscriptions = XiFactory::getInstance('subscription','model')->getPostActivationSubscriptions($plans, $expiry, $onAllPlan);
		}
		
		if(count($subscriptions)>0){
			foreach($subscriptions as $sub_id => $sub){
				$subscription = PayplansSubscription::getInstance($sub_id, null, $sub);
				
				// if current preexpiry was not applied
				if($subscription->getParams()->get($event.$expiry,false) == false){
					$this->_sendEmail($subscription);
					//mark that we have triggered preexpiry event
					//XITODO : it should be an event so other app can work on it
					$subscription->getParams()->set($event.$expiry,true);
					$subscription->save();
					
					$sentmail++;
				}
			}
		}
		
		return $sentmail;
	}
}