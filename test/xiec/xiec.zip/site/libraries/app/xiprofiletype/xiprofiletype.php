<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class  PayplansAppXiprofiletype extends PayplansApp
{
	protected $_location	= __FILE__;

	public function onPayplansSubscriptionAfterSave($prev, $new)
	{
		return $this->_triggerXiprofiletype($prev,$new);
	}


	protected function _triggerXiprofiletype($prev, $new)
	{
		// no need to trigger if previous and current state is same
		if($prev != null && $prev->getStatus() == $new->getStatus()){
			return true;
		}

		// check the status
		if($new->getStatus() != $this->getAppParam('on_status', XiStatus::NONE)){
			return true;
		}

		// now try to findout the data and process the email
		$this->_setXiprofiletype($new);

		//
		return true;
	}

	protected function _setXiprofiletype($object)
	{
		// object is of subscription type
		$userId = $object->getBuyer();

		require_once JPATH_ROOT.DS.'components'.DS.'com_xipt'.DS.'api.xipt.php';
		return XiptAPI::setUserProfiletype($userId, $this->getAppParam('xiprofiletype', XiptAPI::getDefaultProfiletype()));
	}
	
	function onPayplansPlanAfterSelection($plansId, $planContoller)
	{		
		require_once JPATH_ROOT.DS.'components'.DS.'com_xipt'.DS.'api.xipt.php';
		// get global config of JSPT
		// if show_ptype_during_reg is true, then we do not need to do anything
		if(XiptAPI::getGlobalConfig('show_ptype_during_reg', true) == true){
			return true;
		}
		
		// This is for registration process, so consider only subscription active status 
		if($this->getAppParam('on_status', XiStatus::NONE) != XiStatus::SUBSCRIPTION_ACTIVE){
			return true;
		}
		// in other case we need to get the xi profile type attached with this app
		// set thi ptype in session, so that at registration time it will be available
		$session = XiFactory::getSession();
		$session->set('SELECTED_PROFILETYPE_ID', $this->getAppParam('xiprofiletype', XiptAPI::getDefaultProfiletype()), 'XIPT');
		
		return true;
	}
}