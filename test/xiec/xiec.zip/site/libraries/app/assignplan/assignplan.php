<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class  PayplansAppAssignplan extends PayplansApp
{
	protected $_location	= __FILE__;

	public function onPayplansSubscriptionAfterSave($prev, $new)
	{
		// no need to trigger if previous and current state is same
		if($prev != null && $prev->getStatus() == $new->getStatus()){
			return true;
		}
		
		$newStatus  = $new->getStatus();
		$userid     = $new->getBuyer();
		
		$active = $this->getAppParam('assignPlan');
		$active	= (is_array($active)) ? $active : array($active);
		
		$hold 	= $this->getAppParam('setPlanOnHold');
		$hold	= (is_array($hold)) ? $hold : array($hold);
		
		$expire = $this->getAppParam('setPlanOnExpire');
		$expire	= (is_array($expire)) ? $expire : array($expire);

		//if subscription is active
		if($newStatus == XiStatus::SUBSCRIPTION_ACTIVE){
			return $this->_setPlan($userid, $active);
		}
		
		//if subscription is hold
		if($newStatus == XiStatus::SUBSCRIPTION_HOLD){
			return $this->_setPlan($userid, $hold);
		}
		
		// if subscription is expire
		if($newStatus == XiStatus::SUBSCRIPTION_EXPIRED){
			return $this->_setPlan($userid, $expire);
		}

		return true;
	}

	protected function _setPlan($userId, $assignPlan)
	{
		if(!$userId){
			return true;
		}

		//check if there is any plan in assignplan to assign/set
		if(empty($assignPlan) && !(is_array($assignPlan))){
			return true;
		}
		
		foreach ($assignPlan as $planid){
			if(!empty($planid)){
				$plan = PayplansPlan::getInstance($planid);
				$plan->subscribe($userId)
			 		 ->setStatus(XiStatus::ORDER_COMPLETE)
			 	 	 ->save();
			}
		}
		return true;
	}
}