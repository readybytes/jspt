<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

//jimport('joomla.html.toolbar.button');
//class_exists('JButtonStandard',true);
XiHelperLoader::addAutoLoadFile(JPATH_LIBRARIES.DS.'joomla'.DS.'html'.DS.'toolbar'.DS.'button'.DS.'standard.php', 'JButtonStandard');

class JButtonXiDelete extends JButtonStandard
{
	var $_name = 'xidelete';
	
	function _getCommand($name, $task, $list, $hide=false)
	{
		$todo		= JString::strtolower(JText::_( $name ));
		$message	= JText::sprintf( 'Please make a selection from the list to', $todo );
		$message	= addslashes($message);
		$hidecode	= $hide ? 'hideMainMenu();' : '';
		if($list) {
			$cmd = "javascript:if(document.adminForm.boxchecked.value==0){alert('$message');}else{ xi.jQuery.apprise('Are you sure to delete?', {'verify':true}, function(r){if(r){submitbutton('$task');} else{return false;}});}";
		} else {
			$cmd = "javascript:$hidecode xi.jQuery.apprise('Are you sure to delete?', {'verify':true}, function(r){if(r){submitbutton('$task');} else{return false;}})";
		}
 		return $cmd;
	}
}