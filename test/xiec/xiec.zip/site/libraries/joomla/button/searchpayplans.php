<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

jimport('joomla.html.toolbar.button');
class JButtonSearchpayplans extends JButton
{
	var $_name = 'Searchpayplans';

	function fetchButton( $type='Searchpayplans', $name = '')
	{
		// display search module
		$text	= XiText::_('COM_PAYPLANS_TOOLBAR_SEARCH');
		$class	= $this->fetchIconClass('search');
		$doTask = "payplansAdmin.searchBoxDropdown()";
		$html	= "<a href=\"#\" onclick=\"$doTask\" class=\"toolbar\">\n";
		$html .= "<span id=\"search-button\" class=\"$class\" title=\"$text\">\n";
		$html .= "</span>\n";
 		$html	.= "$text\n";
		$html	.= "</a>\n";
		$attribs['style']	= 'xhtml';
		$module = JModuleHelper::getModule('mod_payplans_search');
		$html .= "<div id='search'><div class='arrow'></div><div class='inner-search'>".JModuleHelper::renderModule($module, $attribs)."</div></div>";

		return $html;
	}
	
	public function fetchId($type='Confirm', $name = '', $text = '', $task = '', $list = true, $hideMenu = false)
	{
		return;
	}
	
}
