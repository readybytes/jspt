<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * Event names should start always as
 * onPayplansTax
 * @author shyam
 */

abstract class PayplansAppTax extends PayplansApp
	implements PayplansIfaceAppTax
{

	/**
	 * Applicable on orders (non-PHPdoc)
	 * @see PayplansApp::_isApplicable()
	 */
	public function _isApplicable(PayplansIfaceApptriggerable $refObject = null)
	{
		// if not with reference to order then return
		if(!($refObject instanceof PayplansOrder)){
			return false;
		}
				
		return parent::_isApplicable($refObject);
	}
	
	/**
	 * Simply Checks, if current-app is attached to given subscription
	 * Tips : Avoid overriding this function
	 */
	public function _doCheckApplicableOnSubscription(PayplansSubscription $subscription)
	{
		//Check if not applicable on given subscription
		if($this->getParam('applyAll',false)){
			return true;
		}

		$subPlan = array_shift($subscription->getPlans());
		return in_array($subPlan,$this->getPlans());
	}
	
	/**
	 * Iteratively apply tax 
	 * Tips : Avoid overriding this function
	 */
	function _doApplyTax(PayplansOrder $order)
	{
		//if order have multiple subscriptions, we need apply tax on each
		$totalTax = 0;
		foreach($order->getSubscriptions() as $subscription){
			$price 	= $subscription->getPrice();
			$tax 	= $subscription->getTax();

			if($this->_doCheckApplicableOnSubscription($subscription, $price, $tax) ==false){
				continue;
			}

			//calculate tax
			$totalTax += $this->_doCalculateTax($subscription, $price, $tax);		
			$taxUsed = true;
		}

		// add the tax to order, if tax was applied
		if($taxUsed){
			$order->setTax($totalTax)->save();
		}
		
		return $taxUsed;
	}
}