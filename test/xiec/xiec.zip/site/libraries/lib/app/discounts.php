<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * Event names should start always as
 * onPayplansDiscount
 * @author shyam
 */

abstract class PayplansAppDiscounts extends PayplansApp
	implements PayplansIfaceAppDiscount
{

	// All discount app should have some common params
	// Like :
	// publish_start
	// publish_end
	public function _isApplicable(PayplansIfaceApptriggerable $refObject = null)
	{
		// if not with reference to order then return
		if(!($refObject instanceof PayplansOrder)){
			return false;
		}

		//if coupon is published as per dates
		$publish_start 	= $this->getAppParam('publish_start', '');
		$publish_end	= $this->getAppParam('publish_end','');

		$now = new XiDate();
		if($publish_start != ''){
			$start = new XiDate($publish_start);
			if($start->toUnix() > $now->toUnix()){
				return false;
			}
		}

		if($publish_end != ''){
			$end = new XiDate($publish_end);
			if($end->toUnix() < $now->toUnix()){
				//also disable the discount
				$this->published = false;
				$this->save();
				return false;
			}
		}
		
		return parent::_isApplicable($refObject);
	}
	
	/**
	 * Simply Checks, if disocunt-app is attached to given subscription
	 * Tips : Avoid overriding this function
	 */
	public function _doCheckApplicableOnSubscription(PayplansSubscription $subscription)
	{
		//Check if not applicable on given subscription
		if($this->getParam('applyAll',false)){
			return true;
		}

		$subPlan = array_shift($subscription->getPlans());
		return in_array($subPlan,$this->getPlans());
	}
	
	/**
	 * Iteratively apply discount 
	 * 
	 * Tips : Avoid overriding this function
	 */
	function _doApplyDiscount(PayplansOrder $order)
	{
		//if order have multiple subscriptions, we need apply discount on each
		$discountUsed = false;
		foreach($order->getSubscriptions() as $subscription){
			/* @var $subscription PayplansSubscription */
			$price 		= $subscription->getPrice();
			$discount 	= $subscription->getDiscount();

			if($this->_doCheckApplicableOnSubscription($subscription, $price, $discount) ==false){
				continue;
			}

			$actualDiscount = 0;
			// for non recurring order and if discount is applicable on all recurring payment
			if($order->isRecurring() == false || $this->getAppParam('onlyFirstRecurringDiscount', false) == false){
				//calculate discount
				$actualDiscount = $this->_doCalculateDiscount($subscription, $price, $discount);		
				$actualDiscount = ($price < $actualDiscount ) ? $price : $actualDiscount ;
				
				//update the subscription with discount, old discount will be lapsed
				$subscription->setDiscount($actualDiscount);
			}
			$firstPrice 		 = $subscription->getFirstPrice();
			// either a recurring order OR some first price is set
			if($order->isRecurring() == true || $firstPrice !== PAYPLANS_UNDEFINED){
				// calculate discount for first (trial) price
				
				$actualTrialDiscount = 0;
				
				// if discount is applicable on all recurring payment 
				// and first price is not set
				if($this->getAppParam('onlyFirstRecurringDiscount', false) == true && $firstPrice === PAYPLANS_UNDEFINED){
					$subscription->setFirstPrice($price);
					$firstPrice = $price;
				}
				
				// first price is set
				if($firstPrice !== PAYPLANS_UNDEFINED){
					$actualTrialDiscount = $this->_doCalculateDiscount($subscription, $firstPrice, $discount);		
					$actualTrialDiscount = ($firstPrice < $actualTrialDiscount ) ? $firstPrice : $actualTrialDiscount ;
				}
				
				$subscription->setFirstPriceDiscount($actualTrialDiscount);
			}
				
			$subscription->save();
			
			$discountUsed = true;
		}

		// refresh the order, if discount was applied
		if($discountUsed){
			$order->refresh()->save();
		}
		
		return $discountUsed;
	}
}