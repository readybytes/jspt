<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * All PAYMENT Plugin should implement this interface
 * Event names should start always as
 * onPayplansPayment
 * @author shyam
 */

abstract class PayplansAppPayment extends PayplansApp
{

	/**
	 * @param PayplansPayment $refObject
	 */
	public function _isApplicable(PayplansIfaceApptriggerable $refObject = null)
	{
		// if with reference to plan then return
		if($refObject instanceof PayplansPlan){
			return parent::_isApplicable($refObject);
		}

		// if not with reference to payment then return
		if(!($refObject instanceof PayplansPayment)){
			return false;
		}

		// if the payment is being asked from me then only do it
		if($refObject->getApp() == $this->getId()){
			return true;
		}

		return false;
	}

	/**
	 * If app can accept recurring payments
	 */
	public function _isRecurring(PayplansPayment $payment)
	{
		$plans = $payment->getPlans(PAYPLANS_INSTANCE_REQUIRE);
		//XITODO : need to change in concept when multiple subscription support will be available
		// if any one plans if recurring then return true
		foreach($plans as $plan){
			if($plan->getRecurring()){
				return true;
			}	
		}
		
		return false;
	}
	
	/**
	 * Just before going to display payments form
	 */
	public function onPayplansPaymentBefore(PayplansPayment $payment, $data=null)
	{
		return true;
	}


	public function onPayplansPaymentDisplay(PayplansPayment $payment, $data=null)
	{
		return true;
	}
	/**
	 * Render Payment Forms
	 * @param data : to bind it with any Params or anything else
	 */
	public function onPayplansPaymentForm(PayplansPayment $payment, $data=null)
	{
		return true;
	}

	/**
	 * Render Payment Forms at Admin Panel
	 * @param data : to bind it with any Params or anything else
	 */
	public function onPayplansPaymentFormAdmin(PayplansPayment $payment, $data=null)
	{
		return true;
	}

	/**
	 * Render Payment Records
	 * @param data : to bind it with any Params or anything else
	 */
	public function onPayplansPaymentRecord(PayplansPayment $payment =null)
	{
		if($payment->getTransaction() && $payment->getStatus() != XiStatus::NONE){
			//XITODO : probably we need INI there, so it should not be lost becuase of save
			$this->assign('transaction_html',PayplansHelperParam::iniToArray($payment->getTransaction()));
			
			return $this->_render('transaction');
		}
	}

	/**
	 * Payment collection is complete
	 * Show a thank you message.
	 */
	public function onPayplansPaymentAfter(PayplansPayment $payment, $action, $data, $controller)
	{
		//change status from NONE to STARTED only when action is success
		// if status is not NONE then don't do anything 
		if($payment->getStatus() == XiStatus::NONE && $action=='success'){
			$payment->set('status', XiStatus::PAYMENT_INITIATED)
					->save();
		}

		if($action=='error'){

				$errors = array();
				$log_id = JRequest::getVar('log_id');
				if($log_id && !empty($log_id)){
					$record = XiFactory::getInstance('log', 'model')->loadRecords(array('id'=>$log_id));
					$errors = unserialize(base64_decode($record[$log_id]->content));
					$errors = unserialize(base64_decode($errors['content']));
				}
				else 
				{
					$record = array_pop(PayplansHelperLogger::getLog($payment, XiLogger::LEVEL_ERROR));
					$errors = unserialize(base64_decode($record->content));
				}
				
				$this->assign('errors', $errors);
				
				// set error template
				$controller->setTemplate($action);
				return $this->_render('error');
		}
		return true;
	}

	/**
	 * A trigger comes from payment service.
	 * Verify Payment Details, all sanity checks
	 */
	public function onPayplansPaymentNotify(PayplansPayment $payment, $data=null, $controller)
	{
		return true;
	}

	/**
	 * If plugin need some special event
	 */
	public function onPayplansPaymentCustom(PayplansPayment $payment, $data=null)
	{
		return true;
	}


	/**
	 * onSave actions
	 */
	public function onPayplansPaymentBeforeSave(PayplansPayment $prev=null, PayplansPayment $new=null, $data = null)
	{
		return true;
	}

	public function onPayplansPaymentAfterSave(PayplansPayment $prev=null, PayplansPayment $new=null, $data = null)
	{
		return true;
	}
}