<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * All PAYMENT Plugin should implement this interface
 * Event names should start always as
 * onPayplansPayment
 * @author shyam
 */

abstract class PayplansAppPayment extends PayplansApp
{

	/**
	 * @param PayplansPayment $refObject
	 */
	public function _isApplicable(PayplansIfaceApptriggerable $refObject = null)
	{
		// if with reference to plan then return
		if($refObject instanceof PayplansPlan){
			return parent::_isApplicable($refObject);
		}

		// if not with reference to payment then return
		if(!($refObject instanceof PayplansPayment)){
			return false;
		}

		// if the payment is being asked from me then only do it
		if($refObject->getApp() == $this->getId()){
			return true;
		}

		return false;
	}

	/**
	 * If app can accept recurring payments
	 */
	public function _isRecurring(PayplansPayment $payment)
	{
		// XITODO : copied to order, remove from here
		$plans = $payment->getPlans(PAYPLANS_INSTANCE_REQUIRE);
		//XITODO : need to change in concept when multiple subscription support will be available
		// if any one plans if recurring then return true
		foreach($plans as $plan){
			if($plan->getRecurring()){
				return true;
			}	
		}
		
		return false;
	}
	
	/**
	 * Just before going to display payments form
	 */
	public function onPayplansPaymentBefore(PayplansPayment $payment, $data=null)
	{
		return true;
	}


	public function onPayplansPaymentDisplay(PayplansPayment $payment, $data=null)
	{
		return true;
	}
	/**
	 * Render Payment Forms
	 * @param data : to bind it with any Params or anything else
	 */
	public function onPayplansPaymentForm(PayplansPayment $payment, $data=null)
	{
		return true;
	}

	/**
	 * Render Payment Forms at Admin Panel
	 * @param data : to bind it with any Params or anything else
	 */
	public function onPayplansPaymentFormAdmin(PayplansPayment $payment, $data=null)
	{
		return true;
	}

	/**
	 * Render Payment Records
	 * @param data : to bind it with any Params or anything else
	 */
	public function onPayplansPaymentRecord(PayplansPayment $payment =null)
	{
		if($payment->getTransaction() && $payment->getStatus() != XiStatus::NONE){
			//XITODO : probably we need INI there, so it should not be lost becuase of save
			$this->assign('transaction_html',PayplansHelperParam::iniToArray($payment->getTransaction()));
			
			return $this->_render('transaction');
		}
	}

	/**
	 * Payment collection is complete
	 * Show a thank you message.
	 */
	public function onPayplansPaymentAfter(PayplansPayment $payment, $action, $data, $controller)
	{
		//change status from NONE to STARTED only when action is success
		// if status is not NONE then don't do anything 
		if($payment->getStatus() == XiStatus::NONE && $action=='success'){
			$payment->set('status', XiStatus::PAYMENT_INITIATED)
					->save();
		}

		if($action=='error'){

				$errors = array();
				$log_id = JRequest::getVar('log_id');
				if($log_id && !empty($log_id)){
					$record = XiFactory::getInstance('log', 'model')->loadRecords(array('id'=>$log_id));
					$errors = unserialize(base64_decode($record[$log_id]->content));
					$errors = unserialize(base64_decode($errors['content']));
				}
				else 
				{
					$record = array_pop(PayplansHelperLogger::getLog($payment, XiLogger::LEVEL_ERROR));
					$errors = unserialize(base64_decode($record->content));
					$errors = unserialize(base64_decode($errors['content']));
				}
				
				$this->assign('errors', $errors);
				
				// set error template
				$controller->setTemplate($action);
				return $this->_render('error');
		}
		return true;
	}

	/**
	 * A trigger comes from payment service.
	 * Verify Payment Details, all sanity checks
	 */
	public function onPayplansPaymentNotify(PayplansPayment $payment, $data=null, $controller)
	{
		return true;
	}

	public function onPayplansPaymentSubscriptionCancel(Payplans $payment, $controller)
	{
		return true;	
	}
	
	/**
	 * If plugin need some special event
	 */
	public function onPayplansPaymentCustom(PayplansPayment $payment, $data=null)
	{
		return true;
	}


	/**
	 * onSave actions
	 */
	public function onPayplansPaymentBeforeSave(PayplansPayment $prev=null, PayplansPayment $new=null)
	{
		return true;
	}

	public function onPayplansPaymentAfterSave(PayplansPayment $prev=null, PayplansPayment $new=null)
	{
		if($prev != null && $prev->getStatus() == $new->getStatus()){
			return true;
		}
		
		// Child Payment
		// currently we are assuming that only recurring payment can have child payments
		if($new->isMaster() == false){
			return $this->_onAfterChildPaymentSave($prev, $new);
		}
		
		return $this->_onAfterMasterPaymentSave($prev, $new);
	}
	
	protected function _onAfterMasterPaymentSave(PayplansPayment $prev=null, PayplansPayment $new=null)
	{
		$order = PayplansOrder::getInstance( $new->getOrder());

		// Child Payment
		// currently we are assuming that only recurring payment can have child payments
		if($new->isMaster() == false){
			return true;
		}
		
		// if there is change in status of order
		switch($new->getStatus()){
			case Xistatus::NONE 			:
							$orderStatus = XiStatus::NONE;
							break;

			case Xistatus::PAYMENT_COMPLETE	:
							$new->completeOrder();
							break;

			case Xistatus::PAYMENT_HOLD		:
			case XiStatus::PAYMENT_RECURRING_CANCEL :
			case XiStatus::PAYMENT_RECURRING_FAILED :
							$orderStatus = XiStatus::ORDER_HOLD;
							break;

			case Xistatus::PAYMENT_PENDING  :
			case Xistatus::PAYMENT_INITIATED:
							$orderStatus = XiStatus::ORDER_CONFIRMED;
							break;
		
			case XiStatus::PAYMENT_RECURRING_EOT :
							$orderStatus = XiStatus::ORDER_EXPIRED;
							break;

			case XiStatus::PAYMENT_RECURRING_SIGNUP:
			case XiStatus::PAYMENT_RECURRING_START:
							break;
			default 						:
							$orderStatus = XiStatus::NONE;
		}


		if(isset($orderStatus) && $order->getStatus() != $orderStatus && $orderStatus){
			// IMP : always refresh first, then change and save
			$order->refresh()
				  ->set('status', $orderStatus)
				  ->save();
		}

		return true;
	}
	
	protected function _onAfterChildPaymentSave(PayplansPayment $prev=null, PayplansPayment $new=null)
	{
		// get its master payment and complete the order
		$masterPayment = $new->getMasterPayment();
		
		switch($new->getStatus()){
				case XiStatus::PAYMENT_COMPLETE :	
					// XITODO : if master payment is on hold
					// then a child payment with complete status
					// what to do with master payment
					// currently we are making it sign up and sending an email to admins
					$masterPayment->completeOrder();
					$masterPayment->set('status', XiStatus::PAYMENT_RECURRING_SIGNUP)->save();
					break;
					
				case XiStatus::PAYMENT_HOLD :
					$masterPayment->set('status', XiStatus::PAYMENT_RECURRING_FAILED)
								  ->save();
					break;
					
				case XiStatus::PAYMENT_PENDING :
					$masterPayment->set('status', XiStatus::PAYMENT_RECURRING_FAILED)
								  ->save();
					break;
				
				case XiStatus::NONE :			
				default :
					// do nothing
					break;
			}
		return true;
	}
	
}