<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansPlan extends XiLib
	implements PayplansIfaceApptriggerable, PayplansIfaceApiPlan
{
	// Table fields
	protected $plan_id;
	protected $title;
	protected $published;
	protected $visible;
	protected $description;
	protected $time;
	protected $payment;
	protected $params;
	protected $_planapps;

	// not for table fields
	public function reset()
	{
		$this->plan_id 			= 0;
		$this->title 			= '';
		$this->published		= 1;
		$this->visible			= 1;
		$this->description		= '';
		$this->payment 			= PayplansHelperParam::getParamObject(PAYPLANS_PATH_XML.DS.'plan.payment');
		$this->time    			= PayplansHelperParam::getParamObject(PAYPLANS_PATH_XML.DS.'plan.time');
		$this->params  			= PayplansHelperParam::getParamObject(PAYPLANS_PATH_XML.DS.'plan.params');
		$this->_planapps		= array();
		return $this;
	}

	/**
	 * @return PayplansPlan
	 */
	static public function getInstance($id=0, $type=null, $bindData=null)
	{
		return parent::getInstance('plan',$id, $type, $bindData);
	}
	
	public function afterBind($id = 0)
	{
		if(!$id) return $this;

		$this->_planapps = XiFactory::getInstance('planapp', 'model')
									->getPlanApps($id);
		return $this;
	}

	public function getTitle()
	{
		return $this->title;
	}

	public function getPrice()
	{
		return PayplansHelperFormat::price($this->getPayment()->getValue('price'));
	}

	public function getExpiration()
	{
		$rawTime = $this->getTime()->getValue('expiration');

		return PayplansHelperPlan::convertIntoTimeArray($rawTime);
	}
	
	public function setExpiration($time)
	{
		$this->getTime()->setValue('expiration', $time);
		return $this;
	}

	public function getCurrency()
	{
		return XiFactory::getConfig()->currency;
	}

	public function bind($data, $ignore=array())
	{
		if(is_object($data)){
			$data = (array) ($data);
		}

		parent::bind($data, $ignore=array());

		if(isset($data['planapps'])){
			$this->_planapps = $data['planapps'];
		}

		return $this;
	}

	public function save()
	{
		parent::save();
		return $this->_savePlanApps();
	}

	private function _savePlanApps()
	{
		// delete all existing values of current plan id
		$model = XiFactory::getInstance('planapp', 'model');
		$model->deleteMany(array('plan_id' => $this->getId()));

		// insert new values into planapp for current plan id
		$data['plan_id'] = $this->getId();
		if(is_array($this->_planapps)){
			foreach($this->_planapps as $app){
				$data['app_id'] = $app;
				$model->save($data);
			}
		}

		return $this;
	}

	public function subscribe($userId)
	{
		//Create a NEW Order
		$order = PayplansOrder::getInstance()
					->setBuyer($userId)
					->save();

		// Create a Subscription
		// attach order with subscription
		$subscription = PayplansSubscription::getInstance();
		$subscription->setPlan($this)
					 ->setOrder($order)
					 ->save();

		// refresh order after saving subscription
		$order->refresh();
		return $order;
	}

	function hasApp($appId)
	{
		XiError::assert($appId, XiText::_('COM_PAYPLANS_INVALID_APP_ID_TO_CHECK'));

		return in_array($appId,$this->_planapps);
	}

	/**
	 * Implementing interface Apptriggerable
	 * @return array
	 */
	public function getPlans()
	{
		return array($this->getId());
	}
	
	public function getPublished()
	{
		return $this->published;
	}
	
	public function getVisible()
	{
		return $this->visible;
	}
	
	public function getDescription()
	{
		return $this->description;
	}
	
	public function getPlanapps()
	{
		return $this->_planapps;
	}
	
	public function getRawExpiration()
	{
		return $this->getTime()->get('expiration');
	}
	
	public function getTime()
	{
		return $this->time;
	}
	
	public function getTeasertext()
	{
		return $this->getParams()->get('teasertext','');
	}
	
	public function getParams()
	{
		return $this->params;
	}
	
	public function getPayment()
	{
		return $this->payment;
	}
	
	public function getRecurring()
	{
		if($this->getTime()->get('expirationtype', 'fixed') == 'recurring'){
			return true;
		}
		
		return false;
	}
	
	public function getRecurrenceCount()
	{
		return $this->getTime()->get('recurrence_count', 1);
	}
	
	public function delete()
	{
		//delete plan only when no subscription exists for the corresponding plan
		$subscription = XiFactory::getInstance('subscription','model')
									->loadRecords(array('plan_id'=>$this->getId()));
		if(empty($subscription)){
			return parent::delete();
		}
		
		$this->setError(XiText::_('COM_PAYPLANS_PLAN_GRID_CAN_NOT_DELETE_PLAN_SUBSCRIPTION_EXISTS'));
		return false;
	}
}