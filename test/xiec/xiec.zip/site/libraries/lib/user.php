<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * User object
 */
class PayplansUser extends XiLib
	implements PayplansIfaceApptriggerable, PayplansIfaceApiUser
{
	protected	  $user_id	 	 = 0 ;
	protected	  $realname		 = '';
	protected	  $username		 = '';
	protected	  $email		 = '';
	protected	  $usertype		 = '';
	protected	  $registerDate	 = '';
	protected	  $lastvisitDate = '';
	protected 	  $params        = '';
	protected	  $address		 = '';
	protected 	  $state		 = '';
	protected	  $city			 = '';
	protected 	  $country		 = '';
	protected     $zipcode		 = '';
	protected     $preference	 = '';	
	
	protected 	  $_subscriptions= array();

	public function __construct($config = array())
	{
		//return $this to chain the functions
		return $this->reset($config);
	}
	
	/**
	 * @return PayplansUser
	 */
	static public function getInstance($id=0, $type=null, $bindData=null)
	{
		return parent::getInstance('user',$id, $type, $bindData);
	}

	// Reset to construction time.
	public function reset($config=array())
	{
		$this->user_id	  	= 0 ;
		$this->username  	= '';
		$this->email		= '';
		$this->usertype		= '';
	  	$this->registerDate	= '';
		$this->lastvisitDate= '';
		
		// XITODO : bind params before using it
		$this->params		= PayplansHelperParam::getParamObject(PAYPLANS_PATH_XML.DS.'user.params');
		$this->_subscriptions= array();
		$this->address		= '';
		$this->state		= '';
		$this->city			= '';
		$this->country		= '';
		$this->zipcode		= '';
		$this->preference	= PayplansHelperParam::getParamObject(PAYPLANS_PATH_XML.DS.'user.preference');
		return $this;
	}	
	
	protected function _loadSubscriptions($id)
	{
		// get all subscription records of this order
		$records = XiFactory::getInstance('subscription','model')
								->loadRecords(array('user_id'=>$id));

		foreach($records as $record){
			$this->_subscriptions[$record->subscription_id] = PayplansSubscription::getInstance( $record->subscription_id, null, $record);
		}

		return $this;
	} 
	
	public function afterBind($id = 0)
	{
		if(!$id) return $this;

		//load dependent records
		return $this->_loadSubscriptions($id);
	}
	
	function login($username, $password)
	{
		$result = XiFactory::getApplication()->login(array('username'=>$username, 'password'=>$password));
		if($result instanceof JException ){
			// no need to enqueue message login function itself do that
			//$app->enqueueMessage($result->message);
			return false;
		}
		
		return true;
	}

	/**
	 * Implementing interface Apptriggerable
	 * @return array
	 */
	public function getPlans($status=XiStatus::SUBSCRIPTION_ACTIVE)
	{
		//XITODO : implement caching
		$ret = array();

		$filter = array('user_id'=>$this->getId());

		if($status !== null){
			$filter = array('user_id'=>$this->getId(), 'status'=>$status);
		}
		
		//return only active subscriptions of the user if status is not mentioned
		$subscriptions = XiFactory::getInstance('subscription', 'model')
				->loadRecords($filter);

		foreach($subscriptions as $item){
			$ret[] = $item->plan_id;
		}

		return $ret;
	}
	
	public function getRealname()
	{
		return $this->realname;
	}
	
	public function getUsername()
	{
		return $this->username;
	}
	
	public function getEmail()
	{
		return $this->email;
	}
	
	public function getUsertype()
	{
		return $this->usertype;
	}
	
	public function getRegisterDate()
	{
		return $this->registerDate;
	}
	
	public function getLastvisitDate()
	{
		return $this->lastvisitDate;
	}
	
	public function setAddress($address ='')
	{
		$this->address = $address;
		return $this;
	}
	
	public function getAddress()
	{
		return $this->address;
	}
	
	public function setState($state ='')
	{
		$this->state = $state;
		return $this;
	}
	
	public function getState()
	{
		return $this->state;
	}
	
	public function setCity($city = '')
	{
		$this->city = $city;
		return $this;
	}
	
	public function getCity()
	{
		return $this->city;
	}
	
	public function setCountry($country = '')
	{
		$this->country = $country;
		return $this;
	}
	
	public function getCountry()
	{
		return $this->country;
	}
	
	public function setZipcode($zipcode = '')
	{
		$this->zipcode = $zipcode;
		return $this;
	}
	
	public function getZipcode()
	{
		return $this->zipcode;
	}
	
	public function setPreference($key, $value)
	{
		$this->preference->set($key,$value);
		return $this;
	}
	
	public function getPreference($key = null, $default = false)
	{
		if($key === null)
		{
			return $this->preference;
		}
		
		return $this->preference->get($key, $default);
	}
	
	
	/* ------ Implement API ------------ */
	
	/* (non-PHPdoc)
	 * @see PayplansIfaceApiUser::getSubscriptions()
	 */
	public function getSubscriptions($status=NULL)
	{
		$subs = array();
		foreach($this->_subscriptions as $id => $sub){
			if($status===null || (int)$status === (int)$sub->getStatus()){
				$subs[$id] = $sub;
			}
		}
		return $subs;
	}
	
	public function isAdmin()
	{
		return XiHelperJoomla::isAdmin($this->getId()); 
	}
	
	public function setParam($key, $value)
	{
		XiError::assert($this);
		$this->getParams()->set($key,$value);
		return $this;
	}
	
	/**
	 * 
	 * @return XiParameter
	 */
	public function getParams()
	{
		return $this->params;
	}
}