<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * User object
 */
class PayplansUser extends XiLib
	implements PayplansIfaceApptriggerable, PayplansIfaceApiUser
{
	protected	  $user_id	 	 = 0 ;
	protected	  $realname		 = '';
	protected	  $username		 = '';
	protected	  $email		 = '';
	protected	  $usertype		 = '';
	protected	  $registerDate	 = '';
	protected	  $lastvisitDate = '';
	protected 	  $params        = '';
	
	protected 	  $_subscriptions= array();

	public function __construct($config = array())
	{
		//return $this to chain the functions
		return $this->reset($config);
	}
	
	/**
	 * @return PayplansUser
	 */
	static public function getInstance($id=0, $type=null, $bindData=null)
	{
		return parent::getInstance('user',$id, $type, $bindData);
	}

	// Reset to construction time.
	public function reset($config=array())
	{
		$this->user_id	  	= 0 ;
		$this->name 		= '';
		$this->username  	= '';
		$this->email		= '';
		$this->usertype		= '';
	  	$this->registerDate	= '';
		$this->lastvisitDate= '';
		
		// XITODO : bind params before using it
		$this->params		 = null;
		$this->_subscriptions= array();
		return $this;
	}	
	
	protected function _loadSubscriptions($id)
	{
		// get all subscription records of this order
		$records = XiFactory::getInstance('subscription','model')
								->loadRecords(array('user_id'=>$id));

		foreach($records as $record){
			$this->_subscriptions[$record->subscription_id] = PayplansSubscription::getInstance( $record->subscription_id, null, $record);
		}

		return $this;
	} 
	
	public function afterBind($id = 0)
	{
		if(!$id) return $this;

		//load dependent records
		return $this->_loadSubscriptions($id);
	}
	
	function login($username, $password)
	{
		$result = XiFactory::getApplication()->login(array('username'=>$username, 'password'=>$password));
		if($result instanceof JException ){
			// no need to enqueue message login function itself do that
			//$app->enqueueMessage($result->message);
			return false;
		}
		
		return true;
	}

	/**
	 * Implementing interface Apptriggerable
	 * @return array
	 */
	public function getPlans()
	{
		static $ret = null;

		if($ret===null){

			$ret = array();
			//return only active subscriptions of the user
			$subscriptions = XiFactory::getInstance('subscription', 'model')
					->loadRecords(array('user_id'=>$this->getId(), 'status'=>XiStatus::SUBSCRIPTION_ACTIVE));

			foreach($subscriptions as $item){
				$ret[] = $item->plan_id;
			}
		}

		return $ret;
	}
	
	public function getRealname()
	{
		return $this->realname;
	}
	
	public function getUsername()
	{
		return $this->username;
	}
	
	public function getEmail()
	{
		return $this->email;
	}
	
	public function getUsertype()
	{
		return $this->usertype;
	}
	
	public function getRegisterDate()
	{
		return $this->registerDate;
	}
	
	public function getLastvisitDate()
	{
		return $this->lastvisitDate;
	}
	
	
	/* ------ Implement API ------------ */
	
	/* (non-PHPdoc)
	 * @see PayplansIfaceApiUser::getSubscriptions()
	 */
	public function getSubscriptions($status=NULL)
	{
		$subs = array();
		foreach($this->_subscriptions as $id => $sub){
			if($status===null || (int)$status === (int)$sub->getStatus()){
				$subs[$id] = $sub;
			}
		}
		return $subs;
	}
}