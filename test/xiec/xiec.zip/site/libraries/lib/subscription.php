<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansSubscription extends XiLib
	  implements PayplansIfaceOrderable, 
	  			 PayplansIfaceApptriggerable, 
	  			 PayplansIfaceApiSubscription,
	  			 PayplansIfaceMaskable
{
	// Table fields
	protected $subscription_id;
	protected $order_id;
	protected $user_id;
	protected $plan_id;
	protected $status;
	protected $total;
	/**
	 * @var XiDate
	 */
	protected $subscription_date;
	/**
	 * @var XiDate
	 */
	protected $expiration_date;
	/**
	 * @var XiDate
	 */
	protected $cancel_date;
	/**
	 * @var XiParameter
	 */
	protected $params;


	// Fields not related to tables
	/**
	 * @var PayplansPlan
	 */
	private $_plan ;


	/**
	 * @return PayplansSubscription
	 */
	static public function getInstance($id=0, $type=null, $bindData=null)
	{
		return parent::getInstance('subscription',$id, $type, $bindData);
	}
	
	// not for table fields
	public function reset()
	{
		$this->subscription_id 	= 0;
		$this->order_id 		= 0;
		$this->user_id 			= 0;
		$this->plan_id 			= 0;
		$this->total 			= 0.0000;
		$this->status			= XiStatus::NONE;
		$this->subscription_date= new XiDate();
		$this->expiration_date	= new XiDate();
		$this->cancel_date		= new XiDate('0000:00:00 00:00:00');
		$this->params			= PayplansHelperParam::getParamObject(PAYPLANS_PATH_XML.DS.'subscription.params');

		return $this;
	}

	public function save()
	{
		//also make sure data is uptodate
		$this->total  = $this->params->get('price') - $this->params->get('discount');

		//let it saves
		return parent::save();
	}

	public function afterBind($id = 0)
	{
		if(!$id) return $this;

		// set disount, so that some calculation can be applied
		$this->setDiscount($this->getDiscount());
		
		//load dependent Plan records
		$this->_plan = PayplansPlan::getInstance($this->plan_id);
		return $this;
	}

	public function setPlan($plan)
	{
		XiError::assert($plan);
		
		//support passing a plan-id.
		if(is_a($plan,'PayplansPlan')===false){
			$plan = PayplansPlan::getInstance($plan);
		}
		
		// no need to reset all time, for edit it will reset id, which is not desirable
		//$this->reset();

		// add basic data
		$this->plan_id 		= $plan->getId();
		$this->title		= $plan->getTitle();
		$this->status		= XiStatus::NONE;
		$this->cancel_date	= null;

		// current timestamp
		$this->subscription_date= new XiDate();

		//add expiration to current timestamp
		$dateExp	= 	new XiDate();
		$this->expiration_date	= $dateExp->addExpiration($plan->getRawExpiration());

		// set params
		$this->params->set('price',$plan->getPrice());
		$this->params->set('discount',0);
		$this->total  = $this->getPrice() - $this->getDiscount();

		$this->_plan	= $plan;
		return $this;
	}

	// Interface support
	public function getTitle()
	{
		if(!isset($this->_plan))
			return '';

		return $this->_plan->getTitle();
	}

	public function getPrice()
	{
		return PayplansHelperFormat::price($this->params->get('price'));
	}
	
	public function setPrice($price)
	{
		$this->params->set('price', $price);
		return $this;
	}

	public function getTotal()
	{
		return PayplansHelperFormat::price($this->total);
	}

	public function getDiscount()
	{
		return PayplansHelperFormat::price($this->params->get('discount'));
	}

	public function setDiscount($discount=0)
	{
		// discount should not be greater than price
		$price = $this->getPrice();
		if($price < $discount){
			$discount = $price;
		}
		
		$this->params->set('discount', $discount);
		return $this;
	}

	public function getStatus()
	{
		return $this->status;
	}

	public function setStatus($status)
	{
		$this->status = $status;
		return $this;
	}

	public function setBuyer($userId=0)
	{
		$this->user_id = $userId;
		return $this;
	}

	public function getBuyer($instance=false)
	{
		if($instance == PAYPLANS_INSTANCE_REQUIRE){
			return PayplansUser::getInstance($this->user_id);
		}

		return $this->user_id;
	}

	public function setOrder(PayplansOrder $order)
	{
		return $this->setBuyer($order->getBuyer())
			 		->set('order_id', $order->getId())
			 		->save();
	}

	/**
	 * Implementing interface Apptriggerable
	 * @return array
	 */
	public function getPlans($requireInstance = false)
	{
		if($requireInstance===PAYPLANS_INSTANCE_REQUIRE){
			return array(PayplansPlan::getInstance($this->plan_id));
		}
		//get all subscription's plans
		return array($this->plan_id);
	}

	public function getOrder($instance=false)
	{
		if($instance == PAYPLANS_INSTANCE_REQUIRE){
			return PayplansOrder::getInstance($this->order_id);
		}
		
		return $this->order_id;
	}

	public function getSubscriptionDate()
	{
		return $this->subscription_date;
	}

	public function getExpirationDate()
	{
		return $this->expiration_date;
	}

	public function setExpirationDate($date)
	{
		if(!is_a($date, 'XiDate')){
			$date = new XiDate($date); 
		}
		
		$this->expiration_date= $date;
		return $this;
	}
	
	public function getCancelDate()
	{
		return $this->cancel_date;
	}

	public function getBuyerName()
	{
		return PayplansHelperUser::getName($this->user_id);
	}

	public function getBuyerUsername()
	{
		return PayplansHelperUser::getUserName($this->user_id);
	}

	public function getStatusName($version='')
	{
		return XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($this->status).$version);
	}
	
	/*Implement API */
	/* 
	 * (non-PHPdoc)
	 * @see PayplansIfaceApiSubscription::isActive()
	 */
	public function isActive()
	{
		return ($this->status==XiStatus::SUBSCRIPTION_ACTIVE);	
	}
	
	public function delete()
	{
		$order = $this->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		parent::delete();
		
		if($order){
			return $order->refresh();	
		}
		
		return null;
	}
	
	public function getParams()
	{
		return $this->params;
	}
	
	public function renew()
	{
		$plan = array_pop($this->getPlans(PAYPLANS_INSTANCE_REQUIRE));
		$this->expiration_date	= $this->getExpirationDate()->addExpiration($plan->getRawExpiration());
		$this->save();
		return $this;
	}
	
	public function isRecurring()
	{
		$plan = array_pop($this->getPlans(PAYPLANS_INSTANCE_REQUIRE));
		return $plan->getRecurring();
	}
}
