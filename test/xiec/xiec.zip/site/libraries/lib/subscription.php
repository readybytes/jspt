<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansSubscription extends XiLib
	  implements PayplansIfaceOrderable, 
	  			 PayplansIfaceApptriggerable, 
	  			 PayplansIfaceApiSubscription,
	  			 PayplansIfaceMaskable
{
	// Table fields
	protected $subscription_id;
	protected $order_id;
	protected $user_id;
	protected $plan_id;
	protected $status;
	protected $total;
	/**
	 * @var XiDate
	 */
	protected $subscription_date;
	/**
	 * @var XiDate
	 */
	protected $expiration_date;
	/**
	 * @var XiDate
	 */
	protected $cancel_date;
	/**
	 * @var XiParameter
	 */
	protected $params;


	// Fields not related to tables
	/**
	 * @var PayplansPlan
	 */
	private $_plan ;


	/**
	 * @return PayplansSubscription
	 */
	static public function getInstance($id=0, $type=null, $bindData=null)
	{
		return parent::getInstance('subscription',$id, $type, $bindData);
	}
	
	// not for table fields
	public function reset()
	{
		$this->subscription_id 	= 0;
		$this->order_id 		= 0;
		$this->user_id 			= 0;
		$this->plan_id 			= 0;
		$this->total 			= 0.0000;
		$this->status			= XiStatus::NONE;
		$this->subscription_date= new XiDate('0000:00:00 00:00:00');
		$this->expiration_date	= new XiDate('0000:00:00 00:00:00');
		$this->cancel_date		= new XiDate('0000:00:00 00:00:00');
		$this->params			= PayplansHelperParam::getParamObject(PAYPLANS_PATH_XML.DS.'subscription.params');

		return $this;
	}

	public function save()
	{
		//also make sure data is uptodate
		$this->total  = $this->params->get('price') - $this->params->get('discount');

		// if subscription status is active and expiration time is not set/valid
		// it means activate subscription now
		if($this->getStatus() == XiStatus::SUBSCRIPTION_ACTIVE 
			&& ($this->getSubscriptionDate()->toMySql() == null
					&& $this->getExpirationDate()->toMySql() == null)){
			
			$this->subscription_date= new XiDate();
			
			//add expiration to current timestamp
			$dateExp	= 	new XiDate();
			$plan = array_pop($this->getPlans(PAYPLANS_INSTANCE_REQUIRE));
			$this->expiration_date	= $dateExp->addExpiration($plan->getRawExpiration());
			
		}
		
		
		//let it saves
		return parent::save();
	}

	public function afterBind($id = 0)
	{
		if(!$id) return $this;

		// set disount, so that some calculation can be applied
		$this->setDiscount($this->getDiscount());
		
		//load dependent Plan records
		$this->_plan = PayplansPlan::getInstance($this->plan_id);
		return $this;
	}

	public function setPlan($plan)
	{
		XiError::assert($plan);
		
		//support passing a plan-id.
		if(is_a($plan,'PayplansPlan') === false){
			$plan = PayplansPlan::getInstance($plan);
		}
		
		// no need to reset all time, for edit it will reset id, which is not desirable
		//$this->reset();

		// add basic data
		$this->plan_id 		= $plan->getId();
		$this->title		= $plan->getTitle();
		$this->status		= XiStatus::NONE;
		$this->cancel_date	= null;

		// current timestamp
		$this->subscription_date= new XiDate('0000:00:00 00:00:00');
		$this->expiration_date = new XiDate('0000:00:00 00:00:00');
		
		// set params
		$this->setPrice($plan->getPrice());
		$this->setDiscount(0);
		$this->total  = $this->getTotal();

		$this->setFirstPrice($plan->getFirstPrice());
		$this->setFirstPriceDiscount(0);
		$this->getFirstPriceTotal();  // will set also
				
		$this->_plan	= $plan;
		return $this;
	}

	// Interface support
	public function getTitle()
	{
		if(!isset($this->_plan))
			return '';

		return $this->_plan->getTitle();
	}

	public function getPrice()
	{
		return PayplansHelperFormat::price($this->params->get('price'));
	}
	
	public function getFirstPrice()
	{
		if($this->params->get('first_price', PAYPLANS_UNDEFINED) === PAYPLANS_UNDEFINED){
			return PAYPLANS_UNDEFINED;
		}
		
		return PayplansHelperFormat::price($this->params->get('first_price', PAYPLANS_UNDEFINED));
	}
	
	public function setPrice($price)
	{
		$this->params->set('price', $price);
		//also update total
		$this->getTotal();
		return $this;
	}

	public function setFirstPrice($price)
	{
		$this->params->set('first_price', $price);
		//also update total
		$this->getFirstPriceTotal();
		return $this;
	}
	
	public function getTotal()
	{
		//always ensure it to be calculated
		$this->total = $this->getPrice()-$this->getDiscount();
		return PayplansHelperFormat::price($this->total);
	}
	
	public function getFirstPriceTotal()
	{
		if($this->getFirstPrice() === PAYPLANS_UNDEFINED){
			$this->params->set('first_price_total', PAYPLANS_UNDEFINED);
			return PAYPLANS_UNDEFINED;
		}
		
		//always ensure it to be calculated
		$this->params->set('first_price_total', $this->getFirstPrice()-$this->getFirstPriceDiscount());
		$firstPriceTotal = $this->params->get('first_price_total', PAYPLANS_UNDEFINED);
		
		return PayplansHelperFormat::price($firstPriceTotal);
	}

	public function getDiscount()
	{
		return PayplansHelperFormat::price($this->params->get('discount'));
	}
	
	public function getFirstPriceDiscount()
	{
		return PayplansHelperFormat::price($this->params->get('first_price_discount'));
	}

	public function setDiscount($discount=0)
	{
		// discount should not be greater than price
		$price = $this->getPrice();
		if($price < $discount){
			$discount = $price;
		}
		
		$this->params->set('discount', $discount);
		//also update total
		$this->getTotal();
		
		return $this;
	}

	public function setFirstPriceDiscount($discount = 0)
	{
		// discount should not be greater than price
		$price = $this->getFirstPrice();
		if($price < $discount){
			$discount = $price;
		}
		
		$this->params->set('first_price_discount', $discount);
		//also update total
		$this->getFirstPriceTotal();
		
		return $this;
	}
	
	public function getStatus()
	{
		return $this->status;
	}

	public function setStatus($status)
	{
		$this->status = $status;
		return $this;
	}

	public function setBuyer($userId=0)
	{
		$this->user_id = $userId;
		return $this;
	}

	public function getBuyer($requireinstance=false)
	{
		if($requireinstance == PAYPLANS_INSTANCE_REQUIRE){
			return PayplansUser::getInstance($this->user_id);
		}

		return $this->user_id;
	}

	/**
	 * (non-PHPdoc)
	 * @see PayplansIfaceApiSubscription::setOrder()
	 * @return PayplansSubscription
	 */
	public function setOrder(PayplansOrder $order)
	{
		return $this->setBuyer($order->getBuyer())
			 		->set('order_id', $order->getId())
			 		->save();
	}

	/**
	 * Implementing interface Apptriggerable
	 * @return array
	 */
	public function getPlans($requireInstance = false)
	{
		if($requireInstance===PAYPLANS_INSTANCE_REQUIRE){
			return array(PayplansPlan::getInstance($this->plan_id));
		}
		//get all subscription's plans
		return array($this->plan_id);
	}

	/**
	 * @return PayplansOrder
	 * 
	 * (non-PHPdoc)
	 * @see components/com_payplans/libraries/iface/api/PayplansIfaceApiSubscription::getOrder()
	 */
	public function getOrder($requireinstance=false)
	{
		if($requireinstance == PAYPLANS_INSTANCE_REQUIRE){
			return PayplansOrder::getInstance($this->order_id);
		}
		
		return $this->order_id;
	}

	public function getSubscriptionDate()
	{
		return $this->subscription_date;
	}

	public function getExpirationDate()
	{
		return $this->expiration_date;
	}

	public function setExpirationDate($date)
	{
		if(!is_a($date, 'XiDate')){
			$date = new XiDate($date); 
		}
		
		$this->expiration_date= $date;
		return $this;
	}
	
	public function getCancelDate()
	{
		return $this->cancel_date;
	}

	public function getBuyerName()
	{
		return PayplansHelperUser::getName($this->user_id);
	}

	public function getBuyerUsername()
	{
		return PayplansHelperUser::getUserName($this->user_id);
	}

	public function getStatusName($version='')
	{
		return XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($this->status).$version);
	}
	
	/*Implement API */
	/* 
	 * (non-PHPdoc)
	 * @see PayplansIfaceApiSubscription::isActive()
	 */
	public function isActive()
	{
		return ($this->status==XiStatus::SUBSCRIPTION_ACTIVE);	
	}
	
	public function delete()
	{
		$order = $this->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		parent::delete();
		
		if($order){
			return $order->refresh()->save();	
		}
		
		return null;
	}
	
	public function getParams()
	{
		return $this->params;
	}
	
	public function renew()
	{
		$plan = array_pop($this->getPlans(PAYPLANS_INSTANCE_REQUIRE));
		
		if($this->getSubscriptionDate()->toMySql() == null){
			$this->subscription_date = new XiDate();
		}
	
		if($this->getExpirationDate()->toMySql() == null){
			$this->expiration_date = new XiDate();
		}
		
		$extend_from = $this->getExpirationDate();
		$current_date	= new XiDate('now');
		
		// extend the subscription time from the date which is greater not from the expiration date always
		// as in some cases user renew the subscription after few days of expiration 
		if($current_date->toMySQL() > $this->getExpirationDate()->toMySQL()){
			$extend_from = $current_date;
		}

		$this->expiration_date	= $extend_from->addExpiration($plan->getRawExpiration());
		$this->set('status', XiStatus::SUBSCRIPTION_ACTIVE)->save();
		return $this;
	}
	
	public function isRecurring()
	{
		$plan = array_pop($this->getPlans(PAYPLANS_INSTANCE_REQUIRE));
		return $plan->getRecurring();
	}
}