<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansPayment extends XiLib
	implements PayplansIfaceApptriggerable, PayplansIfaceApiPayment, PayplansIfaceMaskable
{
	// Table fields
	protected $payment_id;
	protected $order_id;
	protected $app_id;
	protected $amount;
	protected $currency;
	protected $status;
	protected $is_refund;
	protected $created_date;
	protected $modified_date;
	protected $transaction;

	/**
	 * @return PayplansPayment
	 */
	static public function getInstance($id=0, $type=null, $bindData=null)
	{
		return parent::getInstance('payment',$id, $type, $bindData);
	}
	
	// not for table fields
	public function reset()
	{
		XiError::assert($this);
		$this->payment_id		= 	0;
		$this->order_id			=	0;
		$this->app_id			=	0;
		$this->amount			=	0.0000;
		$this->currency			= 	XiFactory::getConfig()->currency;;
		$this->status			=	XiStatus::NONE;
		$this->is_refund		=	false;
		$this->created_date		=	new XiDate();
		$this->modified_date	=	new XiDate();
		$this->transaction		= 	"No Records ";

		return $this;
	}

	public function getStatus()
	{
		return $this->status;
	}

	public function setStatus($status)
	{
		$this->status=$status;
		return $this;
	}

	public function getBuyer($instance=false)
	{
		return PayplansOrder::getInstance($this->order_id)
					->getBuyer($instance);
	}

	/**
	 * Implementing interface Apptriggerable
	 * @return array
	 */
	public function getPlans($requireInstance = false)
	{
		//get all subscription's plans
		$order = PayplansOrder::getInstance($this->order_id);
		return $order ? $order->getPlans($requireInstance) : array();
	}

	public function setOrder($order)
	{
		$this->order_id = is_a($order,'PayplansOrder') ? $order->getId() : $order;  	
		return $this;
	}
	
	public function setApp($app)
	{
		$this->app_id = is_a($app,'PayplansApp') ? $app->getId() : $app;  	
		return $this;
	}
	
	
	public function getOrder($requireInstance = false)
	{
		if($requireInstance == PAYPLANS_INSTANCE_REQUIRE){
			return PayplansOrder::getInstance($this->order_id);
		}
		
		return $this->order_id;
	}

	public function getAppName()
	{
		return PayplansApp::getInstance( $this->app_id)->getTitle();
	}

	public function getAmount()
	{
		return PayplansHelperFormat::price($this->amount);
	}

	public function getCurrency()
	{
		return $this->currency;
	}

	public function getStatusName($version='')
	{
		return XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($this->status).$version);
	}

	public function getCreatedDate()
	{
		return $this->created_date;
	}

	public function getModifiedDate()
	{
		return $this->modified_date;
	}

	public function getApp($instance = false)
	{
		if($instance){
			return PayplansApp::getInstance($this->app_id);
		}
		
		return $this->app_id;
	}
	
	public function getTransaction()
	{
		return $this->transaction;
	}
	
	
	public function setTransaction($transaction)
	{
		//convert array to ini
		if(is_array($transaction)){
			$transaction= PayplansHelperParam::arrayToIni($transaction);
		}
		
		$this->transaction=$transaction;
		return $this;
	}
	
	public function getIsRefund()
	{
		return $this->is_refund;
	}
	
	public function delete()
	{
		$order = $this->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		parent::delete();

		if($order){
			return $order->refresh();
		}
		
		return null;
	}
	
	public function getSubscriptions()
	{
		return $this->getOrder(PAYPLANS_INSTANCE_REQUIRE)->getSubscriptions();
	}
	
}