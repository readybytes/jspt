<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansOrder extends XiLib
	implements PayplansIfaceApptriggerable, PayplansIfaceApiOrder, PayplansIfaceMaskable
{
	// Table fields
	protected $order_id;
	protected $buyer_id;
	protected $subtotal;
	protected $discount;
	protected $total;
	protected $currency;
	protected $status;
	protected $created_date;

	//secondary information
	protected $_subscriptions	= array();
	protected $_payments		= array();
	
	//XITODO : convert name to taxrate
	protected $tax 	 	= 0.0000;
	
	// Not used
	protected $shipping = 0.0000;

	protected $shipping_address = null;
	protected $billing_address	= null;
	protected $params;

	/**
	 * @return PayplansOrder
	 */
	static public function getInstance($id=0, $type=null, $bindData=null)
	{
		return parent::getInstance('order',$id, $type, $bindData);
	}

	// 	not for table fields
	public function reset($config=array())
	{
		$this->order_id	= 0;
		$this->buyer_id	= 0;
		$this->subtotal	= 0.0000;
		$this->discount	= 0.0000;
		$this->total	= 0.0000;

		// Load default currency from configuration
		$this->currency 	= XiFactory::getConfig()->currency;
		$this->status		= XiStatus::NONE;

		//XITODO : Is it ok to store current timestamp ?
		$this->created_date = new XiDate();

		//clean all subscriptions stored
		$this->_subscriptions	= array();
		$this->_payments		= array();
		$this->params			= 	PayplansHelperParam::getParamObject(PAYPLANS_PATH_XML.DS.'order.params');
		
		return $this;
	}

	public function _loadSubscriptions($order_id)
	{
		// get all subscription records of this order
		$subRecords = XiFactory::getInstance('subscription','model')
								->loadRecords(array('order_id'=>$order_id));

		$this->_subscriptions   = array();
		$this->total 	= 0.0000;
		$this->subtotal = 0.0000;
		$this->discount = 0.0000;

		foreach($subRecords as $record){
			$subscription = PayplansSubscription::getInstance( $record->subscription_id, null, $record);
			$this->addSubscription($subscription);
		}

		return $this;
	}

	public function _loadPayments($order_id)
	{
		// get all subscription records of this order
		$records = XiFactory::getInstance('payment','model')
								->loadRecords(array('order_id'=>$order_id), array('limit'));

		$this->_payments	= array();

		foreach($records as $record){
			$this->addPayment(PayplansPayment::getInstance( $record->payment_id, null, $record));
		}

		return $this;
	}

	public function afterBind($id = 0)
	{
		if(!$id) return $this;

		//load dependent records
		return $this->_loadSubscriptions($id)->_loadPayments($id);
	}

	/**
	 * It will add subscription to the order.
	 * Item is orderable, so it will have all kind of function to get
	 * additional data
	 * @param Orderable $subscription
	 */
	public function addSubscription(PayplansIfaceOrderable $subscription)
	{
		// save it on _subscriptions list
		$this->_subscriptions[$subscription->getId()]=$subscription;

		// now update self record
		$this->subtotal += $subscription->getPrice();
		$this->discount += $subscription->getDiscount();
		// update total with the discount and the tax in the order table
        //because tax apply only on order not on the subscription
		//IMP: update total
		$this->calculateTotal();
		
		return $this;
	}

	//Payment records of orders
	public function addPayment(PayplansPayment $item)
	{
		// save it on payment list
		$this->_payments[$item->getId()]=$item;
		return $this;
	}

	/**
	 * Create payments
	 * @param unknown_type $appId
	 * @param boolean $checkFirstPayment : Now deprecated, not required, starting from 1.3
	 */
	public function createPayment($appId, $checkFirstPayment=false)
	{
		$setFirstPayment = false;

		//IMP : save is must to ensure new record get a ID
		// XITODO : add som intelligency
		// e.g. reduce discount on each recurring payment
		// first installment will charge x amount and another will charge y amount
		$payment = PayplansPayment::getInstance()
						->set('order_id',$this->getId())
						->set('app_id',$appId)
						->set('amount',$this->getTotal())
						->set('currency', $this->getCurrency('isocode'));

		$amount = $this->getFirstTotal();
		// No need to check $checkFirstPayment as we can check it ourseleves
		if($amount !== PAYPLANS_UNDEFINED && count($this->getCompletedPayments(XiStatus::PAYMENT_COMPLETE)) == 0){
			$payment->set('amount', $amount);
			$setFirstPayment = true;
		}

		$payment->save();
		
		// set the payment id of trial/ set-up payment linked with this order in params
		if($setFirstPayment === true){
			$this->params->set('first_payment_id',$payment->getId());
			$this->save();
		}

		//also add into payment list of order
		$this->addPayment($payment);
		return $payment;
	}


	public function setBuyer($userId=0)
	{
		$this->buyer_id = $userId;

		// update all subscriptions
		foreach($this->_subscriptions as $subscription){
			$subscription->setBuyer($userId);
		}

		return $this;
	}

	public function getBuyer($requireinstance=false)
	{
		if($requireinstance == PAYPLANS_INSTANCE_REQUIRE){
			return PayplansUser::getInstance($this->buyer_id);
		}

		return $this->buyer_id;
	}

	public function refresh()
	{
		// set previous state in session so that logging can be done properly
		$previousObj = unserialize(serialize($this));
		XiFactory::getSession()->set(JString::strtoupper($this->getName()).'_PREVIOUS_OBJECT', serialize($previousObj));
		
		// get all subscription records of this order
		$this->_loadSubscriptions($this->getId());
		$this->_loadPayments($this->getId());

		//refresh total
		$this->calculateTotal();
		
		// save update order
		return $this;
	}

	public function getStatus()
	{
		return $this->status;
	}

	public function setStatus($status)
	{
		$this->status = $status;
		return $this;
	}

	public function confirm($appId)
	{
		//create a new payment for this order_id
		$this->_payments = $this->createPayment($appId);
		// in case of renewals order might be complete
		if($this->getStatus() != XiStatus::ORDER_COMPLETE){
			$this->set('status', Xistatus::ORDER_CONFIRMED)
				 ->save();
		}

		return $this;
	}

	public function getPayment()
	{
		return $this->getPayments();
	}

// 	//IMP : Always use calculateTotal, never set total directly
//	public function setTotal($total)
//	{
//		$this->total = $total;
//		return $this;
//	}

	public function setSubtotal($subtotal)
	{
		$this->subtotal = $subtotal;
		return $this;
	}
	
	function calculateTotal()
	{
		// update total with tax  
		$this->total = ($this->subtotal - $this->discount);
		$this->total += $this->total * $this->tax / 100;
		return $this;
	}
	
	public function getFirstTotal()
	{
		$total = PAYPLANS_UNDEFINED;
		foreach($this->_subscriptions as $sub){
			$subtotal = $sub->getFirstPriceTotal();
			if($subtotal === PAYPLANS_UNDEFINED){
				continue;
			}
			$total = ($total === PAYPLANS_UNDEFINED) ? 0 : $total;
			$total += $subtotal;
		}
		
		if(JString::trim($total) === PAYPLANS_UNDEFINED || floatval($total) == floatval(0)){
			return $total;
		}

		// update total with tax 
		$total += $total * $this->tax / 100;
		return $total;
	}
	
	public function getFirstSubtotal()
	{
		$subtotal = PAYPLANS_UNDEFINED;
		foreach($this->_subscriptions as $sub){
			$amount = $sub->getFirstPrice();
			if($amount === PAYPLANS_UNDEFINED){
				continue;
			}
			$subtotal = ($subtotal === PAYPLANS_UNDEFINED) ? 0 : $subtotal;
			$subtotal += $amount;
		}
		
		if(JString::trim($subtotal) === PAYPLANS_UNDEFINED || floatval($subtotal) == floatval(0)){
			return $subtotal;
		}
		
		return $subtotal;
	}

	public function getFirstPriceDiscount()
	{
		$discount = 0;
		foreach($this->_subscriptions as $sub){
			$subtotal = $sub->getFirstPriceDiscount();
			$discount += $subtotal;
		}
		
		return PayplansHelperFormat::price($discount);
	}
	
	public function getFirstPriceTax()
	{
		$tax 	   = 0;
		$discount  = $this->getFirstPriceDiscount();
		$subtotal  = $this->getFirstSubtotal();
		if($subtotal === PAYPLANS_UNDEFINED){
			return PayplansHelperFormat::price($tax);
		}

		$tax = ($subtotal - $discount) * $this->tax / 100;
		return PayplansHelperFormat::price($tax);
	}
	
	/**
	 * 
	 * @deprecated in 1.3
	 * @param $status
	 */
	public function getCompletedPayments($status = XiStatus::PAYMENT_COMPLETE)
	{
		return $this->getPayments(XiStatus::PAYMENT_COMPLETE);
	}
	
	public function getTotal()
	{
		$this->calculateTotal(); 
		return PayplansHelperFormat::price($this->total);
	}

	public function getSubtotal()
	{
		return PayplansHelperFormat::price($this->subtotal);
	}

//	public function complete()
//	{
//		return $this->set('status', XiStatus::ORDER_COMPLETE)
//			 		->save();
//	}

	public function getDiscount()
	{
		return PayplansHelperFormat::price($this->discount);
	}

	public function getTaxAmount()
	{
		$tax = ($this->subtotal - $this->discount) * $this->tax / 100;
		return PayplansHelperFormat::price($tax);
	}
	
	public function getTaxRate()
	{
		return $this->tax;
	}
	
	public function setTaxRate($tax)
	{
		$this->tax = $tax;
		return $this->calculateTotal();
	}


	public function getShipping()
	{
		return PayplansHelperFormat::price($this->shipping);
	}

 	/**
 	 * Implementing interface Apptriggerable
 	 * @return array
 	 */
 	public function getPlans($requireInstance = false)
 	{
 		$ret = array();
 		//get all subscription's plans
 		foreach($this->_subscriptions as $subscription){
 			$ret = array_merge($ret, $subscription->getPlans($requireInstance));
 		}

 		return $ret;
 	}

 	/**
 	 * @return PayplansSubscription Array
 	 */
 	public function getSubscriptions()
 	{
 		return $this->_subscriptions;
 	}

	/**
 	 * @return PayplansPayment[]
 	 */
 	public function getPayments($status = null)
 	{
 		if($status === null){
 			return $this->_payments;
 		}
 		
 		$selected = array();
 		foreach ($this->_payments as $payment) {
 			/* @var $payment PayplansPayment */ 			
 			if($payment->getStatus() == $status){
 				$selected[$payment->getId()] = $payment;
 			}
 		}
 		
 		return $selected;
 	}
 	
	public function getStatusName($version='')
	{
		return XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($this->status).$version);
	}
	
	public function getCurrency($format = null)
	{
		return PayplansHelperFormat::currency(XiFactory::getCurrency($this->currency), array(), $format);
	}
	
	public function getCreatedDate()
	{
		return $this->created_date;
	}
	
	public function isRecurring()
	{
		$plans = $this->getPlans(PAYPLANS_INSTANCE_REQUIRE);
		//XITODO : need to change in concept when multiple subscription support will be available
		// if any one plans if recurring then return true
		foreach($plans as $plan){
			if($plan->getRecurring()){
				return true;
			}	
		}
		
		return false;
	}
	
	function renewSubscriptions()
	{
		foreach($this->_subscriptions as $sub){
			$sub->renew();
		}
		
		return $this;
	}
	
	function getMasterPayment()
 	{
 		if(empty($this->_payments)){
 			return false;
 		}
 		
 		foreach(array_reverse($this->_payments, true) as $payment){
 			if($payment->isMaster() == true){
 				return $payment;
 			}
 		}
 		
 		return false;
 	}
 	
 	/**
 	 * 
 	 * If order is not already expired, then only complete it
 	 * @return PayplansOrder
 	 */
 	function complete($recentPayment=null)
 	{
 		// If order is expired then we MUST not mark it complete
 		if($this->getStatus() == XiStatus::ORDER_EXPIRED){
 			$message = XiText::_('COM_PAYPLANS_ORDER_ERROR_ORDER_WAS_NOT_COMPLETED_BECAUSE_ALREADY_EXPIRED');
 			if($recentPayment){
 				PayplansHelperLogger::log(XiLogger::LEVEL_ERROR, $message, $recentPayment);	
 			}
 			
 			PayplansHelperLogger::log(XiLogger::LEVEL_ERROR, $message, $this);
 			return $this;	
 		}
 		
 		// renewal of free subscription when no payment 
		// has been made for the order
 		if(floatval(0) == floatval($this->getTotal())){
			if($this->getStatus() == XiStatus::ORDER_COMPLETE){
				$this->renewSubscriptions();
			}
	     }
              
 		if($this->getMasterPayment()){
	 		$totalPayment  = count($this->getPayments(XiStatus::PAYMENT_COMPLETE));
	 		// if completed payment is greated than 1, 
			// then need to renew the subscription
			if($totalPayment > 1){
				$this->renewSubscriptions();
			}
 		}
 		
		$orderStatus = XiStatus::ORDER_COMPLETE;
		// approval is required for first payment only
		if(($this->getStatus() != XiStatus::ORDER_COMPLETE) && (XiFactory::getconfig()->autoCompleteOrder == false)){
			$orderStatus = XiStatus::ORDER_PAID;
		}
								
		return $this->set('status', $orderStatus)->save();
 	}
 	
 	//return the payment id of first payment in case of recurring plan when first payment amount is set
	public function getFirstPaymentId()
	{		
		return $this->params->get('first_payment_id',0);
	}
	
	
	public function setParam($key, $value)
	{
		XiError::assert($this);
		$this->getParams()->set($key,$value);
		return $this;
	}
	
	public function getParam($key,$default=null)
	{
		XiError::assert($this);
		return $this->getParams()->Get($key,$default);
	}
	
	public function getParams()
	{
		return $this->params;
	}
}

