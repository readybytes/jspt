<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

// If file is already included
if(defined('PAYPLANS_DEFINE_SITE'))
	return;

define('PAYPLANS_DEFINE_SITE', true);

// define the joomla version
$version = new JVersion();
if($version->RELEASE==='1.5'){
	define('PAYPLANS_JVERSION', '15');
	define('PAYPLANS_JVERSION_15', true);
	define('PAYPLANS_JVERSION_16', false);
	define('PAYPLANS_COM_USER', 'com_user');	
	define('PAYPLANS_COM_USER_VIEW_REGISTER', 'register');
}else {
	define('PAYPLANS_JVERSION', '16');
	define('PAYPLANS_JVERSION_16', true);
	define('PAYPLANS_JVERSION_15', false);
	define('PAYPLANS_COM_USER', 'com_users');
	define('PAYPLANS_COM_USER_VIEW_REGISTER', 'registration');
}

define('XI_ENABLE_STATE',  1);
define('XI_DISABLE_STATE', 0);

define('XI_COMPONENT_NAME','payplans');
define('PAYPLANS_PATH_COMPONENT_SITE', dirname(dirname(__FILE__)));
define('PAYPLANS_PATH_COMPONENT_ADMIN', JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_payplans');
define('PAYPLANS_VERSION', '1.0.0');
define('PAYPLANS_REVISION','824');
define('PAYPLANS_PREMIUM_BUILD', 1);

//define XI paths
define('XI_PATH_LIBRARY',		PAYPLANS_PATH_COMPONENT_SITE.DS.'libraries'.DS.'base');
define('XI_PATH_HELPER',		XI_PATH_LIBRARY.DS.'helper');
define('XI_PATH_BEHAVIOUR',		XI_PATH_LIBRARY.DS.'model'.DS.'behaviour');
define('XI_PATH_PLUGIN',		XI_PATH_LIBRARY.DS.'plugin');

//all folder paths
define('PAYPLANS_PATH_CONTROLLER',	PAYPLANS_PATH_COMPONENT_SITE.DS.'controllers');
define('PAYPLANS_PATH_VIEW',		PAYPLANS_PATH_COMPONENT_SITE.DS.'views');
define('PAYPLANS_PATH_INCLUDE',		PAYPLANS_PATH_COMPONENT_SITE.DS.'includes');
define('PAYPLANS_PATH_TEMPLATE',	PAYPLANS_PATH_COMPONENT_SITE.DS.'templates');
define('PAYPLANS_PATH_LIBRARY',		PAYPLANS_PATH_COMPONENT_SITE.DS.'libraries');
define('PAYPLANS_PATH_HELPER',		PAYPLANS_PATH_COMPONENT_SITE.DS.'helpers');
define('PAYPLANS_PATH_MEDIA',		PAYPLANS_PATH_COMPONENT_SITE.DS.'media');
define('PAYPLANS_PATH_ELEMENTS',	PAYPLANS_PATH_COMPONENT_SITE.DS.'elements');
define('PAYPLANS_PATH_INTERFACE',	PAYPLANS_PATH_LIBRARY.DS.'iface');
define('PAYPLANS_PATH_APPS',		PAYPLANS_PATH_LIBRARY.DS.'app');
define('PAYPLANS_PATH_EVENT',		PAYPLANS_PATH_LIBRARY.DS.'event');
define('PAYPLANS_PATH_SETUP',		PAYPLANS_PATH_LIBRARY.DS.'setup');
define('PAYPLANS_PATH_XML',			PAYPLANS_PATH_LIBRARY.DS.'model'.DS.'xml');
define('PAYPLANS_PATH_FORMATTER',	PAYPLANS_PATH_LIBRARY.DS.'formatter');
define('PAYPLANS_PATH_THEMES',		PAYPLANS_PATH_MEDIA.DS.'themes');

//names which will not vary
define('PAYPLANS_COMPONENT_NAME','com_payplans');

// URL def's
define('PAYPLANS_URL_MEDIA',	"components/com_payplans/media");
define('PAYPLANS_URL_TEMPLATE',	"components/com_payplans/templates");

//
define('XI_FORM_VARIABLE_PREFIX','xi_');

define('PAYPLANS_CONST_NONE', 0);
define('PAYPLANS_CONST_ALL', -1);

// Configuration Keys
define('PAYPLANS_CONFIG_BASIC', 	1);
define('PAYPLANS_CONFIG_ADVANCE', 	2);

define('PAYPLANS_INSTANCE_REQUIRE', true);
define('PAYPLANS_AJAX_REQUEST', JRequest::getBool('isAjax',	false));
