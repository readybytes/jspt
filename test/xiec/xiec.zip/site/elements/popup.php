<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		team@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementPopup extends XiElement
{
	/**
	 * Popup
	 *
	 * @access	protected
	 * @var		string
	 */
	var	$_name = 'Popup';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$options = array();
		$params = array();
		
		$url = $node->attributes('url');
		foreach ($node->children() as $request)
		{
			$name 		= $request->attributes('name');
			$defaultVal = $request->attributes('default');
			
			$url .= "&".$name."=".JRequest::getVar($name, $defaultVal);
		}
		
		return '<a href="" onclick="xi.url.openInModal(\''.XiRoute::_($url).'\');return false;" >'.XiText::_('COM_PAYPLANS_ELEMENT_POPUP_CLICK_HERE').'</a>';
		
	}
}

class JFormFieldPopup extends XiField
{
	public $type = 'popup'; 
}
