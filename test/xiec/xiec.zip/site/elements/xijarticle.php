<?php
/**
 * @version		$Id: article.php 21097 2011-04-07 15:38:03Z dextercowley $
 * @package		Joomla.Administrator
 * @copyright	Copyright (C) 2005 - 2011 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

/**
 * Renders an article element
 *
 * @package		Joomla.Administrator
 * @subpackage	com_content
 * @deprecated	JParameter is deprecated and will be removed in a future version. Use JForm instead.
 * @since		1.5
 */
class JElementXijarticle extends JElement
{
	/**
	 * Element name
	 *
	 * @var		string
	 */
	var	$_name = 'Xi Joomla Article';

	function fetchElement($name, $value, &$node, $control_name)
	{
		return XiHelperJoomla::getArticleElementHtml($control_name, $name, $value);
	}
}
	
class JFormFieldXiprofiletype extends XiField
{
	public $type = 'Xijarticle'; 
}
