<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementXigroup extends XiElement
{
	var	$_name = 'Xigroup';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$reqNone = self::hasAttrib($node, 'addnone');

		$attr = array();
		$attr    = array('none'	=>	'COM_PAYPLANS_NONE');

		return XiHtml::_('elements.groups', $control_name.'['.$name.']', $value, $attr);
	}
}

class JFormFieldXigroup extends XiField
{
	public $type = 'Xigroup'; 
}