<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementXicountry extends XiElement
{
	var	$_name = 'Xicountry';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$reqNone = self::hasAttrib($node, 'addnone');
		$attr = self::getAttributes($node);
		return XiHtml::_('elements.xicountry', $control_name.'['.$name.']', $value, $attr);
	}
}

class JFormFieldXicountry extends XiField
{
	public $type = 'Xicountry'; 
}