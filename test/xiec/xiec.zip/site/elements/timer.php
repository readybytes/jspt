<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementTimer extends XiElement
{
	var	$_name = 'Timer';

	function fetchElement($name, $value, &$node, $control_name)
	{
		return $this->getCurrencyHtml($name, $value, $control_name);
	}

	function getCurrencyHtml($name, $value, $control_name)
	{
		$class = trim(preg_replace('#\[[^\]]+\]#', '_', $control_name.$name));
		
		$yearHtml  = '<label>'.XiText::_('COM_PAYPLANS_TIMER_YEARS').'</label>'
					 .' <select '
					 .'class="'.$class.'" '
					 .'name="'.$class.'_years" '
					 .'id="'.$class.'_years" '
					 .'>';

		$monthHtml  = '<label>'.XiText::_('COM_PAYPLANS_TIMER_MONTHS').'</label>'
					 .' <select '
					 .'class="'.$class.'" '
					 .'name="'.$class.'_months" '
					 .'id="'.$class.'_months" '
					 .'>';

		$dayHtml  = '<label>'.XiText::_('COM_PAYPLANS_TIMER_DAYS').'</label>'
					 .' <select '
					 .'class="'.$class.'" '
					 .'name="'.$class.'_days" '
					 .'id="'.$class.'_days" '
					 .'>';

		$hourHtml  = '<label>'.XiText::_('COM_PAYPLANS_TIMER_HOURS').'</label>'
					 .'<select '
					 .'class="'.$class.'" '
					 .'name="'.$class.'_hours" '
					 .'id="'.$class.'_hours" '
					 .'>';

		$minHtml  = //XiText::_('COM_PAYPLANS_TIMER_MINUTES')
					 '<select '
					 .'style="display:none;" '
					 .'class="'.$class.'" '
					 .'name="'.$class.'_minutes" '
					 .'id="'.$class.'_minutes" '
					 .'>';

		$secHtml  = //XiText::_('COM_PAYPLANS_TIMER_SECONDS')
					 '<select '
					 .'style="display:none;" '
					 .'class="'.$class.'" '
					 .'name="'.$class.'_seconds" '
					 .'id="'.$class.'_seconds" '
					 .'>';

		for($count=0 ; $count<=60 ; $count++){
			$yearHtml  .= ($count<=10) ? '<option value="'.$count.'">'.$count.'</option>' : '';
			$monthHtml .= ($count<=11) ? '<option value="'.$count.'">'.$count.'</option>' : '';
			$dayHtml   .= ($count<=30) ? '<option value="'.$count.'">'.$count.'</option>' : '';
			$hourHtml  .= ($count<=23) ? '<option value="'.$count.'">'.$count.'</option>' : '';
			$minHtml   .= ($count<=59) ? '<option value="'.$count.'">'.$count.'</option>' : '';
			$secHtml   .= ($count<=59) ? '<option value="'.$count.'">'.$count.'</option>' : '';
		}

		$yearHtml  .= '</select> ';
		$monthHtml .= '</select> ';
		$dayHtml   .= '</select> ';
		$hourHtml  .= '</select> ';
		$minHtml   .= '</select> ';
		$secHtml   .= '</select> ';

		$hidden = '<input type="hidden" id="'.$class.'" name="'.$control_name.'['.$name.']" value="'.$value.'" />';

		$content = $this->_getTimerScript($name, $value, $control_name);
		XiFactory::getDocument()->addScriptDeclaration($content);

		return $yearHtml.$monthHtml.$dayHtml.$hourHtml.$minHtml.$secHtml.$hidden;
	}

	function _getTimerScript($name, $value, $control_name)
	{
		$class = trim(preg_replace('#\[[^\]]+\]#', '_', $control_name.$name));
		// XITODO : Javascript clean up
		ob_start();
		?>
		<?php // this script is to convert Year month Day into Seconds?>

		jQuery.noConflict();
		jQuery(document).ready(function($){
			// on page load set the values in respective select box

			var value 		 = "<?php echo $value;?>";
        	var prefix	= "<?php echo $class.'_';?>";
        	var payplansTimerEle = Array('years', 'months', 'days', 'hours', 'minutes', 'seconds');
        	var count 		 = payplansTimerEle.length;

 			for(var i =0; i < count; i++){
 				var element  = $("#" + prefix + payplansTimerEle[i]);
 				element.val(parseInt(value.substr(i * 2, 2), 10));
 			}


    		$("select.<?php echo $class;?>").change(function(){
        		var ele 	= Array('years', 'months', 'days', 'hours', 'minutes', 'seconds');
        		var count 	= ele.length;
        		var prefix	= "<?php echo $class.'_';?>";
        		var timer 	= '';

 				for(var i =0; i < count; i++){
 					var element = $("#" + prefix + ele[i]);
 					var value= element.val();
 					if(10 > value)
						value = '0' + value;

					timer += value;
				}

				var tim = "<?php echo $class;?>";
				//document.getElementById(tim).value = timer;
				$("#" + tim).attr('value', timer);
	   		});
		});

		<?php
		$content = ob_get_contents();
		ob_end_clean();
		return $content;
	}
}

class JFormFieldTimer extends XiField
{
	public $type = 'Timer'; 
}