<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementTimer extends XiElement
{
	var	$_name = 'Timer';

	function fetchElement($name, $value, &$node, $control_name)
	{
		return XiHtml::_('elements.xitimer', $control_name.'['.$name.']', $value, $control_name.$name);
	}
}

class JFormFieldTimer extends XiField
{
	public $type = 'Timer'; 
}