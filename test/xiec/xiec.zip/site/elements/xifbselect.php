<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementXifbselect extends XiElement
{
	var	$_name = 'Xifbselect';

	/*
	 * IMP : value must be json_encoded
	 */
	function fetchElement($name, $value, &$node, $control_name)
	{		
		$class = ( $node->attributes('class') ? 'class="'.$node->attributes('class').'"' : 'class="inputbox"' );
		$size = ( $node->attributes('size') ? 'size="'.$node->attributes('size').'"' : 'size="5"' );

		$options = array ();
		foreach ($node->children() as $option)
		{
			$val	= $option->attributes('value');
			$text	= $option->data();
			$options[$val] = JHTML::_('select.option', $val, JText::_($text));
		}

		return XiHtml::_('elements.xifbselect',  $options, ''.$control_name.'['.$name.']', null, 'value', 'text', $value);
	}
}

class JFormFieldXifbselect extends XiField
{
	public $type = 'Xifbselect'; 
}