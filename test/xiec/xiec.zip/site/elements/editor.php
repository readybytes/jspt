<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementEditor extends XiElement
{
	var	$_name = 'Editor';

	/**
	 * Important : This box need base64_encoded text to display it.
	 * While collecting we need to convert again to base64
	 * @param $name
	 * @param $value
	 * @param $node
	 * @param $control_name
	 */
	function fetchElement($name, $value, &$node, $control_name)
	{
		$editor = XiFactory::getEditor();
		$value = base64_decode($value);

		$width	= $node->attributes('width');
		$height	= $node->attributes('height');
		$col	= $node->attributes('col');
		$row	= $node->attributes('row');

		//	($name, $html, $width, $height, $col, $row, $buttons = true, $params = array())
		return $editor->display($control_name.'['.$name.']',
								htmlspecialchars($value, ENT_QUOTES),
								$width, $height, $col, $row,
								array('pagebreak', 'readmore') ) ;
	}
}

class JFormFieldEditor extends XiField
{
	public $type = 'editor'; 
}