<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
// no direct access
if(!defined('_JEXEC')) die('Restricted access');
class JElementUploadfile extends XiElement
{
   public $_name = 'Upload';
   public function fetchElement($name, $value, &$node, $control_name)
   {
      $value = htmlspecialchars(html_entity_decode($value, ENT_QUOTES), ENT_QUOTES);
      return '<input type="file" name="'.$control_name.'['.$name.']" id="'.$control_name.$name.'" value="'.$value.'" />';
   }

}
class JFormFieldUploadfile extends XiField
{
	public $type = 'Upload'; 
}
?>