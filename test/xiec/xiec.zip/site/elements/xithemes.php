<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

//xitodo : rename all elements to use payplans prefix e.g. JElementPayplansstatus
class JElementXithemes extends XiElement
{
	var	$_name = 'Xithemes';

	function fetchElement($name, $value, &$node, $control_name)
	{
		class_exists('XiHelperTheme', true);
		$themes = XiHelperTheme::getThemes();

		$options = array();
		foreach($themes  as $theme => $path ){
    		$options[] = JHTML::_('select.option', $theme, $theme);
		}

    	$style = (isset($attr['style'])) ? $attr['style'] : '';
    	return JHTML::_('select.genericlist', $options, $control_name.'['.$name.']', $style, 'value', 'text', $value);
	}
}

class JFormFieldXithemes extends XiField
{
	public $type = 'Xithemes'; 
}



