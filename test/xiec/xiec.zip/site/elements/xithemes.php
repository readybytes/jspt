<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

//xitodo : rename all elements to use payplans prefix e.g. JElementPayplansstatus
class JElementXithemes extends XiElement
{
	var	$_name = 'Xithemes';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$themes = XiHelperTheme::getThemes();
		$themeXml =  XiHelperTheme::getXml();

		$options = array();
		foreach($themes  as $theme => $path ){
    		$options[] = JHTML::_('select.option', $theme, $themeXml[$theme]['title']);
		}

    	$style = (isset($attr['style'])) ? $attr['style'] : '';
    	$style .= ' onChange="jsThemePreviewUpdate(this)" ';
    	$result = JHTML::_('select.genericlist', $options, $control_name.'['.$name.']', $style, 'value', 'text', $value);
    	
    	// add image preview in tool tip
    	ob_start();
    	?>
    	<script type="text/javascript">
    	var jsThemeArray = <?php echo json_encode($themeXml); ?> ;
    	var jsThemeSelected = "<?php echo $value ?>" ;
    	
    	function jsThemePreviewUpdate(elem) {
    		jsThemeSelected = elem.value;
    	}

    	function jsThemeGetPreviewHtml(){
        	var html = '<img src="'+ jsThemeArray[jsThemeSelected]['urlpath'] + '/'+jsThemeArray[jsThemeSelected]['thumbnail'] +'" />';
        	xi.jQuery('#xiWindowContent').html(html);
        }
    	
    	function jsThemeLaunchPreview() {
    		xiWindowShow(jsThemeGetPreviewHtml, jsThemeArray[jsThemeSelected]['title'] + ' : by ' + jsThemeArray[jsThemeSelected]['author'], 780, 440);
    		return false;
    	}
		</script>
    	<?php 
    	$script = ob_get_contents();
    	ob_end_clean();
    	$result = $script.$result. ' <span style="padding-left:5px;" left" class="theme-preview-link"><a onClick="jsThemeLaunchPreview();"> '.XiText::_('COM_PAYPLANS_CONFIG_CUSTOMIZE_THEME_PREVIEW').' </a></span>';
    	return $result;
	}
}

class JFormFieldXithemes extends XiField
{
	public $type = 'Xithemes'; 
}
