<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementJusertype extends XiElement
{
	var	$_name = 'Jusertype';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$group 	= XiHelperJoomla::getJoomlaGroups();
		
		$textField = 'value';
		$valueField = 'name';

		if(PAYPLANS_JVERSION_FAMILY == 16){
	       		return XiHTML::_('elements.xifbselect', $group, $control_name.'['.$name.']', array('multiple'=>true), $textField, $valueField, $value);
		}
		
		return XiHTML::_('elements.xifbselect', $group, $control_name.'['.$name.']', null, $textField, $valueField, $value);
	}
}



class JFormFieldJusertype extends XiField
{
	public $type = 'Jusertype'; 
}