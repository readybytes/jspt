<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementParammanipulator extends XiElement
{
	/**
	 * parammanipulator
	 *
	 * @access	protected
	 * @var		string
	 */
	var	$_name = 'Param Manipulator';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$class = ( $node->attributes('class') ? 'class="'.$node->attributes('class').'"' : 'class="inputbox"' );

		$options = array ();
		$params = array();
		foreach ($node->children() as $option)
		{
			$val	= $option->attributes('value');
			$text	= $option->data();
			$options[] = XiHTML::_('select.option', $val, XiText::_($text));
			
			// get attribute params from each option
			$paramsVal	= $option->attributes('params');
			$params[$val] = explode(',', $paramsVal);
		}

		$html  = $this->_getFilterScript($control_name, $name, $params, $value);
		$html .= JHTML::_('select.genericlist',  $options, ''.$control_name.'['.$name.']', $class, 'value', 'text', $value, $control_name.$name);
		return $html;
	}
	
	private function _getFilterScript($control_name, $name, $params, $value)
	{
		ob_start();
		?>
		<script type="text/javascript">
		xi.jQuery(document).ready(function(){
			var ppNamePrefix = "<?php echo $control_name.'-';?>";
			var ppOptionParams = <?php echo json_encode($params);?>;

			function ppParamManipulation(ppCurrentValue){
				for(var index in ppOptionParams){
					if(ppOptionParams.hasOwnProperty(index) == false){
						continue;
					}
					
					if(index == ppCurrentValue){
						continue;
					}
					
					for(var subIndex in ppOptionParams[index]){
						if(ppOptionParams[index].hasOwnProperty(subIndex) == false){
							continue;
						}
						
						xi.jQuery("." + (ppNamePrefix  + ppOptionParams[index][subIndex]).replace(/_/g, '-')).css('display', 'none');
					}
				}
	
				for(var subIndex in ppOptionParams[ppCurrentValue]){
					if(ppOptionParams[ppCurrentValue].hasOwnProperty(subIndex) == false){
						continue;
					}
					
					xi.jQuery("." + (ppNamePrefix + ppOptionParams[ppCurrentValue][subIndex]).replace(/_/g, '-')).fadeIn();
				}	
			}

			ppParamManipulation('<?php echo $value;?>');
			
			var ppElementId = '<?php  echo $control_name.$name;?>';
			xi.jQuery('#'+ ppElementId).change(
				function(){
					ppParamManipulation(this.value);
				}
			);
		});	
		</script>
		<?php 
		$contents = ob_get_contents();
		ob_end_clean();
		
		return $contents;
	} 
}

class JFormFieldParammanipulator extends XiField
{
	public $type = 'parammanipulator'; 
}
