<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementJsmultiprofile extends XiElement
{
	/**
	 * Element name
	 *
	 * @access	protected
	 * @var		string
	 */
	var	$_name = 'Jsmultiprofile';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$profiletype = $this->getJsprofiletype();

		return XiHTML::_('select.genericlist', $profiletype, $control_name.'['.$name.']', null, 'id', 'name', $value);
	}

	function getJsprofiletype()
	{
		$db= & JFactory::getDBO();
		$sql = ' SELECT * FROM '.$db->nameQuote('#__community_profiles');
		$db->setQuery($sql);
		return $db->loadObjectList();
	}
}



class JFormFieldJsmultiprofile extends XiField
{
	public $type = 'Jsmultiprofile'; 
}