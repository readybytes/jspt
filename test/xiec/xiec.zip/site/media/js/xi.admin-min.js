
function PayplansAdminJS()
{this.submit=function(view,action,validActions){funcName=view+'_'+action;if(this[funcName]instanceof Function){if(this[funcName].apply(this)==false)
return false;}
if(action){document.adminForm.task.value=action;}
validActions=eval(validActions);var isValidAction=false;for(var i=0;i<validActions.length;i++){if(validActions[i]==action){isValidAction=true;break;}}
result=true;if(document.adminForm.onsubmit instanceof Function){result=document.adminForm.onsubmit.apply(this,Array(isValidAction));}
if(result){document.adminForm.submit();}}
this.redirect=function(url){window.location.href=url;xiWindowHide();}
this.resetFilters=function(form){var str=new Array();for(i=0;i<form.elements.length;i++)
{var string=form.elements[i].name;if(string&&string.substring(0,6)=='filter'&&(string!='filter_reset'&&string!='filter_submit'))
{form.elements[i].value='';}}
this.submit(view,null,validActions);}
this.showAdvanceSettings=function(){xi.jQuery("div.payplans_advance").css("display","block");if(xi.jQuery("div.payplans_expert").css("display")=="block")
xi.jQuery("div.payplans_expert").css("display","none");}
this.showExpertSettings=function(){xi.jQuery("div.payplans_expert").css("display","block");if(xi.jQuery("div.payplans_advance").css("display")=="block")
xi.jQuery("div.payplans_advance").css("display","none");}}
var payplansAdmin=new PayplansAdminJS();