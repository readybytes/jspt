function xiWindowDraw()
{
	// Remove any existing #xiWindow.
	xi.jQuery('#xiWindow').remove();

	// xiWindow html structure.
	var html  = '';
	html += '<div id="xiWindow">';
	html += '	<!-- top section -->';
	html += '	<div id="xiwin_tl"></div>';
	html += '	<div id="xiwin_tm"></div>';
	html += '	<div id="xiwin_tr"></div>';
	html += '	<div style="clear: both;"></div>';
	html += '	<!-- middle section -->';
	html += '	<div id="xiwin_ml"></div>';
	html += '	<div id="xiWindowContentOuter">';
	html += '		<div id="xiWindowContentTop">';
	html += '			<a href="javascript:void(0);" onclick="xiWindowHide();" id="xiwin_close_btn">Close</a>';
	html += '			<div id="xiwin_logo"></div>';
	html += '           <div class="clr"></div>';
	html += '		</div>';			
	html += '		<div id="xiWindowContentWrap"><div id="xiWindowContent">';
	html += '		</div></div>';
	html += '	</div>';
	html += '	<div id="xiwin_mr"></div>';
	html += '	<div style="clear: both;"></div>';
	html += '	<!-- bottom section -->';
	html += '	<div id="xiwin_bl"></div>';
	html += '	<div id="xiwin_bm"></div>';
	html += '	<div id="xiwin_br"></div>';
	html += '	<div style="clear: both;"></div>';
	html += '</div>';

	var xiWindow = xi.jQuery(html).addClass('new').prependTo('body');
	
	return xiWindow;
}

function xiWindowShow(windowCall, winTitle, winContentWidth, winContentHeight, winType)
{
	// Get xiWindow
	var xiWindow = xi.jQuery('#xiWindow');
	if (xiWindow.length<1) xiWindow = xiWindowDraw();

	// Fix inconsistencies in arguments
	winType          = (winType=='' || winType==null) ? 'dialog' : winType;
	winContentWidth  = parseInt(winContentWidth);
	winContentHeight = parseInt(winContentHeight);	

	// Set up dimensions
	if (xiWindow.hasClass('new'))
	{
		var xiWindowSize = xiWindowGetSize(winContentWidth, winContentHeight);
		xiWindowResizeAddTask('#xiWindow', {'width'      : xiWindowSize.width(),
			                              'height'     : xiWindowSize.height(),
			                              'left'       : xiWindowSize.left(),
			                              'margin-top' : xiWindowSize.top(),
			                              'z-index'    : xiGetZIndexMax() + 1
			                  	         }, {'animate': false});
		xiWindowResizeAddTask('#xiWindowContentOuter, #xiwin_tm, #xiwin_bm', {'width' : xiWindowSize.contentOuterWidth() }, {'animate': false});
		xiWindowResizeAddTask('#xiWindowContentOuter, #xiwin_ml, #xiwin_mr', {'height': xiWindowSize.contentOuterHeight() }, {'animate': false});
		xiWindowResizeAddTask('#xiWindowContentWrap', {'height': xiWindowSize.contentWrapHeight() }, {'animate': false});

		xiWindowResizeExecuteTask(function()
		{
			xiWindow.removeClass('new');
		});
	}
	
	// Assign window type
	xi.jQuery('#xiWindow').attr('class', winType);
	
	// Set up content
	xi.jQuery('#xiwin_logo').html(winTitle);
	xi.jQuery('#xiWindowContent').empty();
	xi.jQuery('#xiWindowAction').remove();

	// Set up behaviour
	xiajax.loadingFunction     = function() {
		xi.jQuery('#xiWindowContentWrap').addClass('loading')
		                                  .css('overflow', 'hidden');
	};
	xiajax.doneLoadingFunction = function() {
		xi.jQuery('#xiWindowContentWrap').removeClass('loading')
		                                  .css('overflow', 'auto');
	};

	// IE6: Rebuild alpha transparent border
	if (xi.jQuery.browser.msie && xi.jQuery.browser.version.substr(0,1)<7 && typeof(jomsIE6)!="undefined" && jomsIE6==true)
	{
		xi.jQuery('#xiwin_tm, #xiwin_bm, #xiwin_ml, #xiwin_mr').each(function()
		{
			xi.jQuery(this)[0].filters(0).sizingMethod="crop";
		})
	}

	// Resize xiWindow
	xiWindowResize2(winContentWidth, winContentHeight, windowCall);
}

function xiWindowHide()
{
	//window.parent.location.href =  window.parent.location.href;
	xi.jQuery('#xiWindow').remove();
	if (xi.jQuery('#xiWindowAction').size()>0)
	{
		xi.jQuery('#xiWindowAction').animate({bottom: -30}, function()
		{
			xi.jQuery('#xiWindow').fadeOut('fast', function(){
				xi.jQuery('#xiWindowAction').remove();
				xi.jQuery(this).addClass('new');
			});
		});
	} else {
		xi.jQuery('#xiWindow').fadeOut('fast', function(){
			xi.jQuery(this).addClass('new');
		});
	}
}

function xiWindowGetSize(winContentWidth, winContentHeight)
{
	var xiWindowSize = {contentWrapHeight   : function() { return winContentHeight },
		               contentOuterWidth   : function() { return winContentWidth },
	                   contentOuterHeight  : function() { return winContentHeight + 30 },
	                   width               : function() { return this.contentOuterWidth() + 40 },
	                   height              : function() { return this.contentOuterHeight() + 40 },
	                   left                : function() { return (xi.jQuery(window).width() - this.width()) / 2 },
	                   top                 : function() { return xi.jQuery(document).scrollTop() + (document.documentElement["clientHeight"] - this.height()) / 2 }
	                  };
	return xiWindowSize;
}

// Legacy code. Forwards to xiWindowResize2().
function xiWindowResize(newHeight, callback, action)
{
	newHeight = parseInt(newHeight);
	xiWindowResize2(xi.jQuery('#xiWindowContentOuter').width(), newHeight, callback);
	if (action!=undefined) xiWindowActions(action);
}

function xiWindowResize2(winContentWidth, winContentHeight, callback)
{
	var xiWindowSize = xiWindowGetSize(winContentWidth, winContentHeight);

	// Legacy code. If there's a difference in width, do not resize (pre-1.5 behaviour).
	var options = {'animate': (xi.jQuery('#xiWindow').width()==xiWindowSize.width())};

	xi.jQuery('#xiWindowContent').addClass('resizing');

	xiWindowResizeAddTask('#xiWindow', {'width'     : xiWindowSize.width(),
		                              'height'    : xiWindowSize.height(),
		                              'left'      : xiWindowSize.left(),
		                              'marginTop' : xiWindowSize.top()
		                  	         }, options);
	xiWindowResizeAddTask('#xiWindowContentOuter, #xiwin_tm, #xiwin_bm', {'width' : xiWindowSize.contentOuterWidth() }, options);
	xiWindowResizeAddTask('#xiWindowContentOuter, #xiwin_ml, #xiwin_mr', {'height': xiWindowSize.contentOuterHeight() }, options);
	xiWindowResizeAddTask('#xiWindowContentWrap', {'height': xiWindowSize.contentWrapHeight()}, options);

	// Reverse task if xiWindow is shrinking
	if (xi.jQuery('#xiWindow').width() > xiWindowSize.width() || xi.jQuery('#xiWindow').height() > xiWindowSize.height())
		xiWindowResizeTask.reverse();

	xiWindowResizeExecuteTask(callback);
}

var xiWindowResizeTask = new Array();
function xiWindowResizeAddTask(target, props, options)
{
	// Set up animation properties
	var defaultProps = {};
	xi.jQuery.extend(defaultProps, props);
	
	// Set up animation options
	var defaultOptions = {'animate' : true,
		                  'queue'   : false,
	                      'duration': 400,
	                      'easing'  : 'swing',
	                      'complete': function(){
	                      	    clearTimeout(window.xiWindowResizeComplete);
	                      		window.xiWindowResizeComplete = setTimeout(function()
	                      		{
	                      			xi.jQuery('#xiWindowContent').removeClass('resizing');
	                      		}, 400);
	                      		xi.jQuery(this).removeClass('resizing');
						   }
	                     };
	xi.jQuery.extend(defaultOptions, options);
	
	if (defaultOptions.animate)
	{
		xiWindowResizeTask.push(function(){ xi.jQuery(target).addClass('resizing').animate(defaultProps, defaultOptions); });
	} else {
		xiWindowResizeTask.push(function(){ xi.jQuery(target).css(defaultProps); });
	}
}

function xiWindowResizeExecuteTask(callback)
{
	do
	{
		xiWindowResizeTask[0]();
		xiWindowResizeTask.splice(0,1);
	}
	while(xiWindowResizeTask.length>0);

	if (callback!=undefined && typeof(callback)=="string") eval(callback);
	if (typeof(callback)=="function") callback();
}

var xiWindowActionsPoll;
function xiWindowActions(action)
{
	// Remove any existing xiWindowActionsPoll
	// Reason why is removed multiple times because xiWindowActions
	// could be called at any point of entry!
	clearInterval(xiWindowActionsPoll);

	setTimeout(function(){
		// Remove any existing xiWindowActionsPoll
		clearInterval(xiWindowActionsPoll);
		
		// Create new xiWindowActionsPoll
		xiWindowActionsPoll = setInterval(function()
							 {
							 	var n = xi.jQuery('.resizing').length;
							 	if (n < 1)
							 	{
									_xiWindowActions(action);
									clearInterval(xiWindowActionsPoll);
								}
							 }, 300);
	}, 300);
}

function _xiWindowActions(action)
{
	// Remove any existing xiWindowAction	
	xi.jQuery('#xiWindowAction').remove();
	
	// Create new xiWindowAction
	xiWindowAction = xi.jQuery('<div>').attr('id', 'xiWindowAction')
	                               .html(action)
	                               .css('bottom', '-30px')
	                               .appendTo('#xiWindowContentOuter');

	// Resize xiWindow
	xiWindowResizeAddTask('#xiWindow', {height: '+=30px'}, {'duration': 200});
	xiWindowResizeAddTask('#xiWindow', {marginTop: '-=15px'}, {'duration': 200});
	
	xiWindowResizeAddTask('#xiWindowContentOuter, #xiwin_mr, #xiwin_ml', {height: '+=30px'}, {'duration': 200});
	xiWindowResizeExecuteTask();
	
	setTimeout(function(){xi.jQuery("#xiWindowAction").animate({bottom: '0px'})}, 200);

	// Set up behavior when actions are invoked
	xiajax.loadingFunction = function() {
		xi.jQuery('#xiWindowAction').addClass('loading');
		xi.jQuery('#xiWindowContent').find('input, textarea, button')
		                         .attr('disabled', true);
	}
	xiajax.doneLoadingFunction = function() {
		xi.jQuery('#xiWindowAction').removeClass('loading');
		xi.jQuery('#xiWindowContent').find('input, textarea, button')
		                         .attr('disabled', false);
	};
}

function xiGetZIndexMax()
{
	var allElems = document.getElementsByTagName?
	document.getElementsByTagName("*"):
	document.all; // or test for that too
	var maxZIndex = 0;

	for(var i=0;i<allElems.length;i++) {
		var elem = allElems[i];
		var cStyle = null;
		if (elem.currentStyle) {cStyle = elem.currentStyle;}
		else if (document.defaultView && document.defaultView.getComputedStyle) {
			cStyle = document.defaultView.getComputedStyle(elem,"");
		}

		var sNum;
		if (cStyle) {
			sNum = Number(cStyle.zIndex);
		} else {
			sNum = Number(elem.style.zIndex);
		}
		if (!isNaN(sNum)) {
			maxZIndex = Math.max(maxZIndex,sNum);
		}
	}	
	return maxZIndex;
}