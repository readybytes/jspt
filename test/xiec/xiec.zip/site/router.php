<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

function _getPayplansMenus()
{
	static $menus = null;

	if($menus ===null){
		if(PAYPLANS_JVERSION_15){
			$menus 	= JSite::getMenu()->getItems('componentid',JComponentHelper::getComponent('com_payplans')->id);
		}else {
			$menus 	= JSite::getMenu()->getItems('component_id',JComponentHelper::getComponent('com_payplans')->id);
		}
	}

	return $menus;
}

function _getPayplansUrlVars()
{
	return array('view', 'task', 'plan_id', 'order_id', 'payment_id', 'app_id', 'subscription_id', 'user_id');
}

function _findPayplansMatchCount($menu, $query)
{
	$vars = _getPayplansUrlVars();
	$count = 0;
	foreach($vars as $var)
	{
		//variable not requested
		if(!isset($query[$var]))
			continue;

		//variable not exist in menu
		if(!isset($menu[$var]))
			continue;

		//exist but do not match
		if($menu[$var] !== $query[$var]){
			/* 
			 * return 0, because if some variables are in conflict
			 * then variable appended in query will be desolved during parsing 
			 * e.g.
			 * 
			 * index.php?option=com_payplans&view=plan
			 * index.php/subscribe
			 * 
 			 * index.php?option=com_payplans&view=plan&task=subscribe&plan_id=1
			 * index.php/subscribe1
			 * 
			 * index.php?option=com_payplans&view=plan&task=subscribe&plan_id=2
			 * index.php/subscribe1?plan_id=2   <== *** WRONG ***
			 * index.php/subscribe?task=subscribe&plan_id=2   <== *** RIGHT ***
			 */ 
			return 0;
		}

		$count++;
	}
	return $count;
}

function PayplansBuildRoute( &$query )
{
	$segments = array();
	$menus = _getPayplansMenus();

	//If item id is not set then we need to extract those
	$selMenu = null;
	if (!isset($query['Itemid']) && $menus)
	{
		$count 		= 0;
		$selMenu 	= $menus[0];

		foreach($menus as $menu){
			//count matching
			$matching = _findPayplansMatchCount($menu->query,$query);

			if($count >= $matching)
				continue;

			//current menu matches more
			$count		= $matching;
			$selMenu 	= $menu;
		}

		//assig ItemID of selected menu
		$query['Itemid'] = $selMenu->id;
	}

	//thhere is no menu item for payplans
	if (!isset($query['Itemid']))
		return $segments;
	
	//finally selected menu is
	$selMenu = JSite::getMenu()->getItem($query['Itemid']);

	//remove not-required variables, which can be calculated from URL itself
	$vars = _getPayplansUrlVars();
	foreach($vars as $var)
	{
		//variable not requested
		if(!isset($query[$var]))
			continue;

		//variable not exist in menu
		if(!isset($selMenu->query[$var]))
			continue;

		//exist but do not match
		if($selMenu->query[$var] === $query[$var])
			unset($query[$var]);
	}

	return $segments;
}

/**
 * @param	array	A named array
 * @param	array
 *
 * Formats:
 */
function PayplansParseRoute( $segments )
{
	$myVars = _getPayplansUrlVars();
	$vars = array();

	foreach($myVars as $v)
	{
		$reqVar = JRequest::getVar($v, null);
		if($reqVar===null)
			continue;

		$vars[$v] = $reqVar;
	}

	return $vars;
}