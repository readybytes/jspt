<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage	Discount
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansAppContentacl extends PayplansApp
{
	protected $_location	= __FILE__;
	
	public function isApplicable($refObject = null, $eventName='')
	{
		$option =JRequest::getVar('option');
		if($eventName === 'onPrepareContent' && $option == 'com_content'){
			return true;
		}
		return parent::isApplicable($refObject, $eventName);
	}

	function onPrepareContent($item, $params, $limitstart)
	{
		if(! $item instanceof stdClass){
			return true;
		}
		
		$categoryId = (isset($item->category) && is_object($item->category)) ? $item->category->id : $item->catid;
		$sectionId = (isset($item->section) && is_object($item->section)) ? $item->section->id : $item->sectionid;
		$articleId = (isset($item->id)) ? $item->id : null;
		
		$block = $this->getAppParam('blockselection', 'none');
		$url = XiRoute::_('index.php?option=com_payplans&view=plan');

		if($block == 'joomla_category' || $block == 'joomla_section' || $block == 'joomla_article'){
			if($this->_isUserAllowed() === true){
				return true;
			}

			if($block == 'joomla_category'){
				if($categoryId != $this->getAppParam('joomla_category', 0)){
					return true;
				}
				$item->text = '<a href="'.$url.'">'.XiText::_('COM_PAYPLANS_CONTENTACL_SUBSCRIBE_PLAN').'</a>';

			}

			if($block == 'joomla_section'){
				if($sectionId != $this->getAppParam('joomla_section', 0)){
					return true;
				}
				$item->text = '<a href="'.$url.'">'.XiText::_('COM_PAYPLANS_CONTENTACL_SUBSCRIBE_PLAN').'</a>';
	
			}
	
			if($block == 'joomla_article'){
				if($articleId != $this->getAppParam('joomla_article', 0)){
					return true;
				}
				$item->text = $item->introtext.'<a href="'.$url.'">'.XiText::_('COM_PAYPLANS_CONTENTACL_SUBSCRIBE_PLAN').'</a>';
			}
				$item->readmore = 0;
				$item->introtext = '';
				$item->fulltext = '';
				$item->link = $url;
		}

		return true;	
	}
	
	function _isUserAllowed()
	{
		$userid 	 = XiFactory::getUser()->id;
		if(!$userid){
			return false;
		}
		
		$user = PayplansUser::getInstance($userid);
		
		$userSubs  = $user->getPlans();
		$plans 	   = $this->getPlans();
		
		// return false when user is non-subscriber
		if(empty($userSubs)){
			return false;
		}
		
		// return true when app is core app,
		// no need to check whether plan is attached with this app or not
		if($this->getParam('applyAll',false) != false){
			return true;
		}

		// if user have an active subscription of the plan attached with the app then return true
		foreach($userSubs as $sub){
			if(in_array($sub, $plans)){
				return true;
			}
		}

		return false;
	}
}