<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * Renders an section element
 *
 * @package		Joomla.Administrator
 * @subpackage	com_content
 * @deprecated	JParameter is deprecated and will be removed in a future version. Use JForm instead.
 * @since		1.5
 */
class JElementXijsection extends XiElement
{
	/**
	 * Element name
	 *
	 * @var		string
	 */
	var	$_name = 'Xijsection';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$sections = array();
	
		if(PAYPLANS_JVERSION_15){
			$sections = $this->getJoomlaSections();
		
			$none = new stdClass();
			$none->section_id = 0;
			$none->title = XiText::_('NONE');
		}

		if(empty($sections)){
			return XiText::_('COM_PAYPLANS_CONTENTACL_NO_SECTION_AVAILABLE');	
		}
		array_unshift($sections, $none);
		
		return XiHTML::_('select.genericlist', $sections, $control_name.'['.$name.']', null, 'section_id', 'title', $value);
	}

	function getJoomlaSections()
	{
		$db 	= JFactory::getDBO();
		
		$query = 'SELECT  `id`  as section_id, title'
			 	. ' FROM #__sections'
			 	;
	 	$db->setQuery( $query );
	 	return $db->loadObjectList();
	}
}
class JFormFieldXijsection extends XiField
{
	public $type = 'Xijsection';
}