<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class JElementXijcategory extends XiElement
{
	/**
	 * Element name
	 *
	 * @var		string
	 */
	var	$_name = 'Xijcategory';

	function fetchElement($name, $value, &$node, $control_name)
	{			
		$categories = $this->getJoomlaCategories();
		
		$none = new stdClass();
		$none->category_id = 0;
		$none->title = XiText::_('NONE');

		if(empty($categories)){
			return XiText::_('COM_PAYPLANS_CONTENTACL_NO_CATEGORY_AVAILABLE');	
		}
		
		array_unshift($categories, $none);

		return XiHTML::_('select.genericlist', $categories, $control_name.'['.$name.']', null, 'category_id', 'title', $value);
	}

	function getJoomlaCategories()
	{
		$db 	= JFactory::getDBO();
		
		$query = 'SELECT  `id`  as category_id, title'
			 	. ' FROM #__categories'
			 	;
	 	$db->setQuery( $query );
	 	return $db->loadObjectList();
	}
}

class JFormFieldXijcategory extends XiField
{
	public $type = 'Xijcategory'; 
}