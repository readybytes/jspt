<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansAppGooglecheckout extends PayplansAppPayment
{
	//inherited properties
	protected $_location	= __FILE__;
	

	/**
	 * @var boolean
	 * @access protected
	 */
	protected $_isLog = false;

	/**
	 * @var object
	 * @access protected
	 */
	protected $_logObj;
	

	public function getAppParam($key, $default=null)
	{
		static $isSandBox = null;

		// initialize sandbox testing variable
		if($isSandBox === null){
			$isSandBox = parent::getAppParam('sandbox',false);
		}

		//check if such a variable exist, then return it
		if($isSandBox){
			$return = parent::getAppParam('sandbox_'.$key,null);
			if($return !== null)
				return $return;
		}

		// else send the normal variable
		return parent::getAppParam($key,$default);
	}

    /**
     * All events need to be implemented
     */
	public function onPayplansPaymentBefore()
	{
		return true;
	}

	/**
	 * Prepares the payment form
	 * and returns HTML Form to be displayed to the user
	 * generally will have a message saying, 'confirm entries, then click complete order'
	 *
	 * Submit button target for onsite payments & return URL for offsite payments should be:
	 * index.php?option=com_tienda&view=checkout&task=confirmPayment&orderpayment_type=xxxxxx
	 * where xxxxxxx = $_element = the plugin's filename
	 *
	 * @param $data     array       form post data
	 * @return string   HTML to display
	 */
	public function onPayplansPaymentForm(PayplansPayment $payment, $data = null)
	{	
		return ;
		if(is_object($data)){
			$data = (array)$data;
		}

		/*
		 * get all necessary data and prepare vars for assigning to the template
		 */

		$order = PayplansOrder::getInstance( $payment->getOrder());
		
		$this->assign('orderpayment_id', $payment->getKey());
		$this->assign('orderpayment_amount', $payment->getAmount());
		$this->assign('orderpayment_type', $this->_element);
	
		$this->assign('merchant_id', $this->getAppParam('merchant_id'));
		$this->assign('type_id', JRequest::getInt('id'));

		//$this->assign('post_url', JRoute::_("index.php?option=com_tienda&controller=payment&task=process&ptype={$this->_element}&paction=proceed&tmpl=component"));

		$this->assign('button_url', $this->_getPostUrl(false));
		$this->assign('note', XiText::_( 'GoogleCheckout Note Default' ));

		$uri = XiFactory::getURI();
		$url = $uri->toString(array('path', 'query', 'fragment'));
		$this->assign('r', base64_encode($url));

		// Include all the required files
		require_once dirname($this->_location).DS.'library'.DS.'googlecart.php';
		require_once dirname($this->_location).DS.'library'.DS.'googleitem.php';
		require_once dirname($this->_location).DS.'library'.DS.'googleshipping.php';
		require_once dirname($this->_location).DS.'library'.DS.'googletax.php';
			
		// IMP: getting currency from 
		$cart = new GoogleCart($this->getAppParam('merchant_id'), $this->getAppParam('merchant_key'), $this->_getServerType(), $this->getAppParam('currency', 'USD'));
		
		
		// IMP: one item for one payment
		$quantity = 1;
		$item_temp = new GoogleItem($order->getKey(), $order->getId(), $quantity, $order->getTotal());
		// in argument of GoogleItem first itemname , itemDescription,quantity, unti price
		$cart->AddItem($item_temp);		
		
		
		if (!empty($data['shipping_terms']))
		{
	 	// Add shipping
			$shipTemp = new GooglePickup($data['shipping_name'], $data['shipping_price']); // shipping name and Price as an argument
			$cart->AddShipping($shipTemp);
		}
		$checkout_return_url = JURI::root() ."index.php?option=com_payplans&view=payment&task=complete&action=success&payment_key=".$payment->getKey()."&paction=process";
		$cart->SetContinueShoppingUrl($checkout_return_url);
		$cart->SetMerchantCalculations($checkout_return_url);
		
		// set oredr id and the Data
		$mcprivatedata= new MerchantPrivateData();
		$mcprivatedata->data= array("orderPaymentId"=>$payment->getKey());
		$cart->SetMerchantPrivateData($mcprivatedata);
		$this->assign('cart', $cart);
		$html = $this->_render('form_subscription');
		return $html;
	}
	
	/**
	 * Gets the Paypal gateway URL
	 *
	 * @param boolean $full
	 * @return string
	 * @access protected
	 */
	protected function _getPostUrl($full = true)
	{
		if ($full) {
			$url  = $this->getAppParam('sandbox', false) ? 'https://sandbox.google.com/checkout/api/checkout/v2/checkoutForm/Merchant/' : 'https://checkout.google.com/api/checkout/v2/checkoutForm/Merchant/';
			$url .= $this->getAppParam('merchant_id', '');
		}
		else {
			$url = $this->getAppParam('sandbox', false) ? 'https://checkout.google.com' : 'https://sandbox.google.com/checkout';
		}

		return $url;
	}
	
	/**
	 * Returns the Google Checkout server type
	 *
	 * @return string
	 * @access protected
	 */
	protected function _getServerType()
	{
		return $this->getAppParam('sandbox') ? 'sandbox' : 'production';
	}
	
	public function onPayplansPaymentAfter(PayplansPayment $payment, $action, $data)
	{
		//XITODO : please make status none for cancel task
		if($action=='success'){
			$payment->set('status', XiStatus::PAYMENT_INITIATED)
					->save();
		}
		// Process the payment
		$paction = JRequest::getVar('paction');
		$vars = new JObject();
		$html="";
		switch ($paction)
		{
			case "display_message":
				$html .= $this->_renderHtml( JText::_('GOOGLECHECKOUT MESSAGE PAYMENT ACCEPTED FOR VALIDATION') );
				$html .= $this->_displayArticle();
				break;
			case "process":
				$vars->message = $this->_process();
				$html = $this->_getLayout('message', $vars);
				echo $html; // TODO Remove this
				$app =& JFactory::getApplication();
				$app->close();
				break;
			case "cancel":
				$vars->message = JText::_( 'Goolge Checkout Message Cancel' );
				$html = $this->_getLayout('message', $vars);
				break;
			default:
				$vars->message = JText::_( 'Goolge Checkout Message Invalid Action' );
				$html = $this->_getLayout('message', $vars);
				break;
		}

		return $html;
	}

	public function onPayplansPaymentNotify(PayplansPayment $payment, $data)
	{
		// is it a valid records, ask to paypal
    	if($this->_validateIPN($data) == false){
    		return "INVALID IPN";
    	}

    	$errors = array();
    	// check which type of transaction was it
    	if($data['txn_type'] == 'web_accept') {
    		//Express Checkout or the PayPal Shopping Cart.
    		$errors = $this->_processWebAccept($payment,$data);
    		//XITODO : Add errors to log file or db
        }
        else{
       		// other methods not supported right now
       		//XiError::assert(0, "PAYPAL_INVALID_TRANSACTION_TYPE : ".$data['txn_type']);
        }

		//store the response in the payment AND save the payment
		$payment->set('transaction',PayplansHelperParam::arrayToIni($data))
				->save();

		return count($errors) ? implode("\n", $errors) : ' No Errors';
	}

	public function onPayplansPaymentCustom(PayplansPayment $payment, $data=null)
	{
		return true;
	}

	public function onPayplansPaymentBeforeSave(PayplansPayment $prev, PayplansPayment $new, $data = null)
	{
		return true;
	}
	public function onPayplansPaymentAfterSave(PayplansPayment $prev, PayplansPayment $new, $data = null)
	{
		return true;
	}

}