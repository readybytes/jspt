<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class  PayplansAppOfflinepay extends PayplansAppPayment
{
	protected $_location	= __FILE__;

	public function onPayplansPaymentDisplay(PayplansPayment $payment = null, Array $post=null)
	{
		//XITODO : Implement it
	}

	/**
	 * It will show the payment form
	 * @param $payment
	 * @param $post
	 */
	public function onPayplansPaymentForm(PayplansPayment $payment = null, Array $post=null)
	{
		return $this->_renderForm($payment, $post);
	}
	
	public function _renderForm(PayplansPayment $payment = null, Array $post=null, $form='form')
	{
		//XITODO : Save data from post
		// order id must exists in data
		$order = $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		XiError::assert($order, XiText::_('COM_PAYPLANS_ERROR_INVALID_ORDER_ID'));
		$this->assign('payment_key',$payment->getKey());

		// create new Parameter for transaction
		$transPath = dirname($this->_location).DS.'transaction';
		$transParams = PayplansHelperParam::getParamObject($transPath);
		$transParams->bind($payment->getTransaction());
		$transParams->set('amount', $payment->getAmount());
		$transParams->set('currency', $payment->getCurrency('isocode'));

		$this->assign('transaction_html',$transParams->render('transaction'));

		$this->assign('posturl',XiRoute::_('index.php?option=com_payplans&view=order&task=complete&order_key='.$order->getKey()));
		return $this->_render($form);
	}
	
	public function onPayplansPaymentAfter(PayplansPayment $payment, $action, &$data, $controller)
	{
		XiError::assert(is_array($data) , XiText::_('COM_PAYPLANS_ERROR_INVALID_DATA_ARRAY'));

		if(isset($data['transaction'])==false)
			return false;

		// if required data is not set then return false
		if(isset($data['transaction']['amount']) == false)
			return false;

		// get amount from post
		$appData['amount'] 		= $data['transaction']['amount'] ;
		$appData['transaction']    = PayplansHelperParam::collectParams($data, 'transaction');

		// initiate the payment only if action equals to success else status remains none
		if($action == 'success'){
			$payment->bind($appData)->set('status', XiStatus::PAYMENT_INITIATED)->save();
			return true;
		}		
	}
	
	public function onPayplansPaymentRecord(PayplansPayment $payment = null)
	{
		$this->assign('payment_id', $payment->getId());
		return $this->_renderForm($payment, null, 'adminform');	
	}


	// if payment is being saved from backend 
	public function onPayplansPaymentBeforeSave($prev, $new)
	{
		$transaction = JRequest::getVar('transaction', false);
		
		// do nothing id transaction is not post
		if($transaction == false || !isset($transaction['amount'])){
			return true;
		}
		
		// will be array if it is triggered from backend
		$new->set('amount', $transaction['amount']);
			
		return true;
	}
}
