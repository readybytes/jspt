<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansAppAuthorize extends PayplansAppPayment
{
	protected $_location	= __FILE__;
	
    function onPayplansPaymentForm(PayplansPayment $payment, $data = null)
	{		
		$order = $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		$this->assign('post_url', XiRoute::_("index.php?option=com_payplans&view=order&task=complete&order_key=".$order->getKey()));
		$this->assign('payment', $payment);
		$this->assign('order', $order);
	  	return $this->_render('form');
	}
	
	function onPayplansPaymentAfter(PayplansPayment $payment, $action, $data, $controller)
	{		
		if($action == 'cancel'){
			return true;
		}
		
		require_once 'AuthorizeNet.php'; 
		(!defined("AUTHORIZENET_API_LOGIN_ID")) 	? define("AUTHORIZENET_API_LOGIN_ID", 	$this->getAppParam('api_login_id', '')) : '';    // Add your API LOGIN ID
		(!defined("AUTHORIZENET_TRANSACTION_KEY")) 	? define("AUTHORIZENET_TRANSACTION_KEY", 	$this->getAppParam('transaction_key', '')): ''; // Add your API transaction key
		(!defined("AUTHORIZENET_SANDBOX")) 			? define("AUTHORIZENET_SANDBOX", 			$this->getAppParam('sandbox', 0)): '';       // Set to false to test against production
		(!defined("TEST_REQUEST")) 					? define("TEST_REQUEST", "FALSE"): '';           // You may want to set to true if testing against production
	
		$errors   = array();
		if($this->_isRecurring($payment)){
			$errors = $this->_processRecurringRequest($payment, $data);
		}
		else{
			$errors = $this->_processNonRecurringRequest($payment, $data);
		}		
		
		$order = $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		$url = 'index.php?option=com_payplans&view=order&task=complete&order_key='.$order->getKey();

		$payment->save();
		
		if(count($errors)){
			$message = XiText::_('COM_PAYPLANS_LOGGER_ERROR_IN_AUTHORIZE_PAYMENT_PROCESS');
			$log_id = PayplansHelperLogger::log(XiLogger::LEVEL_ERROR, $message, $payment, $errors);
			$action = "error";			
		}
		
		return parent::onPayplansPaymentAfter($payment, $action, $data, $controller);
	}

	protected function _processRecurringRequest($payment, $data)
	{
	    // Set up the subscription. Use the developer account for testing..
	    $subscription = new AuthorizeNet_Subscription();
	    $order				= $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
	    
	    $sub 				= array_shift($payment->getSubscriptions(PAYPLANS_INSTANCE_REQUIRE));
	
	    // XITODO : need to work on authorize.net
		$durationInDays 	= $sub->getExpirationDate();
		$interval 			= date('d', $sub->getExpirationDate()->toUnix() - $sub->getSubscriptionDate()->toUnix());
		$unit				= 'days';   // days or months
		$totalOccurrences 	= 9999;
		
	    // Set subscription information
	    $subscription->name = $sub->getTitle();
	    $subscription->amount =  $payment->getAmount();
	    $subscription->creditCardCardNumber = trim( $data['x_card_num'] );
	    $subscription->creditCardExpirationDate = trim( $data['x_exp_date'] );
	    $subscription->creditCardCardCode = $data['x_card_code'];
	    $subscription->billToFirstName = trim( $data['x_first_name'] );
	    $subscription->billToLastName = trim( $data['x_last_name'] );
	    $subscription->billToAddress = $data['x_address'];
	    $subscription->billToCity = $data['x_city'];
	    $subscription->billToState = $data['x_state'];
	    $subscription->billToCountry = $data['x_country'];
	    $subscription->billToZip = $data['x_zip'];
	    $subscription->customerEmail = $data['x_email'];
	 
	    // Set the billing cycle for every three months
	    $subscription->intervalLength = $interval;
	    $subscription->intervalUnit = $unit;
	    $subscription->startDate = $sub->getSubscriptionDate()->toFormat('%Y-%m-%d');
	    $subscription->totalOccurrences = $totalOccurrences;
	 
		// order key is invoice key here
		$subscription->orderInvoiceNumber = $order->getKey();

	    $arbInstance = new AuthorizeNetARB(AUTHORIZENET_API_LOGIN_ID, AUTHORIZENET_TRANSACTION_KEY);
	    $arbInstance->setSandbox(true);
	    $arbInstance->setRefId($order->getKey());
	    // Create the subscription
	    $response = $arbInstance->createSubscription($subscription);
			
		if (!$response)
		{
			return array("Transaction Failed");
		}
		
		$transactionArray['refId'] 					= $response->getRefID();
		$transactionArray['result_code']	= $response->getResultCode();
		$transactionArray['response_code']			= $response->getMessageCode();
		$transactionArray['text']   = $response->getMessageText();
		
		
		 // save transaction notification
	    $payment->set('transaction',PayplansHelperParam::arrayToIni($transactionArray));
	  	$fp = file_put_contents(JPATH_SITE.DS.'tmp'.DS.time().'_authorize_recurring', var_export($response, true));
		
		if($transactionArray['result_code'] == 'Error'){
			$errors['response_reason_code'] = $transactionArray['result_code'];
			$errors['response_code']		= $transactionArray['response_code'];
			$errors['response_reason_text'] = $transactionArray['text'];
			return $errors;
		}	  		
		
		$payment->set('status',XiStatus::PAYMENT_RECURRING_START);
		return array(); // ot errors			
	}
	
	protected function _processNonRecurringRequest(PayplansPayment $payment, $data)
	{
		$transactionData = array(
	        'amount' => $payment->getAmount(), 
	        'card_num' => $data['x_card_num'], 
	        'exp_date' => $data['x_exp_date'],
	        'first_name' => $data['x_first_name'],
	        'last_name' => $data['x_last_name'],
	        'address' => $data['x_address'],
	        'city' => $data['x_city'],
	        'state' => $data['x_state'],
	        'country' => $data['x_country'],
	        'zip' => $data['x_zip'],
	        'email' => $data['x_email'],
	        'card_code' => $data['x_card_code']
	        );

		$transaction = new AuthorizeNetAIM();
	    $transaction->setSandbox($this->getAppParam('sandbox', 0));
	    $transaction->setFields($transactionData);
	    
	    $response = $transaction->authorizeAndCapture();
	    
	    $transactionArray = $response->toArray();
	    // to identify it sis testing mode or not
	    $transactionArray['testmode'] = $this->getAppParam('sandbox', 0);
	    
	    // save transaction notification
	    $payment->set('transaction',PayplansHelperParam::arrayToIni($transactionArray));
	
	    $errors   = array();
		if($response->approved){
			$payment->set('status',XiStatus::PAYMENT_COMPLETE);
		}		
		else{
			$payment->set('status',XiStatus::PAYMENT_PENDING);
			$errors['response_reason_code'] = $response->response_reason_code;
			$errors['response_code']		= $response->response_code;
			$errors['response_reason_text'] = $response->response_reason_text;
		}
		
		return $errors;
	}
	
	function onPayplansPaymentNotify($payment, $data, $controller)
	{
		$order = $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		
		// if its a recurring subscrition
	    if(isset($data['x_subscription_id']) && $data['x_subscription_id'] ){
	    	$newPayment = $order->createPayment($this->getId());
			
			$errors = $this->_processNotification($newPayment, $data);
			return count($errors) ? implode("\n", $errors) : ' No Errors';
	    }
	    
	    // if its not a recurring payment
	    // XITODO : we need to do it
	    return ' No Errors ';
	}
	
    function _processNotification(PayplansPayment &$payment, array $data)
    {
    	$errors = array();
    	$order =  PayplansOrder::getInstance( $payment->getOrder());

    	// Get the response code. 1 is success, 2 is decline, 3 is error
	    $response_code = (int) $_POST['x_response_code'];
	 
	    // Get the reason code. 8 is expired card.
	    $reason_code = (int) $_POST['x_response_reason_code'];
	 
	    if ($response_code == 1)
	    {
	        // Approved!
	 		$payment->set('status',XiStatus::PAYMENT_COMPLETE);
	        // Some useful fields might include:
	        // $authorization_code = $_POST['x_auth_code'];
	        // $avs_verify_result  = $_POST['x_avs_code'];
	        // $transaction_id     = $_POST['x_trans_id'];
	        // $customer_id        = $_POST['x_cust_id'];
	    }
	    else if ($response_code == 2)
	    {
	    	// Declined
	    	$payment->set('status',XiStatus::PAYMENT_HOLD);	        
	    }
	    else if ($response_code == 3 && $reason_code == 8)
	    {
	        // An expired card
	        $payment->set('status',XiStatus::PAYMENT_HOLD);	 
	    }
	    else 
	    {
	        // Other error
	        $errors[] = XiText::_('COM_PAYPLANS_INVALID_AUTHORIZE_PAYMENT_STATUS');
	        $payment->set('status', XiStatus::PAYMENT_PENDING); 
	    }

    	//store the response in the payment AND save the payment
		$payment->set('transaction',PayplansHelperParam::arrayToIni($data))
				->save();

		//if error present in the transaction then redirect to error page
		if(!empty($errors)){
			$message = XiText::_('COM_PAYPLANS_LOGGER_ERROR_IN_AUTHORIZE_PAYMENT_PROCESS');
			$log_id = PayplansHelperLogger::log(XiLogger::LEVEL_ERROR, $message, $payment, $errors);

		}
	
        return $errors;
    }
    
	
	/**
	 * #1 : Check for the payment which are in SignUpStart Status and have this App
	 *      get the status from Authorize.net for next 24 hrs from Subscription Date
	 *      Else Make it SignUp Failed     
	 */
	function onPayplansCron()
	{
		$this->_processForSignUp();
	}
	
	/**
	 * Process the payments which are in signup start status
	 * 
	 */
	protected function _processForSignUp()
	{
		$filter = array('app_id' => $this->getId(), 
						'status' => XiStatus::PAYMENT_RECURRING_START
						);
						
		$payments = XiFactory::getInstance('payment', 'model')
								->loadRecords($filter);

		// if no such payment then return
		if(!$payments || empty($payments)){
			return true;
		}
		
		//XITODO : apply some limit 
		foreach($payments as $payment){
			$order = $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
			$status = $this->_getRecurringPaymentStatus($payment, $order);
			 
		}
	}
	
	protected function _getRecurringPaymentStatus($payment, $order)
	{
		$transaction = PayplansHelperParam::iniToArray($payment->getTransaction());
		
		if(empty($transaction) || !isset($transaction['subscriptionId'])){
			return false;
		}
		
		$path 	= "/xml/v1/request.api";
		$host 	= "api.authorize.net";
		if($this->getAppParam('sandbox', 0)){
			$host = "apitest.authorize.net";
		}
		
		$content =  "<?xml version=\"1.0\" encoding=\"utf-8\"?>".
			        "<ARBGetSubscriptionStatusRequest xmlns=\"AnetApi/xml/v1/schema/AnetApiSchema.xsd\">".
			        "<merchantAuthentication>".
			        "<name>" . AUTHORIZENET_API_LOGIN_ID . "</name>".
			        "<transactionKey>" . AUTHORIZENET_TRANSACTION_KEY . "</transactionKey>".
			        "</merchantAuthentication>" .
			        "<subscriptionId>" . $transaction['subscriptionId'] . "</subscriptionId>".
			        "</ARBGetSubscriptionStatusRequest>";
		$response = $this->_sendRequestViaCurl($host, $path, $content);
		
		if (!$response)
		{
			return array("Transaction Failed");
		}
		
		/*
		a number of xml functions exist to parse xml results, but they may or may not be avilable on your system
		please explore using SimpleXML in php 5 or xml parsing functions using the expat library
		in php 4
		parse_return is a function that shows how you can parse though the xml return if these other options are not avilable to you
		*/
		$transactionArray = $this->_parseReturn($response);
		 // save transaction notification
	    $payment->set('transaction',PayplansHelperParam::arrayToIni($transactionArray));
	  	$fp = file_put_contents(JPATH_SITE.DS.'tmp'.DS.time().'_authorize_recurring', var_export($response, true));
		
		if($transactionArray['resultCode'] == 'Error'){
			$errors['response_reason_code'] = $transactionArray['resultCode'];
			$errors['response_code']		= $transactionArray['response_code'];
			$errors['response_reason_text'] = $transactionArray['text'];
			return $errors;
		}	  		
		
		$payment->set('status',XiStatus::PAYMENT_RECURRING_START);
		return array(); // ot errors			
	}
}