<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();?>
<div id="authorize" class="authorize">
	<h2 class="page-heading primary color border background"> 
		<?php echo XiText::_('COM_PAYPLANS_PAYMENT_DETAIL');?> 
	</h2>

	<form method="post" action="<?php echo $post_url;?>" id="checkout_form">

      <fieldset>
      	<div  class="message primary color background">
          <?php echo $payment->getAmount()." ".$payment->getCurrency()." ".XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_PAYMENT_AMOUNT');?>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_CREDIT_CARD_NUMBER')?></label>
          <input type="text" class="required creditcard secondary color border background" size="15" name="x_card_num" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_EXPIRATION_DATE')?></label>
          <input type="text" class="required secondary color border background" size="4" name="x_exp_date" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_CCV')?></label>
          <input type="text" class="required secondary color border background" size="4" name="x_card_code" value=""></input>
        </div>
      </fieldset>
      <fieldset>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_FIRST_NAME')?></label>
          <input type="text" class="required secondary color border background" size="15" name="x_first_name" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_LAST_NAME')?></label>
          <input type="text" class="required secondary color border background" size="14" name="x_last_name" value=""></input>
        </div>
         <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_EMAIL')?></label>
          <input type="text" class="email secondary color border background" size="14" name="x_email" value=""></input>
        </div>

        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_ADDRESS')?></label>
          <input type="text" class="required secondary color border background" size="26" name="x_address" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_CITY')?></label>
          <input type="text" class="required secondary color border background" size="15" name="x_city" value=""></input>
        </div>

        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_STATE')?></label>
          <input type="text" class="required secondary color border background" size="4" name="x_state" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_ZIP_CODE')?></label>
          <input type="text" class="required secondary color border background" size="9" name="x_zip" value=""></input>
        </div>
        <div>
          <label><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_COUNRTY')?></label>
          <input type="text" class="required secondary color border background" size="22" name="x_country" value=""></input>
        </div>
      </fieldset>
      <input type="hidden" name="payment_key" value="<?php echo $payment->getKey();?>" />
      
      <div class="buy-button">
      <input type="submit" name="buy" value="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_BUY')?>" class="submit buy button button-color medium" />
  	  <a class="button button-color medium" id="authorize-pay-cancel" href="<?php echo XiRoute::_("index.php?option=com_payplans&view=order&task=complete&order_key=".$order->getKey()."&payment_key=".$payment->getKey()."&action=cancel"); ?>"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_APP_AUTHORIZE_CANCEL')?></a>
      </div>
	</form>
</div>