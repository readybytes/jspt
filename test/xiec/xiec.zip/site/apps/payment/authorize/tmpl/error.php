<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();?>

<?php if(!empty($errors)):?>
		
		<div>	
				<?php echo XiText::_('COM_PAYPLANS_APP_AUTHORIZE_RESPONSE_REASON_CODE');?>
      			<?php echo empty($errors['response_reason_code'])? '':JString::ucfirst($errors['response_reason_code']); ?>
      	</div>
      	<div>		
      			<?php echo XiText::_('COM_PAYPLANS_APP_AUTHORIZE_RESPONSE_CODE');?>
      			<?php echo empty($errors['response_code'])? '':JString::ucfirst($errors['response_code']); ?>
      	</div>
      	<div class="authorize-response-reason">		
      			<?php echo XiText::_('COM_PAYPLANS_APP_AUTHORIZE_RESPONSE_REASON_TEXT');?>
      			<?php echo empty($errors['response_reason_text'])? '':JString::ucfirst($errors['response_reason_text']); ?>
      	</div>
<?php endif;?>