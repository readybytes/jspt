<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<?php //XITODO: clean javascript?>

<div class="thanks">
<h2 class="page-heading pp-primary pp-color pp-border pp-background"><?php echo XiText::_('COM_PAYPLANS_ADMIN_APP_PAYMENT_PROCESS'); ?></h2>
<div class="after-payment-message pp-primary pp-color pp-border pp-background"><?php echo XiText::_('COM_PAYPLANS_ADMIN_APP_PAY_NOW_HEADING'); ?></div>

<div id="confirm-order">
		<?php echo XiText::_('COM_PAYPLANS_ADMIN_APP_PAY_NOW_MSG'); ?>
		<div style="text-align:left; margin-left:200px; margin-bottom:30px;">
			<ul>
				<li><?php echo XiText::_('COM_PAYPLANS_ADMIN_APP_PAY_NOW_FIRST_REASON'); ?></li>
				<li><?php echo XiText::_('COM_PAYPLANS_ADMIN_APP_PAY_NOW_SECOND_REASON'); ?></li>
			</ul>
		</div>
	
<?php echo XiText::_('COM_PAYPLANS_PAYMENT_ERROR_CONTACT_TO_ADMIN')?>
<?php echo XiHtml::_('elements.email');?>
</div>
</div>

<?php
