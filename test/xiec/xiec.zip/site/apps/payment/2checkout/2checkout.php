<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansApp2checkout extends PayplansAppPayment
{
	protected $_location	= __FILE__;
	
	function isApplicable($refObject = null, $eventName='')
	{
		// return true for event onPayplansControllerCreation
		if($eventName == 'onPayplansControllerCreation'){
			return true;
		}
		
		return parent::isApplicable($refObject, $eventName);
	}
	
	function onPayplansControllerCreation($view, $controller, $task, $format)
	{
		// vendor_order_id should be present in data posted
		// explode it by , 
		// first will be order key 
		// second will be payment key
		if($view == 'order' && $task == 'notify'){
			$keys = JRequest::getVar('vendor_order_id', false);
			if($keys == false){
				return true;
			}
			
			$keys = explode(',', $keys);
			//XITODO : verify it is your work as per app_id
			JRequest::setVar('order_key', array_shift($keys), 'POST');
			JRequest::setVar('payment_key', array_shift($keys), 'POST');
			return true;
		}
		
		return true;
	}
	
    function onPayplansPaymentForm(PayplansPayment $payment, $data = null)
	{
		if(is_object($data)){
			$data = (array)$data;
		}
		
		$order = $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		
		if ($this->getAppParam('alternate_url', false)) {
			$this->assign('post_url', 'https://www2.2checkout.com/2co/buyer/purchase');
		} else {
			$this->assign('post_url', 'https://www.2checkout.com/2co/buyer/purchase');
		}

		if ( $this->getAppParam('sandbox', false) ) {
			$this->assign('testmode',1);
			$this->assign('demo','Y');
		}

		$this->assign('sid', $this->getAppParam('sid',''));
		$this->assign('invoice_number',$payment->getKey());
		$this->assign('payment_key',$payment->getKey());
		$this->assign('order_key', $order->getKey());
		
		// store order key and payment key in merchant order id
		// so that order and payment can be found out at the time of notify
		// this will come as vendor_order_id
		$this->assign('merchant_order_id',$order->getKey(),',',$payment->getKey());
		
		$this->assign('x_invoice_num',$payment->getKey());
		// user should not change the quantity
		$this->assign('fixed','Y');
		$this->assign('total',$payment->getAmount());
		$this->assign('currency', $payment->getCurrency('isocode'));
		$this->assign('return_url', XiRoute::_('index.php?option=com_payplans&view=order&task=complete&action=cancel&order_key='.$order->getKey()));
		$this->assign('cart_order_id', $order->getKey());
		
		// user details, will be used only for non recurring  payments
		$user = $payment->getBuyer(PAYPLANS_INSTANCE_REQUIRE);
		$this->assign('cust_id',$user->getId());
		$this->assign('username', $user->getUsername());
		$this->assign('name',$user->getRealname());

		// XITODO : Probably no need to use below code
//		$plan = array_shift($payment->getPlans(PAYPLANS_INSTANCE_REQUIRE));
//		$this->assign('id_type', 1);
//		$this->assign('c_prod',$plan->getId().',1' );  // quantity is 1
//		$this->assign('c_name', $plan->gettitle());
//		$this->assign('c_description', strip_tags($plan->getDescription()));
		$this->assign('cart_brand_name', 'JPayPlans.com');
		$this->assign('cart_version_name', PAYPLANS_REVISION);
		
		if($this->_isRecurring($payment)){
			$plan = array_pop($order->getPlans(PAYPLANS_INSTANCE_REQUIRE));
			
			// for recurring subscrition we are using Pass-Through-Products Parameters from 2checkout.com
			$this->assign('mode', '2CO'); // always should be 2CO
			$this->assign('li_0_type', 'product'); // 0 is for sequence number of product(starting from 0), product,shipping,tax or coupon
			$this->assign('li_0_name', $plan->getTitle());
			$this->assign('li_0_quantity', 1);  //  quantity should be 1 for now
			$this->assign('li_0_price', $payment->getAmount());  //  payment amount
			
			// Specifies if the corresponding li_#_type is a tangible or intangible. ‘Y’ or ‘N’, if li_#_type is
			// ‘shipping’ forced to ‘Y’.
			$this->assign('li_0_tangible', 'N');  //  No for now in future we may five option for this
			$time = $this->getRecurrenceTime($plan->getExpiration());
			$this->assign('li_0_recurrence', $time['period'].' '.$time['unit']);
			
			$recurrenceDuration = $plan->getRecurrenceCount() * $time['period'];
			$this->assign('li_0_duration', $recurrenceDuration.' '.$time['unit']);	// Forever or # Week | Month | Year – always singular, defaults to Forever.
			
			// for start up fee 
			$first_price = $plan->getFirstPrice();
	        if(!empty($first_price)){
	        	$this->assign('li_0_startup_fee', floatval( floatval($first_price) - floatval($payment->getAmount())));			
	        }
			
			$this->assign('post_url', 'https://www2.2checkout.com/checkout/purchase');

			// set payment status to Recurring Start
			$payment->set('status', XiStatus::PAYMENT_RECURRING_START)->save();
			return $this->_render('form_subscription');
		}
		
		return $this->_render('form');
	}

	/**
	 * parse the notification to get the invoice number
	 * @param array $post
	 */
	function parseNotification( $post )
	{
		$invoice = '';
		if ( !empty( $post['invoice_number'] ) ) {
			$invoice = $post['invoice_number'];
		} elseif ( !empty( $post['merchant_order_id'] ) ) {
			$invoice = $post['merchant_order_id'];
		} else {
			$invoice = $post['x_invoice_num'];
		}

		return $invoice;
	}

	/**
	 * validate the key comes in the notification
	 * @param PayplansPayment $payment
	 * @param array $post
	 */
	function validateNotification($payment, $post)
	{
		// if notification came from INS then need to do following
		// else, in normal case it 
		if(isset($post['message_type'])){
			$string_to_hash = $post['sale_id'].$this->getAppParam('sid', '').$post['invoice_id'].$this->getAppParam('secret_word', '');
			$postKey = $post['md5_hash'];
		}
		else{
			if($this->getAppParam('sandbox', 0)) {
				$string_to_hash	= $this->getAppParam('secret_word', '').$this->getAppParam('sid', '')."1".$post['total'];
			} else {
				$string_to_hash	= $this->getAppParam('secret_word', '').$this->getAppParam('sid', '').$post['order_number'].$post['total'];
			}
			$postKey = $post['key'];
		}
		
		$check_key = strtoupper(md5($string_to_hash));

		return (strcmp($check_key, $postKey) == 0);
	}
	
	protected function _order_created($order, $payment, $data)
	{
		// change status if its recurring order creation 
		// otherwise do nothing
		if(!isset($data['recurring']) || !$data['recurring']){
			return true;
		}
		
		if(!$this->validateNotification($newPayment, $data)){
			$errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_HASH_KEY');
			return $errors;
		}
			
		// if payment status is PAYMENT_RECURRING_START then set it to PAYMENT_RECURRING_SIGNUP
		if($payment->getStatus() == XiStatus::PAYMENT_RECURRING_START){
			$payment->set('status', XiStatus::PAYMENT_RECURRING_SIGNUP);
		}		
		
		return array();
	}
	
	protected function _invoice_status_changed($order, $payment, $data)
	{
		//XITODO : need to work here
		
		return array();
	}
	
	protected function _refund_issued($order, $payment, $data)
	{
		//XITODO : need to work here
		
		return array();
	}
	
	protected function _recurring_installment_success($order, &$payment, $data)
	{

//		  'vendor_order_id' => 'promo12345',
//		  'invoice_id' => '1219232477',
//		  'recurring' => '1',
//		  'item_rec_date_next_1' => '2007-11-01',
//		  'item_rec_install_billed_1' => '10',
		// XITODO : check for amount
		$data['sid'] = $data['vendor_id'];
		$newPayment = $order->createPayment($this->getId(), true);
		$newPayment->set('master', 0);
		
		$errors = array();
		
		if(!$this->validateNotification($newPayment, $data))
		{
			$errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_RECEIVER_SID');
			$newPayment->set('status', XiStatus::PAYMENT_PENDING);			
		}
		else{
			$newPayment->set('status', XiStatus::PAYMENT_COMPLETE);
		}

		$payment = $newPayment;
		
		return $errors;
	}
	
	protected function _recurring_installment_failed($order, $payment, $data)
	{
		if(!$this->validateNotification($newPayment, $data)){
			$errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_HASH_KEY');
			return $errors;
		}
		
		$payment->set('status', XiStatus::PAYMENT_RECURRING_FAILED);		
		return true;
	}
	
	protected function _recurring_stopped($order, $payment, $data)
	{
		if(!$this->validateNotification($newPayment, $data)){
			$errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_HASH_KEY');
			return $errors;
		}
		
		$payment->set('status', XiStatus::PAYMENT_RECURRING_CANCEL);
		return true;
	}

	protected function _recurring_complete($order, $payment, $data)
	{
		if(!$this->validateNotification($newPayment, $data)){
			$errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_HASH_KEY');
			return $errors;
		}
		
		$payment->set('status', XiStatus::PAYMENT_RECURRING_EOT);
		return true;
	}
	
	protected function _recurring_restart($order, $payment, $data)
	{
		// XITODO : need to work
		return true;
	}
	
	function onPayplansPaymentNotify($payment, $data, $controller)
	{
		$order 		= $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		
		// if the otification is from INS of 2checkout
		// then message type will be se	
		$func_name = 'invalidFunction';
		if(isset($data['message_type'])){
			$func_name = '_'.JString::strtolower($data['message_type']);
		}

		//XITODO : Log error
		if(method_exists($this, $func_name)){
			$errors = $this->$func_name($order, $payment, $data);
		}else{
			$errors = array(XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_MESSAGE_TYPE'));
		}		
		// XITODO : if method does not exists
		
        $payment->set('transaction',PayplansHelperParam::arrayToIni($data))
				->save();
		
		return $errors;
	}
	
	/**
	 * 
	 * Process the notification for different parameters
	 * @param PayplansPayment $payment
	 * @param array $data
	 */
    function _processNotification(PayplansPayment &$payment, array $data)
    {
    	$errors = array();
    	$order =  PayplansOrder::getInstance($payment->getOrder());

    	// find the required data from post-data, and match with payment
    	if(!$this->validateNotification($payment, $data)){
    		$errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_KEY');
    	}
    	
    	// check reciever sid must be same.
    	if($this->getAppParam('sid') != $data['sid']) {
            $errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_RECEIVER_SID');
        }

        // check payment key
        $invoice = $this->parseNotification($data);
    	if($payment->getKey() != $invoice) {
            $errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_PAYMENT_KEY');
        }

		//XITODO : will it be available during next payments
    	// check the stored order against the payment order
        if ($order->getKey() != $data['order_key']) {
            $errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_ORDER');
        }
        
     	// check customer/user id
    	if($payment->getBuyer() != $data['cust_id']) {
            $errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_USER_ID');
        }
        
        // XITODO : have some doubt here
    	//  
        if ('Y' !== JString::strtoupper($data['credit_card_processed'])) {
            $errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_CREDIT_CARD_PROCESSED');
        }
        
        // if its a recurring payment then do not check for amount
        // payment will be checked by notofication
        if(isset($data['is_recurring']) == false){
	        // check the stored amount against the payment amount
	        if ((float) number_format($order->getTotal(), 2) !== (float) number_format($data['total'], 2)) {
	            $errors[] = XiText::_('COM_PAYPLANS_APP_2CHECKOUT_INVALID_PAYMENT_TOTAL');
	        }
	        // update the payment amount
	        $payment->set('amount', (float) $data['total']);
        }

    	$payment->set('status',XiStatus::PAYMENT_COMPLETE);
        if(!empty($errors)){
        	$payment->set('status',XiStatus::PAYMENT_PENDING);
        	$message = XiText::_('COM_PAYPLANS_LOGGER_ERROR_IN_2CHECKOUT_PAYMENT_PROCESS');
			$log_id = PayplansHelperLogger::log(XiLogger::LEVEL_ERROR, $message, $payment, $errors);
        }
        
        return $errors;
    }

    public function onPayplansPaymentAfter(PayplansPayment $payment, $action, $data, $controller)
	{
		if(isset($data['is_recurring']) == true){
			$data['invoice_number'] = $payment->getKey();
		}

		$errors = $this->_processNotification($payment, $data);			
		
		if(isset($data['is_recurring']) == true){
				$payment->set('status',XiStatus::PAYMENT_RECURRING_SIGNUP);
				if(count($errors)){
					$payment->set('status',XiStatus::PAYMENT_RECURRING_FAILED);
				}			
		}
		
		if(!empty($errors)){
			$action = 'error';
		}
		
		$payment->set('transaction',PayplansHelperParam::arrayToIni($data))
				->save();
				
		return parent::onPayplansPaymentAfter($payment, $action, $data, $controller);
	}
	
	public function getRecurrenceTime($expTime)
	{
		$expTime['year'] 	= isset($expTime['year']) 	? intval($expTime['year'], 10) : 0;
		$expTime['month'] 	= isset($expTime['month']) ? intval($expTime['month'], 10) : 0;
		$expTime['day'] 	= isset($expTime['day']) 	? intval($expTime['day'], 10)  : 0;
		
		// days, if days are not zero then, convert whole time into days and convert it into weeks 
		if(!empty($expTime['day'])){
			$days  = $expTime['year'] * 365;
			$days += $expTime['month'] * 30;
			$days += $expTime['day'];
			
			$weeks = intval($days/7, 10);
			
			return array('period' => $weeks, 'unit' => 'Week', 'frequency' => XiText::_('COM_PAYPLANS_RECURRENCE_FREQUENCY_GREATER_THAN_ONE'));
		}
		
		// if months are not empty 
		if(!empty($expTime['month'])){
			$months  = $expTime['year'] * 12;
			$months += $expTime['month'];
			
			return array('period' => $months, 'unit' => 'Month', 'frequency' => XiText::_('COM_PAYPLANS_RECURRENCE_FREQUENCY_GREATER_THAN_ONE'));
		}
			
		
		// if years are not empty 
		if(!empty($expTime['year'])){			
			return array('period' => $expTime['year'], 'unit' => 'Year', 'frequency' => XiText::_('COM_PAYPLANS_RECURRENCE_FREQUENCY_GREATER_THAN_ONE'));
		}
	}
}
