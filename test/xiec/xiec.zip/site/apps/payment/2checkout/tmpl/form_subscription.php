<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

?>

<script>
window.onload = function() 
{	
	  setTimeout("checkoutSubmit()", 2000);
}

function checkoutSubmit()
{
	document.forms["site_app_<?php echo $this->getName(); ?>_form"].submit();
}
</script>
<div id="payment-2checkout">
<form action="<?php echo $post_url;?>" method="post"
	  name="site_app_<?php echo $this->getName(); ?>_form" >
	  
		<?php unset( $post_url );?>

		<input type="hidden" name="testmode" value="<?php echo $testmode;?>" />
		<input type="hidden" name="demo" value="<?php echo $demo;?>" />		
		
		<input type="hidden" name="sid" value="<?php echo $sid;?>" />
		<input type="hidden" name="mode" value="<?php echo $mode;?>" />
		
		<input type="hidden" name="li_0_type" value="<?php echo $li_0_type;?>" />
		<input type="hidden" name="li_0_name" value="<?php echo $li_0_name;?>" />
		<input type="hidden" name="li_0_quantity" value="<?php echo $li_0_quantity;?>" />
		<input type="hidden" name="li_0_price" value="<?php echo $li_0_price;?>" />
		<input type="hidden" name="li_0_tangible" value="<?php echo $li_0_tangible;?>" />
		<input type="hidden" name="li_0_recurrence" value="<?php echo $li_0_recurrence;?>" />
		<input type="hidden" name="li_0_duration" value="<?php echo $li_0_duration;?>" />		
		
		<input type="hidden" name="currency" value="<?php echo $currency;?>" />
		<input type="hidden" name="fixed" value="<?php echo $fixed;?>" />
		<input type="hidden" name="return_url" value="<?php echo $return_url;?>" />
		<input type="hidden" name="merchant_order_id" value="<?php echo $merchant_order_id;?>" />
		<input type="hidden" name="cust_id" value="<?php echo $cust_id;?>" />
		
		<input type="hidden" name="invoice_number" value="<?php echo $invoice_number;?>" />
		<input type="hidden" name="payment_key" value="<?php echo $payment_key;?>" />
		<input type="hidden" name="invoice_number" value="<?php echo $invoice_number;?>" />
		<input type="hidden" name="order_key" value="<?php echo $order_key;?>" />
		<input type="hidden" name="is_recurring" value="1" />
		
		<div class="prepayment-message">
        	<div id="payment-title"><h2 class="page-heading primary color border background"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_INSTRUCTIONS'); ?></h2></div>
		</div>
		
		<div id="payment-redirection">
			<div class="redirection-message secondary color border background">
				<?php echo XiText::_('COM_PAYPLANS_APP_2CHECKOUT_PAYMENT_REDIRECTION'); ?>
			</div>
			
			<div class="loading"></div>
		</div>
	
		<div id="payment-submit">
			<input type="submit" class="button button-color medium" id="payplans_checkout_btn" value="<?php echo XiText::_('COM_PAYPLANS_APP_2CHECKOUT_CHECKOUT');?>" />
		</div>
		
</form>
</div>
<?php 
