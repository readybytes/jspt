<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>

<script>
window.onload = function() 
{	
	  setTimeout("paypalSubmit()", 2000);
}

function paypalSubmit()
{
	document.forms["site_app_<?php echo $this->getName(); ?>_form"].submit();
}
</script>

<form action="<?php echo $post_url ?>"
	  method="post" name="site_app_<?php echo $this->getName(); ?>_form" >

	<!--ORDER INFO-->
	<input type="hidden" name="order_id" 	value="<?php echo $order->getKey();?>" />
	<input type='hidden' name='invoice' 	value='<?php echo $payment->getKey(); ?>'>
	<input type='hidden' name='item_name' 	value='<?php echo XiText::_('COM_PAYPLANS_ORDER_NUMBER').": ".$order->getKey(); ?>'>
	<input type='hidden' name='item_number' value='<?php echo $order->getKey(); ?>'>
	<input type='hidden' name='amount' 		value='<?php echo number_format($order->getTotal(),2); ?>'>


	<input type='hidden' name='cmd' 			value='_xclick'>
	<input type="hidden" name="business" 		value="<?php echo $merchant_email; ?>" />
	<input type='hidden' name='return' 			value='<?php echo $return_url; ?>'>
	<input type='hidden' name='cancel_return' 	value='<?php echo $cancel_url; ?>'>
	<input type="hidden" name="notify_url" 		value="<?php echo $notify_url; ?>" />
	<input type='hidden' name='currency_code' 	value='<?php echo $order->getCurrency(); ?>'>
	<input type='hidden' name='no_note' 		value='1'>

    <div id="payment-paypal">
		<div class="prepayment-message">
        	<div id="payment-title"><h2 class="page-heading  primary color border background"><?php echo XiText::_('COM_PAYPLANS_PAYMENT_INSTRUCTIONS'); ?></h2></div>
		</div>
		
		<div id="payment-redirection">
			<div class="redirection-message secondary color border background">
				<?php echo XiText::_('COM_PAYPLANS_APP_PAYPAL_PAYMENT_REDIRECTION'); ?>
			</div>
			<div class="loading"></div>
		</div>
	
		<div id="payment-submit">
			<input 	type="submit" class="button button-color medium" id="payplans-app-paypal-payment"
					name="payplans_payment_btn" value="<?php echo XiText::_('COM_PAYPLANS_PAYPAL_PAYMENT')?>"/>
		</div>
	</div>

</form>
