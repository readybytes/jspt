<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansAppPaypal extends PayplansAppPayment
{
	//inherited properties
	// IMP : store txn_id in txn_id for payment
	// and store subscr_id for recurring master payment
	
	protected $_location	= __FILE__;

	public function getAppParam($key, $default=null)
	{
		static $isSandBox = null;

		// initialize sandbox testing variable
		if($isSandBox === null){
			$isSandBox = parent::getAppParam('sandbox',false);
		}

		//check if such a variable exist, then return it
		if($isSandBox){
			$return = parent::getAppParam('sandbox_'.$key,null);
			if($return !== null)
				return $return;
		}

		// else send the normal variable
		return parent::getAppParam($key,$default);
	}

 	/**
     * Gets the Paypal gateway URL
     *
     * @param boolean $full
     * @return string
     * @access protected
     */
    function _getPaypalUrl()
    {
        $url = $this->getAppParam('sandbox') ? 'www.sandbox.paypal.com' : 'www.paypal.com';
        return 'https://' . $url . '/cgi-bin/webscr';
    }

	/**
	 * Checks the validity of given IPN
	 * @param $data
	 */
	function _validateIPN(array $data )
    {
    	$paypal_url	=  $this->_getPaypalUrl();

        $req = 'cmd=_notify-validate';

        foreach ($data as $key => $value) {
        	//ignore joomla url variables
        	if (in_array($key, array('option','task','view','layout'))) {
            	continue;
            }

            $value = urlencode($value);
            $req .= "&$key=$value";
        }

        // open the connection
        //XITODO : check if we need to open a SSL connection or not, also make sure url is https
        $url = $this->getAppParam('sandbox') ? 'www.sandbox.paypal.com' : 'www.paypal.com';
        // OCT 31,2011 : now paypal uses ssl:// in url and port 443
	$fp = fsockopen ('ssl://'.$url , 443, $errno, $errstr, 30);
        XiError::assert($fp);


        // post data back to PayPal system to validate
        $header  = "POST /cgi-bin/webscr HTTP/1.0\r\n";
        $header .= "Host: $url\r\n";
        $header .= "Content-Type: application/x-www-form-urlencoded\r\n";
        $header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
        fputs ($fp, $header . $req);

        // read the response data now
        $return = false;
        while( ! feof($fp)){
        	//XITODO : Add this to tmp log file
        	$response = fgets ($fp, 1024); //echo $res;
        	if (strcmp ($response, 'VERIFIED') == 0) {
        			$return = true;
                    break;
        	}

        	if (strcmp ($response, 'INVALID') == 0) {
        			$return = false;
                    break;
        	}
        }

        fclose($fp);
        return $return;
    }



    /**
     * Payment received; source is a Buy Now, Donation, or Auction Smart Logos button
     * Process in same way
     */
    function _validateNotification(PayplansPayment $payment, array $data)
    {
    	$errors = array();

    	// find the required data from post-data, and match with payment
    	// check reciever email must be same.
    	if($this->getAppParam('merchant_email') != $data['receiver_email']) {
            $errors[] = XiText::_('COM_PAYPLANS_INVALID_PAYPAL_RECEIVER_EMAIL');
        }

        // check payment key
    	if($payment->getKey() != $data['invoice']) {
            $errors[] = XiText::_('COM_PAYPLANS_INVALID_PAYPAL_PAYMENT_KEY');
    	}

        //XITODO : Add TXN_ID and PARENT_TXN_ID fields in table
        return $errors;
    }


    /**
     * All events need to be implemented
     */
	public function onPayplansPaymentBefore()
	{
		return true;
	}

	public function onPayplansPaymentForm(PayplansPayment $payment, $data = null)
	{
		if(is_object($data)){
			$data = (array)$data;
		}

		$order = $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		
		// assign variables for templates
		$this->assign('payment', $payment);
		$this->assign('order',   $order);
		
		$this->assign('merchant_email',$this->getAppParam('merchant_email'));
		$this->assign('merchant_id',$this->getAppParam('merchant_id',false));
		$this->assign('currency', $payment->getCurrency('isocode'));

		// build urls
    	$sandbox = $this->getAppParams()->get('sandbox',false) ? 'sandbox.' : '';

    	$this->assign('post_url', $this->_getPaypalUrl());
    	
    	$root = JURI::root();
    	if(XiFactory::getConfig()->https == true){
    		$root = JString::str_ireplace("http:", "https:", $root);
    	}
    	
    	$this->assign('return_url', $root.'index.php?option=com_payplans&view=order&task=complete&action=success&order_key='.$order->getKey().'&payment_key='.$payment->getKey());
    	$this->assign('cancel_url', $root.'index.php?option=com_payplans&view=order&task=complete&action=cancel&order_key='.$order->getKey().'&payment_key='.$payment->getKey());
    	$this->assign('notify_url', $root.'index.php?option=com_payplans&view=order&task=notify&order_key='.$order->getKey().'&payment_key='.$payment->getKey());

        // render as per requirement of payment type
        /*  _xclick : The button that the person clicked was a Buy Now button.
         * _donations : The button that the person clicked was a Donate button.
         * _xclick-subscriptions : The button that the person clicked was a Subscribe button.
         * _cart : For shopping cart purchases; these additional variables specify the kind of shopping cart button that the person clicked:
         */

        // XITODO : need to change when multiple subscription is available
        $plan = array_shift($payment->getPlans(PAYPLANS_INSTANCE_REQUIRE));
        $time = $this->getRecurrenceTime($plan->getExpiration());
        $this->assign('period', $time['period']);
        $this->assign('unit', $time['unit']); 

        if($this->_isRecurring($payment)){
			//XITODO : why .plz comment
        	$payment->set('status', XiStatus::PAYMENT_RECURRING_START)->save();
        	$recurrence_count = $plan->getRecurrenceCount();  // XITODO : 0 is default value
      
        	$first_price = $order->getFirstTotal();
        	if(JString::trim($first_price) != PAYPLANS_UNDEFINED){
        		// decremet in recurring count
        		$recurrence_count--;
        	}

        	$this->assign('recurrence_count', $recurrence_count);
           	$this->assign('first_price', $first_price);
      
        	return $this->_render('form_subscription');
        }
        
        return $this->_render('form_buynow');
	}
	
	public function getRecurrenceTime($expTime)
	{
		$expTime['year'] = isset($expTime['year']) ? intval($expTime['year']) : 0;
		$expTime['month'] = isset($expTime['month']) ? intval($expTime['month']) : 0;
		$expTime['day'] = isset($expTime['day']) ? intval($expTime['day']) : 0;;
		
		// years
		if(!empty($expTime['year'])){
			if($expTime['year'] >= 5){
				return array('period' => 5, 'unit' => 'Y', 'frequency' => XiText::_('COM_PAYPLANS_RECURRENCE_FREQUENCY_GREATER_THAN_ONE'));
			}
			
			if($expTime['year'] >= 2){
				return array('period' => $expTime['year'], 'unit' => 'Y', 'frequency' => XiText::_('COM_PAYPLANS_RECURRENCE_FREQUENCY_GREATER_THAN_ONE'));
			}
			
			// if months is not set then return years * 12 + months
			if(isset($expTime['month']) && $expTime['month']){
				return array('period' => $expTime['year'] * 12 + $expTime['month'], 'unit' => 'M');
			}				
			
			return array('period' => $expTime['year'], 'unit' => 'Y', 'frequency' => XiText::_('COM_PAYPLANS_RECURRENCE_FREQUENCY_GREATER_THAN_ONE'));
		}
		
		// if months are set
		if(!empty($expTime['month'])){
			// if days are empty
			if(empty($expTime['day'])){
				return array('period' => $expTime['month'], 'unit' => 'M', 'frequency' => XiText::_('COM_PAYPLANS_RECURRENCE_FREQUENCY_GREATER_THAN_ONE'));
			}
			
			// if total days are less or equlas to 90, then return days
			//  IMP : ASSUMPTION : 1 month = 30 days
			$days = $expTime['month'] * 30;
			if(($days + $expTime['day']) <= 90){
				return array('period' => $days + $expTime['day'], 'unit' => 'D', 'frequency' => XiText::_('COM_PAYPLANS_RECURRENCE_FREQUENCY_GREATER_THAN_ONE'));
			}
			
			// other wise convert it into weeks
			return array('period' => intval(($days + $expTime['day'])/7, 10), 'unit' => 'W', 'frequency' => XiText::_('COM_PAYPLANS_RECURRENCE_FREQUENCY_GREATER_THAN_ONE'));
		}
		
		// if only days are set then return days as it is
		if(!empty($expTime['day'])){
			return array('period' => intval($expTime['day'], 10), 'unit' => 'D', 'frequency' => XiText::_('COM_PAYPLANS_RECURRENCE_FREQUENCY_GREATER_THAN_ONE'));
		}
		
		// XITODO : what to do if not able to convert it
		return false;
	}

	public function onPayplansPaymentAfter(PayplansPayment $payment, $action, $data, $controller)
	{
		$record = array_pop(PayplansHelperLogger::getLog($payment, XiLogger::LEVEL_ERROR));			
		if($record && !empty($record)){
			$action = 'error';
		}
		
		return parent::onPayplansPaymentAfter($payment, $action, $data, $controller);
	}

	public function onPayplansPaymentNotify(PayplansPayment $payment, $data, $controller)
	{
		$errors = array();
		$order = $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		
		// is it a valid records, ask to paypal
    	if($this->_validateIPN($data) == false){
    		$errors[] = XiText::_('COM_PAYPLANS_INVALID_IPN');
    		$message = XiText::_('COM_PAYPLANS_LOGGER_PAYMENT_INVALID_IPN');
    		PayplansHelperLogger::log(XiLogger::LEVEL_ERROR, $message, $payment, $errors);
    		return "INVALID IPN";
    	}

		$func_name = '_process_web_accept';

		$func_name_rec 		= isset($data['txn_type']) ? '_process_'.JString::strtolower($data['txn_type']) : 'EMPTY';
		$func_name_nonrec 	= isset($data['payment_status']) ? '_on_payment_'.JString::strtolower($data['payment_status']) : 'EMPTY';
		
		if(method_exists($this, $func_name_rec)){
			$errors = $this->$func_name_rec($order, $payment, $data);
		}
		elseif(method_exists($this, $func_name_nonrec)){
			$errors = $this->$func_name_nonrec($order, $payment, $data);
		}
		else{
			$errors[] = XiText::_('COM_PAYPLANS_APP_PAYPAL_INVALID_TRANSACTION_TYPE_OR_PAYMENT_STATUS');
		}
		
    	//if error present in the transaction then redirect to error page
		if(!empty($errors)){
			$message = XiText::_('COM_PAYPLANS_LOGGER_ERROR_IN_PAYPAL_PAYMENT_PROCESS');
			$log_id = PayplansHelperLogger::log(XiLogger::LEVEL_ERROR, $message, $payment, $errors);

			$payment->set('status', XiStatus::PAYMENT_PENDING);
		}
	
		//store the response in the payment AND save the payment
		$payment->set('transaction',PayplansHelperParam::arrayToIni($data));
		
		// if transaction id is set 
		if(isset($data['txn_id'])){
			$payment->set('txn_id', $data['txn_id']);
		}
		
		$payment->save();
		
		return count($errors) ? implode("\n", $errors) : ' No Errors';
	}

//	public function onPayplansPaymentSubscriptionCancel(Payplans $payment, $controller)
//	{
//			// Set up your API credentials, PayPal end point, and API version.
//			$API_Endpoint = "https://api-3t.paypal.com/nvp";
//			if($this->getAppParam('sandbox')) {
//				$API_Endpoint = "https://api-3t.sandbox.paypal.com/nvp";
//			}
//			$version = urlencode('51.0');
//		
//			// Set the curl parameters.
//			$ch = curl_init();
//			curl_setopt($ch, CURLOPT_URL, $API_Endpoint);
//			curl_setopt($ch, CURLOPT_VERBOSE, 1);
//		
//			// Turn off the server and peer verification (TrustManager Concept).
//			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
//			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
//		
//			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//			curl_setopt($ch, CURLOPT_POST, 1);
//		
//			// Set the API operation, version, and API signature in the request.
//			$nvpreq = "METHOD=ManageRecurringPaymentsProfileStatus&PROFILEID={$payment->getTransactionKey()}&ACTION=Cancel";
//		
//			// Set the request as a POST FIELD for curl.
//			curl_setopt($ch, CURLOPT_POSTFIELDS, $nvpreq);
//		
//			// Get response from the server.
//			$httpResponse = curl_exec($ch);
//		
//			if(!$httpResponse) {
//				XiError::error(false, "$methodName_ failed: ".curl_error($ch).'('.curl_errno($ch).')', XiError::WARNING);
//				return false;
//			}
//		
//			// Extract the response details.
//			$httpResponseAr = explode("&", $httpResponse);
//		
//			$httpParsedResponseAr = array();
//			foreach ($httpResponseAr as $i => $value) {
//				$tmpAr = explode("=", $value);
//				if(sizeof($tmpAr) > 1) {
//					$httpParsedResponseAr[$tmpAr[0]] = $tmpAr[1];
//				}
//			}
//		
//			if((0 == sizeof($httpParsedResponseAr)) || !array_key_exists('ACK', $httpParsedResponseAr)) {
//				XiError::error(false, "Invalid HTTP Response for POST request($nvpreq) to $API_Endpoint.", XiError::warning);
//			}
//		
//		if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"])) {
//			$controller->setMessage('Your recurring order has been successfully cancelled');
//		} else  {
//			$controller->setMessage('Order cancellation has been failed');
//		}
//		
//		return true;
//	}
	
	protected function _on_payment_canceled_reversal($payment, $data)
	{
		//		Canceled_Reversal: A reversal has been canceled. For example, you
		//		won a dispute with the customer, and the funds for the transaction that was
		//		reversed have been returned to you.
		
		$payment->set('status', XiStatus::PAYMENT_COMPLETE);
		return array();
	}

	protected function _on_payment_completed($order, $payment, $data)
	{
		//		Completed: The payment has been completed, and the funds have been
		//		added successfully to your account balance.
		
		$errors = $this->_validateNotification($payment, $data);
		
		// check the stored amount against the payment amount
        $stored_amount = number_format($payment->getAmount(),2);
        if ((float) $stored_amount !== (float) $data['mc_gross']) {
            $errors[] = XiText::_('COM_PAYPLANS_INVALID_PAYPAL_PAYMENT_TOTAL');
        }
        
        // update the payment amount
        $payment->set('amount', (float) $data['mc_gross']);
        
		empty($errors) ? $payment->set('status', XiStatus::PAYMENT_COMPLETE) : '';
		return $errors;
	}
	
	protected function _on_payment_created($order, $payment, $data)
	{
		//  A German ELV payment is made using Express Checkout.
		// Probably we don't need it
		return array();
	}
	
	protected function _on_payment_denied($order, $payment, $data)
	{
		//		Denied: You denied the payment. This happens only if the payment was
		//		previously pending because of possible reasons described for the
		//		pending_reason variable or the Fraud_Management_Filters_x
		//		variable.
		
		$payment->set('status', XiStatus::PAYMENT_HOLD);
		return array();
	}
	
	protected function _on_payment_expired($order, $payment, $data)
	{
		//		This authorization has expired and cannot be captured.
		
		$payment->set('status', XiStatus::PAYMENT_HOLD);
		return array();
	}
	
	protected function _on_payment_failed($order, $payment, $data)
	{
		//		The payment has failed. This happens only if the payment was
		//		made from your customer’s bank account.
		
		$payment->set('status', XiStatus::PAYMENT_HOLD);
		return array();		
	}
	
	protected function _on_payment_pending($order, $payment, $data)
	{
		//		The payment is pending. See pending_reason for more
		//		information.
		
		$payment->set('status', XiStatus::PAYMENT_PENDING);
		return array();
	}
	
	protected function _on_payment_refunded($order, $payment, $data)
	{
		//		Refunded: You refunded the payment.
		
		// 		XITODO : Configurtion is there to ask from admin
		//		What to do on partial refund 
		
		// check the stored amount against the payment amount
        $stored_amount = number_format($payment->getAmount(),2);
        if ((float) $stored_amount !== (float) abs($data['mc_gross'])) {
           $stored_amount = (float) $stored_amount - (float) abs($data['mc_gross']);
        }
        
        // update the payment amount
        $payment->set('amount', (float) $stored_amount);
		
        $payment->set('status', XiStatus::PAYMENT_HOLD);
		return array();
	}
	
	protected function _on_payment_reversed($order, $payment, $data)
	{
		//		Reversed: A payment was reversed due to a chargeback or other type of
		//		reversal. The funds have been removed from your account balance and
		//		returned to the buyer. The reason for the reversal is specified in the
		//		ReasonCode element.
		
		$payment->set('status', XiStatus::PAYMENT_HOLD);
		return array();	
	}
	
	protected function _on_payment_processed($order, $payment, $data)
	{
		//		Processed: A payment has been accepted.
		$payment->set('status', XiStatus::PAYMENT_COMPLETE);
		return array();	
	}
	
	protected function _on_payment_voided($order, $payment, $data)
	{
		//		Voided: This authorization has been voided.
		
		$payment->set('status', XiStatus::PAYMENT_HOLD);
		return array();	
	}
	
	//XITODO : cros check subscr_id
	protected function _process_subscr_payment($order, &$payment, $data)
	{		
		// if same transaction id is set in data
		// it mean multiple notification are sent from paypal for same payment
		$txnPayment = XiFactory::getInstance('payment', 'model')
								->loadRecords(array('txn_id' => $data['txn_id']));
															
		if(empty($txnPayment)){
			$newPayment = $order->createPayment($this->getId(), true);
		}
		else{
			$tmpPayment = array_pop($txnPayment);
			$newPayment = PayplansPayment::getInstance($tmpPayment->payment_id, null, $tmpPayment);
		}
		
		// change the invoice key as this is a recurring paymnet 
		// and each time new payment will be created
		$data['invoice'] = $newPayment->getKey();
		$errors = $this->_validateNotification($newPayment, $data);
		$func_name = '_on_payment_'.JString::strtolower($data['payment_status']);
		
		$temp = $this->$func_name($order, $newPayment, $data);
		$errors = array_merge($errors, $temp);	
		
		// this is a child payment
		$newPayment->set('master', 0);
		
		// assign new payment to original payment
		$payment = $newPayment;
		return $errors;
	}
	
	protected function _process_subscr_signup($order, $payment, $data)
	{
		// check for first price total
		// if its 0 then paypal will send you the notification
		// so create payment with zero amount and make it complete
		
		$payment->set('status', XiStatus::PAYMENT_RECURRING_SIGNUP)
				->set('txn_id', $data['subscr_id'])
				->set('transaction',PayplansHelperParam::arrayToIni($data))
				->save();
				
		$firstTotal = $order->getFirstTotal();
		if($firstTotal === PAYPLANS_UNDEFINED){
			return array();
		}
		
		if(number_format($firstTotal, 2, '.', '') == number_format(0, 2, '.', '')){
			$newPayment = $order->createPayment($this->getId(), true);
			$newPayment->set('master', 0)
						->set('status', XiStatus::PAYMENT_COMPLETE)->save();
		}
		return array();
	}
	
	protected function _process_subscr_cancel($order, $payment, $data)
	{
		$payment->set('status', XiStatus::PAYMENT_RECURRING_CANCEL)->save();
		$order->set('status', XiStatus::ORDER_HOLD)->save();
		return array();
	}
	
	protected function _process_subscr_modify($order, $payment, $data)
	{
		// XITODO : what to do here
	}
	
	protected function _process_subscr_failed($order, $payment, $data)
	{
		$paymet->set('status', XiStatus::PAYMENT_RECURRING_FAILED);
		$order->set('status', XiStatus::ORDER_HOLD);		
		return array();
	}
	
	protected function _process_subscr_eot($order, $payment, $data)
	{
		$paymet->set('status', XiStatus::PAYMENT_RECURRING_EOT);
		$order->set('status', XiStatus::ORDER_EXPIRED);
		return array();
	}
}
