<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansAppPaypal extends PayplansAppPayment
{
	//inherited properties
	protected $_location	= __FILE__;

	public function getAppParam($key, $default=null)
	{
		static $isSandBox = null;

		// initialize sandbox testing variable
		if($isSandBox === null){
			$isSandBox = parent::getAppParam('sandbox',false);
		}

		//check if such a variable exist, then return it
		if($isSandBox){
			$return = parent::getAppParam('sandbox_'.$key,null);
			if($return !== null)
				return $return;
		}

		// else send the normal variable
		return parent::getAppParam($key,$default);
	}

 	/**
     * Gets the Paypal gateway URL
     *
     * @param boolean $full
     * @return string
     * @access protected
     */
    function _getPaypalUrl()
    {
        $url = $this->getAppParam('sandbox') ? 'www.sandbox.paypal.com' : 'www.paypal.com';
        return 'https://' . $url . '/cgi-bin/webscr';
    }

	/**
	 * Checks the validity of given IPN
	 * @param $data
	 */
	function _validateIPN(array $data )
    {
    	$paypal_url	=  $this->_getPaypalUrl();

        $req = 'cmd=_notify-validate';

        foreach ($data as $key => $value) {
        	//ignore joomla url variables
        	if (in_array($key, array('option','task','view','layout'))) {
            	continue;
            }

            $value = urlencode($value);
            $req .= "&$key=$value";
        }

        // open the connection
        //XITODO : check if we need to open a SSL connection or not, also make sure url is https
        $url = $this->getAppParam('sandbox') ? 'www.sandbox.paypal.com' : 'www.paypal.com';
        $fp = fsockopen ($url , 80, $errno, $errstr, 30);
        XiError::assert($fp);


        // post data back to PayPal system to validate
        $header  = "POST /cgi-bin/webscr HTTP/1.0\r\n";
        $header .= "Host: $url\r\n";
        $header .= "Content-Type: application/x-www-form-urlencoded\r\n";
        $header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
        fputs ($fp, $header . $req);

        // read the response data now
        $return = false;
        while( ! feof($fp)){
        	//XITODO : Add this to tmp log file
        	$response = fgets ($fp, 1024); //echo $res;
        	if (strcmp ($response, 'VERIFIED') == 0) {
        			$return = true;
                    break;
        	}

        	if (strcmp ($response, 'INVALID') == 0) {
        			$return = false;
                    break;
        	}
        }

        fclose($fp);
        return $return;
    }



    /**
     * Payment received; source is a Buy Now, Donation, or Auction Smart Logos button
     * Process in same way
     */
    function _processNotification(PayplansPayment &$payment, array $data)
    {
    	$errors = array();
    	$order =  PayplansOrder::getInstance( $payment->getOrder());

    	// find the required data from post-data, and match with payment
    	// check reciever email must be same.
    	if($this->getAppParam('merchant_email') != $data['receiver_email']) {
            $errors[] = XiText::_('COM_PAYPLANS_INVALID_PAYPAL_RECEIVER_EMAIL');
        }

        // check payment key
    	if($payment->getKey() != $data['invoice']) {
            $errors[] = XiText::_('COM_PAYPLANS_INVALID_PAYPAL_PAYMENT_KEY');
        }

        // check the stored amount against the payment amount
        $stored_amount = number_format($order->getTotal(),2);
        if ((float) $stored_amount !== (float) $data['mc_gross']) {
            $errors[] = XiText::_('COM_PAYPLANS_INVALID_PAYPAL_PAYMENT_TOTAL');
        }
        // update the payment amount
        $payment->set('amount', (float) $data['mc_gross']);


        // check and update payment status
        if($data['payment_status'] == 'Completed'){
        	$payment->set('status',XiStatus::PAYMENT_COMPLETE);

        }elseif($data['payment_status'] == 'Pending'){
        	$payment->set('status',XiStatus::PAYMENT_PENDING);
        }
        else{
        	$errors[] = XiText::_('COM_PAYPLANS_INVALID_PAYPAL_PAYMENT_STATUS');
        }


        //XITODO : Add TXN_ID and PARENT_TXN_ID fields in table
		if(count($errors)){
			$payment->set('status', XiStatus::PAYMENT_PENDING);
		}

    	//store the response in the payment AND save the payment
		$payment->set('transaction',PayplansHelperParam::arrayToIni($data))
				->save();

		//if error present in the transaction then redirect to error page
		if(!empty($errors)){
			$message = XiText::_('COM_PAYPLANS_LOGGER_ERROR_IN_PAYPAL_PAYMENT_PROCESS');
			$log_id = PayplansHelperLogger::log(XiLogger::LEVEL_ERROR, $message, $payment, $errors);

		}
	
        return $errors;
    }


    /**
     * All events need to be implemented
     */
	public function onPayplansPaymentBefore()
	{
		return true;
	}

	public function onPayplansPaymentForm(PayplansPayment $payment, $data = null)
	{
		if(is_object($data)){
			$data = (array)$data;
		}

		$order = $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		
		// assign variables for templates
		$this->assign('payment', $payment);
		$this->assign('order',   $order);
		
		$this->assign('merchant_email',$this->getAppParam('merchant_email'));
		$this->assign('merchant_id',$this->getAppParam('merchant_id',false));
		$this->assign('currency',$this->getAppParam('currency',false));

		// build urls
    	$sandbox = $this->getAppParams()->get('sandbox',false) ? 'sandbox.' : '';

    	$this->assign('post_url', $this->_getPaypalUrl());
    	$this->assign('return_url', XiRoute::_('index.php?option=com_payplans&view=order&task=complete&action=success&order_key='.$order->getKey().'&payment_key='.$payment->getKey()));
    	$this->assign('cancel_url', XiRoute::_('index.php?option=com_payplans&view=order&task=complete&action=cancel&order_key='.$order->getKey().'&payment_key='.$payment->getKey()));
    	$this->assign('notify_url', XiRoute::_('index.php?option=com_payplans&view=order&task=notify&order_key='.$order->getKey().'&payment_key='.$payment->getKey()));

        // render as per requirement of payment type
        /*  _xclick : The button that the person clicked was a Buy Now button.
         * _donations : The button that the person clicked was a Donate button.
         * _xclick-subscriptions : The button that the person clicked was a Subscribe button.
         * _cart : For shopping cart purchases; these additional variables specify the kind of shopping cart button that the person clicked:
         */

        // XITODO : need to change when multiple subscription is available
        $plan = array_shift($payment->getPlans(PAYPLANS_INSTANCE_REQUIRE));
        $time = $this->getRecurrenceTime($plan->getExpiration());
        $this->assign('period', $time['period']);
        $this->assign('unit', $time['unit']); 
        $this->assign('recurrence_count', $plan->getRecurrenceCount());  // XITODO : 0 is default value
        if($this->_isRecurring($payment)){
			//XITODO : why .plz comment
        	$payment->set('status', XiStatus::PAYMENT_RECURRING_START)->save();
        	return $this->_render('form_subscription');
        }
        
        return $this->_render('form_buynow');
	}
	
	public function getRecurrenceTime($expTime)
	{
		$expTime['year'] = isset($expTime['year']) ? intval($expTime['year']) : 0;
		$expTime['month'] = isset($expTime['month']) ? intval($expTime['month']) : 0;
		$expTime['day'] = isset($expTime['day']) ? intval($expTime['day']) : 0;;
		
		// years
		if(!empty($expTime['year'])){
			if($expTime['year'] >= 5){
				return array('period' => 5, 'unit' => 'Y');
			}
			
			if($expTime['year'] >= 2){
				return array('period' => $expTime['year'], 'unit' => 'Y');
			}
			
			// if months is not set then return years * 12 + months
			if(isset($expTime['month']) && $expTime['month']){
				return array('period' => $expTime['year'] * 12 + $expTime['month'], 'unit' => 'M');
			}				
			
			return array('period' => $expTime['year'], 'unit' => 'Y');
		}
		
		// if months are set
		if(!empty($expTime['month'])){
			// if days are empty
			if(empty($expTime['day'])){
				return array('period' => $expTime['month'], 'unit' => 'M');
			}
			
			// if total days are less or equlas to 90, then return days
			//  IMP : ASSUMPTION : 1 month = 30 days
			$days = $expTime['month'] * 30;
			if(($days + $expTime['day']) <= 90){
				return array('period' => $days + $expTime['day'], 'unit' => 'D');
			}
			
			// other wise convert it into weeks
			return array('period' => intval(($days + $expTime['day'])/7, 10), 'unit' => 'W');
		}
		
		// if only days are set then return days as it is
		if(!empty($expTime['day'])){
			return array('period' => intval($expTime['day'], 10), 'unit' => 'D');
		}
		
		// XITODO : what to do if not able to convert it
		return false;
	}

	public function onPayplansPaymentAfter(PayplansPayment $payment, $action, $data, $controller)
	{
		$record = array_pop(PayplansHelperLogger::getLog($payment, XiLogger::LEVEL_ERROR));			
		if($record && !empty($record)){
			$action = 'error';
		}
		
		return parent::onPayplansPaymentAfter($payment, $action, $data, $controller);
	}

	public function onPayplansPaymentNotify(PayplansPayment $payment, $data, $controller)
	{
		$errors = array();
		$order = $payment->getOrder(PAYPLANS_INSTANCE_REQUIRE);
		
		// is it a valid records, ask to paypal
    	if($this->_validateIPN($data) == false){
    		$errors[] = XiText::_('COM_PAYPLANS_INVALID_IPN');
    		$message = XiText::_('COM_PAYPLANS_LOGGER_PAYMENT_INVALID_IPN');
    		PayplansHelperLogger::log(XiLogger::LEVEL_ERROR, $message, $payment, $errors);
    		return "INVALID IPN";
    	}
    	
//		switch ( $data['txn_type'] ) {
//			// below two txn_tyoe are same
//			case "web_accept":
//			case "subscr_payment":
//				break;
//			case "subscr_signup":
//			case "subscr_cancel":
//			case "subscr_modify":
//				// Docs suggest mc_amount1 is set with signup, cancel or modify
//				// Testing shows otherwise
//				$data['mc_gross'] = isset($data['mc_amount3']) ? $data['mc_amount3'] : null;
//			break;
//			case "subscr_failed":
//			case "subscr_eot":
//				// May create a problem somewhere donw the line, but NULL
//				// is a more representative value
//			break;
//			default:
//			// Either a fraud attempt, or PayPal has changed its API
//			// XITODO: Raise Error
//			$data['mc_gross'] = null;
//		}
		
    	$func_name = '_process_'.$data['txn_type'];
		//XITODO : check if method exists
    	$errors = $this->$func_name($order, $payment, $data);

		return count($errors) ? implode("\n", $errors) : ' No Errors';
	}

	public function onPayplansPaymentCustom(PayplansPayment $payment, $data=null)
	{
		return true;
	}

	public function onPayplansPaymentBeforeSave(PayplansPayment $prev=null, PayplansPayment $new=null, $data = null)
	{
		return true;
	}
	
	public function onPayplansPaymentAfterSave(PayplansPayment $prev=null, PayplansPayment $new=null, $data = null)
	{
		return true;
	}
	
	protected function _process_web_accept($order, $payment, $data)
	{
		return $this->_processNotification($payment, $data);
	}
	//XITODO : cros check subscr_id
	protected function _process_subscr_payment($order, $payment, $data)
	{		
		$newPayment = $order->createPayment($this->getId());
		
		// change the invoice key as this is a recurring paymnet 
		// and each time new payment will be created
		$data['invoice'] = $newPayment->getKey();
		$errors = $this->_processNotification($newPayment, $data);
		return $error;		
	}
	
	protected function _process_subscr_signup($order, $payment, $data)
	{
		$payment->set('status', XiStatus::PAYMENT_RECURRING_SIGNUP)
				->set('transaction',PayplansHelperParam::arrayToIni($data))
				->save();
		return true;
	}
	
	protected function _process_subscr_cancel($order, $payment, $data)
	{
		$payment->set('status', XiStatus::PAYMENT_RECURRING_CANCEL)->save();
		$order->set('status', XiStatus::ORDER_HOLD)->save();
		return true;
	}
	
	protected function _process_subscr_modify($order, $payment, $data)
	{
		// XITODO : what to do here
	}
	
	protected function _process_subscr_failed($order, $payment, $data)
	{
		$paymet->set('status', XiStatus::PAYMENT_RECURRING_FAILED);
		$order->set('status', XiStatus::ORDER_HOLD);		
		return true;
	}
	
	protected function _process_subscr_eot($order, $payment, $data)
	{
		$paymet->set('status', XiStatus::PAYMENT_RECURRING_EOT);
		$order->set('status', XiStatus::ORDER_EXPIRED);
		return true;
	}
}

/**
 *
 * <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
 * <input type="hidden" name="cmd" value="_cart">
 * <input type="hidden" name="business" value="seller@designerfotos.com">
 * <input type="hidden" name="item_name" value="hat">
 * <input type="hidden" name="item_number" value="123">
 * <input type="hidden" name="amount" value="15.00">
 * <input type="hidden" name="first_name" value="John">
 * <input type="hidden" name="last_name" value="Doe">
 * <input type="hidden" name="address1" value="9 Elm Street">
 * <input type="hidden" name="address2" value="Apt 5">
 * <input type="hidden" name="city" value="Berwyn">
 * <input type="hidden" name="state" value="PA">
 * <input type="hidden" name="zip" value="19312">
 * <input type="hidden" name="night_phone_a" value="610">
 * <input type="hidden" name="night_phone_b" value="555">
 * <input type="hidden" name="night_phone_c" value="1234">
 * <input type="image" name="submit" border="0" src="https://www.paypal.com/en_US/i/btn/btn_buynow_LG.gif" alt="PayPal - The safer, easier way to pay online">
 * </form>
 */
/**
notify_url :
  The URL to which PayPal posts information about the transaction, in the form of Instant Payment Notification messages.
  Limit = 255


---- item -----
item_name : 127 char
amount :
item_number : subscription_id : 127 char

----transaction-----
currency_ code : 3 digit code
custom - the variable return to website 256 char
invoice : invoice number 127 digit


--- cart
business : merchant id / email address
paymentaction=sale
shopping_url=return url

---for subscribe

 */


   /* TYPICAL RESPONSE FROM PAYPAL INCLUDES:
       * mc_gross=49.99
       * &protection_eligibility=Eligible
       * &address_status=confirmed
       * &payer_id=Q5HTJ93G8FQKC
       * &tax=0.00
       * &address_street=10101+Some+Street
       * &payment_date=12%3A13%3A19+Dec+05%2C+2008+PST
       * &payment_status=Completed
       * &charset=windows-1252
       * &address_zip=11259
       * &first_name=John
       * &mc_fee=1.75
       * &address_country_code=US
       * &address_name=John+Doe
       * &custom=some+custom+value
       * &payer_status=verified
       * &business=receiver%40domain.com
       * &address_country=United+States
       * &address_city=Some+City
       * &quantity=1
       * &payer_email=sender%40emaildomain.com
       * &txn_id=3JK16594EX581780W
       * &payment_type=instant
       * &payer_business_name=John+Doe
       * &last_name=Doe
       * &address_state=CA
       * &receiver_email=receiver%40domain.com
       * &payment_fee=1.75
       * &receiver_id=YG9UDRP6DE45G
       * &txn_type=web_accept
       * &item_name=Name+of+item
       * &mc_currency=USD
       * &item_number=Number+of+Item
       * &residence_country=US
       * &handling_amount=0.00
       * &transaction_subject=Subject+of+Transaction
       * &payment_gross=49.99
       * &shipping=0.00
       * &=
       * */
