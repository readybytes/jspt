<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Google Analytics E-Commerce Tracking
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansAppGanalytics extends PayplansApp
{
	protected $_location	= __FILE__;
	
	public function isApplicable($refObject = null, $eventName='')
	{
		// if not with reference to payment then return
		if($refObject === null || !($refObject instanceof PayplanssiteViewOrder) 
				|| $eventName != 'onPayplansViewAfterRender'){
			return false;
		}
	
		$newRefObject = PayplansOrder::getInstance($refObject->getModel()->getId());
		return parent::isApplicable($newRefObject, $eventName);
	}
	
	
	public function onPayplansViewAfterRender(XiView $view, $task, $output)
	{
		$action = JRequest::getVar('action');
		if($task !== 'complete' && $action != 'success'){
			return true;
		}

		$this->assign('ga_id', $this->getAppParam('ga_id'));
		
		$order = PayplansOrder::getInstance($view->getModel()->getId());
		$payment = $order->getPayments();
		
		$this->assign('payment',array_pop($payment));
		$this->assign('order',$order);
		$this->assign('subscriptions',$order->getSubscriptions());
		
		$script = $this->_render('script');
		
		// add javascript to document object
		XiFactory::getDocument()->addScriptDeclaration($script);
		
		return true;
	}
}