<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Google Analytics E-Commerce Tracking
* @contact 		shyam@readybytes.in
*/
// refer http://code.google.com/apis/analytics/docs/tracking/gaTrackingEcommerce.html
if(defined('_JEXEC')===false) die(); ?>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', '<?php echo $ga_id; ?>']);
  _gaq.push(['_trackPageview']);
  
  _gaq.push(['_addTrans',
    '<?php echo $order->getKey(); ?>',
    'Subscriptions Powered By JPayPlans',
    '<?php echo $order->getTotal(); ?>'
  ]);

	<?php foreach ($subscriptions as $sub):?>
	  _gaq.push(['_addItem',
	    '<?php echo $order->getKey(); ?>',
	    '<?php echo array_shift($sub->getPlans()); ?>',
	    '<?php echo $sub->getTitle();; ?>',
	    '<?php echo '';?>', // future addition of category
	    '<?php echo $sub->getParams()->get('price'); ?>',   // IMP Need Raw price, not formatted : unit price - required
	    '1'               // quantity - required
	  ]);
  	<?php endforeach;?>
  
  _gaq.push(['_trackTrans']); //submits transaction to the Analytics servers

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(ga);
  })();

</script>
<?php 
/**
 IMPORTANT : 
The values for the price and total parameters must be supplied as integers, 
and are not affiliated with any currency value. For these parameters, either 
a comma or a period in the value indicates a fractional value. So, for example, 
if you provide 1,996.00 as the value for the total, it is recorded as 1.996, 
not as $1,996.00. This is because the format for this parameter is a simple 
integer format and commas and other currency indicators are not recognized. 
In addition, because these values are recorded as integers, there is no association
with any currency. Consequently, any currency conversion that you require must
be first handled by your ecommerce software before you pass the data to Analytics.
 
 
 */