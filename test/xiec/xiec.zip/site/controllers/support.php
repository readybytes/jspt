<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplanssiteControllerSupport extends XiController
{
	protected 	$_defaultTask = 'notask';
  
	function emailform($user = null)
	{
		return true;
	}
	
	function sendemail()
	{
		$args 	= JRequest::getVar('arg1', '');

		// IMP : we are working for ajax only for now
		if(JRequest::getBool('isAjax',	false) == false){
			return false;
		}
		
		//if it is an ajax request, decode the args
		$args	= json_decode($args);
				
		$subject = $args[0];
		$from	 = $args[1];
		$body	 = $args[2];		
		
		$admins = XiHelperJoomla::getUsersToSendSystemEmail();		
		
		$first = array_shift($admins);
		// get other super admin users email
		$cc = null;
		foreach ( $admins as $admin )
		{
			$cc[] = $admin->email;
		}
		
		if(!JUtility::sendMail($from, $from, $first->email, $subject, $body, 0, null, $cc)){
			$this->setTemplate('error');
			return true;
		}
		
		$this->setTemplate('sent');
		return true;
	}
}

