<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplanssiteControllerOrder extends XiController
{
	protected 	$_defaultTask = 'display';
	
	/*
	 * expects key instead of id
	 */
    protected   $_requireKey  = true;
    
	function display($userId = null)
	{
		$userId = XiFactory::getUser($userId)->id;

		//if user is not logged in
		// currently sending to login page
		if(!$userId){
			$return	= JURI::getInstance()->toString();
			$url    = 'index.php?option='.PAYPLANS_COM_USER.'&view=login';
			$url   .= '&return='.base64_encode($return);
			$this->setRedirect($url, XiText::_('COM_PAYPLANS_ORDER_YOU_MUST_LOGIN_FIRST'));
			return false;
		}

		$this->setTemplate('display');
		return true;
	}

	/**
	 * Show confirmation page.
	 * Generally send to Cart of Payplans
	 */
 	public function confirm()
       {
               $orderId = $this->getModel()->getId();
               $order         = PayplansOrder::getInstance( $orderId);
               
               // if order is not valid then redirect to plan page
               if(!$orderId){
                       $this->setMessage(XiText::_('COM_PAYPLANS_ORDER_PLEASE_SELECT_A_VALID_PLAN'));
                       $this->setRedirect(XiRoute::_("index.php?option=com_payplans&view=plan"));
                       return false;
               }
                       
               //if order is for free plan then redirect to complete order page
               if(floatval(0) == floatval($order->getSubtotal())){
                       $this->setRedirect(XiRoute::_('index.php?option=com_payplans&view=order&task=complete&order_key='.$order->getKey()),false);
                       return false;
               }

               // data is not post then show order details
               if(JRequest::getVar('payplans_order_confirm_btn', 'BLANK', 'POST') === 'BLANK'){
                       //else get order confirmation page
                       $this->setTemplate(__FUNCTION__);
                       return true;
               }

               // if order is confirmed then redirect to app
               // with orderid, appid, and function name which is to be called for app
               $appId   = JRequest::getVar('app_id', 0);
               XiError::assert($appId, XiText::_('COM_PAYPLANS_ERROR_INVALID_APP_ID'));

               //confirm order and create payment
               $order->confirm($appId);
               // get payemnt created
               $payment = $order->getPayment();

               $url = 'index.php?option=com_payplans&view=payment&task=pay&payment_key='.$payment->getKey();
               $this->setRedirect(XiRoute::_($url, false));
               return false;
       }
	

	/**
	 * After completion of payment process
	 * Show some message to user.
	 * @param unknown_type $paymentId
	 */
	public function complete()
	{
		//load order record
		$orderId = $this->getModel()->getId();
		
		XiError::assert($orderId, XiText::_('COM_PAYPLANS_ERROR_INVALID_ORDER_ID'));
		$order = PayplansOrder::getInstance($orderId);	
		
		//XITODO : V IMP : should have check on getTotal
		// if its free plan, then no need to get payment key
		if(floatval(0) == floatval($order->getSubtotal())){
			$this->setTemplate('success');
			$order->complete();
			return true;
		}
		
		// get payment key form posted data
		$paymentKey = JRequest::getVar('payment_key', false);
		XiError::assert($paymentKey, XiText::_('COM_PAYPLANS_ERROR_INVALID_PAYMENT_ID'));
		
		$payment = PayplansPayment::getInstance(XiFactory::getEncryptor()->decrypt($paymentKey));
			
		// set template success, so application can change it if required.
		$action = JRequest::getVar('action','success');
		$this->setTemplate($action);

		// trigger apps, so they can do postpayment work
		$post = JRequest::get('POST');
		$args = array($payment, $action, &$post, $this);
		$appCompleteHtml = PayplansHelperEvent::trigger('onPayplansPaymentAfter',$args,'payment',$payment);

		// assign appCompleteHtml to view // XITODO : clean it
		$this->getView()->assign('appCompleteHtml', $appCompleteHtml);

		return true;
	}

	/**
	 * It is notification of payment recieved from Banks/Paypal
	 * that some one has made payment, so we should process it and
	 * update the status of payment
	 * 
	 * V V IMP : App must decide how to find order key and payment key.
	 * App must work on onPayplansControllerCreation
	 * If orderkey and payment key is not known.
	 *
	 * @param array $post
	 */
	public function notify($post=null)
	{
		//load order record
		$orderId = $this->getModel()->getId();
		
		XiError::assert($orderId, XiText::_('COM_PAYPLANS_ERROR_INVALID_ORDER_ID'));
		$order = PayplansOrder::getInstance($orderId);	
		
		// get payment key form posted data
		$paymentKey = JRequest::getVar('payment_key', false);
		XiError::assert($paymentKey, XiText::_('COM_PAYPLANS_ERROR_INVALID_PAYMENT_ID'));
		
		$payment = PayplansPayment::getInstance(XiFactory::getEncryptor()->decrypt($paymentKey));

		$post = $post ? $post : JRequest::get('POST');
		if(JDEBUG){
			// When debug mode is on dump in file
			file_put_contents(JPATH_SITE.DS.'tmp'.DS.time(), var_export($post,true), FILE_APPEND);
		}

		$args = array($payment, $post, $this);
		$results = PayplansHelperEvent::trigger('onPayplansPaymentNotify',$args,'payment',$payment);

		foreach($results as $result){
			if($result === false){
				// some problem here
			}

			// echo the output
			if($result !== true){
				echo $result;
			}
		}

		// no need to generate payment view, its already done via app
		return false;
	}
	
	public function trigger($event=null,$args=null)
	{
		parent::trigger($event,$args);
	}
}

