<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplanssiteControllerPayment extends XiController
{
	protected 	$_defaultTask = 'notask';

	/*
	 * expects key instead of id
	 */
    protected   $_requireKey  = true;

	/**
	 * Collect payment for given payment key
	 */
	public function pay()
	{
		//load payment record
		$paymentId = $this->getModel()->getId();
		XiError::assert($paymentId,XiText::_('COM_PAYPLANS_ERROR_INVALID_PAYMENT_ID'));
		$payment = PayplansPayment::getInstance( $paymentId);

		//trigger all payment apps only
		$post = JRequest::get('POST');
		$args = array($payment,$post);
		$results = PayplansHelperEvent::trigger('onPayplansPaymentForm',$args,'payment',$payment);
		$resultHtml = array();
		// for testing purpose
		if(!defined('PAYPLANS_UNIT_TEST_MODE')){
			//XITODO : use implode
			foreach($results as $result){
				if($result == false){
					//XITODO: some problem here tackle it
					continue;
				}
				// echo the output, if it is not true but Html
				if($result !== true){
					$resultHtml[] = $result;
				}			
			}
		}
		$this->setTemplate('pay');
		$this->getView()->assign('result', $resultHtml);
		// no need to generate payment view, its already done via app
		return true;
	}

	/**
	 * Custom action to be triggered on payment application
	 *
	 * @param $action
	 * @param $paymentId
	 */
	public function custom($action=null, $paymentId=null, $post=null)
	{
		//load payment record
		$paymentId = $this->getModel()->getId();
		XiError::assert($paymentId,XiText::_('COM_PAYPLANS_ERROR_INVALID_PAYMENT_ID'));
		$payment = PayplansPayment::getInstance( $paymentId);

		//collect action to be performed
		//XITODO : Security Check, MUST not start from _
		$action  = JRequest::getVar('action',$action);
		XiError::assert(!empty($action) , XiText::sprintf('COM_PAYPLANS_ERROR_INVALID_ACTION_%s_TO_TRIGGER',$action));

		// trigger apps,
		$post = $post ? $post : JRequest::get('POST');
		$args = array($payment,$post);
		PayplansHelperEvent::trigger($action,$args,'payment',$payment);

		// no need to generate payment view, its already done via app
		return false;
	}
	
	function invoice($userId = null)
	{
		$userId = XiFactory::getUser($userId)->id;

		//if user is not logged in
		// currently sending to login page
		if(!$userId){
			$return	= JURI::getInstance()->toString();
			$url    = 'index.php?option='.PAYPLANS_COM_USER.'&view=login';
			$url   .= '&return='.base64_encode($return);
			$this->setRedirect($url, XiText::_('COM_PAYPLANS_PAYMENT_INVOICE_YOU_MUST_LOGIN_FIRST_TO_VIEW'));
			return false;
		}
		
		$paymentId  = $this->getModel()->getId();
		$payment	= PayplansPayment::getInstance( $paymentId);
		$payment_status = $payment->getStatus();
		$order      = PayplansOrder::getInstance( $payment->getOrder());
		
		//if payment status is either none or started, then redirect to order detail page
		if(in_array($payment_status, array(XiStatus::NONE,XiStatus::PAYMENT_INITIATED))){
			$url = 'index.php?option=com_payplans&view=order&task=display&order_key='.$order->getKey();
			$this->setRedirect(XiRoute::_($url), XiText::_('COM_PAYPLANS_INVOICE_IS_NOT_GENERATED_YET'));
		}
		
		$this->setTemplate(__FUNCTION__);
	}
	
	public function trigger($event=null,$args=null)
	{
		parent::trigger($event,$args);
	}
}