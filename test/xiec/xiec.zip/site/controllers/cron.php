<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplanssiteControllerCron extends XiController
{
	protected 	$_defaultTask = 'trigger';

	// No Model
	public function getModel()
	{
		return null;
	}

	/**
	 * The function called which will trigger the cron action
	 */
	public function trigger()
	{
		header("Content-type: image/png");
	    echo file_get_contents(PAYPLANS_PATH_MEDIA.DS.'images'.DS.'cron.png');
	
 		// IMP : No need to check security, as we can always check if we require to process or not	    

		// check if we need to trigger, dont trigger too frequently
		if(PayplansHelperCron::checkRequired()==false){
			PayplansHelperUtils::markExit('Cron Job NOT REQUIRED');
			return false;
		}

		// trigger plugin and apps
		$args = array();
		PayplansHelperEvent::trigger('onPayplansCron', $args);

		// Mark exit
		$msg = XiText::_('COM_PAYPLANS_LOGGER_CRON_EXECUTED');
		PayplansHelperUtils::markExit($msg);
		PayplansHelperLogger::log(XiLogger::LEVEL_INFO, $msg, null, $msg, 'XiFormatter','Payplans_Cron');

		//XITODO : make it independent of XML file
		$date = new XiDate(); 
		PayplansConfig::getInstance(PAYPLANS_CONFIG_ADVANCE)
			->bind(array('config'=>array('cronAcessTime'=>$date->toUnix())))
			->save();
			
		 // set the header for the image
	   	return false;
	}
}

