<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansHelperUtils
{

	static public function markExit($msg='NO_MESSAGE')
	{
		// if not already set
		if(defined('PAYPLANS_EXIT')==false){
			define('PAYPLANS_EXIT',$msg);
			return true;
		}

		//already set
		return false;
	}
	
	static public function getMethodsDefinedByClass($class)
	{
	    $rClass = new ReflectionClass($class);
	    $array = array();
	    foreach ($rClass->getMethods() as $rMethod)
	    {
	        try
	        {
	            // check whether method is explicitly defined in this class
	            if ($rMethod->getDeclaringClass()->getName()
	                == $rClass->getName())
	            {
	                $array[] =  $rMethod->getName();
	            }
	        }
	        catch (exception $e)
	        {    /* was not in parent class! */    }
	    }
	   
	    return $array;
	}
	
	static public function ignoreImplode($array, $glue= '<br />' , $ignore=array(true,false)){
		$first = true ;
		$return = '';
		foreach ($array as $value) {
			if(in_array($value, $ignore, true))
				continue;
			
			//
			$return .= $value;
		}		
		return $return;
	}
}