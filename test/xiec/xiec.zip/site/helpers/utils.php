<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansHelperUtils
{

	static public function markExit($msg='NO_MESSAGE')
	{
		// if not already set
		if(defined('PAYPLANS_EXIT')==false){
			define('PAYPLANS_EXIT',$msg);
			return true;
		}

		//already set
		return false;
	}
	
	static public function getMethodsDefinedByClass($class)
	{
	    $rClass = new ReflectionClass($class);
	    $array = array();
	    foreach ($rClass->getMethods() as $rMethod)
	    {
	        try
	        {
	            // check whether method is explicitly defined in this class
	            if ($rMethod->getDeclaringClass()->getName()
	                == $rClass->getName())
	            {
	                $array[] =  $rMethod->getName();
	            }
	        }
	        catch (exception $e)
	        {    /* was not in parent class! */    }
	    }
	   
	    return $array;
	}
	
	static public function ignoreImplode($array, $glue= '<br />' , $ignore=array(true,false)){
		$first = true ;
		$return = '';
		foreach ($array as $value) {
			if(in_array($value, $ignore, true))
				continue;
			
			//
			$return .= $value;
		}		
		return $return;
	}
	
	function loadLanguage($extension = '', $basePath = JPATH_BASE)
	{
		if(empty($extension)) {
			$extension = 'plg_'.$this->_type.'_'.$this->_name;
		}

		$lang =& JFactory::getLanguage();
		return $lang->load( strtolower($extension), $basePath);
	}
	
	
	static function pathFS2URL($fsPath='')
	{
		// get reference path from root
		$urlPath	= XiHelperUtils::str_ireplace(JPATH_ROOT.DS, '', $fsPath);
		
		// replace all DS to URL-slash
		$urlPath	= JPath::clean($urlPath, '/');
		
		// prepend URL-root
		return JURI::root().$urlPath;
	}
	
	//XITODO::decrease the parameters
	function saveUploadedFile($storagepath='',$filepath='',$filename='',$supportedExtensions=array(),$savedname="default")
	{
	   //no file selected then do nothing
	   if(empty($filepath))
		  {
		  	return false;
		  }
		
	    $app = XiFactory::getApplication();
		//remove backslashes from file name
		$filename1 = stripslashes($filename);
		//get file extension
	   	$extension = JFile::getExt($filename1);
	   	//to lower case
	  	$extension = strtolower($extension);
	  	//check if file has supported extensions or not
	    if(!in_array($extension, $supportedExtensions))
		   {
			$app->enqueueMessage(XiText::_('COM_PAYPLANS_CONFIG_CUSTOMIZATION_EDIT_EXTENSION_NOT_SUPPORTED'));
		    return false;
		    }
	    //check if folder exist or not. If not exists then create it.
	    if(JFolder::exists(JPATH_ROOT.DS.$storagepath)==false)
			JFolder::create(JPATH_ROOT.DS.$storagepath);
			
	    //select the path for image storage
		$imgname = JPATH_ROOT.DS.$storagepath.DS.$savedname.'.'.$extension;
		 
	    $img1= $storagepath.'/'.$savedname.'.'.$extension;
	    copy($filepath, $imgname);
		
		return $img1;
	}
	
	static $assetsLoaded = false;
	public static function loadAssests()
	{
		if(self::$assetsLoaded === true){
			return true;
		}
		
		self::$assetsLoaded = true;
		

		XiHtml::stylesheet('window.css');
		XiHtml::stylesheet('tipsy.css');
		XiHtml::stylesheet('humane.css');
		XiHtml::stylesheet('combo.css');
		XiHtml::stylesheet('apprise.css');
		
		ob_start();
		?>
		var xi_url_base = '<?php echo JURI::base();?>';
		var xi_time_offset_minutes = <?php echo XiHelperJoomla::getUserTimeZone() * 60;?>;
		<?php
		$script = ob_get_contents();
		ob_end_clean();
		XiFactory::getDocument()->addScriptDeclaration($script);

		// Load Mootools first : It is done automatically by script function
		// Load XI Script (Maintain Order)
		// NoConflict already added in jQuery file,
		//XITODO : jQuery loading should be optional
		XiHtml::script('jquery-1.4.2.js');
		XiHtml::script('xi.script.js');
		XiHtml::script('xi.lib.js');

		return true;
	}
}