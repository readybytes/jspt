<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

/**
 * Class will help tp instantiate multiple joomla xiapps plugin with different paramter
 * @author meenal
 * 
 * XITODO : all functions need renaming
 */

class PayplansHelperApp
{
	/**
	 * Add a path from where we can load Apps
	 * @param string $path
	 */
	static function addAppsPath($path=null)
	{
		static $paths = array(PAYPLANS_PATH_APPS);

//		// This cache cleaning create issue, for non-core apps
//		if(XiFactory::cleanStaticCache()){
//			$paths = array(PAYPLANS_PATH_APPS);
//		}

		if($path != null){
			$paths[]= $path;
		}

		return $paths;
	}

	static $_apps = array(); 
	
	/**
	 * Load Apps from various folders
	 * @return Array of Apps
	 */
	static function getApps()
	{
		//already loaded
		if(self::$_apps){
			return self::$_apps;
		}

		//load apps from file systems
		foreach(self::addAppsPath() as $path){
			$newApps = JFolder::folders($path);
			
			if(!is_array($newApps)){
				continue;
			}

			// add to new apps discovered into list (only if app file exist in folder) 
			// also mark them autoload
			foreach($newApps as $app){
				if(JFile::exists($path.DS.$app.DS.$app.'.php')==true){
					PayplansHelperLoader::addAutoLoadFile($path.DS.$app.DS.$app.'.php',
								'PayplansApp'.JString::ucfirst($app));
					
					self::$_apps[$app] = $app;
				}
			}
		}
		
		//do it after complete autloading
		foreach(self::$_apps as $app){
			self::checkAppSetup($app, 'PayplansApp'.JString::ucfirst($app));
		}
		
		// also sort for consistent behaviour
		sort(self::$_apps);
		return self::$_apps;
	}

	/**
	 * return Apps of given purpose e.g. payment
	 * In Default value return all apps
	 * @param string purpose
	 * @return Array of particular Purpose Apps
	 */
	static function getPurposeApps($purpose='')
	{
		static $purposeApps = array();

		$allApps 	 = self::getApps();

		// Return all apps
		if($purpose == ''){
			return $allApps;
		}

		//XITODO : implement cache clean
		// if already cached
		if(isset($purposeApps[$purpose]))
			return $purposeApps[$purpose];

		// not cached, add all classes
		$purposeApps[$purpose] = array();
		$purposeClass	= 'PayplansApp'.JString::ucfirst($purpose);
		foreach($allApps as $app){
			$appClass 		= 'PayplansApp'.JString::ucfirst($app);

			// bug in php, subclass having issue with autoloading multiple chained classes
			// http://bugs.php.net/bug.php?id=51570
			class_exists($appClass, true);

			if(is_subclass_of($appClass, $purposeClass)){
				$purposeApps[$purpose][] = $app;
			}
		}

		return $purposeApps[$purpose];
	}

	/**
	 * Load all the apps in the system
	 * means creating object of every app in table
	 * @return Array PayplansApp
	 */
	static function loadApps()
	{
		static $instances = null;

		//clean cache if required, required during testing
		if(XiFactory::cleanStaticCache()){
			$instances = null;
		}

		if($instances === null)
		{
			//at least load all classes
			self::getApps();

			//now load all records
			$queryFilters = array('published'=>1);
			$apps = XiFactory::getInstance('app', 'model')->loadRecords($queryFilters);

			//XITODO trigger on before load apps event to plugin

			$instances = array();
			foreach($apps as $app){
				//IMP : $app should be given, so it can bind with it rather then loading the data
				$instance = PayplansApp::getInstance( $app->app_id, $app->type, $app);
				if($instance === FALSE){
					continue;
				}
				
				$instances[$app->app_id] = $instance; 
			}

			//trigger on after load apps event to plugin
			$args	= array(&$instances);
			XiHelperPlugin::trigger('onPayplansAppsAfterLoad',$args);
		}

		return $instances;
	}

	/**
	 * Trigger all apps instances
	 * @param String $eventName
	 * @param array $args
	 * @param String $purpose
	 * @param unknown_type $refObject
	 * @return Array
	 */
	static function trigger($eventName, array &$args=array(), $purpose='',  $refObject=null)
	{
		//get Plugins objects
		$apps = self::loadApps();

		$results = array();

		//trigger all apps if they serve the purpose
		foreach($apps as $app)
		{
			if($app->hasPurpose($purpose) && $app->isApplicable($refObject, $eventName)
					&& method_exists($app, $eventName)){
				$results[$app->getId()] = call_user_func_array(array($app,$eventName), $args);
			}
		}

		return $results;
	}

	/**
	 * @deprecated in 1.2, use getXml instead
	 * XITODO:1.4 This will not be available in 1.4 release. Remove it
	 */
	static function getXmlData($what = 'name')
	{
		$result = array();
		foreach(self::getXml() as $key => $array){
			$result[$key] = isset($array[$what])? $array[$what] : null;
		}
		
		return $result;
	}

	static $tags	= null;
	static public function getTags($merged=false, $what = 'tags')
	{
		if(self::$tags === null){
			self::$tags = array();
			foreach(self::getXml() as $key => $array){
				self::$tags[$key] = isset($array[$what])? $array[$what] : array();
			}
		}
		
		// return only tags
		if($merged){
			$mtags= array();
			foreach(self::$tags as $apptag){
				$mtags = array_merge($mtags, $apptag);
			}
			// only unique and sorted
			return array_values(array_unique($mtags));
		}
		return self::$tags;
	}
	
	
	static $xmlData = null;
	static public function getXml()
	{
		$apps = self::getApps();
		
		if(self::$xmlData === null){
			foreach($apps as $app){
				$appInstance = PayplansApp::getInstance( null, $app);
				$xml = $appInstance->getLocation() . DS . $appInstance->getName() . '.xml';
	
				$parser		= XiFactory::getXMLParser('Simple');
				// if document not loaded then skip it 
				if($parser->loadFile($xml) != true){
					continue;
				}
	
				// if no tag was defined at least all tag is added
				self::$xmlData[$appInstance->getName()]['tags'] = array('all'); 
				self::$xmlData[$appInstance->getName()]['location'] = $appInstance->getLocation();
				self::$xmlData[$appInstance->getName()]['icon'] = JPATH_ROOT.DS.'components/com_payplans/media/images/icons/48/app.png';
				
				foreach($parser->document->children() as $child){
					$attribute = JString::strtolower($child->_name);
					$value = $child->_data;
					
					if($attribute == 'tags'){
						$value = array_merge(array('all'), explode(',',$value));
					}
					
					if($attribute == 'icon'){
						$value = $appInstance->getLocation().DS.$value;
					}
					
					self::$xmlData[$appInstance->getName()][$attribute] = $value;
				}
			}
		}
		
		return self::$xmlData;
	}
	
	/**
	 * @deprecated Since 1.3 Use getApplicableApps
	 */
	static function getApplicationApps($purpose='', PayplansIfaceApptriggerable $refObject=null)
	{
		return self::getApplicableApps($purpose, $refObject);
	}
	
	/**
	 * 
	 * Get all apps which are of this purpose and 
	 * applicable on this refObject
	 * 
	 * @param String $purpose
	 * @param PayplansIfaceApptriggerable $refObject
	 * @since 1.3
	 */
	static function getApplicableApps($purpose='', PayplansIfaceApptriggerable $refObject=null)
	{
		//get Plugins classes names
		$apps = self::loadApps();

		$results = array();

		//trigger all apps if they serve the purpose
		foreach($apps as $app)
		{
			if($app->hasPurpose($purpose) && $app->isApplicable($refObject)){
				$results[$app->getId()] = $app;
			}
		}

		return $results;
	}

	/**
	 * Get apps instances of given purpose
	 * (Do not checks applicability)
	 * @param String $purpose
	 * @since 1.3
	 */
	static function getAvailableApps($purpose='')
	{
		//get Plugins classes names
		$apps = self::loadApps();

		$results = array();

		//trigger all apps if they serve the purpose
		foreach($apps as $app)
		{
			if($app->hasPurpose($purpose)){
				$results[$app->getId()] = $app;
			}
		}

		return $results;
	}
	
	/**
	 * @deprecated
	 * XITODO : It will be deprecated soon
	 * Enter description here ...
	 * @param $appType
	 * @param $class
	 */
	static public function checkAppSetup($appType, $class)
	{
		static $metadata = null;

		//load metadata table
		$model = XiFactory::getInstance('appmetadata','model');
		if($metadata === null){
			$metadata = $model->loadRecords();
		}
		
		//if record does not exist, create it
		if(!isset($metadata[$appType])){
			$data = new stdClass();
			$data->appmetadata_id = $appType;
			$data->installed	  = 0;
			$data->params 		  = "\n\n";			
			$metadata[$appType]=$data;
		}
		
		// record always exists
		$data = $metadata[$appType];
		if(!($data->installed)){
			// class exists
			if(!class_exists($class, true)){
				return false;
			}
			
			// 	call installation routing if any
			if(method_exists($class, '_install')){
				call_user_func(array($class, '_install'));
			}
			
			// mark it installed
			$data->installed	  = 1;
			$model->save((array)$data, $data->appmetadata_id, $new=true);
		}
		
		return true;
	}
}
