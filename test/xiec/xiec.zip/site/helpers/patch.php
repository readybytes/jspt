<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();

jimport('joomla.filesystem.file');

class PayplansHelperPatch
{
	static function getMapper()
	{
		$_mapper = array();
		// when add new patch update the definition
		$_mapper['START'] = 'secondPatch';
		$_mapper['secondPatch'] = 'patch_enable_plugins';
		$_mapper['patch_enable_plugins'] = 'patch_enable_modules';
		$_mapper['patch_enable_modules'] = 'patch_001_log_table';
		
		$_mapper['patch_001_log_table'] 					= 'patch_002_remove_oldplugins';
		$_mapper['patch_002_remove_oldplugins'] 			= 'patch_003_add_table_appmetadata';
		$_mapper['patch_003_add_table_appmetadata'] 		= 'patch_004_remove_apps_paymenttmpl';
		$_mapper['patch_004_remove_apps_paymenttmpl'] 		= 'patch_005_add_customization_config';
		$_mapper['patch_005_add_customization_config'] 		= 'patch_006_remove_element_editor';
		$_mapper['patch_006_remove_element_editor']   		= 'patch_007_modify_user_table';
		$_mapper['patch_007_modify_user_table']   			= 'patch_008_remove_installer_helpers';
		$_mapper['patch_008_remove_installer_helpers']   	= 'patch_009_add_master_column_in_payment';
		$_mapper['patch_009_add_master_column_in_payment']  = 'patch_010_add_params_columns';
		$_mapper['patch_010_add_params_columns']			= 'patch_011_add_currency_symbol_column';
		$_mapper['patch_011_add_currency_symbol_column']	= 'patch_012_docman_app_migration'; 
		$_mapper['patch_012_docman_app_migration']			= 'patch_013_docman_resource_migration';
		$_mapper['patch_013_docman_resource_migration']		= 'patch_014_k2group_app_migration';
		$_mapper['patch_014_k2group_app_migration']			= 'patch_015_juga_app_migration';
		$_mapper['patch_015_juga_app_migration']			= 'patch_016_juga_resource_migration';
		$_mapper['patch_016_juga_resource_migration']		= 'patch_017_jsmultiprofile_app_migration';
		$_mapper['patch_017_jsmultiprofile_app_migration']  = 'patch_018_xiprofiletype_app_migration';
		$_mapper['patch_018_xiprofiletype_app_migration']	= 'patch_019_jusertype_app_migration';
		$_mapper['patch_019_jusertype_app_migration']		= 'patch_020_jusertype_resource_migration';
		$_mapper['patch_020_jusertype_resource_migration']	= 'patch_021_alter_column_in_resource';
		$_mapper['patch_021_alter_column_in_resource']		= 'END';
		return $_mapper;
	}
	
	static function applyPatches($class='PayplansHelperPatch', $mapper=null)
	{
		if($mapper === null){
			$mapper = self::getMapper();
		}
		
		$nextPatch = XiHelperPatch::queryPatch();
		
		// as we will get the previous patch applied
		$nextPatch= $mapper[$nextPatch]; 
		
		//apply patches
		while($nextPatch !== 'END')
		{
			if(method_exists($class, $nextPatch)===false){
				return false;
			}
			// XITODO : handle false return 
			$result = call_user_func(array($class, $nextPatch));
			//update current patch to database
			XiHelperPatch::updatePatch($nextPatch);
			
			//if some error return false
			if($result === false){
				return false;
			}
			
			//get next patch
			$nextPatch = $mapper[$nextPatch];
		}
		
		return true;
	}

	//do install install.sql
	static function firstPatch()
	{
		return XiHelperPatch::applySqlFile(dirname(__FILE__).DS.'patch'.DS.'sql'.DS.'install.sql');
	}


	//install system data
	static function secondPatch()
	{
		// check if admin payment app already exists 
		// if exists then do nothing other wise insert it
		$query 	= new XiQuery();
		$result = $query->select('app_id')
						->from('#__payplans_app')
						->where(' `type` = "adminpay" ')
						->dbLoadQuery()->loadObjectList();
						
		if(empty($result)){
			$db = XiFactory::getDBO();
			$sql = "INSERT IGNORE INTO `#__payplans_app` 
					(`title`, `type`, `description`, `core_params`, `app_params`, `ordering`, `published`) 
					VALUES
					('Admin Payment', 'adminpay', 'Through this application Admin can create payment from back-end. There is no either way to create payment from back-end. This application can not be created, changed and deleted. And can not be used for fron-end payment.', 'applyAll=1\n\n', '\n', 1, 1)";
			$db->setQuery($sql);
			$db->query();
		}
		
		return XiHelperPatch::applySqlFile(dirname(__FILE__).DS.'patch'.DS.'sql'.DS.'system-data.sql');
	}

	static function patch_enable_plugins($enable=1)
	{
		$plugins = array( 
						array('system',		'payplans'),
					 	array('payplans',	'discount'),
					 	array('payplansmigration',	'acctexp'),
					 	array('payplansmigration',	'ambrasubs'),
					 	array('payplansmigration',	'sample'),
						array('payplansregistration', 'joomla'),
					    array('payplansregistration', 'jomsocial'),
					    array('payplansregistration', 'auto')
					  );
						
		foreach($plugins as $plugin){
			$folder = $plugin[0];
			$pluginName = $plugin[1];
			XiHelperPatch::changePluginState($pluginName, $enable, $folder);
		}

		return true;
	}
	
	static function patch_enable_modules($enable=1)
	{
		$modules	= array(
					'mod_payplans_setup'  		=> 'payplans-admin-dashboard',
					'mod_payplans_migration'  	=> 'payplans-admin-dashboard',
					'mod_payplans_search' 		=> 'payplans-admin-dashboard-bottom',
					'mod_payplans_chart' 		=> 'payplans-admin-dashboard-charts'
				);
		foreach($modules as $module=>$position){
			XiHelperPatch::changeModuleState($module, $position, $enable);
		}

		// special case order mod_payplans_setup at least order
		XiHelperPatch::changeModuleOrder(-100, 'mod_payplans_setup');
		return true;
	}
	
	// add log table
	static function patch_001_log_table()
	{
		//add log table
		return XiHelperPatch::applySqlFile(dirname(__FILE__).DS.'patch'.DS.'sql'.DS.__FUNCTION__.'.sql');
	}
	
	// Remove obsolete plugins to reduce the errors.
	static function patch_002_remove_oldplugins()
	{
		// 4 payplans plugins (core/ambrasubs/acctexp/sample)
		XiHelperPatch::uninstallPlugin('core','payplans');
		XiHelperPatch::uninstallPlugin('sample','payplans');
		XiHelperPatch::uninstallPlugin('ambrasubs','payplans');
		XiHelperPatch::uninstallPlugin('acctexp','payplans');
	}
	
	// Add App Installer level utility
	static function patch_003_add_table_appmetadata()
	{
		//add log table
		return XiHelperPatch::applySqlFile(dirname(__FILE__).DS.'patch'.DS.'sql'.DS.__FUNCTION__.'.sql');
	}
	
	static function patch_004_remove_apps_paymenttmpl()
	{
		$dirsToRemove = array('ganalytics', 'adminpay', '2checkout', 'authorize', 'offlinepay', 'paypal', 'googlecheckout');
		foreach($dirsToRemove as $dir){
			if(JFolder::exists(JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'libraries'.DS.'app'.DS.$dir)){
				JFolder::delete(JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'libraries'.DS.'app'.DS.$dir);
			}			
		}
		
		$filesToRemove = array('cancel', 'success', 'error', 'triggered');
		foreach($filesToRemove as $file){
			if(JFile::exists(JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'templates'.DS.'default'.DS.'payment'.DS.'default_'.$file.'.php')){
				JFile::delete(JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'templates'.DS.'default'.DS.'payment'.DS.'default_'.$file.'.php');
			}			
		}
	}
	
	static function patch_005_add_customization_config()
	{
		//insert customization params to config
		return XiHelperPatch::applySqlFile(dirname(__FILE__).DS.'patch'.DS.'sql'.DS.__FUNCTION__.'.sql');
	}
	
	static function patch_006_remove_element_editor()
	{
		if(JFile::exists(JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'elements'.DS.'editor.php')){
				JFile::delete(JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'elements'.DS.'editor.php');
		}
		return true;	
	}
	
	//modification in payplans_user table.. as from version 1.2, table contain more columns
	static function patch_007_modify_user_table()
	{
		$db		= JFactory::getDBO();
		$query	= "ALTER TABLE `#__payplans_user` ".
				  " ADD COLUMN `address` VARCHAR(255) NOT NULL DEFAULT '' , ".
				  " ADD COLUMN `state` VARCHAR(255)  NULL DEFAULT '' , ".
				  " ADD COLUMN `city` VARCHAR(255)  NULL DEFAULT '' , ".
				  " ADD COLUMN `country` INT(11) NOT NULL DEFAULT '0' , ".
				  " ADD COLUMN `zipcode` VARCHAR(10) NOT NULL DEFAULT '', ".
				  " ADD COLUMN `preference` TEXT NOT NULL DEFAULT '' ";
				
		$db->setQuery($query);
		if(!$db->query())
			return false;
		
		return true;	
	}
	
	static function patch_008_remove_installer_helpers()
	{
		XiHelperPatch::removeFile(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_payplans'.DS.'installer'.DS.'helper.php');		
				
		// remove installer patches and helper folder
		XiHelperPatch::removeDir(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_payplans'.DS.'installer'.DS.'patches');
		XiHelperPatch::removeDir(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_payplans'.DS.'installer'.DS.'helper');
	}
	
	static function patch_009_add_master_column_in_payment()
	{
		// add is_master column 
		// add cunsumed column
		
		$db		= JFactory::getDBO();
		$query	= "ALTER TABLE ".$db->nameQuote('#__payplans_payment')." ".
				  " ADD COLUMN ".$db->nameQuote('master')." TINYINT(1) NULL DEFAULT 0 , ".
				  " ADD COLUMN ".$db->nameQuote('consumed')." TINYINT(1) NULL DEFAULT 0 ";

		$db->setQuery($query);
		if(!$db->query()){
			return false;
		}
		
		// now enter the default value for alread exist data
		
		// CASE 1 : if any payment has the any of recurring payment status 
		//			mark it as master payment
		$query = "UPDATE ".$db->nameQuote('#__payplans_payment')." ".
				 "SET ".$db->nameQuote('master')." = 1 ".
				 "WHERE ".$db->nameQuote('status')." ".
				 "IN (".XiStatus::PAYMENT_RECURRING_CANCEL.", 
				 		".XiStatus::PAYMENT_RECURRING_EOT.",
				 		".XiStatus::PAYMENT_RECURRING_FAILED.",
				 		".XiStatus::PAYMENT_RECURRING_SIGNUP.",
				 		".XiStatus::PAYMENT_RECURRING_START.") ";
		$db->setQuery($query);
		if(!$db->query()){
			return false;
		}
		
		// CASE 2 : set master =1 to all payment, which does not have these recurring payments for the respective orders
		$query = "SELECT ".$db->nameQuote('order_id')." ".
							"FROM ".$db->nameQuote('#__payplans_payment')." ".
							"WHERE ".$db->nameQuote('status')." ".
							"IN (".XiStatus::PAYMENT_RECURRING_CANCEL.", 
						 		".XiStatus::PAYMENT_RECURRING_EOT.",
						 		".XiStatus::PAYMENT_RECURRING_FAILED.",
						 		".XiStatus::PAYMENT_RECURRING_SIGNUP.",
						 		".XiStatus::PAYMENT_RECURRING_START.") ";
		$db->setQuery($query);
		$results = $db->loadObjectList('order_id');
		
		if(!empty($results)){
			$orderIds = array_keys($results);
		}
		
		$query = "UPDATE ".$db->nameQuote('#__payplans_payment')." ".
				 "SET ".$db->nameQuote('master')." = 1 ";
		if(!empty($orderIds)){
			$query .= "WHERE ".$db->nameQuote('order_id')." NOT IN  (".implode(",", $orderIds).") ";
		}
		
		$db->setQuery($query);
		if(!$db->query()){
			return false;
		}
		
		// CASE 3 : set cunsumed =1 to all existing records
		$query = "UPDATE ".$db->nameQuote('#__payplans_payment')." ".					
				 "SET ".$db->nameQuote('consumed')." = 1 ";
		$db->setQuery($query);
		if(!$db->query()){
			return false;
		}
		
		return true;
	}
	
	public static function patch_010_add_params_columns()
	{
		$db		= XiFactory::getDBO();
		$query	= "ALTER TABLE ".$db->nameQuote('#__payplans_order')." ".
				  " ADD COLUMN ".$db->nameQuote('params')." TEXT DEFAULT NULL";
		$db->setQuery($query);
		if(!$db->query()){
			return false;
		}
		
		$query	= "ALTER TABLE ".$db->nameQuote('#__payplans_payment')." ".
				  " ADD COLUMN ".$db->nameQuote('params')." TEXT DEFAULT NULL";

		$db->setQuery($query);
		if(!$db->query()){
			return false;
		}
		return true;
	}
	
	public static function patch_011_add_currency_symbol_column()
	{
		$db		= JFactory::getDBO();
		$query	= "ALTER TABLE ".$db->nameQuote('#__payplans_currency')." ".
				  " ADD COLUMN ".$db->nameQuote('symbol')." CHAR(10) DEFAULT NULL";
		$db->setQuery($query);
		if(!$db->query()){
			return false;
		}
		
		return XiHelperPatch::applySqlFile(dirname(__FILE__).DS.'patch'.DS.'sql'.DS.'patch_011_currency_symbol.sql');
	} 
    
	public static function patch_012_docman_app_migration()
	{
		PayplansHelperPatch::_appMigration('docman', 'addToGroup', 'on_status', 'removeFromGroup');
	}
		
	public static function patch_013_docman_resource_migration()
	{	
		$model = XiFactory::getInstance('app', 'model');
		// now migrtae users to resource table
		$apps  			= $model->loadRecords(array('type' => 'docman'), array('limit'));
		$plansAppModel 	= XiFactory::getInstance('planapp', 'model');
		
		$status = array('addToGroupOnActive' => XiStatus::SUBSCRIPTION_ACTIVE, 
						'addToGroupOnHold'   => XiStatus::SUBSCRIPTION_HOLD, 
						'addToGroupOnExpire' => XiStatus::SUBSCRIPTION_EXPIRED);
			
		$addToGroupOnExpire = array();
		$addToGroupOnActive = array();
		$addToGroupOnHold   = array();
		
		foreach($apps as $app){
			$appParams  = PayplansHelperParam::iniToArray($app->app_params);
			if(!isset($appParams['addToGroupOnActive']) && !isset($appParams['addToGroupOnHold'])
					&& !isset($appParams['addToGroupOnExpire']) ){
				continue;
			}
					
			$coreParams = PayplansHelperParam::iniToArray($app->core_params);
			
			// is core app
			if(isset($coreParams['applyAll']) && intval($coreParams['applyAll']) === 1){
				$plans = PayplansHelperPlan::getPlans(array(), false);
			}
			else{
				// get plans from plan app
				$plans = $plansAppModel->getAppPlans($app->app_id);
			}
			
			if(empty($plans) || count($plans) === 0){
				continue;
			}
			
			foreach(array_keys($status) as $st)
			if(!empty($appParams[$st])){
				${$st}[$appParams[$st]] = isset(${$st}[$appParams[$st]]) ? ${$st}[$appParams[$st]] : array();
				${$st}[$appParams[$st]] = array_merge(${$st}[$appParams[$st]], $plans);
			}
		}
		
		// get all groups 
		$groups = array_keys($addToGroupOnActive);
		$groups = array_merge($groups, array_keys($addToGroupOnHold));
		$groups = array_merge($groups, array_keys($addToGroupOnExpire));
		$groups = array_unique($groups);
		
		foreach($groups as $group){
			$sql = 'INSERT INTO `#__payplans_resource` (`resource`, `value`, `count`, `subscription_ids`, `user_id`) ';
			$sql .= 'SELECT "com_docman.group", '.$group.', 0, GROUP_CONCAT(`subscription_id`) as `subscription_ids`, `user_id` '
					.' FROM `#__payplans_subscription` WHERE ';
				
			$tmpSql = array();
			foreach($status as $key => $value){				
				if(isset(${$key}[$group]) && count(${$key}[$group]) > 0){
					$tmpSql[] = " `plan_id` IN (".implode(',', ${$key}[$group]).") AND `status` = ".$value;
				}
			}
			
			$sql .= implode(" OR ", $tmpSql);
			$sql .= ' GROUP BY `user_id`';

			$db = XiFactory::getDBO();
			$db->setQuery($sql);
			$db->query();
		}	
	}
	
	public static function patch_014_k2group_app_migration()
	{
		PayplansHelperPatch::_appMigration('k2', 'addToGroup', 'on_status');
	}
	
	
	public static function patch_015_juga_app_migration()
	{
		PayplansHelperPatch::_appMigration('juga', 'addToJugaGroup', 'on_status', 'removeFromJugaGroup');
	}
	
	public static function patch_016_juga_resource_migration()
	{	
		$model = XiFactory::getInstance('app', 'model');
		// now migrtae users to resource table
		$apps  			= $model->loadRecords(array('type' => 'juga'), array('limit'));
		$plansAppModel 	= XiFactory::getInstance('planapp', 'model');
		
		$status = array('addToGroupOnActive' => XiStatus::SUBSCRIPTION_ACTIVE, 
						'addToGroupOnHold'   => XiStatus::SUBSCRIPTION_HOLD, 
						'addToGroupOnExpire' => XiStatus::SUBSCRIPTION_EXPIRED);
			
		$addToGroupOnExpire = array();
		$addToGroupOnActive = array();
		$addToGroupOnHold   = array();
		
		foreach($apps as $app){
			$appParams  = PayplansHelperParam::iniToArray($app->app_params);
			if(!isset($appParams['addToGroupOnActive']) && !isset($appParams['addToGroupOnHold'])
					&& !isset($appParams['addToGroupOnExpire']) ){
				continue;
			}
					
			$coreParams = PayplansHelperParam::iniToArray($app->core_params);
			
			// is core app
			if(isset($coreParams['applyAll']) && intval($coreParams['applyAll']) === 1){
				$plans = PayplansHelperPlan::getPlans(array(), false);
			}
			else{
				// get plans from plan app
				$plans = $plansAppModel->getAppPlans($app->app_id);
			}
			
			if(empty($plans) || count($plans) === 0){
				continue;
			}
			
			foreach(array_keys($status) as $st)
			if(!empty($appParams[$st])){
				${$st}[$appParams[$st]] = isset(${$st}[$appParams[$st]]) ? ${$st}[$appParams[$st]] : array();
				${$st}[$appParams[$st]] = array_merge(${$st}[$appParams[$st]], $plans);
			}
		}
		
		// get all groups 
		$groups = array_keys($addToGroupOnActive);
		$groups = array_merge($groups, array_keys($addToGroupOnHold));
		$groups = array_merge($groups, array_keys($addToGroupOnExpire));
		$groups = array_unique($groups);
		
		foreach($groups as $group){
			$sql = 'INSERT INTO `#__payplans_resource` (`resource`, `value`, `count`, `subscription_ids`, `user_id`) ';
			$sql .= 'SELECT "com_juga.group", '.$group.', 0, GROUP_CONCAT(`subscription_id`) as `subscription_ids`, `user_id` '
					.' FROM `#__payplans_subscription` WHERE ';
				
			$tmpSql = array();
			foreach($status as $key => $value){				
				if(isset(${$key}[$group]) && count(${$key}[$group]) > 0){
					$tmpSql[] = " `plan_id` IN (".implode(',', ${$key}[$group]).") AND `status` = ".$value;
				}
			}
			
			$sql .= implode(" OR ", $tmpSql);
			$sql .= ' GROUP BY `user_id`';

			$db = XiFactory::getDBO();
			$db->setQuery($sql);
			$db->query();
		}	
	}
	
	public static function patch_017_jsmultiprofile_app_migration()
	{
		$model = XiFactory::getInstance('app', 'model');
		$apps  = $model->loadRecords(array('type' => 'jsmultiprofile'), array('limit'));

		foreach($apps as $app){
			$appParams = PayplansHelperParam::iniToArray($app->app_params);
			
			$appParams['jsmultiprofile'] = isset($appParams['jsmultiprofile']) ? $appParams['jsmultiprofile'] : '';
			$appParams['on_status']  = isset($appParams['on_status'])  ? $appParams['on_status']  : '';
			
			if(isset($appParams['on_status']) && !empty($appParams['jsmultiprofile'])){
				
				if(XiStatus::SUBSCRIPTION_ACTIVE == $appParams['on_status']){
					$appParams['jsmultiprofileOnActive'] = $appParams['jsmultiprofile'];
				}
				elseif(XiStatus::SUBSCRIPTION_HOLD == $appParams['on_status']){
					$appParams['jsmultiprofileOnHold'] = $appParams['jsmultiprofile'];
				}
				elseif(XiStatus::SUBSCRIPTION_EXPIRED == $appParams['on_status']){
					$appParams['jsmultiprofileOnExpire'] = $appParams['jsmultiprofile'];					
				}
			}
			
			if(empty($appParams['jsmultiprofile'])){
				$app->published = 0;
				$app->description = $app->description.  "\n This app is of no use. We have made some changes in concept. Please check the documentation";
			}
			
			unset($appParams['jsmultiprofile']);
			unset($appParams['on_status']);
			
			$app->app_params = PayplansHelperParam::arrayToIni($appParams);
			$model->save((array) $app , $app->app_id);
		}

	}
	
	public static function patch_018_xiprofiletype_app_migration()
	{
		$model = XiFactory::getInstance('app', 'model');
		$apps  = $model->loadRecords(array('type' => 'xiprofiletype'), array('limit'));

		foreach($apps as $app){
			$appParams = PayplansHelperParam::iniToArray($app->app_params);
			
			$appParams['xiprofiletype'] = isset($appParams['xiprofiletype']) ? $appParams['xiprofiletype'] : '';
			$appParams['on_status']  = isset($appParams['on_status'])  ? $appParams['on_status']  : '';
			
			if(isset($appParams['on_status']) && !empty($appParams['xiprofiletype'])){
				
				if(XiStatus::SUBSCRIPTION_ACTIVE == $appParams['on_status']){
					$appParams['xiprofiletypeOnActive'] = $appParams['xiprofiletype'];
				}
				elseif(XiStatus::SUBSCRIPTION_HOLD == $appParams['on_status']){
					$appParams['xiprofiletypeOnHold'] = $appParams['xiprofiletype'];
				}
				elseif(XiStatus::SUBSCRIPTION_EXPIRED == $appParams['on_status']){
					$appParams['xiprofiletypeOnExpire'] = $appParams['xiprofiletype'];					
				}
			}
			
			if(empty($appParams['xiprofiletype'])){
				$app->published = 0;
				$app->description = $app->description.  "\n This app is of no use. We have made some changes in concept. Please check the documentation";
			}
			
			unset($appParams['xiprofiletype']);
			unset($appParams['on_status']);
			
			$app->app_params = PayplansHelperParam::arrayToIni($appParams);
			$model->save((array) $app , $app->app_id);
		}

	}
	
	public static function patch_019_jusertype_app_migration()
	{
		$model = XiFactory::getInstance('app', 'model');
		$apps  = $model->loadRecords(array('type' => 'jusertype'), array('limit'));

		foreach($apps as $app){
			$appParams = PayplansHelperParam::iniToArray($app->app_params);
			
			$appParams['jusertype'] = isset($appParams['jusertype']) ? $appParams['jusertype'] : '';
			$appParams['on_status']  = isset($appParams['on_status'])  ? $appParams['on_status']  : '';
			
			if(isset($appParams['on_status']) && !empty($appParams['jusertype'])){
				
				if(XiStatus::SUBSCRIPTION_ACTIVE == $appParams['on_status']){
					$appParams['jusertypeOnActive'] = $appParams['jusertype'];
				}
				elseif(XiStatus::SUBSCRIPTION_HOLD == $appParams['on_status']){
					$appParams['jusertypeOnHold'] = $appParams['jusertype'];
				}
				elseif(XiStatus::SUBSCRIPTION_EXPIRED == $appParams['on_status']){
					$appParams['jusertypeOnExpire'] = $appParams['jusertype'];					
				}
			}
			
			if(empty($appParams['jusertype'])){
				$app->published = 0;
				$app->description = $app->description.  "\n This app is of no use. We have made some changes in concept. Please check the documentation";
			}
			
			unset($appParams['jusertype']);
			unset($appParams['on_status']);
			
			$app->app_params = PayplansHelperParam::arrayToIni($appParams);
			$model->save((array) $app , $app->app_id);
		}

	}
	
	
	public static function patch_020_jusertype_resource_migration()
	{	
		if(PAYPLANS_JVERSION_FAMILY == 16){
			
			$model = XiFactory::getInstance('app', 'model');
			// now migrate users to resource table
			$apps  			= $model->loadRecords(array('type' => 'jusertype'), array('limit'));
			$plansAppModel 	= XiFactory::getInstance('planapp', 'model');
			
			$status = array('jusertypeOnActive' => XiStatus::SUBSCRIPTION_ACTIVE, 
							'jusertypeOnHold'   => XiStatus::SUBSCRIPTION_HOLD, 
							'jusertypeOnExpire' => XiStatus::SUBSCRIPTION_EXPIRED);
				
			$jusertypeOnExpire = array();
			$jusertypeOnActive = array();
			$jusertypeOnHold   = array();
			
			foreach($apps as $app){
				$appParams  = PayplansHelperParam::iniToArray($app->app_params);
				if(!isset($appParams['jusertypeOnActive']) && !isset($appParams['jusertypeOnHold'])
						&& !isset($appParams['jusertypeOnExpire']) ){
					continue;
				}
						
				$coreParams = PayplansHelperParam::iniToArray($app->core_params);
				
				// is core app
				if(isset($coreParams['applyAll']) && intval($coreParams['applyAll']) === 1){
					$plans = PayplansHelperPlan::getPlans(array(), false);
				}
				else{
					// get plans from plan app
					$plans = $plansAppModel->getAppPlans($app->app_id);
				}
				
				if(empty($plans) || count($plans) === 0){
					continue;
				}
				
				foreach(array_keys($status) as $st)
				if(!empty($appParams[$st])){
					${$st}[$appParams[$st]] = isset(${$st}[$appParams[$st]]) ? ${$st}[$appParams[$st]] : array();
					${$st}[$appParams[$st]] = array_merge(${$st}[$appParams[$st]], $plans);
				}
			}
			
			// get all groups 
			$groups = array_keys($jusertypeOnActive);
			$groups = array_merge($groups, array_keys($jusertypeOnHold));
			$groups = array_merge($groups, array_keys($jusertypeOnExpire));
			$groups = array_unique($groups);
			
			foreach($groups as $group){
				$sql = 'INSERT INTO `#__payplans_resource` (`resource`, `value`, `count`, `subscription_ids`, `user_id`) ';
				$sql .= 'SELECT "com_user.usergroup", '.$group.', 0, GROUP_CONCAT(`subscription_id`) as `subscription_ids`, `user_id` '
						.' FROM `#__payplans_subscription` WHERE ';
					
				$tmpSql = array();
				foreach($status as $key => $value){				
					if(isset(${$key}[$group]) && count(${$key}[$group]) > 0){
						$tmpSql[] = " `plan_id` IN (".implode(',', ${$key}[$group]).") AND `status` = ".$value;
					}
				}
				
				$sql .= implode(" OR ", $tmpSql);
				$sql .= ' GROUP BY `user_id`';
	
				$db = XiFactory::getDBO();
				$db->setQuery($sql);
				$db->query();
			}	
		}
	}
	
	static function patch_021_alter_column_in_resource()
	{
		$db = XiFactory::getDBO();
		
		$sql = 'SHOW COLUMNS
  				FROM `#__payplans_resource` 
  				WHERE Field = "resource"';
		
  		$db->setQuery($sql);
  		$result = $db->query();
  		
  		// no need to apply patch
  		if(empty($result)){
  			return true;
  		}
  		
  		$sql = "ALTER TABLE `#__payplans_resource` CHANGE `resource` `title`  varchar(255) NOT NULL";
  		$db->setQuery($sql);
  		return $db->query();
	}

    //enbale only system plugin during upgradation
	static function patch_enable_system_plugin($enable=1)
	{
			XiHelperPatch::changePluginState('payplans', $enable, 'system');
            return true;
	}
	
	protected function _appMigration($appType, $addParameter = '', $statusParameter = 'on_status', $removeParameter = '')
	{
		$model = XiFactory::getInstance('app', 'model');
		$apps  = $model->loadRecords(array('type' => $appType), array('limit'));

		foreach($apps as $app){
			$appParams = PayplansHelperParam::iniToArray($app->app_params);
			
			$appParams[$addParameter] = isset($appParams[$addParameter]) ? $appParams[$addParameter] : '';
			$appParams[$statusParameter]  = isset($appParams[$statusParameter])  ? $appParams[$statusParameter]  : '';
			
			if(isset($appParams[$statusParameter]) && !empty($appParams[$addParameter])){
				
				if(XiStatus::SUBSCRIPTION_ACTIVE == $appParams[$statusParameter]){
					$appParams['addToGroupOnActive'] = $appParams[$addParameter];
				}
				elseif(XiStatus::SUBSCRIPTION_HOLD == $appParams[$statusParameter]){
					$appParams['addToGroupOnHold'] = $appParams[$addParameter];
				}
				elseif(XiStatus::SUBSCRIPTION_EXPIRED == $appParams[$statusParameter]){
					$appParams['addToGroupOnExpire'] = $appParams[$addParameter];					
				}
			}
			
			if(empty($appParams[$addParameter])){
				$app->published = 0;
				$app->description = $app->description.  "\n This app is of no use. We have made some changes in concept. Please check the documentation";
			}
			
			// remove removeFromGroup, attToGroup, on_status
			if(!empty($removeParameter)){
				unset($appParams[$removeParameter]);
			}
			
			unset($appParams[$addParameter]);
			unset($appParams[$statusParameter]);
			
			$app->app_params = PayplansHelperParam::arrayToIni($appParams);
			$model->save((array) $app , $app->app_id);
		}
	}
	
}
