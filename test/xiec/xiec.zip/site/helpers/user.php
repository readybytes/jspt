<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansHelperUser
{
	static function getName($userId)
	{
		$user = PayplansUser::getInstance( $userId);
		if($user === false){
			return XiText::_('COM_PAYPLANS_LOGGER_MODIFIER_DELETED');
		}

		return $user->getRealname();
	}
	
	static function getUserName($userId)
	{
		$user = PayplansUser::getInstance( $userId);
		if($user === false){
			return XiText::_('COM_PAYPLANS_LOGGER_MODIFIER_SYSTEM');
		}

		return $user->getUsername();
	}
	
	static function exists($what, $value)
	{
		$db = JFactory::getDBO();
		$query = 'SELECT id FROM #__users WHERE '.$db->nameQuote($what).' = ' . $db->Quote( $value );
		$db->setQuery($query, 0, 1);
		if($db->loadResult()){
			return true;
		}
		
		return false;
	}
	
	static public function getID($payplansRegistration=true)
	{
		$id = XiFactory::getUser()->get('id');

		//get userId from session in case of autoRegistration
		if($id != null && $payplansRegistration){
			$id = XiFactory::getSession()->get('REGISTRATION_USER_ID');
		}
		
		return $id;
	}
	static public function getIP()
	{
		$ip = JRequest::getVar('HTTP_X_FORWARDED_FOR', null, 'SERVER');
		
		if($ip == null){
			$ip = JRequest::getVar('REMOTE_ADDR', null, 'SERVER');
		}

		if($ip == null){
			return XiText::_('COM_PAYPLANS_LOGGER_REMOTE_IP_NOT_DEFINED');
		}
		
		return $ip;
	}
}