<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansHelperLogger
{
	static public function log($level, $message, $object=null, $content=null, $type= 'XiFormatter', $class= 'SYSTEM')
	{
		$logger = XiFactory::getLogger();
		
		$object_id 	= 0;
		if($object && is_object($object)){
			$object_id 	 = method_exists($object, 'getId') ? $object->getId() : 0 ;
			$class 		 = get_class($object);
		}
		
		// always encode the content
		$log['type']	=	$type;
		$log['content'] =	base64_encode(serialize($content));
		$content 		= 	base64_encode(serialize($log));
		return $logger->log($level, $message, $object_id, $class, $content);
	}
	
	//return log entries for the given object and mentioned log-level
	static public function getLog($object=null, $level)
	{
		if($object && is_object($object)){
			$object_id 	 = method_exists($object, 'getId') ? $object->getId() : 0 ;
			$record = XiFactory::getInstance('log', 'model')->loadRecords(array('object_id'=>$object_id, 'level'=>$level));
			return $record;
		}

		return false;
	}
}
