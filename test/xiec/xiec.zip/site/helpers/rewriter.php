<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansHelperRewriter
{
	public static function getRelativeObjects($refObject)
	{
		$obj = array();
		
		if($refObject instanceof PayplansOrder){
			$order = $refObject;
		}
		else{
			$order = $refObject->getOrder(PAYPLANS_INSTANCE_REQUIRE); 
		}	
		
		$obj[] = array_pop($order->getPlans(PAYPLANS_INSTANCE_REQUIRE));
		$obj[] = array_pop($order->getPayments());
		$obj[] = $order->getBuyer(PAYPLANS_INSTANCE_REQUIRE);
		$obj[] = array_pop($order->getsubscriptions());
		$obj[] = $order;
		return $obj;
	} 
}