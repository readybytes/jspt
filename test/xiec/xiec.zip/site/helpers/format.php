<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

//XITODO : On Start Trigger also ask for Formatter Class,
// so 3PD can format the display,
// Or it can be converted into templates

class PayplansHelperFormat
{
	static function country($item, $config=array())
	{
		return $item->title;
	}

	static function currency($item, $config=array())
	{
		return $item->title.' ('. $item->currency_id .')';
	}

	static function amount($amount, $currency, $config=array())
	{
		return " $amount ($currency) ";
	}
	
	static function price($amount)
	{
		$fractionDigitCount = XiFactory::getconfig()->fractionDigitCount;
		
		// XITODO : configuration for rounding the value or not
		return number_format(round($amount, $fractionDigitCount), $fractionDigitCount, '.', '');
	}

//	static function address($item, $config=array())
//	{
//		return 	"{$item->street1} {$item->street2}"
//				.",{$item->city}  {$item->state}"
//				.",{$item->countryid} -{$item->zipcode}";
//
//	}

//	static function status($item, $config=array())
//	{
//		return $item->title;
//	}

	static function user($item, $config=array())
	{
		if(!empty($config)){
			return self::_ops('user', $item, $config);
		}
		
		return $item->realname.' ( '.$item->username.' ) ';
	}

	static function app($item, $config=array())
	{
		return $item->title;
	}

//	static function paymenttype($item, $config=array())
//	{
//		return $item->title;
//	}

	static function planTime($time, $config=array())
	{
		$year = (int) $time['year'];
		$month = (int) $time['month'];
		$day = (int) $time['day'];
		$hour = (int) (isset($time['hour'])?$time['hour'] : 0 ) ;

		$str = '';
		// in case when plan expiration time is not set
		if($year==0 && $month==0 && $day==0 && $hour==0){
			$str = XiText::_('COM_PAYPLANS_PLAN_LIFE_TIME');
			return $str;
		}
		
		$count = 0;
		$onecount = 0;
		
		foreach($time as $key => $value)
		{
			$value = (int)$value;
			$count += $value ? 1 : 0;
			$onecount += $value==1 ? 1 : 0;
		}
		
		$counter = 0;
		foreach($time as $key => $value)
		{
			$value = (int)$value;
			$key = JString::strtoupper($key);
			
			// show values if they are greater than zero only
			if(!$value){
				continue;
			}
				
			$key .= ($value>1) ? 'S':'';
			$valueStr = '';
			if($value > 1 || $count>1){
				$valueStr = $value." ";
			}
			
			$concatStr = $counter ? " ".XiText::_('COM_PAYPLANS_PLANTIME_CONCATE_STRING_AND')." " : '';
			$str .= $concatStr.$valueStr.XiText::_("COM_PAYPLANS_PLAN_{$key}");
			$counter++;
		}

		return $str;
	}
	
	static function order($item, $config=array('prefix'=>false, 'link'=>false, 'admin'=>false, 'attr'=>''))
	{
		return self::_ops('order', $item, $config);
	}
	
	static function subscription($item, $config=array('prefix'=>false, 'link'=>false, 'admin'=>false, 'attr'=>''))
	{
		return self::_ops('subscription', $item, $config);
	}
	
	static function payment($item, $config=array('prefix'=>false, 'link'=>false, 'admin'=>false, 'attr'=>''))
	{
		return self::_ops('payment', $item, $config);
	}
	
	private static function _ops($entity, $item, $config)
	{
		$str = $config['prefix'] ? XiText::_('COM_PAYPLANS_SEARCH_'.JString::strtoupper($entity)).' # ' : '' ;
		
		// show ID in admin
		$id = array('var'=>'key', 'value'=>$item->getKey());
		if($config['admin']){
			$id = array('var'=>'id', 'value'=>$item->getId());	
		}
		
		// add ID in string
		$str .= $id['value'];
		
		// do we need to create link
		if($config['link']){
			$link = XiRoute::_('index.php?option=com_payplans&'."view={$entity}&task=edit&{$id['var']}={$id['value']}");
			$str = XiHtml::link($link, $str, $config['attr']);
		}
		
		return $str;
	}
}