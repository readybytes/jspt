<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansHelperCron
{
	public function getURL()
	{
		// Give public URL
		return JURI::root().'index.php?option=com_payplans&view=cron&task=trigger';
	}
	
	static function doCronEvents()
	{
		// do subscription expiry
		self::doSubscriptionExpiry();
	}

	/*
	 * Expire all
	 */
	static function doSubscriptionExpiry(XiDate $time=null)
	{
		//get all records which need to be marked expired now
		$subscriptions = XiFactory::getInstance('subscription','model')
							->getActiveSubscriptions($time);

		foreach($subscriptions as $sub_id => $subscription){
			$subscription = PayplansSubscription::getInstance($sub_id, null, $subscription);
			// if its a recurring subscription
			if($subscription->isRecurring()){
				$dateExp	= unserialize(serialize($subscription->getExpirationDate()));
				$dateExp->addExpiration(XiFactory::getConfig()->expert_wait_for_payment);
				
				$now = new XiDate();
				if($dateExp->toUnix() > $now->toUnix()){
					continue;
				}
			}
			
			$subscription->setStatus(XiStatus::SUBSCRIPTION_EXPIRED)
						 ->save();
		}

		return true;
	}
	
	public static function checkRequired($config=null)
	{
		if($config === null){
			$config = XiFactory::getConfig();
		}
		
		$frequency 	= $config->cronFrequency;
		$accessTime = $config->cronAcessTime;
		$date 		= new XiDate(); 
		$now 		= $date->toUnix();

		// Debug message
		//echo " (($now - $accessTime) > $frequency) = ".(($now - $accessTime) > $frequency);
		
		return (($now - $accessTime) > $frequency) ;
	}
}