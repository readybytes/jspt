<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Payplans Default Subscription Plan Plugin
 */
class plgPayplansDefaultPlan extends XiPlugin
{
		// joomla 1.6 compatibility
		public function onUserBeforeSave($user, $isnew)
		{
			return $this->onBeforeStoreUser($user, $isnew);
		}

		/*
		 * if new user then maintain into session to avoid conflict with jspt process
		 */
		public function onBeforeStoreUser($user, $isnew)
		{
			if($isnew){
				XiFactory::getSession()->set('DEFAULT_PLAN_NEW_USER', true);
			}

			return true;
		}

		// Joomla 1.6 compatibility
		public function onAfterStoreUser($user, $new)	
		{
	 	    return $this->onUserAfterSave($user, $new);
		}
		
		function onUserAfterSave($user, $new)
		{
			//apply default subscription plan to new registered user
			$defaultPlan = $this->params->get('defaultPlan',0); 
			$newUser = XiFactory::getSession()->get('DEFAULT_PLAN_NEW_USER', $new);

			if(($defaultPlan != 0) && ($newUser === true)){
				$plan = PayplansPlan::getInstance($defaultPlan);
				$plan->subscribe($user['id'])
				 	 ->setStatus(XiStatus::ORDER_COMPLETE)
				 	 ->save();
				 XiFactory::getSession()->clear('DEFAULT_PLAN_NEW_USER');
			}
			
			return true;
		}
}