<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
* @package		Payplans
* @subpackage		Plugin
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class plgPayplansmigrationAmember extends XiPluginMigration
{	
	protected $_location   = __FILE__;
	
	// Amember is not a "component-name" but we consider it as cmponent name. 
	protected $_component 	= 'amember';
	protected $_title		= 'amember';
	
	//payment from these apps will be migrated
	protected $_appMapper = array(
								'authorize'=>'authorize_aim'
								,'adminpay' =>'manual'
								,'paypal'	=>'paypal'
//								,'offlinepay'=>'offline_payment'
//								,'2checkout' =>'2checkout'
								);

	
	function __construct(& $subject, $config = array()) 
	{
		//$mapper:: I'm containing all payments(amember) and orders(payplans) relation 
		$this->_mapper = Array();

		//Mapping transaction information
		$this->_transactionMapper = self::getTransactionMapper();
		$this->_tablePrefix = self::_getTablePrefix();
			
		return parent::__construct($subject, $config);
	}
	
	function onPayplansStartMigration(){
		$startTime = explode(' ', microtime());
		$session = XiPluginMigrationHelper::getInstance();
		$session->write('startMigration', $startTime);
	}

	protected function _postMigration()
	{
		$endTime   = explode(' ', microtime());
		$session   = XiPluginMigrationHelper::getInstance();
		$startTime = $session->read('startMigration');
		$session->clear('startMigration');
		$totalTime = $endTime[0] + $endTime[1] - ($startTime[1] + $startTime[0]);
		//time in min
		$totalTime = $totalTime/60;
		$this->_assign('totalTime',round($totalTime));
		return $this->_render('post');
	}

	public function _isAvailable(Array $options= array())
	{
		$db 	= new XiQuery();
		$query	= "SHOW TABLES LIKE '{$this->_tablePrefix}%'";
		//get All tables
		$amemberTables  = $db->dbLoadQuery($query)->loadResultArray();
		$memberTable	= "{$this->_tablePrefix}members";
		$paymentTable	= "{$this->_tablePrefix}payments";
		if(	!empty($amemberTables) && 
			in_array($memberTable, $amemberTables) && 
			in_array($paymentTable, $amemberTables)
		) return true;
		
	  return false;
	}
	
	protected function _estimateRecords()
	{
		$query	= new XiQuery();
		$records = 0;

		$records += (int) $query->select(' COUNT(*)')->from($this->_tablePrefix.'products')->dbLoadQuery()->loadResult();
		$query->clear();
		
		//Migratoe::Might be it's not accurate.but I'm consider only those user-records which is common in both joomla and amember
		$sql = "SELECT COUNT(*)
				FROM `#__users` AS juser
 				LEFT JOIN `{$this->_tablePrefix}members` AS amember
 				ON ( amember.`email` = juser.`email` )
 				WHERE amember.`login` = juser.`username`";
		
		$records += (int) $query->dbLoadQuery($sql)->loadResult();
		$query->clear();
		$this->_helper->write('record_count',$records);
		return $records;
	}

	protected function _migrateTables()
	{
		$query	= new XiQuery();
					
		//truncate tables
		$query->truncate('#__payplans_plan')->dbLoadQuery()->query();
		$query->truncate('#__payplans_app')->dbLoadQuery()->query();
		$query->truncate('#__payplans_order')->dbLoadQuery()->query();
		$query->truncate('#__payplans_subscription')->dbLoadQuery()->query();
		$query->truncate('#__payplans_payment')->dbLoadQuery()->query();	
		$query->clear();
		
		//Drop few temp tables If exist.
		self::_dropTempTables();
		
		//craete a temporary table for all required data 
		$this->_createTempTables();
		
		// Migrate Plans
		// insert records which can be directly mapped
		$str 	=  " INSERT INTO `#__payplans_plan` 
					(`plan_id`, `title`, `description`)
					  SELECT  `product_id`, `title`, `description`
					  FROM `{$this->_tablePrefix}products`
					";
		$query->dbLoadQuery($str)->query();
		$query->clear();
		
		$this->_helper->write('message', 'Table Migrating');
		$this->_scheduleNextFunction('_TablesMigrations');
		return 0;
	}
	
	protected function _TablesMigrations($limit, $offset=0)
	 {
		
		$query = new XiQuery();
		
		//Migrator:: I want to those user which is existing into joomla table 
		// and their payment is active.
		
		// Might be required max len 512 for using GROUP_CONCATE in query. 
		//(then now column data-type will be "VARCHAR " or "VARBINARY")		
		//$str = " SET SESSION group_concat_max_len = 512 ";
		//$query->dbLoadQuery($str)->query();
		//$query->clear();

		$records =  $query->select("`user_id`,`member_id` 
									, GROUP_CONCAT(`payment_id` SEPARATOR ',') as payments
									,GROUP_CONCAT(`plan` SEPARATOR ',') AS plans")
						   ->from("`#__payplans_tmp_amember_payment`")
						   ->group("`user_id`")
						   ->limit($limit,$offset)
						   ->dbLoadQuery()
						   ->loadObjectList("user_id")
						   ;
		$query->clear();
		
		foreach( $records as $userId=>$record){
			$payments = explode(",", $record->payments);
			$plans	= explode(",", $record->plans);
			
			foreach($plans as $key => $value){
				$paymentId 		= $payments[$key];
				$paymentRecords = self::_getParams($paymentId);
				$param 			= unserialize($paymentRecords[$userId]->param);
				//previousPay will identify payment(is recurring or not).If any recurring occures then only make new payment with existing order.
				$previousPay	= $this->isRecurring($param);
				$this->_makeOrderSubsPay($userId,$paymentRecords,$previousPay);
			}
		}
		
		$query->from("(SELECT a.`user_id`  FROM `#__payplans_tmp_amember_payment` AS a GROUP BY a.`user_id`)  AS B");
		$this->_scheduleNextFunction('_migratePlans',$query, $offset, count($records));
		//$this->_scheduleNextFunction('_MigrationComplete',$query, $offset, count($records));
		$this->_helper->write('message', 'Table Migrating');
		return count($records);
	}
	
	
	// These functions migrate one table at a time
	protected function _migratePlans($limit, $offset=0)
	{
		$this->_helper->write('message', 'Migrating Plans');
		$query	= new XiQuery();
		
		// map records which cannot be mapped directly
		$records = $query->select('*')->from('amember_products')
						->dbLoadQuery()
						->loadAssocList('product_id');

		// start migrating records 
		foreach($records as $id => $record){
			
			$plan = PayplansPlan::getInstance($id);
			
			$params = unserialize($record['data']);
			$expiration = $params['expire_days'];
			//get last value from string for identify. Year,Month and Day
			$lastChar = substr($expiration, -1);
			$period	  = substr($expiration,0,-1);
			// migrate payment & time data
			$expiration	= PayplansHelperPlan::convertExpirationTime($period,	ucfirst($lastChar));

			$plan->getPayment()->setValue('price', $record['price']);
			$plan->getTime()->setValue('expiration', $expiration);
			
			//XiTODO:: If plan is recurring
//			$expirationtype = (empty($params['is_recurring']))? "fixed" :"recurring";
//			$plan->getTime()->setValue('expirationtype', $expirationtype);
			//XITODO : How to migrate trial data.
			$plan->save();
		}
		
		$this->_helper->write('message', 'Migrating plans');		
		//$this->_scheduleNextFunction('_PaymentMigration', $query, $offset, count($records));
		$this->_scheduleNextFunction('_MigrateSubscription', $query, $offset, count($records));
		return count($records);
	}
	
	//Currntly this function is only set order status and refresh order.
	protected function _MigrateSubscription($limit, $offset=0)
	{ 
		// apply limit		
		$query	= new XiQuery();		
		$records= $query->select('*')
						->from('#__payplans_subscription')
						->limit($limit, $offset)
						->dbLoadQuery()
						->loadAssocList('subscription_id');
			
		// start migrating records 
		foreach($records as $id => $record){
			
			//	 Load Subscription
			$subscription = PayplansSubscription::getInstance($id);
			if(!$subscription){
				continue;
			}
			
			//update status
			$orderStatus = ($record['status'] == XiStatus::SUBSCRIPTION_ACTIVE) ? XiStatus::ORDER_COMPLETE : XiStatus::ORDER_HOLD;

			//XITODO : Param column pending.
			
			// update order total
			$order = $subscription->getOrder(PAYPLANS_INSTANCE_REQUIRE);
			
			$subscription->setPrice($record['total']);			
			$subscription->save();
			
			//update order status			
			$order->setSubtotal($record['total'])
				  ->refresh()
				  ->setStatus($orderStatus)
				  ->save();	
		}
		
		$this->_helper->write('message', 'Migrating Subscription');
		$this->_scheduleNextFunction('_migratePayments',$query, $offset, count($records));
		return count($records);
	}
	
	
	protected function _migratePayments($limit, $offset=0) {
		// XiTODO:: Any thing pending???
		//$this->_scheduleNextFunction('_MigrationComplete',$query, $offset, count($records));
		return $this->_scheduleNextFunction('_MigrationComplete');
	}
	
	function _MigrationComplete() {
		self::_dropTempTables();
		parent::_MigrationComplete();
	}
	
	
	private function _makeOrderSubsPay($userId,$paymentRecords,$previousPay = false){	
		
		$db  = new XiQuery();
		// few user have payments id but their payment_sys is free. 
		// So we dont consider in recurring these type of user and create new record. 
		if(	!empty($previousPay) &&
			isset($this->_mapper[$previousPay])){
			$orderId = $this->_mapper[$previousPay]['order'];
		}
		
		//First create order and subs then make payment,if order is not created.
		if(empty($orderId)){
			// create order
			$query = "
						INSERT INTO `#__payplans_order` 
								 (`buyer_id`,`subtotal`,`total`
								 ,`created_date`,`modified_date`) 
							VALUES( $userId
								  ,{$paymentRecords[$userId]->amount}
								  ,{$paymentRecords[$userId]->amount}
								  ,'{$paymentRecords[$userId]->start}'
								  ,'{$paymentRecords[$userId]->start}'
								  )							   
					";
			$db->dbLoadQuery($query)->query();
			$db->clear();
			
			// Migrator:: Now, I'm creating subscription
			// I have taken all active subscription so I will consider all subs as "ACTIVE"  
			$query = "
					INSERT INTO `#__payplans_subscription` 
								  (`user_id`,`plan_id`,`subscription_date`,
								   `expiration_date`,`total`,`status`)
							VALUES ($userId,{$paymentRecords[$userId]->plan}
								   ,'{$paymentRecords[$userId]->start}'
								   ,'{$paymentRecords[$userId]->end}'
								   ,{$paymentRecords[$userId]->amount}
								   ,".XiStatus::SUBSCRIPTION_ACTIVE
								   .")
					";
			$db->dbLoadQuery($query)->query();
			
			// Insert order id into subscription table.
			//get last order id
			$query = "
						SELECT `order_id`
						FROM `#__payplans_order`
						ORDER BY order_id DESC
						LIMIT 1
					 ";
			$orderId = $db->dbLoadQuery($query)->loadResult();
			//get last subscription_id
			$query = "
						SELECT `subscription_id`
						FROM `#__payplans_subscription`
						ORDER BY subscription_id DESC
						LIMIT 1
					 ";
			$subId = $db->dbLoadQuery($query)->loadResult();
			
			$query = "
						UPDATE `#__payplans_subscription` 
						SET `order_id` = $orderId
						WHERE `subscription_id` = $subId;
					 ";
			$db->dbLoadQuery($query)->query();
		}
		//Migrator::creating payment
		$paymentAppMapper =  $this->_getPaymentMapper();
		$appId = 0;
		if(isset($paymentAppMapper[$paymentRecords[$userId]->app]))
			$appId = $paymentAppMapper[$paymentRecords[$userId]->app]->getId();
			
		//Set transaction record
		$param = unserialize($paymentRecords[$userId]->param);
		$transactionRecords = $this->getTransactionRecords($userId,$param );
		
		//XiTODO:: Is it ok??
		$startDate 	   = $paymentRecords[$userId]->start;
		$paymentStatus = XiStatus::PAYMENT_COMPLETE;
		$masterPay 	   = 1;
		if(!empty($previousPay) && isset($this->_mapper[$previousPay])){
			$startDate = $this->_mapper[$previousPay]['start'];	
			//$paymentStatus =XiStatus::PAYMENT_RECURRING_SIGNUP;
			$masterPay = 0;
		}

		//XiTODO::  Default currency code is USD ???
		$currencyCode = "USD";
		if(!empty($param) && isset($param[1]['x_Currency_Code']))
			$currencyCode= $param[1]['x_Currency_Code']; 
			
		$query = "
					INSERT INTO `#__payplans_payment`
						   (`order_id`,`app_id`
						   ,`currency`,`amount`
						   ,`created_date`,`modified_date`
						   ,`status`,`master`
						   , `transaction`) 
					VALUES ( $orderId, $appId
							,'$currencyCode'					
							, {$paymentRecords[$userId]->amount}
							,'$startDate'
							,'{$paymentRecords[$userId]->start}'
							, $paymentStatus
							, $masterPay
							, ".'"'.mysql_real_escape_string($transactionRecords).'"'."
							)				
				 ";
		$db->dbLoadQuery($query)->query();
		
		//$_mapper:: Maintain payment (amember) and order (PP) relation 
		 $payment = (int)$paymentRecords[$userId]->payment_id;
		$this->_mapper[$payment]['order'] = $orderId;
		$this->_mapper[$payment]['start'] = $paymentRecords[$userId]->start;
	}
	
	//If record is recurring then return previous payment id.
	private function isRecurring($param){
		if (!empty($param) && isset($param[0]['RENEWAL_ORIG'])){
			// Get privious payment 
			$recurringPay = $param[0]['RENEWAL_ORIG'];
			if(!empty($recurringPay)){
				$recurringPay = explode(":", $recurringPay);
				// Privious Payment exist then return prv payment id ( for make new paymeny on existing order)
				if(!empty($recurringPay) && isset($recurringPay[1])){
					return  trim($recurringPay[1]);
			}
		}
	 }
	 return false;
	}
	
	
	function _getPaymentMapper() {
		static $appMapper ;
		//XiTODO:: it must be invoked only one time on all req.
		if(!$appMapper){
			$appMapper = parent::_getPaymentMapper();
		}	
		return $appMapper;
	}

	
	private function _getParams($paymentId){
		$query =JFactory::getDbo();
		$str   = "
				SELECT *
				FROM `#__payplans_tmp_amember_payment`
				WHERE  `payment_id` = $paymentId 
				";
		$query->setQuery($str);
		$record = $query->loadObjectList("user_id");
		return $record;
	}

	private function _getTablePrefix(){
		//XiTODO:: Ask to user for amember prefix.
		return "amember_";
	} 
	
	 private function _createTempTables(){

	 	$db = new XiQuery();	
		//craete a temporary table for all required data 
		//Create #__payplans_tmp_amember
		$query = "  CREATE TABLE IF NOT EXISTS `#__payplans_tmp_amember` 
					SELECT `id` as user_id, `username`, juser.`email` as juser_email , 
					amember.`email` as amember_email, amember.`member_id`,`added`,
					amember.`remote_addr` as ip, amember.`data` as param
					FROM `#__users` AS juser
 					LEFT JOIN `{$this->_tablePrefix}members` AS amember
 					ON ( amember.`email` = juser.`email` )
 					WHERE amember.`login` = juser.`username`";
	
		$db->dbLoadQuery($query)->query();
		
		$query = " ALTER TABLE `#__payplans_tmp_amember` ". 
				 " ADD PRIMARY KEY (`user_id`) ";	
		$db->dbLoadQuery($query)->query();

		// Create #__payplans_tmp_amember_payment
		// Payment must be completed and order by payment_id.
		$query = " 
				CREATE TABLE IF NOT EXISTS  `#__payplans_tmp_amember_payment`
						SELECT temp.`user_id`, a_payment.`member_id`, a_payment.`payment_id`
							   , a_payment.`begin_date` as start
							   , a_payment.`expire_date` as end
							   , a_payment.`product_id`  AS plan
							   , a_payment.`paysys_id` AS app
							   , a_payment.`amount`  AS amount
							   , a_payment.`data` AS param
						FROM `amember_payments` as a_payment
						INNER JOIN `#__payplans_tmp_amember` as temp
						ON temp.`member_id` = a_payment.`member_id`
						WHERE a_payment.`completed` = 1 AND 
							  a_payment.`paysys_id` IN ('manual','authorize_aim')
						ORDER BY a_payment.`payment_id`
				";
		$db->dbLoadQuery($query)->query();
	}
	
	private function _dropTempTables() {
		$query	= new XiQuery();
		$query->drop('#__payplans_tmp_amember')->dbLoadQuery()->query();
		$query->drop('#__payplans_tmp_amember_payment')->dbLoadQuery()->query();
	}
	
	private function getTransactionRecords($userId,$param){
		
		$transactionRecords = Array();
		$transactionRecords['testmode'] = false;
		if(!empty($param)){
			foreach($param as $key => $value){
				//if array key, $k exist then store value according our key-value(get by _transactionMapper)
				//otherwise store as it.
				if(array_key_exists($key, $this->_transactionMapper)){
					$transactionRecords[$this->_transactionMapper[$key]] = $value;
					continue;	
				}
				if(is_array($value)){
					foreach ($value as $k => $v){
						if(array_key_exists($k, $this->_transactionMapper)){
							$transactionRecords[$this->_transactionMapper[$k]] = $v;
							continue;	
						}
						$transactionRecords[$k] = $v;
				}
				continue;
			}
			$transactionRecords[$key] = $value;
			}
		}
		return PayplansHelperParam::arrayToIni($transactionRecords);
	}
	
	private function getTransactionMapper() {
				$transactionMapper=	Array ( 
									'x_Tran_Key' => 'transaction_id',
									'x_Invoice_Num' => 'invoice_number' ,
									'x_Amount' => 'amount' ,
									'x_Currency_Code' => 'currency' ,
									'x_Email' => 'email_address',
									'x_First_Name' => 'first_name',
									'x_Last_Name' => 'last_name',
									'x_Address' => "address", 
									'x_City' => "city", 
									'x_State' => "state" ,
									'x_Zip' => "zip_code" ,
									'x_Country' => "country" ,
									'x_Company' =>'company',
									'x_Phone' => 'phone',
								    'RESPMSG' => 'response_msg'
								   );		
		return $transactionMapper;
	}
}
