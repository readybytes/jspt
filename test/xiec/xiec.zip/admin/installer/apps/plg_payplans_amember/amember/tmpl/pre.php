<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Modules
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die(); ?>
<div  class="dashboard-migrate-pre">	
	<div class="dashboard-migrate-pre-warning"><?php echo XiText::_('PLG_PAYPLANS_AMBRASUBS_MIGRATION_WARNING');?></div>
	<div class="dashboard-migrate-pre-instruction">
	<ul>
		<li><?php echo XiText::_('PLG_PAYPLANS_AMEMBER_MIGRATION_INSTRUCTION1');?></li>
		<li><?php echo XiText::_('PLG_PAYPLANS_AMEMBER_MIGRATION_INSTRUCTION2');?></li>
		<li><?php echo XiText::_('PLG_PAYPLANS_AMEMBER_MIGRATION_INSTRUCTION3');?></li>
		<li><?php echo XiText::_('PLG_PAYPLANS_AMEMBER_MIGRATION_INSTRUCTION4');?></li>
	</ul>
	</div>
	<div class="dashboard-migrate-pre-estimated-records"><?php echo XiText::_('PLG_PAYPLANS_AMEMBER_ESTIMATED_RECORDS');?><?php echo $record_count; ?></div>
	<div class="dashboard-migrate-pre-estimated-time"><?php echo XiText::_('PLG_PAYPLANS_AMEMBER_ESTIMATED_TIME');?><?php echo round($time_estimate/60,0); echo XiText::_('PLG_PAYPLANS_AMEMBER_ESTIMATED_TIME_MINUTES');?></div> 
</div> 
