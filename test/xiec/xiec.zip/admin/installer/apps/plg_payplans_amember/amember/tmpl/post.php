<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Modules
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die(); ?>
<div class="dashboard-migrate-post-thanks">
<?php echo XiText::_('PLG_PAYPLANS_AMEMBER_THANKS_MESSAGE');?> 
<div >
<?php echo XiText::_('PLG_PAYPLANS_AMEMBER_MIGRATE_TIME')
		  .$totalTime
		  .XiText::_('PLG_PAYPLANS_AMEMBER_ESTIMATED_TIME_MINUTES');?>
</div>
</div>