<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license	GNU/GPL, see LICENSE.php
* @package	PayPlans
* @subpackage	Modules
* @contact 	shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

?>
<div class="dashboard-search-module">
	<div class="dashboard-search-panel">
		<form action="" method="post" name="searchBox" id="searchBox" >
			<input id="payplans_search_text" type="text" autocomplete="off" onkeyup="return payplansAdmin.searchBoxKeyUp(event)" onkeypress="return payplansAdmin.searchBoxKeyDown(event)" title="<?php echo XiText::_('COM_PAYPLANS_MOD_SEARCH_TOOLTIP');?>" name="payplans_search_text" class="inputbox" alt="payplans_search_text" size="30" />
			<a href="" onClick="xi.dashboard.modsearch(); return false;" id="go"><?php //echo XiText::_('COM_PAYPLANS_MOD_SEARCH') ?></a>
			<?php echo JHTML::_( 'form.token' ); ?>
		</form>	
	</div>
	
	<div id="payplans-search-results" class="dashboard-search-results"></div>	
</div>