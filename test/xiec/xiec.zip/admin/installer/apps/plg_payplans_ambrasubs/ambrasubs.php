<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
* @package		Payplans
* @subpackage		Plugin
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class plgPayplansmigrationAmbrasubs extends XiPluginMigration
{
	protected $_location    = __FILE__;
	protected $_title		= 'ambrasubs';
	// component name
	protected $_component = 'ambrasubs';
	
	//payment from these apps will be migrated
	protected $_appMapper = array(
								'paypal'=> 'payment_paypal',
								'authorize'=>'payment_authorizedotnet',
								'offlinepay' =>'payment_offline',
								'adminpay' =>'admin'
								// 'payment_psigate'
								// 'payment_points' 
								// 'payment_moneybookers 
								// 'payment_moneris 
								// 'payment_googlecheckout 
								);
	
	protected function _estimateRecords()
	{
		$query	= new XiQuery();
		$records = 0;
		
		//plans
		$records += (int) $query->select(' COUNT(*)')->from('#__ambrasubs_types')->dbLoadQuery()->loadResult();
		$query->clear();
		
		//payments
		$records += (int) $query->select(' COUNT(*)')->from('#__ambrasubs_payments')->dbLoadQuery()->loadResult();
		$query->clear();
		
		//subscription
		$records += (int) $query->select(' COUNT(*)')->from('#__ambrasubs_users2types')->dbLoadQuery()->loadResult();
		$query->clear();

		//store in session
		$this->_helper->write('record_count',$records);
		
		return $records;
	}

	protected function _migrateTables()
	{
		$query	= new XiQuery();			
		//truncate tables
		$query->truncate('#__payplans_plan')->dbLoadQuery()->query();
		$query->truncate('#__payplans_planapp')->dbLoadQuery()->query();
		$query->truncate('#__payplans_order')->dbLoadQuery()->query();
		$query->truncate('#__payplans_subscription')->dbLoadQuery()->query();
		$query->truncate('#__payplans_payment')->dbLoadQuery()->query();	
		$query->clear();
		
		// Migrate Plans
		// insert records which can be directly mapped
		$str 	=  ' INSERT INTO `#__payplans_plan` 
						(`plan_id`, `title`, `published`, `visible`, `ordering`, `description`)
					  SELECT  `id`, `title`, `published`, 1, `ordering`, `description`
					  FROM `#__ambrasubs_types`
					';
		$query->dbLoadQuery($str)->query();
		$query->clear();
		
		// create blank orders
		$str = 	'INSERT INTO `#__payplans_order` 
					 (`order_id`, `buyer_id`, `created_date`)
				 SELECT    u2t.`u2tid`, u2t.`userid`, u2t.`created_datetime`
				 FROM `#__ambrasubs_users2types`  AS u2t
				 INNER JOIN  `#__users` AS u ON u2t.`userid`=u.`id`
				 WHERE u.`id` <> 0 
				';
		$query->dbLoadQuery($str)->query();
		$query->clear();
		
		// create subscriptions
		$str = 	'INSERT INTO `#__payplans_subscription` 
					(`subscription_id`, `user_id`, `plan_id`, `order_id`, `subscription_date`, `expiration_date`)
				 SELECT  u2t.`u2tid`, u2t.`userid`, u2t.`typeid`, u2t.`u2tid`,  u2t.`created_datetime`, u2t.`expires_datetime`  
				 FROM `#__ambrasubs_users2types`  AS u2t
				 INNER JOIN  `#__users` AS u ON u2t.`userid`=u.`id`
				 WHERE u.`id` <> 0 
				';
								;
		$query->dbLoadQuery($str)->query();
		$query->clear();
		
		// create payments
		// order_id and app_id should be 0 so it does not interfere with other objects.
		// once we create apss and add data to it, then we will update it.
		$str = 	'INSERT INTO `#__payplans_payment` 
					(`payment_id`, `order_id`, `app_id`, `status`,  `modified_date`, `amount`, `created_date`)
				 SELECT    p.`id`, 	0, 	p.`payment_type`, '. XiStatus::PAYMENT_COMPLETE.',		 p.`payment_datetime`, p.`payment_amount`, p.`created_datetime`  
				 FROM  `#__ambrasubs_payments` AS p
				 INNER JOIN  `#__users`	  AS u 	ON p.`created_by`=u.`id`
				 INNER JOIN  `#__ambrasubs_users2types` AS u2t ON p.`id`=u2t.`paymentid`
				 WHERE u.`id` <>0   AND u2t.`paymentid` <> 0
				 
				';
		$query->dbLoadQuery($str)->query();
		$query->clear();
		
		// setup next functions
		$this->_helper->write('message', 'Tables migration done');
		$this->_scheduleNextFunction('_migratePlans');
		return 0;
	}
	
	
	// These functions migrate one table at a time
	protected function _migratePlans($limit, $offset=0)
	{
		$this->_helper->write('message', 'Migrating Plans');
		$query	= new XiQuery();
		
		// map records which cannot be mapped directly
		$records = $query->select('*')->from('#__ambrasubs_types')
						->limit($limit, $offset)
						->dbLoadQuery()
						->loadAssocList('id');
						
						

		// start migrating records 
		foreach($records as $id => $record){
			
			$plan = PayplansPlan::getInstance($id);
			
			// migrate payment & time data
			$expiration	= PayplansHelperPlan::convertExpirationTime($record['period'],	'D');

			$plan->getPayment()->setValue('price', $record['value']);
			$plan->getTime()->setValue('expiration', $expiration);
			
			//XITODO : migrate trial data when we have it. #118
			$plan->save();
		}
		
		$this->_helper->write('message', 'Migrating plans');		
		$this->_scheduleNextFunction('_migrateSubscription', $query, $offset, count($records));
		return count($records);
	}
	
	/**
	 */
	protected function _migrateSubscription($limit, $offset=0)
	{	
		// apply limit		
		$query	= new XiQuery();		
		$records= $query->select('*')
						->from('#__ambrasubs_users2types AS u2t')
						->join('inner', '`#__users`  AS u 	ON u2t.`userid`=u.`id` ')
						->join('inner', '`#__ambrasubs_types` AS t 	ON u2t.`typeid`=t.`id`')
						->join('inner', '`#__ambrasubs_payments` AS p 	ON u2t.`paymentid`=p.`id`')
						->where('u.`id` <>0 ')
						->limit($limit, $offset)
						->order('u2t.`u2tid`')
						->dbLoadQuery()
						->loadAssocList('u2tid');
			
		// start migrating records 
		foreach($records as $id => $record){
			
			//	 Load Subscription
			$subscription = PayplansSubscription::getInstance($id);
			if(!$subscription){
				continue;
			}
			
			//update status
			$status 	 = $record['status'] ? XiStatus::SUBSCRIPTION_ACTIVE : XiStatus::SUBSCRIPTION_HOLD;
			$orderStatus = $record['status'] ? XiStatus::ORDER_COMPLETE : XiStatus::ORDER_HOLD;

			
			//XITODO : Add IP to proper table. #289
			//$params = unserialize(base64_decode($record['params']));
			//$ip	= @$params['creator_ip'];
			
			// update order total
			$order = $subscription->getOrder(PAYPLANS_INSTANCE_REQUIRE);
			
			//update order status			
			$order->setStatus($orderStatus)->save();
				
			// finally save changes in subscription
			$subscription->setStatus($status);
			$subscription->setPrice($record['payment_amount']);
			$subscription->save();
			
			//refresh order
			$order->refresh()->save();
		}
		
		$this->_helper->write('message', 'Migrating Subscription');
		$this->_scheduleNextFunction('_migratePayments',$query, $offset, count($records));
		return count($records);
	}
	
	protected function _migratePayments($limit, $offset=0)
	{
		$paymentAppMapper =  $this->_getPaymentMapper();
		
		// apply limit
		$query	= new XiQuery();
		$records= $query->select('p.*, u2t.`u2tid` as order_id')
						->from('#__ambrasubs_users2types AS u2t')
						->join('inner', '`#__users`  AS u 	ON u2t.`userid`=u.`id` ')
						->join('inner', '`#__ambrasubs_types` AS t 	ON u2t.`typeid`=t.`id`')
						->join('inner', '`#__ambrasubs_payments` AS p 	ON u2t.`paymentid`=p.`id`')
						->where('u.`id` <> 0  AND u2t.`paymentid` <> 0')
						->limit($limit, $offset)
						->order('`id`')
						->dbLoadQuery()
						->loadAssocList('id');
			
		// start migrating records 
		foreach($records as $id => $record){
			
			//	 Load Subscription
			$payment = PayplansPayment::getInstance($id);
			if(!$payment){
				continue;
			}
		
			// finally save changes in payment
			$payment->setStatus( $record['payment_status'] ? XiStatus::PAYMENT_COMPLETE : XiStatus::PAYMENT_INITIATED );			
			$payment->setOrder($record['order_id']);
			$payment->setTransaction(str_replace(' = ', '=', $record['payment_details']));

			//if app mapping not available
			if(isset($paymentAppMapper[$record['payment_type']])){
				$payment->setApp($paymentAppMapper[$record['payment_type']]->getId());
			}else{
				$payment->setApp(0);
			}
				
			$payment->save();
		}
		
		$this->_helper->write('message', 'Migrating Payments');
		$this->_scheduleNextFunction('_migrationComplete', $query, $offset, count($records));
		return count($records);
	}
	
	protected function _migrateHistory()
	{}

	protected function _migrateCoupons()
	{}
}