<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Modules
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die(); ?>

<div class="dashboard-migrate-started">
	<?php echo XiText::_('PLG_PAYPLANS_AMBRASUBS_MIGRATION_STARTED');?>
</div>
<div class="dashboard-migrate-progress-message"> <span id="dashboard-migrate-progress-message"> &nbsp; </span></div>

<div class="progress-bar"> 
	<div id="dashboard-migrate-progress-bar" class="progress-bar-inner orange"></div>
</div>


<div class="dashboard-migrate-progress-count"><?php echo XiText::_('PLG_PAYPLANS_AMBRASUBS_IMPORT_DATA_PROCESSED')?><span id="dashboard-migrate-progress-count">&nbsp; </span> of <?php echo $record_count; ?> </div>