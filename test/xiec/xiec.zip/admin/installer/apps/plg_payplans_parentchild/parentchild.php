<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage	ParentChild
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Payplans Parent-Child Plugin
 *
 */
class plgPayplansParentChild extends XiPlugin
{
    
    public function onPayplansSystemStart()
	{
		//autoload model and table
        $dir = dirname(__FILE__).DS.'parentchild';
		PayplansHelperLoader::addAutoLoadFile($dir.DS.'model.php', 'PayplansModelParentchild');
		PayplansHelperLoader::addAutoLoadFile($dir.DS.'table.php', 'PayplansTableParentchild');

        return true;
	}

	/**
	* Manipulate plan screen in both frontend and backend according to the 
	 * Parentchild plugin 
	 */
	 
	public function onPayplansViewBeforeRender(XiView $view, $task)
	{
		// if view is admin view of plan
		if(($view instanceof PayplansadminViewPlan) && $task == 'edit'){
        	return $this->_renderAdminPlanEditScreen($view);
		}
		
		// if view is site view of plan
		if(($view instanceof PayplanssiteViewPlan) && $task == 'subscribe')
		{
			// get all plans from view
			$plans  	   = $view->get('plans');
			$records	   = XiFactory::getInstance('parentchild','model')
								->loadRecords();
			$filteredPlans = $plans;
			if(count($records) > 0){
				$filteredPlans = $this->_filterPlans($plans,$records);
			}

			// set plans
			$view->assign('plans',$filteredPlans);
		}

	}

	/**
	 * Save in Parent Child table
	 */
	public function onPayplansPlanAfterSave($previous, $current)
	{
		//get dependent plan, parent plan
		$dependent_plan	= $current->getId();
		$parentplans	= JRequest::getVar('parentplans', false);

		if(empty($parentplans)){
			$parentplans = array();
		}

		$displaychildplan = JRequest::getVar('displaychildplanon', false);
		if($parentplans !== false && $displaychildplan !== false)
		{
			$model            = XiFactory::getInstance('parentchild','model');
			$existingRelation = $model->loadRecords(array('dependent_plan'=>$dependent_plan));
				
			//if no entry in the table for that plan then create new entry
			//else update the existing one
			$new			= false;
			if(!empty($existingRelation)){
				$relation    	= array_shift($existingRelation);
				$childPlan      = $relation->dependent_plan;
			}
			else{
				$childPlan      = $dependent_plan;
				$new			= true;
			}
			$data['dependent_plan'] 	= $childPlan  ;
			$data['base_plan']          = implode(',', $parentplans);
			$data['relation']           = $displaychildplan;
				
			return $model->save($data,$childPlan,$new);
		}
	}

	/**
	 * Display message to user to subscribe Parent plans in case
	 * if he try to renew child plan through subscription Module
	 * while its parent plans are still expired
	 * 
	 * XITODO: IMPLEMENT onPayplansAccessCheck
	 */
	public function onAfterRoute()
	{
		// do not work in admin
		if(XiFactory::getApplication()->isAdmin()){
			return ;
		}
		
		$option = JRequest::getVar('option');
		$view = JRequest::getVar('view');
		$planId = JRequest::getVar('plan_id', 0);
		
		//if url is not same as on order confirm page then return
		if(isset($planId)==false || $option != 'com_payplans' || $view != 'plan'){
			return;
		}

		// We need to act now
		$plan           = PayplansPlan::getInstance($planId);
		$plans[$planId] = $plan;
		$record         = XiFactory::getInstance('parentchild','model')
								->loadRecords(array('dependent_plan'=>$planId));

		// check if plan is allowed to be subscribed
		$filteredPlans  = $this->_filterPlans($plans, $record, $requiredPlans);
		if(count($requiredPlans) <= 0){
			return;
		}

		//get Parent Plans name
		list($parentRelation, $parentPlans)= array_shift($requiredPlans);
		foreach($parentPlans as $plan_id){
			$plansName[] = PayplansHelperPlan::getName($plan_id);
		}
		$parentPlansName = implode(',', $plansName);

		//display message on subscribe screen if parent plans not subsc
		$message = XiText::_('PLG_PAYPLANS_PARENTCHILD_PLAN_SUBSCRIBE_FIRST_SUBSCRIBE_ANY_PARENT_PLAN');
		if($parentRelation == PAYPLANS_CONST_ALL){
			$message = XiText::_('PLG_PAYPLANS_PARENTCHILD_PLAN_SUBSCRIBE_FIRST_SUBSCRIBE_ALL_PARENT_PLAN');
		}
		$message	.=' '.$parentPlansName;

		// finally redirect user
		$returl = XiRoute::_('index.php?option=com_payplans&view=plan&task=subscribe');
		XiFactory::getApplication()->redirect($returl,$message);
		return;
		
	}
	 
	/**
	 * Render Parent Child Template on Plan edit Screen
	 * @param PayplansadminViewPlan $view
	 */
	protected  function _renderAdminPlanEditScreen(PayplansadminViewPlan $view)
	{
		$planId = $view->getModel()->getId();

		$parentchildRelation  = XiFactory::getInstance('parentchild','model')
									->loadRecords(array('dependent_plan'=>$planId));

		$relation = array_shift($parentchildRelation);
		$this->_assign('parentchild_relation', $relation);
		return array('payplans-admin-plan-edit-parentchild' => $this->_render('editplan_parentchild'));
	}

	/**
	 * 
	 * Filter Plans to decide whether to unset plan or not
	 * @param  $plans - plans to be check
	 * @param  $records 
	 * @param  $removedPlans- parameters of the removed plans
	 */
	protected function _filterPlans($givenPlans, $records, &$removedPlans=array())
	{
		$user   			 = XiFactory::getUser();
		$payplansUser		 = PayplansUser::getInstance($user->id);

		$plans               = XiFactory::getInstance('plan','model')
		                             ->loadRecords(array('published'=>'1'));
		$allPlans     		 = array_keys($plans);
		$userPlans    		 = $payplansUser->getPlans();
		$unsubscribedPlans 	 = array_diff($allPlans, $userPlans);
	    
		foreach($records as $id =>$record)
		{
			//if base plan is set then explode else continue for next record
			if(isset($record->base_plan) && $record->base_plan == ''){
				continue;
			}

			// get when to display plan,Parent Plans, subscribed Parent plans
			// and unsubscribed Parent plans
			$parentRelation  			= $record->relation;
			$parentPlans  				= explode(',', $record->base_plan);
			$subscribedParentPlans 		= array_intersect($parentPlans, $userPlans);
			$unsubscribedParentPlans 	= array_intersect($parentPlans,$unsubscribedPlans);
				
			// if all plans are subscribed
			if($parentRelation == PAYPLANS_CONST_ALL && count($unsubscribedParentPlans)==0){
				continue;
			}

			// if any plan is subscribed
			if($parentRelation == PAYPLANS_CONST_ANY && count($subscribedParentPlans)>0){
				continue;
			}
			// else unset plan
			$removedPlans[$id] = array($parentRelation, $parentPlans);
			unset($givenPlans[$id]);
		}

		return $givenPlans;
   }
}