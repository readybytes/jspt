<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Log
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>

<fieldset class="adminform">
	<legend> <?php echo XiText::_('PLG_PAYPLANS_PARENTCHILD_TITLE'); ?> </legend>
	<div class="elementParams">
					<div class="paramTitle" >
							<span 	class="hasTip" 
									title="<?php echo XiText::_('PLG_PAYPLANS_PARENTCHILD_PLAN_EDIT_PARENT_PLANS'); ?>::<?php echo XiText::_('PLG_PAYPLANS_PARENTCHILD_PLAN_EDIT_PARENT_PLANS_DESC'); ?>">				
							<?php echo XiText::_('PLG_PAYPLANS_PARENTCHILD_PLAN_EDIT_PARENT_PLANS'); ?>
							</span>
					</div>
					<div class="paramValue">
						<?php $base_plans = array();?>
						<?php if($parentchild_relation) : ?>
							<?php $depend = $parentchild_relation->base_plan;?>
							<?php if(isset($depend) && !empty($depend)):?>
							      <?php $base_plans = explode(',', $depend); ?>
						         <?php endif;?> 
						<?php endif;?>
						<?php echo XiHtml::_('elements.plans', 'parentplans', $base_plans, array('multiple'=>true)); ?> 
					</div>
	</div>
	<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('PLG_PAYPLANS_PARENTCHILD_PLAN_EDIT_DISPLAY_PLAN') ;?>::<?php echo XiText::_('PLG_PAYPLANS_PARENTCHILD_PLAN_EDIT_DISPLAY_PLAN_DESC');?>">
						<?php echo XiText::_('PLG_PAYPLANS_PARENTCHILD_PLAN_EDIT_DISPLAY_PLAN') ;?>  
					</span>
				</div>
				<div class="paramValue">
					<?php
					$checkvalue = (!empty($parentchild_relation)) ? $parentchild_relation->relation : -2;
					$radio = array(); 
	                $radio[] = XiHtml::_( 'select.option', PAYPLANS_CONST_ANY, XiText::_('PLG_PAYPLANS_PARENTCHILD_PLAN_EDIT_DISPLAY_PLAN_ANY_PLAN'));
					$radio[] = XiHtml::_( 'select.option', PAYPLANS_CONST_ALL, XiText::_('PLG_PAYPLANS_PARENTCHILD_PLAN_EDIT_DISPLAY_PLAN_ALL_PLANS')); 
	                $lists['display'] = XiHtml::_('select.radiolist', $radio, 'displaychildplanon', null, 'value', 'text', $checkvalue );
					echo $lists['display'];?>
				</div>
	</div>
</fieldset>
