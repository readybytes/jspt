<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	ParentChild
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansTableParentchild extends XiTable
{
	public function __construct($tblFullName=null, $tblPrimaryKey='dependent_plan', $db=null)
	{
		// if parent child table does not exist, create it
		if(XiHelperTable::isTableExist('#__payplans_parentchild')==false)
		{
			$sql = 'CREATE TABLE IF NOT EXISTS `#__payplans_parentchild` (
						  `dependent_plan`    	   INT NOT NULL ,
						  `base_plan`              VARCHAR(255),
						  `relation`               INT NULL default '.PAYPLANS_CONST_ANY.', 
  						  `display_dependent_plan` INT NULL default 0,
  						  `params`                 TEXT,
  						   PRIMARY KEY (`dependent_plan`)
						)
						ENGINE = MyISAM
						DEFAULT CHARACTER SET = utf8;';
			$dbo = XiFactory::getDBO();
			$dbo->setQuery($sql);
			$dbo->query();
			
			// Temporary Hack : clean cached tablelist, we have added one
			XiHelperTable::$tables = null;
		}
	
		return parent::__construct($tblFullName, 'dependent_plan', $db);
	}
 }