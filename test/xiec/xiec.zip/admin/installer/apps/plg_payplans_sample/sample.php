<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
* @package		Payplans
* @subpackage		Plugin
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class plgPayplansmigrationSample extends XiPluginMigration
{	
	protected $_location   = __FILE__;
	
	// component name
	protected $_component 	= 'sample';
	protected $_title		= 'sample';
	
	//payment from these apps will be migrated
	protected $_appMapper = array();

	public function _isAvailable(Array $options= array())
	{
		return true;
	}
	
	protected function _estimateRecords()
	{
		$records = 50;
		$this->_helper->write('record_count',$records);
		
		return $records;
	}

	protected function _migrateTables()
	{
		$query	= new XiQuery();
					
		//truncate tables
		$query->truncate('#__payplans_plan')->dbLoadQuery()->query();
		$query->truncate('#__payplans_app')->dbLoadQuery()->query();
		$query->truncate('#__payplans_order')->dbLoadQuery()->query();
		$query->truncate('#__payplans_subscription')->dbLoadQuery()->query();
		$query->truncate('#__payplans_payment')->dbLoadQuery()->query();	
		$query->clear();
		
		require_once PAYPLANS_PATH_INSTALLER_ADMIN.DS.'helper.php';
		PayplansInstallHelper::applySqlFile(dirname($this->_location).DS.'sample'.DS.'install.sql');
		
		// create admin pay app also
		XiSetup::getInstance('adminpay')->doApply();

		// setup next functions
		$this->_scheduleNextFunction('_migrationComplete');
		return 50;
	}
}
