<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage	Discount
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


/**
 * Discount System
 * @author shyam
 */
class PayplansAppDiscount extends PayplansAppDiscounts
{
	//inherited properties
	protected $_location	= __FILE__;

	// Entry Function 
	public function onPayplansApplyDiscount(PayplansOrder $order, $discountCode)
	{
		$result = $this->_doCheckAllowed($order, $discountCode);
		
		//Important Check : use strict !== , Do not use != 
		if($result !== true){
			return $result;
		}
		
		//apply discount on each subscriptions
		$discountUsed = $this->_doApplyDiscount($order);

		// if discount have been used then update consumer list
		if($discountUsed){
			$this->addConsumers($order->getId());
		}

		return true;
	}

	//Check if current discount should be applied as per discount purpose
	public function _doCheckAllowed(PayplansOrder $order, $discountCode)
	{
		// is equal to my discount code
		if($discountCode != $this->getAppParam('coupon_code', false)){
			return false;
		}
		
		//	order already have discount or first price already have discount
		if(floatval($order->getDiscount()) || floatval($order->getFirstPriceDiscount())){
			return XiText::_('COM_PAYPLANS_APP_DISCOUNT_ERROR_ORDER_ALREADY_HAVE_DISCOUNT');
		}
		
 
		$reusable   = $this->getAppParam('reusable', 'yes');

		//restrict user to use the same discount code on different subscriptions if reusable parameter is set to no
		if($reusable == 'no'){
			$userId		    = $order->getBuyer();
			$orderRecords   = XiFactory::getInstance('order','model')
								->loadRecords(array('buyer_id'=> $userId));

			$orders = array();
			foreach($orderRecords as $record){
				$orders[] = $record->order_id;
			} 
			
			$usedBy 	= $this->getAppParam('used_quantity','');
			$orderList  = explode(',', $usedBy);					
			$intersect  = array_intersect($orderList, $orders);

			//user already used the mentioned discount code, not allowed to use it again
			if(count($intersect) > 0 ){
				return XiText::_('COM_PAYPLANS_APP_DISCOUNT_ERROR_ALREADY_USED');
			}	
		}
		// if coupon have been used completely	
		// unlimited usage if allowed quantity is ''
		$allowedQuantity = $this->getAppParam('allowed_quantity', '');
		if($allowedQuantity !== '' 	&& $allowedQuantity <= count($this->getConsumers())){
			return XiText::_('COM_PAYPLANS_APP_DISCOUNT_ERROR_CODE_ALLOWED_QUANTITY_CONSUMED');
		}
		
		//Only required : if we have multiple discount per order
		//used_quantity : csv of order_id
		//if(in_array($order->getId(), $usedBy)){
		//	return true;
		//}
		
		return true;
	}

	public function _doCalculateDiscount(PayplansSubscription $subscription, $price, $discount)
	{
		if($price <= 0){
			return 0;
		}

		//calculate discount
		if($this->getAppParam('coupon_amount_type','fixed') === 'percentage'){
			return $this->getAppParam('coupon_amount')*$price/100;
		}

		return $this->getAppParam('coupon_amount');
	}

	public function getConsumers()
	{
		$usedBy = $this->getAppParam('used_quantity','');
		return ($usedBy == '') ? array() : explode(',', $usedBy);
	}
	
	public function addConsumers($orderId)
	{
		$usedBy   = $this->getConsumers();
		$usedBy[] = $orderId;
		$this->setAppParam('used_quantity',implode(',',$usedBy));
		$this->save();
	}
}