<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage	Discount
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


/**
 * Discount System
 * @author shyam
 */
class PayplansAppDiscount extends PayplansAppDiscounts
{
	//inherited properties
	protected $_location	= __FILE__;

	// Entry Function 
	public function onPayplansApplyDiscount(PayplansOrder $order, $discountCode)
	{
		$result = $this->_doCheckAllowed($order, $discountCode);
		
		//Important Check : use strict !== , Do not use != 
		if($result !== true){
			return $result;
		}
		
		//apply discount on each subscriptions
		$discountUsed = $this->_doApplyDiscount($order);

		// if discount have been used then update consumer list
		if($discountUsed){
			$this->addConsumers($order->getId());
		}

		return true;
	}

	//Check if current discount should be applied as per discount purpose
	public function _doCheckAllowed(PayplansOrder $order, $discountCode)
	{
		// is equal to my discount code
		if($discountCode != $this->getAppParam('coupon_code', false)){
			return false;
		}
		
		//	order already have discount
		if(floatval($order->getDiscount())){
			return XiText::_('COM_PAYPLANS_APP_DISCOUNT_ERROR_ORDER_ALREADY_HAVE_DISCOUNT');
		}

		// if coupon have been used completely	
		// unlimited usage if allowed quantity is ''
		$allowedQuantity = $this->getAppParam('allowed_quantity', '');
		if($allowedQuantity !== '' 	&& $allowedQuantity <= count($this->getConsumers())){
			return XiText::_('COM_PAYPLANS_APP_DISCOUNT_ERROR_CODE_ALLOWED_QUANTITY_CONSUMED');
		}
		
		//Only required : if we have multiple discount per order
		//used_quantity : csv of order_id
		//if(in_array($order->getId(), $usedBy)){
		//	return true;
		//}
		
		return true;
	}

	public function _doCalculateDiscount(PayplansSubscription $subscription, $price, $discount)
	{
		if($price <= 0){
			return 0;
		}
		
		if($subscription->getDiscount()){
		}

		//calculate discount
		if($this->getAppParam('coupon_amount_type','fixed') === 'percentage'){
			return $this->getAppParam('coupon_amount')*$price/100;
		}

		return $this->getAppParam('coupon_amount');
	}

	public function getConsumers()
	{
		$usedBy = $this->getAppParam('used_quantity','');
		return ($usedBy == '') ? array() : explode(',', $usedBy);
	}
	
	public function addConsumers($orderId)
	{
		$usedBy   = $this->getConsumers();
		$usedBy[] = $orderId;
		$this->setAppParam('used_quantity',implode(',',$usedBy));
		$this->save();
	}
}