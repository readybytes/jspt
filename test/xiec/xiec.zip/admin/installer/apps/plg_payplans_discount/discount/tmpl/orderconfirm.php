<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

?>


<div id="app-discount-apply">
	<div class="app-discount-apply-title"><?php echo XiText::_("COM_PAYPLANS_ENTER_DISCOUNT_CODE"); ?></div>
	<span id="app-discount-apply-inputs">
		<input id="app_discount_code_id" name="app_discount_code" value="" />
		<a  id="app_discount_code_submit" onClick="xi.order.discount.apply(<?php echo $orderId;?>);"><?php echo XiText::_("COM_PAYPLANS_APP_DISCOUNT_APPLY");?></a>
		<div id="app-discount-apply-error" class="error" style="display:none;">&nbsp;</div>
	</span>
</div>