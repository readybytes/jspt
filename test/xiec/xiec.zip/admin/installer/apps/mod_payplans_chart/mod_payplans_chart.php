<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license	GNU/GPL, see LICENSE.php
* @package	PayPlans
* @subpackage	Modules
* @contact 	shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

// ensure payplans is loaded 
require_once JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'includes'.DS.'includes.php';

// find which type of chart to show by default
$type  = $params->get('chart_type','default');
$modId = XiHelperUtils::jsCompatibleId($module->title.'_'.$module->id);
// render toolbar script, will update variables if toolbar was submited
require dirname(__FILE__).DS.'tmpl'.DS.'_script.php';

// render chart
require(JModuleHelper::getLayoutPath('mod_payplans_chart', $type));