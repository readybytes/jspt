<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license	GNU/GPL, see LICENSE.php
* @package	PayPlans
* @subpackage	Modules
* @contact 	shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<script type="text/javascript">
xi.jQuery(document).ready(function (){
	xi.jQuery('#modChartForm_<?php echo $modId;?> select').bind('change', function(){document.modChartForm_<?php echo $modId;?>.submit();});
});
</script>


<form action="<?php echo JURI::getInstance()->toString(); ?>" method="post" id="modChartForm_<?php echo $modId;?>" name="modChartForm_<?php echo $modId;?>">
<div class="mod-payplans-chart-form">
	<div class="mod-payplans-chart-global">
		<?php 
			$postType = XiFactory::getApplication()->getUserStateFromRequest('params_'.$modId,'params_'.$modId, null);
			if(isset($postType) && isset($postType['chart_type'])){
				$type=$postType['chart_type'];
			}
			
			// echo chart selection toolbar
			$chartSelector = new XiParameter("chart_type=$type\n\n", dirname(dirname(__FILE__)).DS.'mod_payplans_chart.xml');
			$results = $chartSelector->renderToArray('params_'.$modId);
		?>
		<div class="mod-payplans-chart-filter">	
			<span class="chart-filter-title"><?php echo XiText::_('MOD_PAYPLANS_CHART_TYPE_LABEL');?></span>
			<span class="chart-filter-option"><?php echo $results['chart_type'][1]; ?></span>
		</div>
	</div>
	
	<div class="mod-payplans-chart-specific">
		<?php 
			$toolbar_path = JModuleHelper::getLayoutPath('mod_payplans_chart', $type.'_toolbar');
			if(JFile::exists($toolbar_path)){ 
				include $toolbar_path;
			}
		 ?>
	</div>

</div>
</form>