<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license	GNU/GPL, see LICENSE.php
* @package	PayPlans
* @subpackage	Modules
* @contact 	shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

$options = array ();
// IMP : use %n for date format as we need to replace it by %n-1 (javascript month starts from 0)
$chartRevenueTimeOptions = array(
							'%Y,%n,%d' => 'DAILY',
							'%Y,%n,01' => 'MONTHLY',
							'%Y,00,01' => 'YEARLY'
						);

$options[] = JHTML::_('select.option', '%Y,%n,%d', XiText::_('MOD_PAYPLANS_CHART_DEFAULT_FILTER_REVENUE_TIME_LABEL'));						
foreach($chartRevenueTimeOptions as $value => $opt ){
	$options[] = JHTML::_('select.option', $value, XiText::_('MOD_PAYPLANS_CHART_DEFAULT_FILTER_REVENUE_TIME_OPTION_'.$opt));
}

$modChartDefaultFilterRevenueTimeValue = XiFactory::getApplication()->getUserStateFromRequest('modChartDefaultFilterRevenueTimeValue_'.$modId,'modChartDefaultFilterRevenueTimeValue_'.$modId, '%Y,%n,%d');
?>
<div class="mod-payplans-chart-filter"> 
	<span class="chart-filter-option"><?php echo XiHTML::_('select.genericlist',  $options, 'modChartDefaultFilterRevenueTimeValue_'.$modId, '', 'value', 'text', $modChartDefaultFilterRevenueTimeValue, 'modChartDefaultFilterRevenueTimeValue_'.$modId); ?></span>
</div>
<?php 
