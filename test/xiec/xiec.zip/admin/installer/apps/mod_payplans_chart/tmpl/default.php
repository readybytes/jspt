<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license	GNU/GPL, see LICENSE.php
* @package	PayPlans
* @subpackage	Modules
* @contact 	shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

// Create a chart of given type
$chart = XiFactory::getChart('annotatedtimeline');
	
//set name 
$chart->setTitle($module->title);
$chart->setId($modId);
		
// set dimension
$chart->setOption('title',$module->title);
$chart->setOption('height', $params->get('chart_height',300));
$chart->setOption('width', $params->get('chart_width',700));

//1. add columns in chart
$chart->data->addColumn('day', XiText::_('MOD_PAYPLANS_CHART_COLUMN_DATE'), 'date');
$chart->data->addColumn("revenue", XiText::_('MOD_PAYPLANS_CHART_COLUMN_TOTAL_REVENUE'), 'number');
	

//2. set data now
$data = array();
$payments = PayplansApi::getPayments(array());
foreach($payments as $payment){
	//calculate revenue only on the basis of completed payments
	if($payment->status != XiStatus::PAYMENT_COMPLETE){
		continue;
	}
	$date = new XiDate($payment->created_date);
	$day = $date->toFormat($modChartDefaultFilterRevenueTimeValue, null, null, true /*format as per JS*/);
	
	//init day
	if(isset($data[$day])==false){
		$data[$day] = array('day'=> "Date($day)", 'revenue' => 0);
	}
	
	$data[$day]['revenue'] += intval($payment->amount,10);
}
	
//add data in chart
$chart->data->addRows($data);

// render
echo $chart->draw();