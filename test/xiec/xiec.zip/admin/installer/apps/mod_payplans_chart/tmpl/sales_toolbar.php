<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license	GNU/GPL, see LICENSE.php
* @package	PayPlans
* @subpackage	Modules
* @contact 	shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

$options = array ();
$chartSalesTimeOptions = array(
							'7_DAYS' => '000007000000',
							'1_MONTH'=> '000100000000',
							'2_MONTH'=> '000200000000',
							'3_MONTH'=> '000300000000',
							'6_MONTH'=> '000600000000',
							'1_YEAR' => '010000000000'
						);
$options[] = JHTML::_('select.option', '000100000000', XiText::_('MOD_PAYPLANS_CHART_SALES_FILTER_PERIOD_LABEL'));						
foreach($chartSalesTimeOptions as $opt => $value){
	$options[] = JHTML::_('select.option', $value, XiText::_('MOD_PAYPLANS_CHART_SALES_FILTER_PERIOD_OPTION_'.$opt));
}

$modChartSalesFilterPeriodValue = XiFactory::getApplication()->getUserStateFromRequest('modChartSalesFilterPeriodValue_'.$modId,'modChartSalesFilterPeriodValue_'.$modId, '000100000000');
?>
<div class="mod-payplans-chart-filter">	
	<span class="chart-filter-option"><?php echo JHTML::_('select.genericlist',  $options, 'modChartSalesFilterPeriodValue_'.$modId, '', 'value', 'text', $modChartSalesFilterPeriodValue, 'modChartSalesFilterPeriodValue_'.$modId);?></span>
</div>
<?php 
