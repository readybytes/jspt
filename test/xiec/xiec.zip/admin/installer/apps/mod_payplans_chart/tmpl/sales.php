<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license	GNU/GPL, see LICENSE.php
* @package	PayPlans
* @subpackage	Modules
* @contact 	shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

// Create a chart of given type
$chart = XiFactory::getChart('columnchart');
	
//set name 
$chart->setTitle(XiText::_('MOD_PAYPLANS_CHART_TYPE_SALES'));
$chart->setId($modId);

// set dimension
$chart->setOption('title',XiText::_('MOD_PAYPLANS_CHART_TYPE_SALES'));
$chart->setOption('height', $params->get('chart_height',300));
$chart->setOption('width', $params->get('chart_width',700));

    
//1. add columns in chart
$chart->data->addColumn('date', XiText::_('MOD_PAYPLANS_CHART_COLUMN_DATE'), 'date');
	
//2. we will add columns for every plan
$plans = PayplansApi::getPlans();
$planIds = array();
foreach($plans as $plan){
	$chart->data->addColumn("plan_{$plan->plan_id}_revenue", $plan->title, 'number');
	$planIds[] = $plan->plan_id;
}
	
//3. set data now
$now  = new XiDate();
$filter = array();
$filter['subscription_date']= array( array('<' , $now->toMySQL()),
								array('>' , $now->subtractExpiration($modChartSalesFilterPeriodValue)->toMySQL()) 
							  );

$filter['status']=array(array('<>', XiStatus::NONE));
							  
$subscriptions = PayplansApi::getSubscriptions($filter);
$data = array();
foreach($subscriptions as $subscription){
	$date = new XiDate($subscription->subscription_date);
	$day = $date->toFormat(XiDate::YYYY_MM_DD_FORMAT, null, null, true /*format as per JS*/);
	
	//init day
	if(isset($data[$day])==false){
		$data[$day] = array('date'=> "Date($day)");

		// setup all columns
		foreach($planIds as $plan){
			$data[$day][$plan]= 0;
		}
	}
	
	// not a valid plan
	if(!in_array($subscription->plan_id, $planIds )){
		continue;
	}
	
	$data[$day][$subscription->plan_id]+=1;
}
//sort data according to dates
asort($data);
//add data in chart
$chart->data->addRows($data);

//
$chart->setOption('isStacked', true);
$chart->setOption('vAxis', array('title' => XiText::_("MOD_PAYPLANS_CHART_TYPE_SALES_HAXIS_TITLE")));

// render
echo $chart->draw();