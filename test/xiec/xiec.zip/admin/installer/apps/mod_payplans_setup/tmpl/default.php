<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license	GNU/GPL, see LICENSE.php
* @package	PayPlans
* @subpackage	Modules
* @contact 	shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

JHTML::_('behavior.tooltip');
$counter = 1;
$required= 0;
?>


<div id="mod-payplans-setup" >
<?php foreach($rules as $rule) :?>
	<?php
	 	$text = $rule->getMessage();
	 	$pClass = 'done';
	 	if($rule->isRequired()){
	 		$required++;
	 		$pClass = 'required';
	 		$text ='<a href="index.php?option=com_payplans&view=support&task=setup&action=doApply&name='.$rule->_name
	 				. '&from='.$rule->_returl.'">'.$text.'</a>';
	 	}
 	?>
	<div id="setup-<?php echo $counter; ?>" class="setuprule-<?php echo $rule->_name; ?>">
	 	<div class="setup-<?php echo $rule->getType().'-'.$pClass;?>" >
				<p class="tooltip hasTip" title="Purpose::<?php echo $rule->getTooltip();?>" payplans-tipsy-gravity="e" >
		 			<?php echo $text;?>
		 		</p>
		 </div>
	</div>
	<?php  $counter++;  ?>
<?php endforeach; ?>
</div>
<?php
