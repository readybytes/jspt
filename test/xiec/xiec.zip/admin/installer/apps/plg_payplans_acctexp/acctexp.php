<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
* @package		Payplans
* @subpackage		Plugin
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class plgPayplansmigrationAcctexp extends XiPluginMigration
{
	protected $_location   	= __FILE__;
	protected $_title		= 'acctexp';
	
	// component name
	protected $_component 	= 'acctexp';
	
	//payment from these apps will be migrated
	protected $_appMapper = array(
								'paypal'	=>'paypal',
								'authorize'	=>'authorize_aim',
								'offlinepay'=>'offline_payment',
								'adminpay' 	=>'admin',
								'2checkout'	=>'2checkout'
								);
	
	protected function _estimateRecords()
	{
		$query	= new XiQuery();
		$records = 0;
		
		$records += (int) $query->select(' COUNT(*)')->from('#__acctexp_plans')->dbLoadQuery()->loadResult();
		$query->clear();
		
		$records += (int) $query->select(' COUNT(*)')->from('#__acctexp_invoices')->dbLoadQuery()->loadResult();
		$query->clear();
		
		$records += (int) $query->select(' COUNT(*)')->from('#__acctexp_subscr')->dbLoadQuery()->loadResult();
		$query->clear();
		
		//$records += $query->select(' COUNT(*)')->from('#__payplans_coupons')->dbLoadQuery()->loadResult();
		//$records += $query->select(' COUNT(*)')->from('#__payplans_log_history')->dbLoadQuery()->loadResult();
		//$records += $query->select(' COUNT(*)')->from('#__payplans_eventlog')->dbLoadQuery()->loadResult();
		//$records += $query->select(' COUNT(*)')->from('#__payplans_microintegrations')->dbLoadQuery()->loadResult();
	
		//store in session
		$this->_helper->write('record_count',$records);
		return $records;
	}
	
	protected function _migrateTables()
	{
		$query	= new XiQuery();			
		//truncate tables
		$query->truncate('#__payplans_plan')->dbLoadQuery()->query();
		$query->truncate('#__payplans_planapp')->dbLoadQuery()->query();
		$query->truncate('#__payplans_order')->dbLoadQuery()->query();
		$query->truncate('#__payplans_subscription')->dbLoadQuery()->query();
		$query->truncate('#__payplans_payment')->dbLoadQuery()->query();
		$query->clear();
		
		// Migrate Plans
		// insert records which can be directly mapped
		$str 	=  ' INSERT INTO `#__payplans_plan` 
						(`plan_id`, `title`, `published`, `visible`, `ordering`, `description`)
					  SELECT  `id`, `name`, `active`, `visible`, `ordering`, `desc`
					  FROM `#__acctexp_plans`
					';
		$query->dbLoadQuery($str)->query();
		$query->clear();
		
		// create blank orders
		$str = 	'INSERT INTO `#__payplans_order` 
					 (`order_id`, `buyer_id`, `created_date`, `subtotal`, `total`, `currency`)
				 SELECT    i.`id`, i.`userid`, i.`created_date`, i.`amount`, i.`amount`, i.`currency`
				 FROM `#__acctexp_invoices`  AS i
				 INNER JOIN  `#__acctexp_subscr` AS s ON i.`subscr_id`= s.`id`
				 INNER JOIN  `#__users` 	AS u ON i.`userid`=u.`id`
				 INNER JOIN  `#__acctexp_plans` AS p ON i.`usage`=p.`id`
				 WHERE i.`transaction_date` <> "0000-00-00 00:00:00"
				 AND i.`userid` <> 0 
				';
		$query->dbLoadQuery($str)->query();
		$query->clear();
		
		// create subscriptions
		$str = 	'INSERT INTO `#__payplans_subscription` 
					(`subscription_id`, `user_id`, `plan_id`, `order_id`, `subscription_date`, `expiration_date`, `cancel_date`)
				SELECT    i.`id`, s.`userid`, s.`plan`, i.`id`,  s.`signup_date`, s.`expiration`, s.`cancel_date`  
				FROM `#__acctexp_subscr` AS s
				LEFT JOIN   `#__acctexp_invoices` AS i 	ON i.`subscr_id`= s.`id`
				INNER JOIN  `#__users` 			  AS u 	ON i.`userid`=u.`id`
				INNER JOIN  `#__acctexp_plans`    AS p 	ON s.`plan`=p.`id`
				WHERE i.`transaction_date` <> "0000-00-00 00:00:00"
				AND i.`userid` <>0 '
				;
		$query->dbLoadQuery($str)->query();
		$query->clear();
		
		// create payments
		// order_id and app_id should be 0 so it does not interfere with other objects.
		// once we create apss and add data to it, then we will update it.
		$str = 	'INSERT INTO `#__payplans_payment` 
					(`payment_id`, `order_id`, `app_id`, `status`,  `modified_date`, `currency`, `amount`, `created_date`)
				 SELECT    h.`id`, 	0, 			0, '. XiStatus::PAYMENT_COMPLETE.',		 h.`transaction_date`, i.`currency`, h.`amount`, i.`created_date`  
				 FROM  `#__acctexp_invoices` AS i
				 INNER JOIN  `#__acctexp_subscr`   	  AS s 	ON i.`subscr_id`= s.`id`
				 INNER JOIN  `#__acctexp_log_history` AS h 	ON i.`invoice_number`= h.`invoice_number`
				 INNER JOIN  `#__users` 			  AS u 	ON i.`userid`=u.`id`
				 INNER JOIN  `#__acctexp_plans`    	  AS p 	ON s.`plan`=p.`id`
				 WHERE i.`transaction_date` <> "0000-00-00 00:00:00"
				 AND i.`userid` <>0  AND h.response <> "YTowOnt9" 
				';
		$query->dbLoadQuery($str)->query();
		$query->clear();
		
		// setup next functions
		$this->_helper->write('message', 'Tables migration done');		
		$this->_scheduleNextFunction('_migratePlans');
		return 0;
	}
	
	
	// These functions migrate one table at a time
	protected function _migratePlans($limit, $offset=0)
	{
		$query	= new XiQuery();
		
		// map records which cannot be mapped directly
		$records = $query->select('*')->select('`active` as `published`')
						->from('#__acctexp_plans')
						->limit($limit, $offset)
						->dbLoadQuery()
						->loadAssocList('id');
						
						

		// start migrating records 
		foreach($records as $id => $record){
			
			$plan = PayplansPlan::getInstance($id);
			$params = unserialize(base64_decode($record['params']));
			
			// migrate payment & time data
			$price		= $params['full_free'] ? 0 : $params['full_amount'];
			$expiration	= PayplansHelperPlan::convertExpirationTime($params['full_period'],	$params['full_periodunit']);

			$plan->getPayment()->setValue('price', $price);
			$plan->getTime()->setValue('expiration', $expiration);
			
			//XITODO : migrate trial data when we have it. #118
			$plan->save();
		}
		
		$this->_helper->write('message', 'Migrating Plans ');
		$this->_scheduleNextFunction('_migrateSubscription', $query, $offset, count($records));
		return count($records);
	}
	
	/**
	 */
	protected function _migrateSubscription($limit, $offset=0)
	{	
		// apply limit
		$query	= new XiQuery();		
		$records= $query->select('s.*, i.*, i.`id` as subscription_id')
						->from('#__acctexp_subscr AS s')
						->join('left', '#__acctexp_invoices AS i ON i.`subscr_id`= s.`id` ')
						->join('inner', '`#__users`  AS u 	ON i.`userid`=u.`id` ')
						->join('inner', '`#__acctexp_plans` AS p 	ON s.`plan`=p.`id`')
						->where('`transaction_date` <> "0000-00-00 00:00:00" AND i.`userid` <>0 ')
						->limit($limit, $offset)
						->order('i.`id`')
						->dbLoadQuery()
						->loadAssocList('subscription_id');
			
		// start migrating records 
		foreach($records as $id => $record){
			
			//	 Load Subscription
			$subscription = PayplansSubscription::getInstance($id);
			if(!$subscription){
				continue;
			}
			
			//update status
			switch($record['status'])
			{	
				case 'Hold':
					$status = XiStatus::SUBSCRIPTION_HOLD;
					$orderStatus = $record['active'] ? XiStatus::ORDER_COMPLETE : XiStatus::ORDER_HOLD;
					break;
					
				case 'Excluded':
					//update expiry date
					$subscription->set('9999-01-01 01:01:01');					
				case 'Active':
					$status = XiStatus::SUBSCRIPTION_ACTIVE;
					$orderStatus = XiStatus::ORDER_COMPLETE;
					break;
					
				case 'Expired':
				case 'Cancelled':
				default:
					$status = XiStatus::SUBSCRIPTION_EXPIRED;
					$orderStatus = ($record['status'] == 'Expired') ? XiStatus::ORDER_COMPLETE  : XiStatus::ORDER_HOLD;
					break;
			} 
			
			//XITODO : Add IP to proper table. #289
			//$params = unserialize(base64_decode($record['params']));
			//$ip	= @$params['creator_ip'];
			
			// update order total
			$order = $subscription->getOrder(PAYPLANS_INSTANCE_REQUIRE);
			
			//update order status			
			$order->setStatus($orderStatus)->save();
				
			// finally save changes in subscription
			$subscription->setStatus($status);
			$subscription->setPrice($record['amount']);			
			$subscription->save();
			
			//refresh order
			$order->refresh()->save();
		}
		
		$this->_helper->write('message', 'Migrating Subscription');
		$this->_scheduleNextFunction('_migratePayments',$query, $offset, count($records));
		return count($records);
	}

	protected function _migratePayments($limit, $offset=0)
	{
		$paymentAppMapper =  $this->_getPaymentMapper();
		
		// apply limit
		$query	= new XiQuery();		
		$records= $query->select('i.*, h.*, h.`id` as payment_id , i.`id` as order_id')
						->from('#__acctexp_invoices 				AS i' )
						->join('inner', '`#__acctexp_subscr`		AS s ON i.`subscr_id`= s.`id` ')
						->join('inner', '`#__acctexp_log_history` 	AS h ON i.`invoice_number` = h.`invoice_number` ')
						->join('inner', '`#__users`  				AS u ON i.`userid`=u.`id` ')
						->join('inner', '`#__acctexp_plans` 		AS p ON s.`plan`=p.`id`')
						->where('i.`transaction_date` <> "0000-00-00 00:00:00" AND i.`userid` <>0  AND h.`response` <> "YTowOnt9" ')
						->limit($limit, $offset)
						->order('i.`id`')
						->dbLoadQuery()
						->loadAssocList('payment_id');
			
		// start migrating records 
		foreach($records as $id => $record){
			
			//	 Load Subscription
			$payment = PayplansPayment::getInstance($id);
			if(!$payment){
				continue;
			}
			
			$response = $this->_aecResponseDecoding($record['response']);
			if($response && !is_array($response)){
				// we can't convert these stupidly encoded transactions
				continue;				
			}
		
			// finally save changes in payment
			$payment->setStatus(XiStatus::PAYMENT_COMPLETE);
			$payment->setOrder($record['order_id']);
			$payment->setTransaction($response);
					
			//if app mapping not available
			if(isset($paymentAppMapper[$record['method']])){
				$payment->setApp($paymentAppMapper[$record['method']]->getId());
			}else{
				$payment->setApp(0);
			}
			
			$payment->save();
		}
		
		$this->_helper->write('message', 'Migrating Payments');
		
		$this->_scheduleNextFunction('_migrationComplete', $query, $offset, count($records));
		return count($records);
	}
	
	public function _aecResponseDecoding($response)
	{
		// try to decode it
		$tmp = base64_decode($response);
		if(empty($tmp) || is_string($tmp)===false){
			return null;
		}
			
		$response  = unserialize($tmp);			
		$i =0;
		
		//re-decode if not proper array
		while(is_array($response)===true  &&  count($response)===1)
		{
			$tmp  = array_keys($response);
			if(is_array($tmp)===false || count($tmp)<=0 ){
				break; 
			}	
			
			$tmp = base64_decode($tmp[0]);
			
			if(empty($tmp) || is_string($tmp)===false 
					|| (is_array($tmp)===false && strstr($tmp, 'a:')==FALSE)){
				$response = null;
				break; 
			}
			
			$response  = unserialize($tmp);
			
			if($i >= 50){
				$response = null;
				break;
			}
			
			$i++;	
		}
		
		return $response;
	}
	
	protected function _migrateHistory()
	{}

	protected function _migrateCoupons()
	{}
}
