<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage	Discount
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Payplans Discount Plugin
 *
 * @author shyam
 */
class plgPayplansBasictax extends XiPlugin
{
	public function onPayplansSystemStart()
	{
		$dir = dirname(__FILE__).DS.'basictax'.DS.'app';
		PayplansHelperApp::addAppsPath($dir);
		
		return true;
	}
	
	
	// on render of order, display output
	public function onPayplansViewBeforeRender(XiView $view, $task)
	{
		if(!($view instanceof PayplanssiteViewOrder)){
			return true;
		}

		if($task != 'confirm'){
			return true; 
		}

		$country 	= 0;
		$userId 	= XiFactory::getUser()->id;
		$orderId  = $view->getModel()->getId();
		
		if(!empty($userId)){
			$user 	  =  PayplansUser::getInstance($userId);
			$country  =  $user->getCountry();
			
			$orderKey = PayplansOrder::getInstance($orderId)->getKey();

			// Apply tax as per user country
			self::_onPayplansTaxRequest($orderKey, $country);
		}

		$this->_assign('country', $country);
		$this->_assign('orderId', $orderId);
		return array('payplans_order_confirm_payment' => $this->_render('orderconfirm'));
	}

	//apply tax on the order supplied according to mentioned country
	//returns updated order and error  
	public function _onPayplansTaxRequest($orderKey, $country)
	{
		//trigger the discount
		$orderId = XiFactory::getEncryptor()->decrypt($orderKey);
		$order = PayplansOrder::getInstance($orderId);
		$args  = array($order, $country);
		$results = PayplansHelperEvent::trigger('onPayplansApplyTax', $args, '', $order);

		$error = '';
		$tax =0; // default tax is Zero
		foreach($results as $result){
			
			// check if app returned error string
			if(is_string($result)){
				$error .= $result . ' ';
				break;
			}

			// tax rate was porivded
			if(is_float($result)){
				$tax= $result;
				break;
			}
		}
		$order->setTaxRate($tax)->save();
		
		//save user country
		$user = $order->getBuyer(PAYPLANS_INSTANCE_REQUIRE);
		$user->setCountry($country)
           			->save();

        return array($order, $error);

	}
	
	// on render of order, display output
    function onPayplansTaxRequest($orderKey, $country)
     {
     	list($order, $error) = self::_onPayplansTaxRequest($orderKey, $country);
     	
		// order have been updated
		$response = XiFactory::getAjaxResponse();
		
		// if error = '', then no error will be shown
		$response->addScriptCall('xi.tax.displayError',$error);
		$response->addScriptCall('xi.tax.validateCountry');
		$response->addScriptCall('xi.jQuery(\'#payplans\').find(\'.tax-amount\').html', $order->getTaxAmount());
		$response->addScriptCall('xi.jQuery(\'#payplans\').find(\'.first-tax-amount\').html', $order->getFirstPriceTax());
		$response->addScriptCall('xi.jQuery(\'#payplans\').find(\'.regular-amount\').html',$order->getTotal());
		$response->addScriptCall('xi.jQuery(\'#payplans\').find(\'.first-amount\').html',$order->getFirstTotal());

		$response->sendResponse();
	}
}
