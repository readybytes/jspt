<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplanssiteViewBasictax extends XiView
{
	function __construct($config = array())
	{
		//need to give our template address
		$config['template_path']=array(dirname(__FILE__).DS.'tmpl'.DS.'site');
		return parent::__construct($config);
	}
}

class PayplansadminViewBasictax extends XiView
{
	function __construct($config = array())
	{
		//need to give our template address
		$config['template_path']=array(dirname(__FILE__).DS.'tmpl'.DS.'admin');
		return parent::__construct($config);
	}
}