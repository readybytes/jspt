xi.extend({
	tax : {
		
		validateCountry:function(){
			//disable checkout button only when no country is selected
			if(xi.jQuery('#app_basictax_country_id').val() != 0 ){
				xi.jQuery('#app_basictax_country_id').removeClass('invalid');
				xi.jQuery('#payplans-order-confirm').attr("disabled", false);
			}
			else{
				xi.jQuery('#app_basictax_country_id').addClass('invalid');
				xi.jQuery('#payplans-order-confirm').attr("disabled", true);
			}
		},
		
		apply: function(){
			var orderKey = xi.jQuery('input[name="order_key"]').val();
			var country = xi.jQuery('#app_basictax_country_id').val();
			var url = "index.php?option=com_payplans&view=order&task=trigger&event=onPayplansTaxRequest&order_key="+orderKey;
			
			// args to pick
			//var args= Array(orderKey, country);
			
			// remove the error message
			xi.tax.displayError('');
			
			//disable the button
			xi.tax.validateCountry();
			
			xiajax.call(url, orderKey, country);
		},
		
		displayError: function(message){
			xi.jQuery('#app-tax-apply-error').html(message);
			if(message !== ''){
				xi.jQuery('#app-tax-apply-error').css('display','block');
			}
			else{
				xi.jQuery('#app-tax-apply-error').css('display','none');
			}
		}
	}
});

xi.jQuery(document).ready(function (){
	// disable payment button
	xi.tax.validateCountry();
	// update order details as per tax
	xi.tax.apply();
	// attach tax information update handler
	xi.jQuery('#app_basictax_country_id').bind('change', xi.tax.apply);
});