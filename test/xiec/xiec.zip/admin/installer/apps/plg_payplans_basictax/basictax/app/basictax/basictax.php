<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage	Discount
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


/**
 * Discount System
 * @author shyam
 */
class PayplansAppBasictax extends PayplansApp
{
	//inherited properties
	protected $_location	= __FILE__;
	
	// 	Entry Function 
	public function onPayplansApplyTax(PayplansOrder $order, $countryCode)
	{
		$applyTo = $this->getAppParam('tax_country', array());
		
		if($applyTo != PAYPLANS_CONST_ALL){
			//When only one item is selected 
			if(is_array($applyTo )==false){
				$applyTo = array($applyTo );
			}
		
			// not applicable
			if(in_array($countryCode,$applyTo) ==false){
				return false;
			}
		}
				
		// return tax rate to be used
		// MUST float cast it
		return floatval($this->getAppParam('tax_rate', 0));	
	}	
}