<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansTableBasictax extends XiTable
{

	function __construct($tblFullName=null, $tblPrimaryKey=null, $db=null)
	{
		// if table does not exist, create it
		if(XiHelperTable::isTableExist('#__xiec_plugin_basictax_taxrate')==false)
		{
			$sql = "CREATE TABLE IF NOT EXISTS `#__xiec_plugin_basictax_taxrate` (
						  `taxrate_id`    INT NOT NULL AUTO_INCREMENT,
						  `app_id`    	  INT NULL default 0,
						  `title`         VARCHAR(255) NOT NULL default '',
						  `description`   VARCHAR(255) NOT NULL default '',
						  `rate`          DECIMAL(10,5) NOT NULL DEFAULT '0.00000',
						  `published`     TINYINT(1) NULL DEFAULT 1,
						  `ordering`      INT NULL DEFAULT 0,
						  `created_date`  DATETIME NOT NULL,
						  `modified_date` DATETIME NOT NULL ,
						  `params`	  	  TEXT NOT NULL,
						   PRIMARY KEY (`taxrate_id`)
						)
						ENGINE = MyISAM
						DEFAULT CHARACTER SET = utf8;";
			$dbo = JFactory::getDBO();
			$dbo->setQuery($sql);
			$dbo->query();
			
			// Temporary Hack : clean cached tablelist, we have added one
			XiHelperTable::$tables = null;
		}

		// Our table have different names then class name so we need to provide more data
		return parent::__construct('#__xiec_plugin_basictax_taxrate', 'taxrate_id');
	}
	
}