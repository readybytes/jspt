<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in


*/
if(defined('_JEXEC')===false) die();
?>
<script src="<?php echo PayplansHelperUtils::pathFS2URL(dirname(__FILE__).DS.'basictax.js');?>" type="text/javascript"></script>
<div class="payment-details">
	<div class = "detail-label">
		<?php echo XiText::_("COM_PAYPLANS_ENTER_TAX_INFORMATION"); ?>*
	</div>

	<div class = "detail-dec">
		<?php echo XiHtml::_('elements.xicountry', 'app_basictax_country_id', $country, array('option_none'=>true)); ?>
		<span id="app-tax-apply-error" class="error" style="display:none;">&nbsp;</span>
	</div>
</div>