<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Log
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>

<form action="<?php echo $uri; ?>" method="post" id="adminForm" name="adminForm">
	
	<?php echo $this->loadTemplate('filter'); ?>
	<table id="payplans_grid" class="payplans_grid adminlist plan-grid">
		
		<thead>
		<!-- TABLE HEADER START -->
			<tr>
				<th class="default-grid-sno">
			    <?php echo XiHtml::_('grid.sort', "NUM", $record_key, $filter_order_Dir, $filter_order);?>
			    </th>			
			    <th class="default-grid-chkbox">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($records); ?>);" />
				</th>
				<th><?php echo XiHtml::_('grid.sort', "PLG_PAYPLANS_BASICTAX_GRID_TITLE", 'title', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "PLG_PAYPLANS_BASICTAX_GRID_RATE", 'rate', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "PLG_PAYPLANS_BASICTAX_GRID_PUBLISHED", 'published', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "PLG_PAYPLANS_BASICTAX_GRID_CREATED_DATE", 'created_date', $filter_order_Dir, $filter_order);?></th>
				
			</tr>
		<!-- TABLE HEADER END -->
		</thead>
		
		<tbody>
		<!-- TABLE BODY START -->
			<?php $count= $limitstart;
			$cbCount = 0;
			foreach ($records as $record):?>
				<tr class="<?php echo "row".$count%2; ?>">
					<td> <?php echo $count+1; ?> </td>
					<th class="default-grid-chkbox">
		    			<?php echo XiHtml::_('grid.id', $cbCount++, $record->{$record_key} ); ?>
		    		</th>
					<td><?php echo $record->title;?>
						<br />
						<?php echo $record->description;?>
					</td>
					<td><?php echo $record->rate ;?></td>
					<td><?php echo XiHtml::_("grid.switchBool", $record, 'published', $count);?></td>					
					<td><?php echo $record->created_date ;?></td>	
				</tr>
			<?php $count++;?>
			<?php endforeach;?>
		<!-- TABLE BODY END -->
		</tbody>
		
		<tfoot>
			<tr>
				<td colspan="9">
					<?php echo $pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
	</table>

	<input type="hidden" name="filter_order" value="<?php echo $filter_order;?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $filter_order_Dir;?>" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
</form>
<?php 