<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* 
* Highly Inspired from AEC micro integration for docman
*/
if(defined('_JEXEC')===false) die();

class PayplansAppMtree extends PayplansApp
{
	protected $_location	= __FILE__;
	
	const DO_NOTHING = -1;
	const SET_TRUE 	 =  1;
	const SET_FALSE  =  0;
	
	// applicable only if mosets tree exist
	public function _isApplicable(PayplansIfaceApptriggerable $refObject)
	{
		return JFolder::exists(JPATH_SITE .DS.'components'.DS.'com_mtree');
	}
	
	public function onPayplansSubscriptionAfterSave($prev, $new)
	{
		// no need to trigger if previous and current state is same
		if($prev != null && $prev->getStatus() == $new->getStatus()){
			return true;
		}

		// check the status
		if($new->getStatus() != $this->getAppParam('on_status', XiStatus::NONE)){
			return true;
		}
		$user_id = $new->getBuyer();
		
		// do publish/unpublish
		$publish_listings = $this->getAppParam('publish_listings', self::DO_NOTHING);
		$this->_updateListings('link_published', $user_id, $publish_listings);

		$feature_listings = $this->getAppParam('feature_listings', self::DO_NOTHING);
		$this->_updateListings('link_featured', $user_id, $feature_listings);

		return true;
	}
	
	// When new Listing is added this should be activated immeditaely
	function onMTreeListing(PayplansUser $user, $user_id)
	{
		$message = array();
		
		$userPlans = $user->getPlans();
		
		if($this->getParam('applyAll',false) == false){
			$appPlans = $this->getPlans();
			
			if(count(array_intersect($userPlans, $appPlans)) <= 0){
				return false;
			}
		}

		if(!empty($userPlans)){
			$publish_listings = $this->getAppParam('publish_listings', self::DO_NOTHING);
			$this->_updateListings('link_published', $user_id, $publish_listings);
	
			$feature_listings = $this->getAppParam('feature_listings',self::DO_NOTHING);
			$this->_updateListings('link_featured', $user_id, $feature_listings);
		}
		return true;
	}

	function _updateListings($what, $userid, $newStatus=self::DO_NOTHING)
	{
		if($newStatus === self::DO_NOTHING){
			return true;
		}
			
		$db = JFactory::getDBO();
		// attempted to publish only those link which are unpublished
		if($what == 'link_published'){
			$query =  ' UPDATE #__mt_links'
						. ' SET ' .$what.  '='. $newStatus
						. ' WHERE `user_id` ='. $userid.' AND `link_published` = 0'
						. ' LIMIT '.$this->getAppParam('allowed_listings',1)
						;
		}
		//a link is marked as featured only when it is published
		if($what == 'link_featured'){
			$query =  ' UPDATE #__mt_links'
						. ' SET ' .$what.  '='. $newStatus
						. ' WHERE `user_id` ='. $userid.' AND `link_published` = 1 AND `link_featured` = 0'
						. ' LIMIT '.$this->getAppParam('allowed_listings',1)
						;
		}
		$db->setQuery( $query );
		if($db->query()){
			return true;
		} else {
			$this->setError( $db->getErrorMsg());
			return false;
		}
	}
	
}