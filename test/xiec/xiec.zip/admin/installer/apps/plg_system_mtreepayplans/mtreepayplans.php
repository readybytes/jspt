<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * Payplans Mosets Tree Plugin
 * @author shyam
 */
jimport('joomla.filesystem.path');
jimport( 'joomla.plugin.plugin' );

class plgSystemMtreepayplans extends JPlugin
{
	function __construct(& $subject, $config = array())
	{
		parent::__construct($subject, $config);
	}
	
	public function onPayplansSystemStart()
	{
		//add app path to app loader
		$appPath = dirname(__FILE__).DS.'mtreepayplans'.DS.'app';
		PayplansHelperApp::addAppsPath($appPath);

		return true;
	}
	
	function onAfterRoute()
	{
		$user_id = JFactory::getUser()->get('id');
		$component = JRequest::getVar('option');

		if($component != 'com_mtree'){
			return false;
		}
		// initially unpublish all the listing submitted by the user
		$db = JFactory::getDBO();
		$query =  ' UPDATE #__mt_links'
					. ' SET `link_published` = 0'
					. ' WHERE `user_id` ='. $user_id
					;

		$db->setQuery( $query );
		$db->query();
	
		//trigger the app
		$user 	 = PayplansUser::getInstance($user_id);
		$args	 = array($user, $user_id);
		$results = PayplansHelperApp::trigger('onMTreeListing', $args, '', $user);
	}
}