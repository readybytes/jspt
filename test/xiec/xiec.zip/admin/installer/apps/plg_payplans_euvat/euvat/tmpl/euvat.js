xi.extend({
	euvat : {
		/* XITODO : move to order namespace */
		validateCountryAndPurpose:function(){
			
			var disable = false;
	
			//disable checkout button only when no country is selected
			xi.jQuery('#app_euvat_country_id').addClass('invalid');
			var country = xi.jQuery('#app_euvat_country_id').val();
			if(country != 0 ){
				xi.jQuery('#app_euvat_country_id').removeClass('invalid');
			}else{
				disable = disable || true;
			}
			
			// check purpose is correct
			xi.jQuery('#app_euvat_use_purpose').addClass('invalid');
			var purpose = xi.jQuery('#app_euvat_use_purpose').val();
			if(purpose != 0 || xi.jQuery('#app_euvat_use_purpose').css('display')=='none'){
				xi.jQuery('#app_euvat_use_purpose').removeClass('invalid');
			}else{
				disable = disable || true;
			}

			// check business purpose
			if(purpose == 2){				
				var businessName = xi.jQuery('#app_euvat_business_name').val();
				xi.jQuery('#app_euvat_business_name').removeClass('invalid');
				if(businessName == ''){
					xi.jQuery('#app_euvat_business_name').addClass('invalid');
					disable = disable || true;
				}
				
				if(xi.jQuery('#app_euvat_business_vatno').hasClass('invalid')){
					disable = disable || true;
				}
				
			}
			       	
			xi.jQuery('#payplans-order-confirm').attr("disabled", disable);
		},
		
		changePurpose : function(){
			var purpose = xi.jQuery('#app_euvat_use_purpose').val();
			xi.jQuery('.eu-vat-buisness-fields').css('display','none');
			
			//show business fields if required
			if(purpose==2){
				xi.jQuery('.eu-vat-buisness-fields').css('display','block');
			}
			
			xi.euvat.validateCountryAndPurpose();
			
			// apply tax
			xi.euvat.apply();
		},
		
		apply: function(){
			var orderKey = xi.jQuery('input[name="order_key"]').val();
			var country = xi.jQuery('#app_euvat_country_id').val();
			var purpose = xi.jQuery('#app_euvat_use_purpose').val();
			var businessName = xi.jQuery('#app_euvat_business_name').val();
			var businessVat = xi.jQuery('#app_euvat_business_vatno').val();
			
			var url = "index.php?option=com_payplans&view=order&task=trigger&event=onPayplansTaxRequest&order_key="+orderKey;
			
			// args to pick
			var args= Array(orderKey, country, purpose, businessVat,businessName);
			
			// remove the error message
			xi.euvat.displayError('','#app-euvat-business-vatno-error');
			xi.euvat.displayError('','#app-euvat-use-purpose-error');			
						
			//disable the button
			xi.euvat.validateCountryAndPurpose();
			
			xiajax.call(url, args[0],args[1],args[2],args[3],args[4]);
		},
		
		displayError: function(message, loc){
			xi.jQuery(loc).html(message);
			xi.jQuery(loc).css('display','none');
			if(message !== ''){
				xi.jQuery(loc).css('display','block');
			}
		},
		
		disablefields: function(){
			xi.jQuery('#euvat_purpose').hide();
			xi.jQuery('#app_euvat_use_purpose').hide();
			xi.jQuery('#euvat_business_name_label').hide();
			xi.jQuery('#euvat_business_vatno_label').hide();
			xi.jQuery('#app_euvat_business_name').hide();
			xi.jQuery('#euvat_business_vatno_div').hide();
		},

		enablefields: function(){
			xi.jQuery('#euvat_purpose').show();
			xi.jQuery('#app_euvat_use_purpose').show();
			xi.jQuery('#euvat_business_name_label').show();
			xi.jQuery('#euvat_business_vatno_label').show();
			xi.jQuery('#app_euvat_business_name').show();
			xi.jQuery('#euvat_business_vatno_div').show();
			var purpose = xi.jQuery('#app_euvat_use_purpose').val();
			xi.jQuery('.eu-vat-buisness-fields').css('display','none');
			
			//show business fields if required
			if(purpose==2){
				xi.jQuery('.eu-vat-buisness-fields').css('display','block');
			}
		}
	}
});

xi.jQuery(document).ready(function (){
	
	// disable payment button
	xi.euvat.validateCountryAndPurpose();
	xi.euvat.changePurpose();
	
	// attach tax information update handler
	xi.jQuery('#app_euvat_country_id').bind('change', xi.euvat.apply);
	xi.jQuery('#app_euvat_use_purpose').bind('change', xi.euvat.changePurpose);
	xi.jQuery('#app_euvat_business_vatno').bind('change', xi.euvat.apply);
});