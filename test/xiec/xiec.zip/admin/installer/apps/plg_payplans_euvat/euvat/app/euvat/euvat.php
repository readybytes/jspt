<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage	Discount
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansAppEuvat extends PayplansApp
{
	//inherited properties
	protected $_location	= __FILE__;
	
	// 	Entry Function 
	public function onPayplansApplyTax(PayplansOrder $order, $countryCode, $purpose, $vatno)
	{
		$applyTo = $this->getAppParam('tax_country', array());
		
		if($applyTo != PAYPLANS_CONST_ALL){
			//When only one item is selected 
			if(is_array($applyTo )==false){
				$applyTo = array($applyTo );
			}
		
			// not applicable
			if(in_array($countryCode,$applyTo) ==false){
				return PAYPLANS_EUVAT_NOT_APPLICABLE;
			}
		}

		$response = XiFactory::getAjaxResponse();
		// return tax rate to be used
		if($purpose == PLG_EUVAT_PURPOSE_BUSINESS){
			
			// no need to verify VAT
			if($this->getAppParam('tax_check_vatno',1) == 0){
				return floatval($this->getAppParam('tax_rate_business', 0));
			}
			
			//verification of VAT required
			$result = $this->_validateVAT($countryCode, $vatno);
			
			// verification failed : success and apply personal tax if vat no. is not valid
        	//return ($result !==true) ? $result : floatval($this->getAppParam('tax_rate_business', 0));
            if($result !==true)
            {   
				if(is_array($result)){
	                foreach($result as $loc => $msg){
	                   $response->addScriptCall('xi.euvat.displayError',$msg,$loc);
	                   $response->addScriptCall('xi.jQuery(\'#app_euvat_business_vatno\').addClass','invalid');
	                }
				}

                $purpose = PLG_EUVAT_PURPOSE_PERSONAL;
                return floatval($this->getAppParam('tax_rate_personal', 0));	
            }
            else{
            	$response->addScriptCall('xi.jQuery(\'#app_euvat_business_vatno\').removeClass','invalid');
                return floatval($this->getAppParam('tax_rate_business', 0));
            }
		}
		
		return floatval($this->getAppParam('tax_rate_personal', 0));	
	}	
	

	/**
	 * plugin : payment_paypal_vat for ambrasubs
	 * @version	1.0
	 * @author 	Nicholas K. Dionysopoulos
	 * @link 	http://www.dionysopoulos.me
	 * @copyright Copyright (C) 2010 Nicholas K. Dionysopoulos. All rights reserved.
	 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
	 * 
	 * 
	 * Uses the web API to validate a VAT number against the VIES system
	 * @param string $country The two-letter ISO country code
	 * @param string $vat_number The VAT number without the local prefix (only numbers)
	 * @return bool True if this is a valid VAT number
	 * 
	 * sample test : GB / 802311782 will return true
	 */
	protected function _validateVAT($country, $vat_number)
	{
		// Catch degenerate cases
		if(empty($country)) return false; // No country specified
		// No VAT number
		if(empty($vat_number)){ 
			return array('#app-euvat-business-vatno-error' => XiText::_('PLG_EUVAT_VAT_VALIDATION_VAT_NUMBER_IS_BLANK')); 
		}
		
		// convert country id to country code
		$countries = XiFactory::getInstance('country', 'model')->loadRecords();
		$country = $countries[$country];
		$country = $country->isocode2;
		
		// Construct the REST query
		if($country == 'GR'){
			$c = 'EL'; // Greece is a special case; the ISO code is GR, the VAT country code is EL. Duh!
		}

		$c = urlencode($country);
		$v = urlencode(strtoupper($vat_number));
		$validation_url = "http://isvat.appspot.com/$c/$v/";

		// Post and get results using cURL
		$process=curl_init($validation_url);
		curl_setopt($process, CURLOPT_HEADER, 0);
		curl_setopt($process, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.0.3705; .NET CLR 1.1.4322; Media Center PC 4.0)'); // Pretend we are IE7, so that webservers play nice with us
		curl_setopt($process, CURLOPT_TIMEOUT, 5);
		curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
		@curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);	// The @ sign allows the next line to fail if
		@curl_setopt($process, CURLOPT_MAXREDIRS, 2);		// open_basedir is set or if safe mode is enabled
		$buffer = curl_exec($process);
		curl_close($process);

		// Parse results
		// No response
		if(empty($buffer)){
			return array('#app-euvat-business-vatno-error' => XiText::_('PLG_EUVAT_VAT_VALIDATION_NO_RESPONSE')); 
		} 

		// Valid VAT number
		if($buffer == 'true'){
			return true; 
		} 
		
		// Invalid VAT or VAT validation service is down
		return array('#app-euvat-business-vatno-error' => XiText::_('PLG_EUVAT_VAT_VALIDATION_FAILED')); 
	}
}
