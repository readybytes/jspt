<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in


*/
if(defined('_JEXEC')===false) die();
?>
<script src="<?php echo PayplansHelperUtils::pathFS2URL(dirname(__FILE__).DS.'euvat.js');?>" type="text/javascript"></script>
<div class="payment-details">
	<div class = "detail-label">
	<?php echo XiText::_("COM_PAYPLANS_ENTER_TAX_INFORMATION"); ?>*
	</div>

	<div class = "detail-dec">
		<?php echo XiHtml::_('elements.xicountry', 'app_euvat_country_id', $country, array('option_none'=>true)); ?>
		<span id="app-euvat-country-id-error" class="error" style="display:none;">&nbsp;</span>
	</div>
</div>

<div class="payment-details">
	<div class = "detail-label" id="euvat_purpose">
		<?php echo XiText::_("COM_PAYPLANS_EUVAT_USE_PURPOSE"); ?>*
	</div>

	<div class = "detail-dec">
		<?php 
			$options = array();
			$options[] = XiHtml::_('select.option', 0, XiText::_('COM_PAYPLANS_APP_EUVAT_USE_PURPOSE_SELECT'));
			$options[] = XiHtml::_('select.option', PLG_EUVAT_PURPOSE_PERSONAL, XiText::_('COM_PAYPLANS_APP_EUVAT_USE_PURPOSE_PERSONAL'));
			$options[] = XiHtml::_('select.option', PLG_EUVAT_PURPOSE_BUSINESS, XiText::_('COM_PAYPLANS_APP_EUVAT_USE_PURPOSE_BUSINESS'));
	    	echo XiHtml::_('select.genericlist', $options, 'app_euvat_use_purpose', 'width=40px', 'value', 'text', $purpose);
	    ?>
		<span id="app-euvat-use-purpose-error" class="error" style="display:none;">&nbsp;</span>
	</div>
</div>

<div class="payment-details">
	<div class = "detail-label eu-vat-buisness-fields" id="euvat_business_name_label" style="<?php echo $purpose== PLG_EUVAT_PURPOSE_PERSONAL ? 'display:none;' : ''; ?>">
		<?php echo XiText::_("COM_PAYPLANS_EUVAT_BUSINESS_NAME"); ?>*
	</div>

	<div class="detail-dec eu-vat-buisness-fields" style="<?php echo $purpose== PLG_EUVAT_PURPOSE_PERSONAL ? 'display:none;' : ''; ?>">
		<input id="app_euvat_business_name" name="app_euvat_business_name" class="required" size="20" value="<?php echo $business_name; ?>"/>
	</div>
</div>

<div class="payment-details">
	<div class = "detail-label eu-vat-buisness-fields" id="euvat_business_vatno_label" style="<?php echo $purpose== PLG_EUVAT_PURPOSE_PERSONAL ? 'display:none;' : ''; ?>">
		<?php echo XiText::_("COM_PAYPLANS_EUVAT_BUSINESS_VATNO"); ?>*
	</div>

	<div class="detail-dec eu-vat-buisness-fields" id="euvat_business_vatno_div"style="<?php echo $purpose== PLG_EUVAT_PURPOSE_PERSONAL ? 'display:none;' : ''; ?>">
		<input id="app_euvat_business_vatno" name="app_euvat_business_vatno" class="hasTip required" title="<?php echo XiText::_('COM_PAYPLANS_EUVAT_BUSINESS_VATNO_DESC');?>" size="10" value="<?php echo $business_vatno; ?>" />
		<span id="app-euvat-business-vatno-error"  class="error" style="display:none;width:100%;">&nbsp;</span>
	</div>
</div>