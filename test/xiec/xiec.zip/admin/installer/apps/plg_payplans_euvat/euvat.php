<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		Payplans
* @subpackage	Discount
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

define('PLG_EUVAT_PURPOSE_PERSONAL', 1);
define('PLG_EUVAT_PURPOSE_BUSINESS', 2);

class plgPayplansEuvat extends XiPlugin
{
	public function onPayplansSystemStart()
	{
		$dir = dirname(__FILE__).DS.'euvat'.DS.'app';
		PayplansHelperApp::addAppsPath($dir);
		
		return true;
	}
	
	
	// on render of order, display output
	public function onPayplansViewBeforeRender(XiView $view, $task)
	{
		if(!($view instanceof PayplanssiteViewOrder)){
			return true;
		}

		if($task != 'confirm'){
			return true; 
		}

		$country 		= 0;
		$purpose		= 0;
		$businessName	= '';
		$businessVatno	= '';
		$userId 		= XiFactory::getUser()->id;
		$orderId  		= $view->getModel()->getId();
		
		if(!empty($userId)){
			$user 	  =  PayplansUser::getInstance($userId);
			$country  =  $user->getCountry();
			$businessVatno  =  $user->getPreference('tin');
			$businessName 	=  $user->getPreference('business_name');
			$purpose 		= $user->getPreference('business_purpose');
			
			$orderKey = PayplansOrder::getInstance($orderId)->getKey();

			// Apply tax as per user country
			self::_onPayplansTaxRequest($orderKey, $country, $purpose, $businessVatno, $businessName);
		}

		$this->_assign('country', $country);
		$this->_assign('orderId', $orderId);
		
		$this->_assign('purpose', $purpose);
		$this->_assign('business_name', $businessName);
		$this->_assign('business_vatno', $businessVatno);
		
		return array('payplans_order_confirm_payment' => $this->_render('orderconfirm'));
	}

	// 	on render of order, display output
    function onPayplansTaxRequest($orderKey, $country,$purpose=0, $businessNo='', $businessName='')
     {
     	list($order, $error, $proceed) = self::_onPayplansTaxRequest($orderKey, $country, $purpose, $businessNo, $businessName);
     	
		// order have been updated
		$response = XiFactory::getAjaxResponse();
		
		// if error = '', then no error will be shown
		foreach($error as $loc => $msg)
        {
			//if country selected is not in app then disable purpose fields
			if($msg == PAYPLANS_EUVAT_NOT_APPLICABLE){
				$response->addScriptCall('xi.euvat.disablefields');
			}
			else{
				$response->addScriptCall('xi.euvat.displayError',$msg,$loc);
			}
		}
        // enable fields again if country selected is in app
		if(!in_array(PAYPLANS_EUVAT_NOT_APPLICABLE,$error))
		{
			$response->addScriptCall('xi.euvat.enablefields');
		}
		$response->addScriptCall('xi.euvat.validateCountryAndPurpose');		
		$response->addScriptCall('xi.jQuery(\'#payplans\').find(\'.tax-amount\').html', $order->getTaxAmount());
		$response->addScriptCall('xi.jQuery(\'#payplans\').find(\'.first-tax-amount\').html', $order->getFirstPriceTax());
		$response->addScriptCall('xi.jQuery(\'#payplans\').find(\'.regular-amount\').html',$order->getTotal());
		$response->addScriptCall('xi.jQuery(\'#payplans\').find(\'.first-amount\').html',$order->getFirstTotal());
		
		$response->sendResponse();
	}
	
	// on render of order, display output
	public function _onPayplansTaxRequest($orderKey, $country, $purpose, $businessVat, $businessName)
	{
		//should allow user to proceed
		$proceed = TRUE;
		
		$error = array();
		$error['#app-euvat-country-id-error']='';
		
		//trigger the discount
		$orderId = XiFactory::getEncryptor()->decrypt($orderKey);
		$order = PayplansOrder::getInstance($orderId);
		
		
		$args  = array($order, $country, &$purpose, $businessVat);
		$results = PayplansHelperEvent::trigger('onPayplansApplyTax', $args, '', $order);

		
		$tax =0; // default tax is Zero
		foreach($results as $result){
			// 	check if app returned error string, convert to location aware error
			if(is_string($result)){
				$result = array('#app-euvat-country-id-error' => $result);
				// break ; // IMP : do not break, we need to process 
			}
			
			// check if app returned error string for particular location
			if(is_array($result)){
				foreach($result as $loc => $msg){
					$error[$loc] = isset($error[$loc]) ? $error[$loc].$msg  : $msg ;
				}
				$proceed=false;
				break;
			}

			// tax rate was porivded
			if(is_float($result)){
				$tax= $result;
				break;
			}
		}
		$order->setTaxRate($tax)->save();
		
		//save user country
		$order->getBuyer(PAYPLANS_INSTANCE_REQUIRE)
			->setPreference('business_purpose', $purpose)
			->setPreference('business_name', $businessName)
			->setPreference('tin', $businessVat)
			->setCountry($country)
			->save();

        return array($order, $error, $proceed);
	}
}
