<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );


// check if Payplans installed or not
jimport('joomla.filesystem.file');

// Load particular autoloading required
$app = JFactory::getApplication();
$basepath	= $app->isAdmin() ? JPATH_ADMINISTRATOR : JPATH_SITE ;
$fileName 	= $basepath . DS . 'components'.DS.'com_payplans'.DS.'includes'.DS.'includes.php';

if(!JFile::exists($fileName))
{
	return true;
}
else
{
	$option	= JRequest::getVar('option');
	//do not load payplans when component is com_installer
	if($option == 'com_installer'){
		return true;
	}

	require_once $fileName;

	/**
	 * Payplans System Plugin
	 *
	 * @package	Payplans
	 * @subpackage	Plugin
	 */
	class  plgSystemPayplans extends XiPlugin
	{
		public $_app = null;

		function __construct(& $subject, $config = array())
		{
			parent::__construct($subject, $config);
			$this->_app = JFactory::getApplication();
		}

		function _accessCheck()
		{
			// Do not affect backend
			if ($this->_app->isAdmin()){
				return true;
			}
			
			//
			$user = XiFactory::getUser();
			$pUser = PayplansUser::getInstance($user->id);
			
			if($pUser->isAdmin()){
				return true;
			}
			
			// Any App and plugin can handle this event
			$args = array($pUser, $options=array());
			$result  = PayplansHelperEvent::trigger('onPayplansAccessCheck', $args, '', null);
			
			// is access check failed
			if(in_array(false, $result,true)){
				$result  = PayplansHelperEvent::trigger('onPayplansAccessFailed', $args, '', null);
				return false;
			}
			return true;
		}
		
		function onAfterRoute()
		{
			// Let us do access check
			self::_accessCheck();
			
			$option	= JRequest::getVar('option');
			$view 	= JRequest::getVar('view');
			$task	= JRequest::getVar('task');
			$document = JFactory::getDocument();
			if($document->getType() != 'html')
				return;

			if(JRequest::getVar('option',null, 'GET') != 'com_payplans'){
				return true;
			}
			
			PayplansHelperUtils::loadAssests();
			return true;
		}

		public function onAfterDispatch()
		{
			// add language text to javascript  
			XiText::autoLoadJS();
			
			return true;
		}
		/**
		 * Add a image just before </body> tag
		 * which will href to cron trigger.
		 */
		function onAfterRender()
		{
			//V. IMP. : During uninstallation of Payplans
			// after uninstall this function get executed
			// so prevent it
			$option = JRequest::getVar('option');
			if($option == 'com_installer'){
				return true;
			}
			
			// PayPlans was not included and loaded
			if(defined('PAYPLANS_DEFINE_ONSYSTEMSTART')==false){
				return;
			}

			// Only do if configuration say so : expert_run_automatic_cron is set to 1
			if(XiFactory::_getConfig()->expert_run_automatic_cron != 1){
				return;
			}
			
			// Only render for HTML output
			if (JFactory::getDocument()->getType() !== 'html' ) { return; }

			//only add if required, then add call back
			if(PayplansHelperCron::checkRequired()== true){
				// Add a cron call back			
				$cron = '<img src="'.PayplansHelperCron::getURL().'" />';
				$body = JResponse::getBody();
				$body = str_replace('</body>', $cron.'</body>', $body);
				JResponse::setBody($body);
			}
		}

		function onAfterInitialise()
		{
			//trigger system start event after loading of joomla framework
			if(defined('PAYPLANS_DEFINE_ONSYSTEMSTART')==false){
				// bug in php, subclass having issue with autoloading multiple chained classes
				// http://bugs.php.net/bug.php?id=51570
				class_exists('XiPlugin', true);
				
				//IMP : Do not load system plugins
				PayplansHelperEvent::trigger('onPayplansSystemStart');
				//XiHelperPlugin::trigger('onPayplansSystemStart');
				define('PAYPLANS_DEFINE_ONSYSTEMSTART', true);
			}
			
			/// load registration polugin of payplans
			XiHelperPlugin::loadPlugins('payplansregistration');
			
			//load override language file after all plugin has been loaded
			$filename = 'com_payplans';
			$language = JFactory::getLanguage();
			$language->load($filename.'_override', JPATH_SITE);			
		}
		

		/*
		 * XITODO : MED : Remove these functions and move to some testing plugins
		 * as these are for testing only
		 * */
		function prefixJustForTestTrue()
		{
			return true;
		}

		function justForTestFalse()
		{
			return false;
		}

		function xiTestingTriggerGiven($given)
		{
			return $given;
		}

		function prefixTestingTriggerVisibility()
		{
			return false;
		}

		// Joomla 1.6 compatibility
		public function onBeforeDeleteUser($user)	
		{
	 	    return $this->onUserBeforeDelete($user);
		}
		
		function onUserBeforeDelete($user)
		{
			$db = JFactory::getDBO();
			$userId = $user['id'];

			$orderRecords =  XiFactory::getInstance('order', 'model')
									->loadRecords(array('buyer_id'=>$userId));

			if(!empty($orderRecords)){
				foreach($orderRecords as $record){
					$order = PayplansOrder::getInstance($record->order_id)
											->delete();
				}
			}	
		}
		
		function onPrepareContent($item, $params, $limitstart)
		{
			$args = array(&$item, &$params, $limitstart);
			$results = PayplansHelperEvent::trigger('onPrepareContent', $args);
			return true;
		}
	}
}

