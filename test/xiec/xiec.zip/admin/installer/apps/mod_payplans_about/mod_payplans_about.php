<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Module
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

require_once JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'includes'.DS.'includes.php';
?>
<p style="font-size: 100%; word-spacing: 1px;"><a href='http://www.jpayplans.com' target="_blank">JPayPlans</a>
is a Paid Membership and Subscription Extensions for Joomla!. It helps you to Create Paid
Membership website for online consultancy, services or community. JPayPlans have
been developed by <a href='http://www.joomlaxi.com' target="_blank">
Team JoomlaXi</a>, a team of professional web developers dedicated to deliver high-quality
extensions, unique solutions and advanced services for Joomla!. </p>



<?php if(!stristr(JURI::root(),'localhost')) : ?>
<h3>Get social with JPayPlans</h3>
<!-- Load Facebook if it is not localhost -->
<table>
  <tr>
    <td>
    	<iframe src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FJPayPlans%2F163304620386072&amp;layout=box_count&amp;show_faces=false&amp;width=60&amp;action=like&amp;font=trebuchet+ms&amp;colorscheme=light&amp;height=65" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:60px; height:65px;" allowTransparency="true"></iframe>
    </td>
    <td>
    	<a href="http://twitter.com/share" class="twitter-share-button" data-url="http://www.jpayplans.com" data-text="#JPayPlans : Best Paid Membership and Subscription Extensions for #Joomla!" data-count="vertical" data-via="JPayPlans" data-related="JoomlaXi:Trust them for your next #Joomla Project.">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
    </td>
    <td></td>
    <td style="align:center;text-align:center;">
    	<a href='http://extensions.joomla.org/extensions/extension-specific/jomsocial-extensions/16566' target="_blank">
		<img alt="View us at JED" src="../components/com_payplans/media/images/social/joomla.png">
		<div>JED</div>
		</a>
    </td>
  </tr>
</table>
<?php endif;?>

<p style="text-align:right;color:gray;">An initiative by <a href='http://www.readybytes.in' target="_blank">Ready Bytes Software
Labs Pvt. Ltd.</a></p>
<?php

