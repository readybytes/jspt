<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license	GNU/GPL, see LICENSE.php
* @package	Payplans
* @subpackage	Upgrade Plugin
* @contact	payplans@readybytes.in
*/
// no direct access
if(defined( '_JEXEC' )==false) {
	die( 'Restricted access' );
} 


class plgPayplansUpgrade extends XiPlugin
{

	public function onPayplansSystemStart()
	{
		//add discount app path to app loader
		$appPath = dirname(__FILE__).DS.'upgrade'.DS.'app';
		PayplansHelperApp::addAppsPath($appPath);

		return true;
	}
	
	public function onPayplansViewBeforeRender(XiView $view, $task)
	{
		// handle order confirmation
		if(($view instanceof PayplanssiteViewOrder)==true && $task == 'confirm'){
			return $this->_updateOrderBeforeConfirmation($view, $task);
		}

		return true;
	}
	
	public function onPayplansUpgradeFromRequest()
	{
		$userid = XiFactory::getUser()->id;
		if(!$userid){
			// XITODO : show a proper message here, that you are not logged in
			return true;
		}
		
		$user = PayplansUser::getInstance($userid);
		$this->_assign('subscriptions', $user->getSubscriptions(XiStatus::SUBSCRIPTION_ACTIVE));
		
		$html= $this->_render('upgrade_from');	

		$domObject   = 'xiWindowContent';
		$domProperty = 'innerHTML';

		$response	= XiFactory::getAjaxResponse();
		$response->addAssign( $domObject , $domProperty , $html );
		//$response->addScriptCall('xi.upgrade.getPlansUpgradeTo', array_shift(array_keys($plans)));
		$response->sendResponse();
	}
	

	public function onPayplansUpgradeToRequest($subKey)
	{
		// find available plans		
		$plans = $this->_onPayplansUpgradeToRequest($subKey);
		
		$this->_assign('upgrade_to', $plans);
		$this->_assign('sub_key', $subKey);
		$html= $this->_render('upgrade_to');	

		$response	= XiFactory::getAjaxResponse();
		$response->addScriptCall('xi.jQuery(\'#payplans-upgrade-'.$subKey.'-to\').html', $html);
		$response->sendResponse();
	}
	
	
	protected function _onPayplansUpgradeToRequest($subKey)
	{
		$subId = XiFactory::getEncryptor()->decrypt($subKey);
		$plan  = array_shift(PayplansSubscription::getInstance($subId)->getPlans(true));
		// should return plans' instances
		$args = array();
		$results = PayplansHelperEvent::trigger('onPayplansUpgradeTo', $args, '', $plan);
		
		$plans = array();
		foreach($results as $result){
			foreach($result as $plan){
				$plans[$plan->getId()] = $plan;
			}
		}
		
		return $plans;
	}
	
	public function onPayplansUpgradeDisplayConfirm($newPlanId, $subKey)
	{
		$userid = XiFactory::getUser()->id;
		// XITODO : show a proper message here, that you are not logged in
		if(!$userid){
			return true;
		}
		
		// find available plans for this subscription		
		$availablePlans = $this->_onPayplansUpgradeToRequest($subKey);
		if(isset($availablePlans[$newPlanId]) == false){
			//XITODO : Plan is not avilable for upgrade, show Error Message
			return true;
		}
		
		// plan can be upgraded
		$subId 	  = XiFactory::getEncryptor()->decrypt($subKey);
		$oldSub   = PayplansSubscription::getInstance($subId);
		$oldPlan  = array_shift($oldSub->getPlans(true));
		$newPlan  = PayplansPlan::getInstance($newPlanId);
		$oldOrder = $oldSub->getOrder(true);
		
		
		// 
		$result = $this->_calculateUnutilizedValue($oldSub);
		$paidAmount = $result['paid'];
		$unutilized = $result['unutilized'];
		
		$newOrder = $this->_createUpgradeOrder($oldSub, $newPlan);
		
		// should return plans' instances
		$args = array($newOrder, $newPlan, $unutilized, $oldPlan, $oldOrder);
		$results = PayplansHelperEvent::trigger('onPayplansDisplayConfirm', $args, '', $oldPlan);
		
		//render html
		$this->_assign('new_order', $newOrder);
		$this->_assign('new_sub', array_shift($newOrder->getSubscriptions()));
		$this->_assign('new_plan', $newPlan);
		
		$this->_assign('old_plan', $oldPlan);
		$this->_assign('old_order', $oldOrder);
		$this->_assign('old_sub',  $oldSub);
		
		$this->_assign('unutilized_amount', $unutilized);
		$this->_assign('paid_amount',  $paidAmount);
			
		$html= $this->_render('upgrade_details');	

		$domObject   = 'payplans-popup-upgrade-details';
		$domProperty = 'innerHTML';

		$response	= XiFactory::getAjaxResponse();
		$response->addAssign( $domObject , $domProperty , $html );
		$response->sendResponse();
	}
	
	protected function _calculateUnutilizedValue(PayplansSubscription $oldSub)
	{
		//IMP : If subscription is no more active, value as 0
		if($oldSub->getStatus() != XiStatus::SUBSCRIPTION_ACTIVE){
			return array(0,0);
		}
		//$oldPlan  = array_shift($oldSub->getPlans(true));
		
		// find value utilized by old subscription
		$start   = intval($oldSub->getSubscriptionDate()->toUnix());
		$expires = intval($oldSub->getExpirationDate()->toUnix());
		$now     = intval(XiDate::getInstance()->toUnix());
		
		$totalTime	= $expires - $start;
		
		// Use first price total, if available from subscription
		// We do not collect it from order/payment, 
		// as we are not sure how much subscriptions were purchased
		$payments = $oldSub->getOrder(true)->getPayments(XiStatus::PAYMENT_COMPLETE);
		if(count($payments) == 0){
			// none of payment were completed
			$totalValue = 0;
		}else{
			// pick last payment
			/* @var $payment PayplansPayment */
			$payment = array_pop($payments);
			$totalValue = $payment->getAmount();
		}
		
		// free subscription OR life time subscription
		if($totalValue ==0 || $expires == 0){
			$usedValue = 0;	
		}else{
			$used  		= $now - $start;
			// if total time is not in hours, then calculate as per days
			$oneday = 24*60*60;
			
			if($totalTime > 3*$oneday){
				$used 		= intval($used/$oneday);
				$totalTime 	= intval($totalTime/$oneday);		
			}
			
			$usedValue  = $totalValue * $used / $totalTime;
		}
		
		// the value which is not utilized, and will be added into discount
		$unutilizedValue = $totalValue - $usedValue;
		
		return array('paid' => $totalValue, 'unutilized'=>$unutilizedValue);
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param PayplansSubscription $oldSub
	 * @param PayplansPlan $newPlan
	 * @return PayplansOrder
	 */
	protected function _createUpgradeOrder(PayplansSubscription $oldSub, PayplansPlan $newPlan)
	{
		// the value which is not utilized, and will be added into discount
		$result = $this->_calculateUnutilizedValue($oldSub);
		$paidAmount 	 = $result['paid'];
		$unutilizedValue = $result['unutilized'];
		
		//Create a NEW Order		
		$newOrder = $newPlan->subscribe($oldSub->getBuyer());
		$newSub   = array_shift($newOrder->getSubscriptions());
		
		//XITODO : Currently we do not support trial prices in new plan, We will do it in future
		// update order and subscription
		$newSub->setFirstPrice($newPlan->getPrice()-$unutilizedValue)->save();
		$newOrder->setParam('upgrading_from', $oldSub->getKey())->save();

		// return order
		return $newOrder;
	}
	
	protected function onPayplansUpgradeToCancel($order_key)
	{
		// XITODO : show a proper message here, that you are not logged in
		$userid = XiFactory::getUser()->id;
		if(!$userid){
			return true;
		}
		
		// find order
		$orderId  = XiFactory::getEncryptor()->decrypt($order_key);
		$order = PayplansOrder::getInstance($orderId);
		
		// check if order is from same person
		if($order->getBuyer() != $userid){
			return true;
		}
		
		$order->delete();

		$response	= XiFactory::getAjaxResponse();
		$response->sendResponse();
	}
	
	/**
	 * When the upgrade order is getting complete, 
	 * we need to 
	 *  - mark existing subscription and order expired
	 *  - XITODO : mark existing order expired (it not support upgrades for one out of multiple-subscription in a single order)
	 *  - XITODO : cancel recurring payments for previous subscription
	 *  - if normal payment then  
	 * 
	 * @param PayplansOrder $previous
	 * @param PayplansOrder $current
	 */
	function onPayplansOrderAfterSave($previous=null, $current=null)
	{
		// Consider Previous State also
		if(isset($previous) && $previous->getStatus() == $current->getStatus()){
			return true;
		}

		// if there is change in status of order
		if($current->getStatus() != Xistatus::ORDER_COMPLETE){
			return true;
		}
		
		// is it upgrading from some plan ?
		$upgradingFrom = $current->getParam('upgrading_from',0);
		if(!$upgradingFrom){ // not upgrading
			return true;
		}
		
		// user is upgrading, cancel his previous subscription and order
		$oldSub = PayplansSubscription::getInstance(XiFactory::getEncryptor()->decrypt($upgradingFrom));
		$oldSub->getOrder(true)->setStatus(XiStatus::ORDER_EXPIRED)->save();
		
		
		// We are marking ORDER expired, 
		// so for recurring payments will not able to enable the order again 
		
		return true;
	}

	/**
	 * XITODO : When user confirms upgrade-order, we need to make sure everything is up-to-date
	 * because -
	 * 
	 * I can make a upgrade request today, if I do not complete order
	 * and complete this after some months, I will get the same discount
	 * calculated on the time of creation of upgrade-request. 
	 */
	protected function _updateOrderBeforeConfirmation(XiView $view, $task)
	{	
		// find order
		$newOrder 	= PayplansOrder::getInstance($view->getModel()->getId()); 

		// is it upgrading from some plan ?
		$upgradingFrom = $newOrder->getParam('upgrading_from',0);
		if(!$upgradingFrom){ // not upgrading
				return true;
		}

		// update order again, as per current situation
		// user is upgrading, cancel his previous subscription and order
		$oldSub   = PayplansSubscription::getInstance(XiFactory::getEncryptor()->decrypt($upgradingFrom));
		$newSub	  = array_shift($newOrder->getSubscriptions());
		$newPlan  = array_shift($newSub->getPlans(true));
		
		$result = $this->_calculateUnutilizedValue($oldSub);
		$paidAmount 	 = $result['paid'];
		$unutilizedValue = $result['unutilized'];
		
		$newSub->setFirstPrice($newPlan->getPrice()-$unutilizedValue)->save();
		$newOrder->refresh()->save();
		
		$oldOrderKey = $oldSub->getOrder(true)->getKey();
		
		$key 	= '<a href="'. XiRoute::_('index.php?option=com_payplans&view=order&order_key='.$oldOrderKey ).'">'.$oldOrderKey.'</a>';
		$amount = PayplansHelperFormat::amount($unutilizedValue, $oldSub->getOrder(true)->getCurrency()); 
		$message = XiText::sprintf('COM_PAYPLANS_UPGRADE_UPGRADING_FROM_KEY_DISCOUNTED_AMOUNT', $key, $amount);
        XiFactory::getApplication()->enqueueMessage($message);
		return true;
	}
}
