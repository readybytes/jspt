<?php
/**
 * @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * @package		PayPlans
 * @subpackage	Frontend
 * @contact 		shyam@readybytes.in


 */
if(defined('_JEXEC')===false) die();
?>
<div id="payplans" class="payplans">

	<div id="payplans-upgrading-from">
		<!-- Header -->
		<div class="pp-upgrade-details-action-top pp-primary pp-reverse pp-light pp-border pp-background">
			<h1 class="div-heading pp-primary pp-color pp-border pp-background">
				<?php echo XiText::_('PLG_PAYPLANS_UPGRADE_SELECT_ACTIVE_SUBSCRIPTION');?>
			</h1>
		</div>
		
	<?php $count = 1;?>
	<?php if(is_array($subscriptions)):?>
	<?php foreach($subscriptions as $subscription): ?>
	
		<div class="subscription-record">
		
			<div class="subscription-status" style="float:right;" >
				<a href="#" onClick="xi.upgrade.getPlansUpgradeTo('<?php echo $subscription->getKey();?>'); return false;" class="small xi-button pp-button-color" ><?php echo XiText::_('PLG_PAYPLANS_UPGRADE_THIS_SUBSCRIPTION'); ?></a>
				<div id='payplans-upgrade-<?php echo $subscription->getKey();?>-to'>&nbsp;</div>
			</div>
			
			<div class="subscription-summary">
				<h4>
					<span style="display:block;float:left;"><?php echo "#".$count . ' : ' . $subscription->getTitle(); ?></span>
				<span class="small pp-primary pp-reverse pp-color pp-border pp-background" style="display:block;float:left;clear:left;">
						<!-- when plan expiration time includes hours only then display hours -->
						<?php 
							
							$plan = array_shift($subscription->getPlans(true));
							$exp_time = $plan->getExpiration();
							$format = ($exp_time['hour']=="00") ? XiDate::SUBSCRIPTION_PAYMENT_FORMAT : XiDate::SUBSCRIPTION_PAYMENT_FORMAT_HOUR; ;
			
							// <!-- display life time as subscription period when plan expiration time is forever -->
							if($subscription->getExpirationDate()->toString()!=null):
								echo $subscription->getSubscriptionDate()->toFormat($format)
											.' <span class="separator">'
											.XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTIONS_TO').'</span> '
											.$subscription->getExpirationDate()->toFormat($format); 
							elseif($subscription->getSubscriptionDate()->toString()==null):
								echo XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTION_NOT_ACTIVATED');
							else :
								echo XiText::_('COM_PAYPLANS_ORDER_SUBSCRIPTION_TIME_LIFETIME');
							endif;
						?>
				</span>
				</h4>
			</div>
			
			<div style="clear:both;">&nbsp;</div>
			
	
	</div>		
	<?php
			$count++;
			endforeach;
	// XITODO else case, show message you can only upgrade your active plans  
	endif;
	
?>
 	</div>
 
	<div id="payplans-popup-upgrade-details">
	</div>

</div>
<?php 