<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in


*/
if(defined('_JEXEC')===false) die();
?>
	<div class="pp-upgrade-details pp-secondary pp-color pp-border pp-background">
			<div class="pp-upgrade-details-action-top pp-primary pp-reverse pp-light pp-border pp-background">
				<h1>
					<span>Upgrade Request Details</span> 
					<span class="small" style="display:block; float:right;" >
						<a href="#" onClick="xi.upgrade.setPlansUpgradeToCancel('<?php echo $new_order->getKey();?>');return false;">
							<?php echo XiText::_('COM_PAYPLANS_UPGRADES_DETAILS_GO_BACK'); ?>
						</a>
					</span>
				</h1> 
			</div>
			<div class="pp-upgrade-details-main">
				
				<div class="pp-upgrade-details-from">
						<?php $old_plan = array_shift($old_sub->getPlans(true));?>
							<div class="pp-info">
								<span class="pp-label pp-primary pp-reverse pp-color">
									<?php echo XiText::_('COM_PAYPLANS_UPGRADES_DETAILS_PREVIOUS_PLAN');?>
								</span>
								<span class="pp-value">
									<?php echo $old_plan->getTitle(); ?>
								</span>
							</div>

							<div class="pp-info">
								<span class="pp-label pp-primary pp-reverse pp-color">
									<?php echo XiText::_('COM_PAYPLANS_UPGRADES_DETAILS_PREVIOUS_PAYMENT');?>
								</span>
								<span class="pp-value">
									<?php echo PayplansHelperFormat::amount($paid_amount, $old_order->getCurrency()); ?>
								</span>
							</div>
							
							<div class="pp-info">
							<span class="pp-label pp-primary pp-reverse pp-color">
								<?php echo XiText::_('COM_PAYPLANS_UPGRADES_DETAILS_NOT_UTILIZED_PAYMENT');?>
							</span>
							<span class="pp-value">
								<?php echo PayplansHelperFormat::amount($unutilized_amount, $old_order->getCurrency()); ?>
							</span>
							</div>
				</div>
				
				<div class="pp-upgrade-details-to">
						<?php $new_plan = array_shift($new_sub->getPlans(true));?>
						<div class="pp-info">
							<span class="pp-label pp-primary pp-reverse pp-color">
								<?php echo XiText::_('COM_PAYPLANS_UPGRADES_DETAILS_NEW_PLAN');?>
							</span>
							<span class="pp-value">
								<?php echo $new_plan->getTitle(); ?>
							</span>
						</div>
						<div class="pp-info">
							<span class="pp-label pp-primary pp-reverse pp-color">
								<?php echo XiText::_('COM_PAYPLANS_UPGRADES_DETAILS_NEW_PRICE');?>
							</span>
							<span class="pp-value"><?php echo PayplansHelperFormat::amount($new_plan->getPrice(), $old_order->getCurrency()); ?></span>
						</div>
						<div class="pp-info">
							<span class="pp-label pp-primary pp-reverse pp-color">
								<?php echo XiText::_('COM_PAYPLANS_UPGRADES_DETAILS_NEW_FIRST_PAYMENT');?>
							</span>
							<span class="pp-value">
								<?php echo PayplansHelperFormat::amount($new_sub->getFirstPriceTotal(), $old_order->getCurrency()); ?>
							</span>
						</div>
						<div class="pp-info">						
							<span class="pp-label pp-primary pp-reverse pp-color">
								<?php echo XiText::_('COM_PAYPLANS_UPGRADES_DETAILS_NEW_REGULAR_PAYMENT');?>
							</span>

							<span class="pp-value">
								<?php echo PayplansHelperFormat::amount($new_sub->getTotal(), $old_order->getCurrency()); ?>
							</span>
						</div>
				</div>
			</div>
			<div class="pp-upgrade-details-action-bottom pp-primary pp-reverse pp-light pp-border pp-background">
			 	<span class="xi-button white"><a href="<?php echo XiRoute::_('index.php?option=com_payplans&view=order&task=confirm&order_key='.$new_order->getKey());?>"><?php echo XiText::_('COM_PAYPLANS_UPGRADES_DETAILS_UPGRADE_NOW');?></a></span>
			    <span><a href="#" onClick="xi.upgrade.setPlansUpgradeToCancel('<?php echo $new_order->getKey();?>');return false;"><?php echo XiText::_('COM_PAYPLANS_UPGRADES_DETAILS_CANCEL');?></a></span>
			</div>
	</div>
<?php 