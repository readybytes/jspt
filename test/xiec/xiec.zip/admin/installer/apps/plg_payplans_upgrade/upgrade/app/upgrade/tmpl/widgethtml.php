<?php
/**
 * @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * @package		PayPlans
 * @subpackage	Frontend
 * @contact 		shyam@readybytes.in


 */
if(defined('_JEXEC')===false) die();
?>
<script src="<?php echo PayplansHelperUtils::pathFS2URL(dirname(__FILE__).DS.'upgrade.js');?>" type="text/javascript"></script>

<div class="payplans-app-widget payplans-app-widget-upgrade">
	<?php $url = XiRoute::_('index.php?option=com_payplans&view=plan&task=trigger&event=onPayplansUpgradeFromRequest&arg1='.json_encode(array()));?>
	<a href="" onClick="xi.url.openInModal('<?php echo $url; ?>');return false;">
		<?php echo XiText::_('COM_PAYPLANS_APP_UPGRADE_BUTTON');?>
	</a>
	
</div>
