<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* 
* Highly Inspired from AEC micro integration for docman
*/
if(defined('_JEXEC')===false) die();

class PayplansAppUpgrade extends PayplansApp
{
	protected $_location	= __FILE__;	
	
	public function onPayplansUpgradeTo()
	{
		// Also collect invisible-plans
		$plans = PayplansHelperPlan::getPlans(array('published' => 1));
		
		$upgradeTo = $this->getAppParam('upgrade_to', array());
		$upgradeTo = is_array($upgradeTo) ? $upgradeTo : array($upgradeTo);
		
		$return  = array();
		foreach($upgradeTo as $pid){
			$return[$pid] = $plans[$pid]; 
		}
		
		return $return;
	}
	
	//render Widget
	public function renderWidgetHtml(XiWidget $widget=null)
	{   
		//get user id       
        $userid = XiFactory::getUser()->id;
		$user 	= PayplansUser::getInstance($userid);
		$userSubscriptions =  $user->getSubscriptions(XiStatus::SUBSCRIPTION_ACTIVE);
		if(!$userid || empty($userSubscriptions)){
			return false;
		}
		
		// widget can append some styling 
		if(isset($widget) && $widget != null){
			$widget->setOption('style_class', 'payplans-app-upgrade-widget');
		}
		
		// create widget object
        $data = $this->_render('widgethtml');
        return $data;
	}
}
