xi.extend({
	upgrade : {
		getPlansUpgradeTo : function(upgrade_from){
			//var args = Array(upgrade_from);
			var url = "index.php?option=com_payplans&view=plan&task=trigger&event=onPayplansUpgradeToRequest";
			xiajax.call(url, upgrade_from);
		},
		
		setPlansUpgradeTo : function(upgrade_to, sub_key){
			// hide current div
			// if not selected an element
			if(upgrade_to <= 0){
				return false;
			}
			
			//xi.jQuery('#payplans-upgrading-from').hide();
			//XITODO: create a new div automatically
			xi.jQuery('#payplans-upgrading-from').hide();
			xi.jQuery('#payplans-popup-upgrade-details').show();
			//var args = Array(upgrade_to, sub_key);
			var url = "index.php?option=com_payplans&view=plan&task=trigger&event=onPayplansUpgradeDisplayConfirm";
			xiajax.call(url, upgrade_to, sub_key);
			
		},
		
		setPlansUpgradeToCancel: function(new_order){
			xi.jQuery('#payplans-upgrading-from').show();
			xi.jQuery('#payplans-popup-upgrade-details').hide();
			//var args = Array(new_order);
			var url = "index.php?option=com_payplans&view=plan&task=trigger&event=onPayplansUpgradeToCancel";
			xiajax.call(url, new_order);
		}
	}
});

xi.jQuery(document).ready(function (){
	
});