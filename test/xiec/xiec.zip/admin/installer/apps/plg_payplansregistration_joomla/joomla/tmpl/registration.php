<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();?>
	<h4 class="div-heading primary color border background">
		<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTERATION_EMAIL');?>
	</h4>

<input type="submit" name="payplansRegisterJoomla" class="button button-color medium" value="<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTRATION_JOOMLA');?>"></input>
<?php  