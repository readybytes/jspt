<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();?>
	<h4 class="divHeading pp-primary pp-color pp-border pp-background">
		<?php echo XiText::_('COM_PAYPLANS_PLAN_JOMSOCIAL_REGISTRATION');?>
	</h4>

<input type="submit" name="payplansRegisterJomsocial" class="xi-button pp-button-color medium" value="<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTRATION_JOMSOCIAL');?>"></input>
<?php  