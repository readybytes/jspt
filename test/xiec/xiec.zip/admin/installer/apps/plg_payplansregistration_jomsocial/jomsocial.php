<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Payplans Registration JomSocial Plugin
 *
 * @package		Payplans
 * @subpackage	Plugin
 */
class  plgPayplansregistrationJomsocial extends XiPluginRegistration
{
	protected $_registrationUrl = 'index.php?option=com_community&view=register';

	function _isRegistrationUrl()
	{
		$vars = $this->_getVars();
		// added task check since for resend activation code url is same except the task
		if($vars['option'] == 'com_community' && $vars['view'] == 'register' && $vars['task'] === 'BLANK'){
			return true;
		}
		
		return false;
	}
	
	function _isRegistrationCompleteUrl()
	{
		$vars = $this->_getVars();
		if($vars['option'] == 'com_community' && $vars['view'] == 'register' && $vars['task'] == 'registerSucess'){
			return true;
		}
		
		return false;
	}
	
	function onPayplansAccessCheck()
	{
		$vars = $this->_getVars(array('option', 'view', 'task', 'profileType'));
		
		//$redirect		= CRoute::_('index.php?option=com_community&view=' . $config->get('redirect_login'), false);
		if($vars['option'] == 'com_community' && $this->_session->get('PAYPLANS_JS_FB_CONNECT_REG', false) == true){
			$this->_app->redirect(XiRoute::_('index.php?option=com_payplans&view=plan&task=subscribe'));
			$this->_session->clear('PAYPLANS_JS_FB_CONNECT_REG');
			return true;
		}
		
		//check for Facebook connect registration
		$func = JRequest::getVar('func', false);
		if($vars['option'] == 'community' && $vars['task'] == 'azrul_ajax' && JString::strtolower($func) == 'connect,ajaxshownewuserform'){
			$this->_session->set('PAYPLANS_JS_FB_CONNECT_REG', true);
		}
		
	}
	
	function onAfterRoute()
	{
		parent::onAfterRoute();
		
		if(XiFactory::getConfig()->registrationType != $this->_name){
			return true;
		}
		
		$vars = $this->_getVars(array('option', 'view', 'task', 'profileType'));
		if($this->params->get('skip_ptype', 0) 
			&& $vars['option'] == 'com_community' && $vars['view'] == 'register' 
			&& $vars['task'] == 'registerProfileType'){	
		
				// default profile type
				$ptype = $this->params->get('jsmultiprofile', 0);
				
				// get all apps of jsmultiprofile
				$apps = XiFactory::getInstance('app', 'model')
								 ->loadRecords(array('type' => 'jsmultiprofile'));
				if(!empty($apps)){		 
					foreach($apps as $app){
						$appInstance = PayplansApp::getInstance($app->app_id, null, $app);
						
						// if app is applied to selected plan, on active status
						if($appInstance->getAppParam('jsmultiprofileOnActive') 
							&& ($appInstance->getAppParam('applyAll', 0) == true 
							    || in_array($this->_getPlan(), $appInstance->getPlans()))){
							
							// get ptype from app
							$ptype = $appInstance->getAppParam('jsmultiprofileOnActive', $this->params->get('jsmultiprofile', 0));
							break;
						}
					}
				}

			$this->_app->redirect(XiRoute::_('index.php?option=com_community&view=register&task=registerProfile&profileType='.$ptype));
		}
	}
	
	/** 
	 * @see XiPluginRegistration::_doCompleteRegistration()
	 * 
	 */
	protected function _doCompleteRegistration()
	{
		$ptype = $this->params->get('jsmultiprofile', 0);
		
		require_once(JPATH_ROOT.DS.'components'.DS.'com_community'.DS.'libraries'.DS.'core.php');
		
		$userId=$this->_getUser();
		$user = CFactory::getUser($userId);
		$user->set('_profile_id', $ptype);
		$user->save();
		
		return parent::_doCompleteRegistration();
	}
}
