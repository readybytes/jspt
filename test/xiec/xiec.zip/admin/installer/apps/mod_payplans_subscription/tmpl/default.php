<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license	GNU/GPL, see LICENSE.php
* @package	PayPlans
* @subpackage	Modules
* @contact 	shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<?php 
// Load JQuery, XI Scripts
PayplansHelperUtils::loadAssests();
XiHtml::stylesheet('style.css', 'modules/mod_payplans_subscription/css/');

if(!$subscriptions){
	return true;
}

?>

<script>
xi.jQuery(document).ready(function(){
	xi.jQuery(".subscription .timeago").timeago();
});
</script>
<?php $count=1;?>
<ul id="mod-subscription">
<?php 	foreach ($subscriptions as $subscription): 
		if($count > $NumRecord)
			break;
	?>

	<li class="latestnews">
	<span class="plan"><?php echo $subscription->getTitle(); ?></span>
	<?php if($subscription->getStatus() == XiStatus::SUBSCRIPTION_EXPIRED && $renew):?>
		<?php $order     = $subscription->getOrder(PAYPLANS_INSTANCE_REQUIRE);
			  $order_key = $order->getKey();
		?>
		<div class="renew"><a href="<?php echo XiRoute::_('index.php?option=com_payplans&view=order&task=confirm&order_key='.$order_key);?>"></a></div>
	<?php endif;?>
	<div class="modifydate" style="height: auto;"> 
	<?php 
	if ($subscription->getStatus() == XiStatus::SUBSCRIPTION_ACTIVE && !$subscription->getExpirationDate()->toFormat($dateFormat) ){
		echo XiText::_('MOD_PAYPLANS_SUBSCRIPTION_EXPIRATION_DATE_LIFETIME');}
		else{
		echo XiText::_('MOD_PAYPLANS_SUBSCRIPTION_EXPIRATION_DATE_'.XiStatus::getName($subscription->getStatus())) ." ". $subscription->getExpirationDate()->toFormat($dateFormat);
	}?>	
	</div>

	</li> 
	<?php $count++; ?>
<?php endforeach;?>
</ul>
<?php 
