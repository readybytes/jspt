<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Payplans Registration Comprofiler Plugin
 *
 * @package		Payplans
 * @subpackage	Plugin
 */

class  plgPayplansregistrationComprofiler extends XiPluginRegistration
{	
	protected $_registrationUrl = 'index.php?option=com_comprofiler&task=registers';
	
	function _isRegistrationUrl()
	{   
		$vars = $this->_getVars();
		if($vars['option'] == 'com_comprofiler' && $vars['task'] == 'registers'){
			return true;
		}
		
		return false;	 
	}
	
	function _isRegistrationCompleteUrl()
	{
		return false;
	}
	
	function onAfterDispatch()
	{
		// do not run in admin panel
		if($this->_app->isAdmin()){
  			return true;
		}
		
		// must be on comprofile save screen
		$vars = $this->_getVars();
		if($vars['option'] != 'com_comprofiler' && $vars['task'] != 'saveregisters'){
			return true;
		}
		
		$registrationType = XiFactory::getConfig()->registrationType;	
		if($registrationType != $this->_name){
			return true;
		}
				
		// complete registration
		if($this->_getUser()){
			$this->_doCompleteRegistration();
		}
				
		return true;
	}
	
}