<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license	GNU/GPL, see LICENSE.php
* @package	PayPlans
* @subpackage	Modules
* @contact 	shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

?>
<div class="dashboard-migration-module">
	<div class="dashboard-migration-panel">
		<?php foreach($icons as $key => $value) : ?>
			<?php if($value !== true && $value !== false && is_array($value)) :?>
				<div onClick="xi.dashboard.preMigration('<?php echo $value['key']?>'); return false;" class="dashboard-migration-icon button white">
						<img src="<?php echo $value['icon']?>" alt="<?php echo $value['key']?>" />
						<br />			
						<span><?php echo $value['title'];?></span>
				</div>
			<?php endif;?>		 
		<?php endforeach;?>
	</div>	
</div>
