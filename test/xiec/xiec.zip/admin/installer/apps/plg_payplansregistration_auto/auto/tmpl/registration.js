xi.extend({
	registration : {		
		check : function(fieldId, funcName) {
			var $field = xi.jQuery('#'+fieldId);
	        var args = Array(fieldId, $field.val());
	        var url = 'index.php?option=com_payplans&view=user&task='+funcName;
	        
	        var opts = {
	        		  lines: 8, // The number of lines to draw
	        		  length: 3, // The length of each line
	        		  width: 3, // The line thickness
	        		  radius: 3, // The radius of the inner circle
	        		  color: '#000', // #rbg or #rrggbb
	        		  speed: 1, // Rounds per second
	        		  trail: 100, // Afterglow percentage
	        		  shadow: false // Whether to render a shadow
	        		};
	        $field.next().html('').spin(opts);
	        
        	xiajax.call(url, args[0], args[1]);
		},

		validate : function(fieldId, result, msg) {
			var $field = xi.jQuery('#'+fieldId);
			xi.jQuery('#err-'+fieldId).html(msg);
			
			$field.next().stop();
        	$field.next().html('*');
	        
        	if(result == true){
	        	$field.removeClass('invalid');
	        	return true;
	        }
	       
	        $field.addClass('invalid');
		}
	}
});



xi.jQuery(document).ready(function (){	

	xi.jQuery('#payplansRegisterAutoUsername').blur(function(){
		$(this).addClass('invalid');
		xi.registration.check(this.id, 'checkusername');
	});

	xi.jQuery('#payplansRegisterAutoEmail').blur(function(){
		$(this).addClass('invalid');
		xi.registration.check(this.id, 'checkemail');
	});

	xi.jQuery('#payplansRegisterAuto').click(function(){
		if(xi.jQuery('#payplansRegisterAutoUsername').hasClass('invalid')
				|| xi.jQuery('#payplansRegisterAutoEmail').hasClass('invalid')){
			return false;
		}
		
		return true;
	});
});