<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in


*/
if(defined('_JEXEC')===false) die();
?>
<script src="<?php echo PayplansHelperUtils::pathFS2URL(dirname(__FILE__).DS.'registration.js');?>" type="text/javascript"></script>

<div id="auto-register">
	<h4 class="div-heading pp-primary pp-color pp-border pp-background">
		<?php echo XiText::_('COM_PAYPLANS_PLAN_AUTO_REGISTERATION');?>
	</h4>

	<div class="row">
		<div class="row-label">
			<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTERATION_USERNAME');?>		
		</div>
		<div class="row-input">
			<input type="text" id="payplansRegisterAutoUsername" name="payplansRegisterAutoUsername" class="placeholder required"/><span class="required">*</span>
		</div>
		<div class="row-error" id="err-payplansRegisterAutoUsername"></div>		
	</div>

	<div class="row">
		<div class="row-label">
			<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTERATION_EMAIL');?>		
		</div>
		<div class="row-input">
			<input type="text" id="payplansRegisterAutoEmail" name="payplansRegisterAutoEmail" class="placeholder required" /><span class="required">*</span>
		</div>
		<div class="row-error" id="err-payplansRegisterAutoEmail"></div>
	</div>

	<div class="row">
		<div class="row-label">
			<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTERATION_PASSWORD');?>		
		</div>
		<div class="row-input">
			<input type="password" id="payplansRegisterAutoPassword" name="payplansRegisterAutoPassword" class="required" /><span class="required">*</span>
		</div>
		<div class="row-error" id="err-payplansRegisterAutoPassword"></div>
	</div>

	<div class="row">
		<div class="row-label">
		</div>
		<div class="row-input">
			<input type="submit" class="xi-button pp-button-color medium" id="payplansRegisterAuto" name="payplansRegisterAuto" value="<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTER_AUTO')?>"/>
		</div>
	</div>
</div>
<?php
