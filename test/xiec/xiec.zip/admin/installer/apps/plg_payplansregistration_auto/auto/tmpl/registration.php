<?php
?>
<div id="auto-register">
	<h4 class="div-heading primary color border background">
		<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTERATION_EMAIL');?>
	</h4>

	<input type="text" name="payplansRegisterAutoEmail" class="placeholder" placeholder="<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTERATION_ENTER_EMAIL');?>"/><span class="required">*</span>
	
	<input type="submit" class="button button-color medium" id="payplansRegisterAuto" name="payplansRegisterAuto" value="<?php echo XiText::_('COM_PAYPLANS_PLAN_REGISTER_AUTO')?>"/>
</div>