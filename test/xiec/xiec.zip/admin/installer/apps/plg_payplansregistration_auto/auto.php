<?php

/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @contact		shyam@joomlaxi.com
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Payplans Registration Plugin
 *
 * @package		Payplans
 * @subpackage	Plugin
 */
class  plgPayplansregistrationAuto extends XiPluginRegistration
{
	protected $_registrationUrl = 'index.php?option=com_payplans&view=plan&task=login';

	function _isRegistrationUrl()
	{
		$vars = $this->_getVars();
		if($vars['option'] == 'com_payplans' && $vars['view'] == 'plan' && $vars['task'] == 'login'){
			return true;
		}
		
		return false;
	}
	
	function _isRegistrationCompleteUrl()
	{
		return true;
	}
	
	/** 
	 * @see XiPluginRegistration::_doStartRegistration()
	 * 
	 */
	protected function _doStartRegistration()
	{
		$planId = $this->_getPlan();

		$email 	  = JRequest::getVar('payplansRegisterAutoEmail', false);
		$username = JRequest::getVar('payplansRegisterAutoUsername', false);
		$password = JRequest::getVar('payplansRegisterAutoPassword', false);
		
		// if $username is not post then redirect to login page again
		if(!$username){
			$this->_app->redirect(XiRoute::_('index.php?option=com_payplans&view=plan&task=login&plan_id='.$planId));
		}
		
		// if email is not post then redirect to login page again
		if(!$email){
			$this->_app->redirect(XiRoute::_('index.php?option=com_payplans&view=plan&task=login&plan_id='.$planId));
		}
		
		// if password is not post then redirect to login page again
		if(!$password || JString::strlen(Jstring::trim($password)) === 0) {
			$this->_app->redirect(XiRoute::_('index.php?option=com_payplans&view=plan&task=login&plan_id='.$planId));
		}
		
		$userId = $this->_autoRegister($username, $email, $password);
		
		if($userId){
			// registration is completed here so call afterRegistrationComplete
			$this->_setUser($userId);
			return $this->_doCompleteRegistration();
		}
		
		return true;
	}
	
	function _autoRegister($username, $email, $password)
	{
		if(PAYPLANS_JVERSION_15){
			return $this->_autoRegister15($username, $email, $password);
		}
		//else for 1.6+
		return $this->_autoRegister16($username, $email, $password);
	}
	
	function _autoRegister15($username, $email, $password)
	{
		jimport('joomla.mail.helper');
		jimport('joomla.user.helper');
		require_once  JPATH_ROOT.DS.'components'.DS.'com_user'.DS.'controller.php';
		JFactory::getLanguage()->load('com_user');
		
		if(!JMailHelper::isEmailAddress($email)){
			$this->_app->enqueueMessage(XiText::_('COM_PAYPLANS_INVALID_EMAIL_ADDRESS'));
			return false;
		}
		
		if(PayplansHelperUser::exists('email', $email)){
			$this->_app->enqueueMessage(XiText::_('COM_PAYPLANS_EMAIL_ALREADY_REGISTERED'));
			return false;
		}
		
		if(PayplansHelperUser::exists('username', $username)){
			$this->_app->enqueueMessage(XiText::_('PLG_PAYPLANSREGISTRATION_AUTO_USERNAME_ALREADY_REGISTERED'));
			return false;
		}
		
		$user 		= clone(JFactory::getUser());
		$authorize	= JFactory::getACL();
		$newUsertype = 'Registered';

		//Update user values
		$user->set('id', 0);
		$user->set('usertype', $newUsertype);
		$user->set('gid', $authorize->get_group_id( '', $newUsertype, 'ARO' ));
		// user will choose his/her password
//		$password = JUserHelper::genRandomPassword();
		
		$data = array(	'username'=>$username,
						'name'=>$username,
						'email'=>$email,
						'password'=>$password,
						'password2'=>$password,
						'block'=>1
					 );
					 
		// Bind the post array to the user object
		if (!$user->bind($data)) {
			XiError::raiseError( 500, $user->getError());
		}
		
		jimport('joomla.user.helper');
		// If user activation is turned on, we need to set the activation information
		$usersConfig = JComponentHelper::getParams( 'com_users' );
		
		// if acc_verification is not set to never_acc_creation, then user activation is required
		$useractivation = $this->_isEmailVerificationRequired() 
							|| $this->params->get('acc_verification', 'always_email') == 'never_sub_active';							
		
		$user->set('block', '0');
		if ($useractivation == true)
		{
			jimport('joomla.user.helper');
			$user->set('activation', JUtility::getHash( JUserHelper::genRandomPassword()) );
			$user->set('block', '1');
		}
		

		if (!$user->save()){
			$this->_app->enqueueMessage(XiText::_('PLG_PAYPLANSREGISTRATION_AUTO_REGISTRATION_SAVE_FAILED_15'));
			return false;
		}

		$this->_sendMail($user, $password);
		
		// Show what will happen to registration
		$this->_app->enqueueMessage(XiText::_('PLG_PAYPLANSREGISTRATION_AUTO_'.JString::strtoupper($this->params->get('acc_verification', 'always_email'))));
		
		return $user->id;
	}
	
	function _sendMail(&$user, $password)
	{
		$mainframe = XiFactory::getApplication();
		$db		= JFactory::getDBO();

		$name 		= $user->get('name');
		$email 		= $user->get('email');
		$username 	= $user->get('username');

		$usersConfig 	= &JComponentHelper::getParams( 'com_users' );
		$sitename 		= $mainframe->getCfg( 'sitename' );
		$useractivation = $usersConfig->get( 'useractivation' );
		$mailfrom 		= $mainframe->getCfg( 'mailfrom' );
		$fromname 		= $mainframe->getCfg( 'fromname' );
		$siteURL		= JURI::base();

		$subject 	= sprintf ( XiText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_ACCOUNT_DETAILS_FOR' ), $name, $sitename);
		$subject 	= html_entity_decode($subject, ENT_QUOTES);

		if($this->_isEmailVerificationRequired()){
			$message = sprintf ( XiText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG_ACTIVATE' ), $name, $sitename, $siteURL.'index.php?option=com_payplans&view=user&task=activate_user&activation='.$user->get('activation'), $siteURL, $username, $password);
		} else {
			$message = sprintf ( XiText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG' ), $name, $sitename, $siteURL, $username, $password);
		}

		$message = html_entity_decode($message, ENT_QUOTES);

		//get all super administrator
		$query = 'SELECT name, email, sendEmail' .
				' FROM #__users' .
				' WHERE LOWER( usertype ) = "super administrator"';
		$db->setQuery( $query );
		$rows = $db->loadObjectList();

		// Send email to user
		if ( ! $mailfrom  || ! $fromname ) {
			$fromname = $rows[0]->name;
			$mailfrom = $rows[0]->email;
		}

		JUtility::sendMail($mailfrom, $fromname, $email, $subject, $message);

		// Send notification to all administrators
		$subject2 = sprintf ( XiText::_('PLG_PAYPLANSREGISTRATION_AUTO_ACCOUNT_DETAILS_FOR' ), $name, $sitename);
		$subject2 = html_entity_decode($subject2, ENT_QUOTES);

		// get superadministrators id
		foreach ( $rows as $row )
		{
			if ($row->sendEmail)
			{
				$message2 = sprintf ( JText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG_ADMIN' ), $row->name, $sitename, $name, $email, $username);
				$message2 = html_entity_decode($message2, ENT_QUOTES);
				JUtility::sendMail($mailfrom, $fromname, $row->email, $subject2, $message2);
			}
		}
	}
	
	
	function _autoRegister16($username, $email, $password)
	{
		require_once  JPATH_ROOT.DS.'components'.DS.PAYPLANS_COM_USER.DS.'models'.DS.'registration.php';
		
		$model = new UsersModelRegistration();
		JFactory::getLanguage()->load(PAYPLANS_COM_USER);
		
		jimport('joomla.mail.helper');
		if(!JMailHelper::isEmailAddress($email)){
			$this->_app->enqueueMessage(XiText::_('COM_PAYPLANS_INVALID_EMAIL_ADDRESS'));
			return false;
		}
		
		if(PayplansHelperUser::exists('email', $email)){
			$this->_app->enqueueMessage(XiText::_('COM_PAYPLANS_EMAIL_ALREADY_REGISTERED'));
			return false;
		}
		
		if(PayplansHelperUser::exists('username', $username)){
			$this->_app->enqueueMessage(XiText::_('PLG_PAYPLANSREGISTRATION_AUTO_USERNAME_ALREADY_REGISTERED'));
			return false;
		}
		
		// load user helper
		jimport('joomla.user.helper');
//		$password = JUserHelper::genRandomPassword();
		$temp = array(	'username'=>$username,'name'=>$username,'email1'=>$email,
						'password1'=>$password, 'password2'=>$password, 'block'=>0 );
				
		$config = JFactory::getConfig();
		$params = JComponentHelper::getParams('com_users');

		// Initialise the table with JUser.
		$user = new JUser;
		
		$data = (array)$model->getData();
		// Merge in the registration data.
		foreach ($temp as $k => $v) {
			$data[$k] = $v;
		}

		// Prepare the data for the user object.
		$data['email']		= $data['email1'];
		$data['password']	= $data['password1'];
		
		
//		$useractivation = $params->get('useractivation');

		// if acc_verification is not set to never_acc_creation, then user activation is required
		$useractivation = $this->_isEmailVerificationRequired() ;
		$useractivation = $useractivation
							|| $this->params->get('acc_verification', 'always_email') == 'never_sub_active';							
		
		// Check if the user needs to activate their account.
		if ($useractivation) {
			jimport('joomla.user.helper');
			$data['activation'] = JUtility::getHash(JUserHelper::genRandomPassword());
			$data['block'] = 1;
		}

		// Bind the data.
		if (!$user->bind($data)) {
			$this->_app->enqueueMessage(XiText::sprintf('PLG_PAYPLANSREGISTRATION_AUTO_BIND_FAILED', $user->getError()));
			return false;
		}

		// Load the users plugin group.
		JPluginHelper::importPlugin('user');

		// Store the data.
		if (!$user->save()) {
			$this->_app->enqueueMessage(XiText::sprintf('PLG_PAYPLANSREGISTRATION_AUTO_REGISTRATION_SAVE_FAILED', $user->getError()));
			return false;
		}

		// Compile the notification mail values.
		$data = $user->getProperties();
		$data['fromname']	= $config->get('fromname');
		$data['mailfrom']	= $config->get('mailfrom');
		$data['sitename']	= $config->get('sitename');
		$data['siteurl']	= JUri::base();

		if ($this->_isEmailVerificationRequired())
		{
			// Set the link to activate the user account.
			$uri = JURI::getInstance();
			$base = $uri->toString(array('scheme', 'user', 'pass', 'host', 'port'));
			$data['activate'] = $base.JRoute::_('index.php?option=com_users&task=registration.activate&token='.$data['activation'], false);

			$emailSubject	= XiText::sprintf(
				'PLG_PAYPLANSREGISTRATION_AUTO_ACCOUNT_DETAILS_FOR',
				$data['name'],
				$data['sitename']
			);

			$emailBody = XiText::sprintf(
				'PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG_ACTIVATE',
				$data['name'],
				$data['sitename'],
				$data['siteurl'].'index.php?option=com_payplans&view=user&task=activate_user&activation='.$data['activation'],
				$data['siteurl'],
				$data['username'],
				$data['password_clear']
			);
		} else {

			$emailSubject	= XiText::sprintf(
				'PLG_PAYPLANSREGISTRATION_AUTO_ACCOUNT_DETAILS_FOR',
				$data['name'],
				$data['sitename']
			);

			$emailBody = XiText::sprintf(
				'PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG',
				$data['name'],
				$data['sitename'],
				$data['siteurl'],
				$data['username'],
				$data['password_clear']
			);
		}

		// Send the registration email.
		$return = JUtility::sendMail($data['mailfrom'], $data['fromname'], $data['email'], $emailSubject, $emailBody);

		// Check for an error.
		if ($return !== true) {
			$this->_app->enqueueMessage(XiText::_('COM_USERS_REGISTRATION_SEND_MAIL_FAILED'), 'error');

			// Send a system message to administrators receiving system mails
			$db = JFactory::getDBO();
			$q = "SELECT id
				FROM #__users
				WHERE block = 0
				AND sendEmail = 1";
			$db->setQuery($q);
			$sendEmail = $db->loadResultArray();
			if (count($sendEmail) > 0) {
				$jdate = new JDate();
				// Build the query to add the messages
				$q = "INSERT INTO `#__messages` (`user_id_from`, `user_id_to`, `date_time`, `subject`, `message`)
					VALUES ";
				$messages = array();
				foreach ($sendEmail as $userid) {
					$messages[] = "(".$userid.", ".$userid.", '".$jdate->toMySQL()."', '".JText::_('COM_USERS_MAIL_SEND_FAILURE_SUBJECT')."', '".JText::sprintf('COM_USERS_MAIL_SEND_FAILURE_BODY', $return, $data['username'])."')";
				}
				$q .= implode(',', $messages);
				$db->setQuery($q);
				$db->query();
			}
			return false;
		}
		
		// Show what will happen to registration
		$this->_app->enqueueMessage(XiText::_('PLG_PAYPLANSREGISTRATION_AUTO_'.JString::strtoupper($this->params->get('acc_verification', 'always_email'))));
		
		// how to find user id 
		return $user->id;
	}
	
	function _isEmailVerificationRequired()
	{
		// get the plan selected
		$isFreePlan = false;
		$plan = PayplansPlan::getInstance($this->_getPlan());
		if(floatval($plan->getPrice()) == floatval(0)){
			$isFreePlan = true;
		}
	
		return $this->params->get('acc_verification', 'always_email') == 'always_email'
					|| ($this->params->get('acc_verification', 'freeplan_email') == 'freeplan_email' && $isFreePlan);
	}
	
	function onPayplansSubscriptionAfterSave($previous, $current)
	{
		if($this->params->get('acc_verification', 'always_email') != 'never_sub_active'){
			return true;
		}
		
		if($current->getStatus() == XiStatus::SUBSCRIPTION_ACTIVE){
			$userid = $current->getBuyer();
			$user = XiFactory::getUser($userid);
			if($user->get('block') == true){
				$user->set('block', 0);
				$user->set('activation', '');
				$user->save();
			}
		}
		
		return true;
	}
	function onAfterRoute()
	{
		// call parent's onAfterRoute
		parent::onAfterRoute(); 
		
	
		$vars = $this->_getVars(array('option','view', 'task', 'activation'));
		//if url is not same as given in the activation link then return
        if($vars['option'] != 'com_payplans' || $vars['view'] != 'user' || $vars['task'] != 'activate_user'){
			return;
		}
			
		$mainframe = XiFactory::getApplication();
		// Initialize some variables
		$db			= XiFactory::getDBO();
		$user 		= XiFactory::getUser();
		$document   = XiFactory::getDocument();

	   $usersConfig = JComponentHelper::getParams( 'com_users' );
	   $userActivation = $usersConfig->get('useractivation');
	   $allowUserRegistration = $usersConfig->get('allowUserRegistration');

		// Check to see if they're logged in, because they don't need activation!
		if ($user->get('id')) {
			// They're already logged in, so redirect them to the home page
			$mainframe->redirect( 'index.php' );
		}
		
		// if user registration is not allowed and user activation is not required then return
		if ($allowUserRegistration == '0' || $userActivation == '0') {
			JError::raiseError( 403, JText::_( 'Access Forbidden' ));
			return;
		}
				
		$returl = XiRoute::_('index.php?option=com_payplans&view=dashboard');
		
		// Do we even have an activation string?
		$activation = JRequest::getVar('activation', '', '', 'alnum' );
		$activation = $db->getEscaped( $activation );
		
		if (empty( $activation )){
			$message = XiText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_REG_ACTIVATE_NOT_FOUND' );
		    XiFactory::getApplication()->redirect($returl,$message); 
			return;
		}
				
		// Now activate this user
		jimport('joomla.user.helper');
		$message = XiText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_REG_ACTIVATE_NOT_FOUND' );
		if (JUserHelper::activateUser($activation)){
			$message = XiText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_REG_ACTIVATE_COMPLETE' );
		}

		// redirect user to $returl and display $message
		XiFactory::getApplication()->redirect($returl,$message); 		
	}
}
