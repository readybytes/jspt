/*
IMP : Only use C-Style comments only

Every ID field should have this convention "tableName_id" , 
where tableName is the name of table, whom this id refers

*/

/*
Add Logging Table
*/
CREATE TABLE IF NOT EXISTS `#__payplans_log` (
  `log_id` 	int(11) NOT NULL AUTO_INCREMENT,
  `level` 	int(11) NOT NULL DEFAULT '0',
  `user_id` 	int(11) NOT NULL,
  `class` 	varchar(255) NOT NULL,
  `object_id` 	int(11) NOT NULL,
  `message`	TEXT NULL ,
  `user_ip` 	varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `content` 	TEXT NULL,
  PRIMARY KEY (`log_id`),
  INDEX `idx_level` (`level` ASC)
) 
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8;
