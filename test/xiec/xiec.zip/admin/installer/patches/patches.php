<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();

jimport('joomla.filesystem.file');

class PayplansPatch
{
	static function getMapper()
	{
		$_mapper = array();
		// when add new patch update the definition
		$_mapper['START'] 		= 'firstPatch';
		
		$_mapper['firstPatch'] 	= 'secondPatch';
		$_mapper['secondPatch'] = 'patch_enable_plugins';
		$_mapper['patch_enable_plugins'] = 'patch_enable_modules';
		$_mapper['patch_enable_modules'] = 'patch_001_log_table';
		
		$_mapper['patch_001_log_table'] = 'patch_002_remove_oldplugins';
		$_mapper['patch_002_remove_oldplugins'] = 'patch_003_add_table_appmetadata';
		$_mapper['patch_003_add_table_appmetadata'] = 'patch_004_remove_apps_paymenttmpl';
		$_mapper['patch_004_remove_apps_paymenttmpl'] = 'patch_005_add_customization_config';
		$_mapper['patch_005_add_customization_config'] = 'END';
		
		
		return $_mapper;
	}
	
	static function applyPatches($nextPatch='START', $class='PayplansPatch', $mapper=null)
	{
		if($mapper === null){
			$mapper = self::getMapper();
		}
		// as we will get the previous patch applied
		$nextPatch= $mapper[$nextPatch]; 
		
		//apply patches
		while($nextPatch !== 'END')
		{
			if(method_exists($class, $nextPatch)===false){
				return false;
			}
			
			$result = call_user_func(array($class, $nextPatch));
			//update current patch to database
			PayplansInstallHelper::updatePatch($nextPatch);
			
			//if some error return false
			if($result === false){
				return false;
			}
			
			//get next patch
			$nextPatch = $mapper[$nextPatch];
		}

		// update build version and global version of payplans in database
		if(class_exists('PayplansInstallHelper'))
				PayplansInstallHelper::updateVersion();
		
		return true;
	}

	//do install install.sql
	static function firstPatch()
	{
		return PayplansInstallHelper::applySqlFile(dirname(__FILE__).DS.'install.sql');
	}


	//install system data
	static function secondPatch()
	{
		return PayplansInstallHelper::applySqlFile(dirname(__FILE__).DS.'system-data.sql');
	}

	static function patch_enable_plugins($enable=1)
	{
		$plugins = array( 
						array('system',		'payplans'),
					 	array('payplans',	'discount'),
					 	array('payplansmigration',	'acctexp'),
					 	array('payplansmigration',	'ambrasubs'),
					 	array('payplansmigration',	'sample'),
						array('payplansregistration', 'joomla'),
					    array('payplansregistration', 'jomsocial'),
					    array('payplansregistration', 'auto')
					  );
						
		foreach($plugins as $plugin){
			$folder = $plugin[0];
			$pluginName = $plugin[1];
			PayplansInstallHelper::changePluginState($pluginName, $enable, $folder);
		}

		return true;
	}
	
	static function patch_enable_modules($enable=1)
	{
		$modules	= array(
					'mod_payplans_about'  		=> 'payplans-admin-dashboard',
					'mod_payplans_setup'  		=> 'payplans-admin-dashboard',
					'mod_payplans_migration'  	=> 'payplans-admin-dashboard',
					'mod_payplans_search' 		=> 'payplans-admin-dashboard-bottom'
				);
		foreach($modules as $module=>$position)
			PayplansInstallHelper::changeModuleState($module, $position, $enable);

		// special case order mod_payplans_setup at least order
		PayplansInstallHelper::changeModuleOrder(-100, 'mod_payplans_setup');
		return true;
	}
	
	// add log table
	static function patch_001_log_table()
	{
		//add log table
		return PayplansInstallHelper::applySqlFile(dirname(__FILE__).DS.'sql'.DS.__FUNCTION__.'.sql');
	}
	
	// Remove obsolete plugins to reduce the errors.
	static function patch_002_remove_oldplugins()
	{
		// 4 payplans plugins (core/ambrasubs/acctexp/sample)
		PayplansInstallHelper::uninstallPlugin('core','payplans');
		PayplansInstallHelper::uninstallPlugin('sample','payplans');
		PayplansInstallHelper::uninstallPlugin('ambrasubs','payplans');
		PayplansInstallHelper::uninstallPlugin('acctexp','payplans');
	}
	
	// Add App Installer level utility
	static function patch_003_add_table_appmetadata()
	{
		//add log table
		return PayplansInstallHelper::applySqlFile(dirname(__FILE__).DS.'sql'.DS.__FUNCTION__.'.sql');
	}
	
	static function patch_004_remove_apps_paymenttmpl()
	{
		$dirsToRemove = array('ganalytics', 'adminpay', '2checkout', 'authorize', 'offlinepay', 'paypal', 'googlecheckout');
		foreach($dirsToRemove as $dir){
			if(JFolder::exists(JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'libraries'.DS.'app'.DS.$dir)){
				JFolder::delete(JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'libraries'.DS.'app'.DS.$dir);
			}			
		}
		
		$filesToRemove = array('cancel', 'success', 'error', 'triggered');
		foreach($filesToRemove as $file){
			if(JFile::exists(JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'templates'.DS.'default'.DS.'payment'.DS.'default_'.$file.'.php')){
				JFile::delete(JPATH_ROOT.DS.'components'.DS.'com_payplans'.DS.'templates'.DS.'default'.DS.'payment'.DS.'default_'.$file.'.php');
			}			
		}
	}
	
	function patch_005_add_customization_config()
	{
		//insert customization params to config
		return PayplansInstallHelper::applySqlFile(dirname(__FILE__).DS.'sql'.DS.__FUNCTION__.'.sql');
	}
	
}
