/*
IMP : Only use C-Style comments only

Every ID field should have this convention "tableName_id" , 
where tableName is the name of table, whom this id refers

*/

/*
Add Application Metadata
*/
CREATE TABLE IF NOT EXISTS `#__payplans_appmetadata` (
  `appmetadata_id` 	varchar(255) NOT NULL, 		
  `installed` 	TINYINT(1) DEFAULT 0,
  `created_date` 	datetime NOT NULL,
  `modified_date` 	datetime NOT NULL,
  `params` 		TEXT NULL,
  PRIMARY KEY (`appmetadata_id`)
) 
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8;
