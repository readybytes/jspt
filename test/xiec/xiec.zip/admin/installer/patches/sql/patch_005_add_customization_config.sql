INSERT IGNORE INTO `#__payplans_config` 
(`config_id`, `title`, `key`, `config`, `componentname`, `path`) 
VALUES
(5, 'Customization', 'payplans_customization', '', 'payplans', 'components/com_payplans/libraries/model/xml/config.payplans_customization')
;
