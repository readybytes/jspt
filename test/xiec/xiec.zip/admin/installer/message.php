<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Installer
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?>

<script type="text/javascript">
window.onload = function(){	
  setTimeout("location.href = 'index.php?option=com_payplans&view=support&task=patch';", 2000);
}
</script>

<style type="text/css">
.installnote {
	width: 92%;
	margin: 6px 24px;
}

.installnote h3 {
	padding: 0 12px;
	text-align:center;
}

.installnote p {
	padding: 0 50px;
}

.pay a{
background: none repeat scroll 0 0 #FF8400;
border: 0px solid #E05F26;
color: #FFFFFF;
padding: 5px;
line-height:25px;
cursor:pointer;
letter-spacing:1px;
text-decoration:none;
}

.pay{
overflow:hidden;
border:1px solid #666
}

.msg{
float:left;
width:100%;
text-align:center;
}

.whtNext{
float:left;
width:43%;
}

#install-sample-data-msg{
font-weight:bold;
border:1px solid #ffc98f;
padding:3px;
background:#FFC98F;
display:none;
}

</style>

<div class="pay">

<div class="msg">

<div class="installnote">
<h3>PayPlans : Subscription / Membership System for Joomla!</h3>
<p>Please do not close the window and do not click on any where. We are redrecting you to Payplans' support page.</p>

<p>Team JoomlaXi<br />
Ready Bytes Software Labs Pvt. Ltd.
</p>
</div>
</div>
</div>
<?php 
