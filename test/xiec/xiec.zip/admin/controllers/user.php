<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();

 class PayplansadminControllerUser extends XiController
{
	
	public function _save(array $data, $itemId=null)
	{
		// we need to collect params, and convert them into INI
		$data['preference']= PayplansHelperParam::collectParams($data,'preference');
		$data['params'] = PayplansHelperParam::collectParams($data,'params');
		return parent::_save($data, $itemId);
	}
	
	/*
	 * apply the selected subscription plan to the selected users
	 */
	public function applyPlan($planId=null, $users = array())
	{
		$url = 'index.php?option=com_payplans&view=user&task=display';
		$planId = $planId ? $planId : JRequest::getInt('plan_id',$planId);
		$users = JRequest::getVar('cid', $users, 'request', 'array');

		// XITODO : proper handling needs to be implemented when plan is applied to large number of users
		foreach($users as $userId){
			if(!$planId){
				return true;
			}
			$plan = PayplansPlan::getInstance( $planId);
			$plan->subscribe($userId)
				 ->setStatus(XiStatus::ORDER_COMPLETE)
				 ->save();
		}
		$this->setRedirect($url);
		return false;

	}
	
	public function selectPlan()
	{
		$this->setTemplate('selectplan');
		return true;
	} 

}

