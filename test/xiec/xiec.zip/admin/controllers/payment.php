<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();


class PayplansadminControllerPayment extends XiController
{
	public function newPayment()
	{
		$this->setTemplate('newpayment');
		return true;
	}

	public function _save(array $data, $itemId=null)
	{
		// asert if order_id and app_id is not in post data
		XiError::assert(isset($data['app_id']) && $data['app_id'], XiText::_('COM_PAYPLANS_ERROR_INVALID_APPLICATION_ID'));
		XiError::assert(isset($data['order_id']) && $data['order_id'], XiText::_('COM_PAYPLANS_ERROR_INVALID_ORDER_ID'));

		$data['transaction'] = PayplansHelperParam::arrayToIni($data, 'transaction');
		parent::_save($data, $itemId, 'payment');
		return true;
	}
}

