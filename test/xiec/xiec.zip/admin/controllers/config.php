<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();

class PayplansadminControllerConfig extends XiController
{
	protected 	$_defaultTask = 'edit';

	public function _save(array $data, $itemId=null)
	{
		$cModel 	= $this->getModel();
		$records 	= $cModel->loadRecords(array(), array(), true);
		$recordKey 	= $cModel->getTable()->getKeyName();
		$logo_image = null;
		
		if(isset($_FILES['payplans_invoice'])){
		    //save logo image
			$companylogo_imgpath = $_FILES['payplans_invoice']['tmp_name']['config']['companyLogo'];
			$companylogo_imgname = $_FILES['payplans_invoice']['name']['config']['companyLogo'];
			$supported_imageExt=array("jpg","jpeg","png","gif");
			$logo_image=PayplansHelperUtils::saveUploadedFile("images/payplans",$companylogo_imgpath,$companylogo_imgname,$supported_imageExt,"companylogo");
		}
 		//XITODO : Not Imp : convert config id to key
 		foreach($records as $record){
		    //save logo image in $data
			if($record->key == "payplans_invoice" && $logo_image!=null)
           {
			  $data[$record->key]['config']['companyLogo']= $logo_image;
			}
			// we need to collect params, and convert them into INI
			$data[$record->key]['config'] = PayplansHelperParam::collectParams($data[$record->key], 'config');
			parent::_save($data[$record->key], $record->config_id);
		}
		return true;
	}
}