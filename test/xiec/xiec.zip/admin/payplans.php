<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

require_once  dirname(__FILE__).DS.'includes'.DS.'includes.php';

//now decide what to do
$view	= JString::strtolower(JRequest::getCmd('view', 		'dashboard'));
$task 	= JString::strtolower(JRequest::getCmd('task'));
$format	= JString::strtolower(JRequest::getCmd('format',	'html'));
$isAjax	=	JRequest::getBool('isAjax',false);
if($isAjax){
	$ajaxResponse	=	XiFactory::getAjaxResponse();
}

// we need to create a object of proper controller
$args	= array();
$args['view'] 			= $view;
$args['controllerClass']= 'Payplansadmin'.'Controller'.JString::ucfirst($view);
$args['task'] 			= $task;
$args['format'] 		= $format;


// trigger apps, so that they can override the behaviour
// if somebody overrided it, then they must overwrite $data['controllerClass']
// in this case they must include the file, where class is defined
$results  =	PayplansHelperEvent::trigger('onPayplansControllerCreation', $args);

//we have setup autoloading for controller classes
//perform the task now
$controllerClass = $args['controllerClass'];
$controller = new $controllerClass();
$controller->execute($task);

//trigger system end event
XiHelperPlugin::trigger('onPayplansSystemEnd');

if($isAjax){
	XiFactory::getAjaxResponse()->sendResponse();
}

$controller->redirect();