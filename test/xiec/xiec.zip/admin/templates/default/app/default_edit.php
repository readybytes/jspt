<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<div id="apps">
<div class="xippElements">
<form action="<?php echo $uri; ?>" method="post" name="adminForm" id="adminForm">

	<div class="elementColumn">
		<fieldset class="adminform">
			<legend> <?php echo XiText::_('COM_PAYPLANS_APP_EDIT_APP_DETAILS' ); ?> </legend>
			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_APP_EDIT_TOOLTIP_APP_NAME') ?>">
						<?php echo XiText::_('COM_PAYPLANS_APP_EDIT_APP_NAME') ?> 
					</span>
				 </div>
				<div class="paramValue"><input name="title"  class="required" type="text" size="35" value="<?php echo $app->getTitle(); ?>" /><span class="required">*</span></div>
			</div>

			<div>
				<input type="hidden" name="id" value="<?php echo $app->getId(); ?>" />
			</div>

			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_APP_EDIT_TOOLTIP_APP_TYPE') ?>">
						<?php echo XiText::_('COM_PAYPLANS_APP_EDIT_APP_TYPE') ?>  
					</span>		
				</div>
				<div class="paramValue"><?php echo $app_names[$app->getType()]; ?></div>
				<input type="hidden" name="type" value="<?php echo $app->getType(); ?>" />
			</div>

			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_APP_EDIT_TOOLTIP_APP_PUBLISHED') ?>">
						<?php echo XiText::_('COM_PAYPLANS_APP_EDIT_APP_PUBLISHED') ?>  
					</span>
				</div>
				<div class="paramValue"><?php echo XiHtml::_('select.booleanlist',  'published', '', $app->getPublished());?></div>
			</div>

			<div id="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_APP_EDIT_TOOLTIP_APP_DESCRIPTION') ?>">
						<?php echo XiText::_('COM_PAYPLANS_APP_EDIT_APP_DESCRIPTION') ?>
					</span>
				</div>
				<div class="paramValue"><textarea name="description" rows="2" cols="40"><?php echo $app->getDescription();?></textarea></div>
			</div>
		</fieldset>
	
		<fieldset class="adminform">
			<legend>
				<?php echo XiText::_('COM_PAYPLANS_APP_EDIT_APP_CONFIGURATION' ); ?>
			</legend>
			<?php echo $app->getParamsHtml('core_params','core_params'); ?>
		</fieldset>

		<fieldset class="adminform">
			<legend>
				<?php echo XiText::_( 'COM_PAYPLANS_APP_EDIT_APPS_PLAN' ); ?>
			</legend>
			<div class="elementParams">
				<div class="paramTitle hasTip" title="<?php echo XiText::_('COM_PAYPLANS_APP_EDIT_APPS_PLAN_TITLE'); ?>::<?php echo XiText::_('COM_PAYPLANS_APP_EDIT_APPS_PLAN_TITLE_DESC'); ?>" >
					<?php echo XiText::_( 'COM_PAYPLANS_APP_EDIT_APPS_PLAN_TITLE' ); ?>
				</div>
				<div class="paramValue">
					<?php $plans = $app->getPlans();
					echo XiHtml::_('elements.plans', 'appplans', $plans, array('multiple'=>true));?>
				</div>
			</div>
		</fieldset>

		<!-- Logs -->
		<?php echo $this->loadTemplate('edit_log');?>
	</div>
	
	<div class="elementColumn">
		<fieldset class="adminform">
			<legend>
				<?php echo XiText::_( 'COM_PAYPLANS_APP_EDIT_APP_PARAMETERS' ); ?>
			</legend>
			<?php echo $app->getParamsHtml('app_params','app_params'); ?>
		</fieldset>
		
		<?php $help_msg = trim($help_message);?>
		<?php if(!empty($help_msg)):?>
			<fieldset class="adminform">
				<legend>
					<?php echo XiText::_( 'COM_PAYPLANS_APP_EDIT_APP_HELP' ); ?>
				</legend>
				<?php echo $help_message; ?>
			</fieldset>
		<?php endif;?>
	</div>

	<input type="hidden" name="task" value="save" />
</form>
</div>
</div>
<?php
