<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<div class="app-select" id="appPopup">
<form action="<?php echo $uri; ?>" method="post" name="adminForm" id="adminForm">

	<div class="filter">
		<div class="select-box">
		<?php echo XiHtml::_('elements.apptags', 'filtertags', '', null, array());?>
		</div>
		<div id="select-other-app" class="other-app">
			<a onClick="xi.jQuery('#filtertags').val('all').change(); return false;" href="" title="Click for Back"><?php //echo XiText::_('COM_PAYPLANS_APP_SELECT_OTHER');?></a>
		</div>
	</div>

	<div class="selectApps">
		<?php foreach($apps as $app) :?> 		
			<?php 
				if(in_array($app, array('adminpay', 'googlecheckout'))) {
			  		continue; 
				} 
			?>
		
			<div class="button white button-app-wrap <?php echo ' f-'.implode(' f-',$appdata[$app]['tags']); ?>" id="button-app-wrap-<?php echo $app; ?>" onClick="xi.apps.clickapp('<?php echo $app; ?>');">
				<div class="button-app" id="button-app-<?php echo $app; ?>">
					<div class="app-icon">
						<img src="<?php echo PayplansHelperUtils::pathFS2URL($appdata[$app]['icon']); ?>" />
					</div>
					<div class="app-name">
						<table height="48px">
							<tr><td>
							<?php echo $appdata[$app]['name']; ?>
							</td></tr>
						</table>
					</div>
				</div>
			</div>				
		<?php endforeach;?>
		
	</div>
	
	<div id="apps-descriptions" >
			<?php foreach($appdata as $app => $data): ?> 
				<div id="apps-description-<?php  echo $app;  ?>" class="appDesc">
				<?php echo $data['description']; ?>
				</div>
			<?php  endforeach; ?>					
	</div>
	
	<div  class="submitApps">
	<input type="hidden" id="payplans-app-new-next" class="submitButton" type="submit" name="appnext" value="<?php echo XiText::_('NEXT');?>" />
	<input type="hidden" name="task" value="new" />
	<input type="hidden" id="type" name="type" value="#" />
	</div>
</form>
</div>
<?php 
