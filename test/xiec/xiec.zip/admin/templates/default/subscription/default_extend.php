<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<div id="extend-popup">
<form action="<?php echo $uri; ?>" method="post" name="select-extend-time" id="select-extend-time">
	<div class="extend-message"><?php echo XiText::_('COM_PAYPLANS_SUBSCRIPTION_GRID_EXTEND_MESSAGE')?></div>
	<div class="extend-time"><?php echo XiHtml::_('elements.xitimer', 'extend_time', '000000000000' ,'extend_time'); ?></div>
</form>
</div>
<?php 
