<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();

?>
	<div class="elementParams">
				<div class="paramTitle"> <?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_USER_USER_ID') ?>  </div>
		<div class="paramValue"><?php echo $user->getId(); ?></div>			
	</div>
	
	<div class="elementParams">
				<div class="paramTitle">  <?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_USER_USER_NAME') ?>  </div>
		<div class="paramValue"><?php echo XiHtml::link(XiRoute::_("index.php?option=com_payplans&view=user&task=edit&id=".$user->getId(), false), $user->getRealname());
				echo ' ('.$user->getUsername().')';
		?></div>
	</div>
	
	<div class="elementParams">
				<div class="paramTitle"> <?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_USER_USER_EMAIL') ?>  </div>
		<div class="paramValue"><?php echo $user->getEmail(); ?>					
	</div></div>
	
<div class="elementParams">
				<div class="paramTitle">  <?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_USER_USERTYPE') ?>  </div>
		<div class="paramValue"><?php echo $user->getUsertype(); ?>					
	</div></div>
	
<div class="elementParams">
				<div class="paramTitle">  <?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_USER_USER_REGISTERDATE') ?>  </div>
		<div class="paramValue"><?php echo XiDate::timeago($user->getRegisterDate()); ?></div>					
	</div>
	
<div class="elementParams">
				<div class="paramTitle"> <?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_USER_USER_LASTVISITDATE') ?>  </div>
		<div class="paramValue"><?php echo XiDate::timeago($user->getLastvisitDate()); ?></div>					
	</div>
<?php 
