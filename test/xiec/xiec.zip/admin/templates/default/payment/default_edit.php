<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<div id="payment">
<div class="xippElements">
<form action="<?php echo $uri; ?>" method="post" name="adminForm" id="adminForm">
	<div class="elementColumn">
		<fieldset class="adminform">
			<legend> <?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_DETAILS' ); ?> </legend>
			
			<div class="elementParams">
				<div class="paramTitle">  
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_TOOLTIP_PAYMENT_ID') ?>">
						<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_PAYMENT_ID') ?> 
					</span>
				</div>
				<div class="paramValue"><?php echo $payment->getId()." (".$payment->getkey().")"; ?>
				<input type="hidden" name="id" value="<?php echo $payment->getId(); ?>" /></div>
			</div>

			<div class="elementParams">
				<div class="paramTitle"> 
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_TOOLTIP_ORDER_ID') ?>">
						<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_ORDER_ID') ?> 
					</span>
				</div>
				<div class="paramValue"><?php echo $payment->getOrder()." (".$order->getkey().")"; ?>
				<input type="hidden" name="order_id" value="<?php echo $payment->getOrder(); ?>" /></div>				
			</div>

<!--		<div class="elementParams">
				<div class="paramTitle"> <?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_IS_REFUND') ?> </div>
				<div class="paramValue"><?php echo XiHtml::_('select.booleanlist',  'is_refund', '', $payment->getIsRefund());?></div>
			</div>-->

		<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_TOOLTIP_CREATION_DATE') ?>">
						<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_CREATION_DATE') ?> 
					</span>
				</div>
				<div class="paramValue"><?php echo $payment->getCreatedDate()->toMySql(); ?></div>
			</div>

		<div class="elementParams">
				<div class="paramTitle"> 
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_TOOLTIP_MODIFIED_DATE') ?>">
						<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_MODIFIED_DATE') ?> 
					</span>
				</div>
				<div class="paramValue"><?php echo $payment->getModifiedDate()->toMySql();?></div>
			</div>

		</fieldset>
		
		
				<fieldset class="adminform">
			<legend>
				<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_TRANSACTION' ); ?>
			</legend>

		<div class="elementParams">
				<div class="paramTitle"> 
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_TOOLTIP_PAYMENT_KEY') ?>">
						<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_PAYMENT_KEY') ?> 
					</span>
				</div>
				<div class="paramValue"><input name="payment_key"  class="readonly" type="text" size="32" value="<?php echo $payment->getKey(); ?>" /></div>

			</div>

		<div class="elementParams">
				<div class="paramTitle"> 
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_TOOLTIP_TYPE') ?>">
						<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_TYPE') ?> 
					</span>
				</div>
				<div class="paramValue"><?php echo XiHtml::_('elements.applist', 'app_id', $payment->getApp(),'payment', array('readonly' => true));?></div>
			</div>

		<div class="elementParams">
				<div class="paramTitle"> 
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_TOOLTIP_AMOUNT') ?>">
						<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_AMOUNT') ?> 
					</span>		
				</div>
				<div class="paramValue">
					<?php 
					echo XiHtml::_('elements.price', 'amount', 'amount_0', $payment->getAmount(), array('style' => 'class="number required"'));
					echo XiHtml::_('elements.currency','currency',$payment->getCurrency(),array('readonly'=>true))?>
				</div>
			</div>

		<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_TOOLTIP_STATUS') ?>">
						<?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_STATUS') ?>
					</span>
				</div>
				<div class="paramValue"><?php echo XiHtml::_('elements.status','status', $payment->getStatus(), 'PAYMENT')?></div>
			</div>
		</fieldset> 
		
		<!-- LOGS -->
			<?php echo $this->loadTemplate('edit_log'); ?>
		
	</div>

	<div class="elementColumn">



		<fieldset class="adminform">
			<legend>
				<?php echo XiText::_( 'COM_PAYPLANS_PAYMENT_EDIT_TRANSACTION_RECORD' ); ?>
			</legend>
			<?php // XITODO : Below mentioned record should be processed via payment app to show it. ?>
			<?php echo $transaction_html; ?>
		</fieldset>
		<!-- ORDER DETAILS START -->
		<div class="orderDetail">
			<fieldset class="adminform">
				<legend> <?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_ORDER' ); ?> </legend>
				<?php 
				if(!empty($user)) : 
					echo $this->loadTemplate('payment_order');
				else :
					echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_ORDER_NO_ORDER');
				endif;?>
			</fieldset>
		</div>
		<!-- ORDER DETAILS END -->
		
				<div class="userDetail">
			<fieldset class="adminform">
				<legend> <?php echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_USER_DETAILS' ); ?> </legend>
					<?php 
					if(!empty($user)) : 
						echo $this->loadTemplate('payment_user');
					else :
						echo XiText::_('COM_PAYPLANS_PAYMENT_EDIT_NO_USER');
					endif;?>
			</fieldset>
		</div>
		<!-- USER DETAILS END -->



	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	</div>
</form>
</div>
</div>
<?php 
