<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?><form action="<?php echo $uri; ?>" method="post" name="adminForm">
<div id="logs-edit" style="text-align: justify;">
<div id="logs-edit-update-head">
<div id="logs-edit-key-label">Status</div>
<div id="logs-edit-description-label">Description</div>
</div>
<div class="" id="logs-edit-update-body">
 	<div id="logs-edit-key-value">
 	<?php echo XiText::_('COM_PAYPLANS_STATUS_NONE');?>
 	</div>
 	<div id="logs-edit-description-label">
 	<?php echo XiText::_('COM_PAYPLANS_NONE_DESCRIPTION');?>
 	</div>
</div> 
 
<div class="" id="logs-edit-update-body">
	<div id="logs-edit-key-value">
 	<?php echo XiText::_('COM_PAYPLANS_STATUS_PAYMENT_INITIATED');?>
 	</div>
 	<div id="logs-edit-description-label">
 	<?php echo XiText::_('COM_PAYPLANS_PAYMENT_INITIATED_DESCRIPTION');?>
 	</div>
</div>

<div class="" id="logs-edit-update-body"> 
 	<div id="logs-edit-key-value">
  	<?php echo XiText::_('COM_PAYPLANS_STATUS_PAYMENT_COMPLETE');?>
 	</div>
 	<div id="logs-edit-description-label">
 	<?php echo XiText::_('COM_PAYPLANS_PAYMENT_COMPLETED_DESCRIPTION');?>
 	</div>
</div>

<div class="" id="logs-edit-update-body"> 
 	<div id="logs-edit-key-value">
 	<?php echo XiText::_('COM_PAYPLANS_STATUS_PAYMENT_HOLD');?>
 	</div>
 	<div id="logs-edit-description-label">
 	<?php echo XiText::_('COM_PAYPLANS_PAYMENT_HOLD_DESCRIPTION');?>
 	</div>
</div>

<div class="" id="logs-edit-update-body"> 
 	<div id="logs-edit-key-value">
 	<?php echo XiText::_('COM_PAYPLANS_STATUS_PAYMENT_PENDING');?>
 	</div>
 	<div id="logs-edit-description-label">
 	<?php echo XiText::_('COM_PAYPLANS_PAYMENT_PENDING_DESCRIPTION');?>
 	</div>
</div>

<div class="" id="logs-edit-update-body">
 	<div id="logs-edit-key-value">
 	<?php echo XiText::_('COM_PAYPLANS_STATUS_PAYMENT_RECURRING_START');?>
 	</div>
 	<div id="logs-edit-description-label">
 	<?php echo XiText::_('COM_PAYPLANS_PAYMENT_RECURRING_START_DESCRIPTION');?>
 	</div>
</div>

<div class="" id="logs-edit-update-body">
 	<div id="logs-edit-key-value">
 	<?php echo XiText::_('COM_PAYPLANS_STATUS_PAYMENT_RECURRING_SIGNUP');?>
 	</div>
 	<div id="logs-edit-description-label">
 	<?php echo XiText::_('COM_PAYPLANS_PAYMENT_RECURRING_SIGNUP_DESCRIPTION');?>
 	</div>
</div>

<div class="" id="logs-edit-update-body">
	 <div id="logs-edit-key-value">
	 <?php echo XiText::_('COM_PAYPLANS_STATUS_PAYMENT_RECURRING_CANCEL');?>
 	</div>
 	<div id="logs-edit-description-label">
 	<?php echo XiText::_('COM_PAYPLANS_PAYMENT_RECURRING_CANCEL_DESCRIPTION');?>
 	</div>
</div>

<div class="" id="logs-edit-update-body">
 	<div id="logs-edit-key-value">
 	<?php echo XiText::_('COM_PAYPLANS_STATUS_PAYMENT_RECURRING_EOT');?>
 	</div>
 	<div id="logs-edit-description-label">
 	<?php echo XiText::_('COM_PAYPLANS_PAYMENT_RECURRING_EOT_DESCRIPTION');?>
 	</div>
</div>

<div class="" id="logs-edit-update-body">
	 <div id="logs-edit-key-value">
 	<?php echo XiText::_('COM_PAYPLANS_STATUS_PAYMENT_RECURRING_FAILED');?>
 	</div>
 	<div id="logs-edit-description-label">
 	<?php echo XiText::_('COM_PAYPLANS_PAYMENT_RECURRING_FAILED_DESCRIPTION');?>
 	</div>
</div> 
 </div>
</form>