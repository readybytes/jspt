<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<div id="payplanedit">
<form action="<?php echo $uri; ?>" method="post" name="adminForm" id="adminForm">
	<div class="elementColumn">
		<fieldset class="adminform">
			<legend> <?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_PLAN_DETAILS' ); ?> </legend>
			<div id="planeditheader">
				<div class="elementParams">
					<div class="paramTitle" > 
						<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_PLAN_TITLE'); ?>::<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_PLAN_TITLE_DESC'); ?>">
						<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_PLAN_TITLE'); ?>
						</span>
					</div>
					<div class="paramValue">
						<input class="required" name="title"  type="text" value="<?php echo $plan->getTitle(); ?>" />
						<span class="required">*</span>
					</div>
				</div>
				
				<div class="elementParams">
					<div class="paramTitle">
						<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_PUBLISHED'); ?>::<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_PUBLISHED_DESC'); ?>">
							<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_PUBLISHED') ?>
						</span>
					</div>
					<div class="paramValue"><?php echo XiHtml::_('select.booleanlist',  'published', '', $plan->getPublished());?></div>
				</div>
				<div class="elementParams">
					<div class="paramTitle" >
						<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_VISIBLE'); ?>::<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_VISIBLE_DESC'); ?>">				
							<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_VISIBLE') ?>
						</span>
					</div>
					<div class="paramValue"><?php echo XiHtml::_('select.booleanlist',  'visible', '', $plan->getVisible());?></div>
				</div>
				
				<!-- PLAN PARAMS -->
				<?php echo $plan->getParamsHtml('params','params'); ?>
			</div>
			<div id="planeditdesc">
				<div id="desctitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_DESCRIPTION') ?>">
						<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_DESCRIPTION') ?>
					</span>
				</div>
				<div>
				<?php
				echo $editor->display( 'description',  htmlspecialchars($plan->getDescription(), ENT_QUOTES),
								'600', '300', '60', '20', array('pagebreak', 'readmore') ) ;
				?>
				</div>
			</div>
		</fieldset>
	</div>
	<div class="elementColumn">
		<fieldset class="adminform">
			<legend>
				<?php echo XiText::_( 'COM_PAYPLANS_PLAN_EDIT_TIME_PARAMETERS' ); ?>
			</legend>
			<?php echo $plan->getParamsHtml('payment','payment'); ?>
			<?php echo $plan->getParamsHtml('time','time'); ?>
		</fieldset>

<?php //XITODO : move to tmpl ?>

		<fieldset class="adminform">
			<legend>
				<?php echo XiText::_( 'COM_PAYPLANS_PLAN_EDIT_ASSOCIATION' ); ?>
			</legend>
			<div class="elementParams">
			<div class="paramTitle hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_APPS_TITLE'); ?>::<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_APPS_TITLE_DESC'); ?>" >
			<?php echo XiText::_( 'COM_PAYPLANS_PLAN_EDIT_APPS_TITLE' ); ?>
			</div>
			<div class="paramValue">
			<?php $apps = $plan->getPlanapps();?>
			<?php 	echo XiHtml::_('elements.applist', 'planapps', $apps, '', array('multiple'=>true)); ?> 
			</div></div>
		<!-- display all core apps if exists -->
		<?php if(!empty($core_apps)):?>
		<div class="elementParams">
			<div class="paramTitle hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_CORE_APPS_TITLE'); ?>" >
			<?php echo XiText::_( 'COM_PAYPLANS_PLAN_EDIT_CORE_APPS_TITLE' ); ?>
			</div>
			<div class="paramValue">
				<div class="core-app-param-value-wrapper">
					<?php foreach($core_apps as $coreApp):?>
						<!-- XITODO Apply css -->
						<div class="core-app-param-value"><?php echo $coreApp;?></div>
					<?php endforeach;?>
				</div>
			</div>
		</div>
		<?php endif;?>
		
		<div class="elementParams">
			<div class="paramTitle">
				<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_GROUPS_TITLE_DESC'); ?>" >
					<?php echo XiText::_( 'COM_PAYPLANS_PLAN_EDIT_GROUPS_TITLE' ); ?>
				</span>
			</div>
			<div class="paramValue">
				<?php $groups = $plan->getGroups();?>
				<?php 	echo XiHtml::_('elements.groups', 'groups', $groups, array('multiple'=>true)); ?> 
			</div>
		</div>		
		</fieldset>
	
      <!-- PARENT CHILD PLUGIN RESULT -->
	  <?php $modules = $this->_renderModules('payplans-admin-plan-edit-parentchild'); ?>
	  <?php foreach($modules as $html):?>
			<?php echo $html; ?>		
 	  <?php endforeach;?>
		
		<!-- LOGS -->
		<?php echo $this->loadTemplate('edit_log'); ?>
	</div>

	<input type="hidden" name="task" value="" />
	<input type="hidden" name="id" value="<?php echo $plan->getId(); ?>" />
</form>
</div>
<?php



