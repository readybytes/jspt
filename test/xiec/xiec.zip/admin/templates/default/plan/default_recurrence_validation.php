<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?>
<div id="recurrence-validation">
			<div id="recurrence-validation-head">
				<div id="app-name-label">
					<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_RECURRENCE_APP_NAME');?>
				</div>
				<div id="unit-label">
					<?php echo XiText::_('COM_PAYPLANS_PLAN_EDIT_RECURRENCE_UNIT');?>
				</div>
				<div id="period-label">
					<?php echo XiText::_('COM_PAYPLANS_PLANS_EDIT_RECURRENCE_PERIOD');?>
				</div>
				<div id="frequency-label">
					<?php echo XiText::_('COM_PAYPLANS_PLANS_EDIT_RECURRENCE_COUNT');?>
				</div>
			</div>
		<?php foreach($time as $app => $recurringTime) : ?>
			<div id="recurrence-validation-body">
				<div id="app-name-value">
					<?php echo $appnames[$app]."\t"; ?>
				</div>
				<div id="unit-value">
					<?php 	echo $recurringTime['period']."\t"; ?>
				</div>
				<div id="period-value">
					<?php echo $recurringTime['unit']."\t";	?> 
				</div>
				<div id="frequency-value">
					<?php echo $recurringTime['frequency']."\t";	?> 
				</div>
			</div>
		<?php endforeach;?>
</div>
<div>
	<?php echo XiText::_('COM_PAYPLANS_PLANS_EDIT_RECURRENCE_COUNT_MSG');?>
</div>
<?php 
