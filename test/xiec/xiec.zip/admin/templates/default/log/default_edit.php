<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?><form action="<?php echo $uri; ?>" method="post" name="adminForm">
<div id="logs-edit">

<?php if(is_array($data)):?>
		<?php $diff = "No";?>
		<?php $previous = $data['previous'];?>
		<?php $current  = $data['current'];?>
		
			<div id="logs-edit-update-head">
				<div id="logs-edit-key-label">
					<?php echo XiText::_('COM_PAYPLANS_LOG_KEY_LABEL');?>
				</div>
				<div id="logs-edit-previous-label">
					<?php echo XiText::_('COM_PAYPLANS_LOG_PREVIOUS_LABEL');?>
				</div>
				<div id="logs-edit-current-label">
					<?php echo XiText::_('COM_PAYPLANS_LOG_CURRENT_LABEL');?>
				</div>
			</div>
			<!-- UPDATE -->
			<?php if(!empty($previous) && !empty($current)):?>
					<?php foreach($current as $key => $val):?>
						<?php $diff = "No";?>
					
						<?php if($current[$key] != $previous[$key]):?>	
							<?php $diff = "Yes";?>
						<?php endif;?>
						<div id="logs-edit-update-body" class="<?php echo $diff=="Yes"?"logs-edit-updated-values":""; ?>">
						<div id="logs-edit-key-value">
						<?php echo $key;?>
						</div>
						<?php if(is_array($previous[$key]) && !empty($previous[$key])):?>
						<div id="logs-edit-previous-value">
							<?php foreach($previous[$key] as $value):?>
									<?php echo $value."\n"; ?>
							 <?php endforeach;?>
						</div>
						<?php else :?>
							<div id="logs-edit-previous-value">
							<?php echo $key=='status' ? XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($previous[$key])):$previous[$key];?>
							</div>
						<?php endif;?>
						<?php if(is_array($current[$key]) && !empty($current[$key])):?>
						<div id="logs-edit-current-value">
							<?php foreach($current[$key] as $val):?>
									<?php echo $val."\n";?>
							 <?php endforeach;?>
						</div>
						<?php else :?>
						<div id="logs-edit-current-value">	
							<?php echo $key=='status' ? XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($current[$key])):$current[$key];?>
						</div>
						<?php endif;?>
						</div>
					<?php endforeach;?>
			

			<?php else:?>
				<!-- DELETE -->
					<?php if(!empty($previous)):?>
						<?php foreach($previous as $key => $val):?> 
							<div id="logs-edit-update-body" class="<?php echo $diff=="Yes"?"logs-edit-updated-values":""; ?>">
							<div id="logs-edit-key-value">
							<?php echo $key;?>
							</div>
							<div id="logs-edit-previous-value">
							<?php echo $key=='status' ? XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($previous[$key])):$previous[$key];?>
							</div>
							<div id="logs-edit-current-value">
							<?php echo "&nbsp;";?>
							</div>
							</div>						
							<?php //echo $key."  ".$previous[$key]."<br />";?> 
						<?php endforeach;?>
					<?php endif;?>
			
					<!-- CREATE -->
					<?php if(!empty($current)):?>
						<?php foreach($current as $key => $val):?> 
							<div id="logs-edit-update-body" class="<?php echo $diff=="Yes"?"logs-edit-updated-values":""; ?>">
								<div id="logs-edit-key-value">
								<?php echo $key;?>
								</div>
								<div id="logs-edit-previous-value">
								<?php echo "&nbsp;";?>
								</div>
								<div id="logs-edit-current-value">
								<?php echo $key === 'status' ? XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($current[$key])): $current[$key];?>
								</div>
							</div>
								<?php //echo $key." = ".$current[$key];?>

						<?php endforeach;?>
					<?php endif;?>
			<?php endif;?>
<?php else:?>
	<?php echo $data;?>
<?php endif;?>
	<input type="hidden" name="task" value="close" />
</div>
</form><?php
