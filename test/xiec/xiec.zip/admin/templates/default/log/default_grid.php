<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Log
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>

<form action="<?php echo $uri; ?>" method="post" id="adminForm" name="adminForm">
	
	<?php echo $this->loadTemplate('filter'); ?>
	<table id="payplans_grid" class="payplans_grid adminlist plan-grid">
		
		<thead>
		<!-- TABLE HEADER START -->
			<tr>
				<th class="default-grid-sno">
			    <?php echo XiHtml::_('grid.sort', "NUM", 'log_id', $filter_order_Dir, $filter_order);?>
			    </th>			
			    <th class="default-grid-chkbox">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($records); ?>);" />
				</th>
				<th><?php echo XiHtml::_('grid.sort', "COM_PAYPLANS_LOG_GRID_MESSAGE", 'message', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "COM_PAYPLANS_LOG_GRID_CLASS", 'class', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "COM_PAYPLANS_LOG_GRID_USER_ID", 'user_id', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "COM_PAYPLANS_LOG_GRID_LEVEL", 'level', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "COM_PAYPLANS_LOG_GRID_OBJECT_ID", 'object_id', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "COM_PAYPLANS_LOG_GRID_USER_IP", 'user_ip', $filter_order_Dir, $filter_order);?></th>
				<th><?php echo XiHtml::_('grid.sort', "COM_PAYPLANS_LOG_GRID_CREATED_DATE", 'created_date', $filter_order_Dir, $filter_order);?></th>
				
			</tr>
		<!-- TABLE HEADER END -->
		</thead>
		
		<tbody>
		<!-- TABLE BODY START -->
			<?php $count= $limitstart;
			$cbCount = 0;
			foreach ($records as $record):?>
				<tr class="<?php echo "row".$count%2; ?>">
					<td> <?php echo $count+1; ?> </td>
					<th class="default-grid-chkbox">
		    			<?php echo XiHtml::_('grid.id', $cbCount++, $record->{$record_key} ); ?>
		    		</th>
					<td><?php echo $record->message;?>
						<a  href="" 
							onclick="xi.url.openInModal('<?php echo 'index.php?option=com_payplans&view=log&task=edit&tmpl=component&record='.$record->{$record_key};?>'); return false;" class="logs-grid-detail"> 
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		    			<?php //echo XiText::_('COM_PAYPLANS_LOG_DETAIL_LINK');?>
						</a>					
					</td>
					<td><?php echo $record->class ;?></td>
					<td><!-- in case there is no user id present then display SYSTEM in modifier -->
						<?php if($record->user_id != 0):?>
								<?php echo  $record->user_id.' ('.PayplansHelperUser::getName($record->user_id).')';?>
				    	<?php else :?>
				    			<?php echo XiText::_('COM_PAYPLANS_LOGGER_MODIFIER_SYSTEM');?>
				    	<?php endif;?>
				    </td>
					<td><?php echo  XiHtml::_('grid.loglevel', '', $record->level);;?></td>
					<td><?php echo $record->object_id ;?></td>
					<td><?php echo $record->user_ip ;?></td>
					<td><?php echo XiDate::timeago($record->created_date); ?></td>
				</tr>
			<?php $count++;?>
			<?php endforeach;?>
		<!-- TABLE BODY END -->
		</tbody>
		
		<tfoot>
			<tr>
				<td colspan="9">
					<?php echo $pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
	</table>

	<input type="hidden" name="filter_order" value="<?php echo $filter_order;?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $filter_order_Dir;?>" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
</form>
<?php 