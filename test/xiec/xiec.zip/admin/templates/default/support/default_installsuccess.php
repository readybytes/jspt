<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Installer
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?>

<div class="pay">

<div class="msg">

<div class="pplogo"></div>
<div class="installnote">
<h3>PayPlans : Subscription / Membership System for Joomla!</h3>
<p>Team JoomlaXi wanted to take a moment to thank you for trying PayPlans.
We greatly apperciate your business and the opportunity to assist you. </p>

<!--<p> You satisfaction is the greatest recognition we could have, so we ask-->
<!--you to inform us if there is ever anything we can do to improve our service;-->
<!--we will do everything in our power to satisfy you.</p>-->
<p>Sincerely</p>
<p>Team JoomlaXi<br />
Ready Bytes Software Labs Pvt. Ltd.
</p>
</div>
<div class="whtNext">
<h4>Share your experience ?</h4>
	<div class="joomla-logo"><a href="http://extensions.joomla.org/extensions/e-commerce/membership-a-subscriptions/16566">Post review at JED</a></div>
</div>

<div class="whtNext">
<h4>Share your love ?</h4>
	<iframe src="http://www.facebook.com/plugins/like.php?href=http://www.facebook.com/payplans"
        scrolling="no" frameborder="0" style="height: 35px; margin-left: 120px;"></iframe> 
</div>

<div class="dive-in">
	<a href="index.php?option=com_payplans">Dive-in to PayPlans</a> 
</div>
</div>

<div class="intro-video">
<iframe class="intro-video-iframe" src="http://www.youtube.com/embed/1vleH2Ry3XQ" frameborder="0" allowfullscreen></iframe>
</div>

</div>
<?php
