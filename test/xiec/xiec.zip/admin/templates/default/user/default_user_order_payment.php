<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>

	<?php $count = 0;?>
	<?php $payment_records = $order->getPayment();?>
			<?php if(!empty($payment_records)):?>
			<h4 class="user-order-payment-title" ><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER_PAYMENT_TITLE');?></h4>
			<table id="payplans_grid" class="payplans_grid adminlist user-payment-grid">
				<tr>
					<th><?php echo "#";?></th>			
					<th><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER_PAYMENT_PAYMENT_AMOUNT');?></th>
					<th><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER_PAYMENT_PAYMENT_CURRENCY');?></th>
					<th><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER_PAYMENT_PAYMENT_TYPE');?></th>
					<th><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER_PAYMENT_PAYMENT_STATUS');?></th>
					<th><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER_PAYMENT_PAYMENT_CREATED_DATE');?></th>
				</tr>
				<?php foreach($payment_records as $record):?>
				<tr class="<?php echo "row".$count%2; ?>">
						<td><?php echo XiHtml::link(XiRoute::_("index.php?option=com_payplans&view=payment&task=edit&id=".$record->getId(), false), $record->getId()); ?></td>
						<td><?php echo $record->getAmount();?></td>
						<td><?php echo $record->getCurrency();?></td>
						<td><?php echo $record->getAppName();?></td>
						<td><?php echo $record->getStatusName('_SMALL');?></td>
						<td><?php echo XiDate::timeago($record->getCreatedDate()->toMysql());?></td>
					</tr>	
			<?php endforeach;?>
			</table>
			<?php endif;?>