<?php 
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<div class="filter">
	<div class="filterLabel"><?php echo XiText::_('COM_PAYPLANS_FILTERS_FILTER_TEXT');?>   </div>
		<div class="filterColOne">
			<span class="filterInputBox"><?php echo XiHTML::_('filters.text', 'username', 'user', $filters);?></span>
			<span class="filterButtons">
				<input type="submit" name="filter_submit" value="<?php echo XiText::_('COM_PAYPLANS_FILTERS_GO');?>" />
				<input type="reset" name="filter_reset" value="<?php echo XiText::_('COM_PAYPLANS_FILTERS_RESET');?>" onclick="payplansAdmin.resetFilters(this.form);" />
			</span>
		</div>
		
		<div class="filterColTwo">
			<div class="apps">
				<?php echo XiHTML::_('filters.jusertype', 'usertype', 'user', $filters);?>
			</div>	
		</div>
	</div>
<?php 