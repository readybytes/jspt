<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>

<?php echo $this->pane->startPane( 'start-pane' );?>
		<?php $count = 0;?> 
		<?php foreach($order_records as $record) : 
				$order->bind($record);?>
				<?php $heading = "#".$order->getId()." <div class='user-order-status'>Status ( ".XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($order->getStatus()).'_SMALL')." )</div>";?>
			<!-- PANEL START -->
			<?php echo $this->pane->startPanel($heading, $order->getStatusName('_SMALL'));?>
			<!-- ORDER TABLE START -->
				<table id="payplans_grid" class="payplans_grid adminlist user-order-grid">
					<tr>
						<th><?php echo XiText::_("COM_PAYPLANS_USER_EDIT_ORDER_ORDER_ID")." #";?></th>
						<th><?php echo XiText::_("COM_PAYPLANS_USER_EDIT_ORDER_SUBTOTAL");?></th>
						<th><?php echo XiText::_("COM_PAYPLANS_USER_EDIT_ORDER_DISCOUNT");?></th>
						<th><?php echo XiText::_("COM_PAYPLANS_USER_EDIT_ORDER_TAX");?></th> 	
						<th><?php echo XiText::_("COM_PAYPLANS_USER_EDIT_ORDER_TOTAL");?></th>
						<th><?php echo XiText::_("COM_PAYPLANS_USER_EDIT_ORDER_CURRENCY");?></th>
				    </tr>
					<tr class="<?php echo "row".$count%2; ?>">
						<td><?php echo XiHtml::link(XiRoute::_("index.php?option=com_payplans&view=order&task=edit&id=".$order->getId(), false), $order->getId());?></td>
						<td><?php echo $order->getSubtotal();?></td>
						<td><?php echo $order->getDiscount();?></td>
						<td><?php echo $order->getTaxAmount();?></td>
						<td><?php echo $order->getTotal();?></td>
						<td><?php echo $order->getCurrency();?></td>
					</tr>		
				</table>
				<!-- ORDER TABLE END -->
				<!-- LOADING SUBSCRIPTION TABLE  -->
				<?php echo $this->loadTemplate('user_order_subscription');?>
				
				<!-- LOADING PAYMENT TABLE -->
				<?php echo $this->loadTemplate('user_order_payment');?>
			<?php $count++;?>
			<?php echo $this->pane->endPanel();?>
			<!-- PANEL END -->
			<?php endforeach;?>	
		<?php echo $this->pane->endPane( 'start-pane' );