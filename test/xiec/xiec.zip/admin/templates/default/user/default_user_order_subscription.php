<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>

	<?php $count = 0;?>			
			<?php foreach($subscr_records as $subscr_record):
					 $subscription->bind($subscr_record);?>
				<?php if($subscription->getOrder()==$order->getId()):?>
					<?php if($count==0):?>
				<h4 class="user-order-subscription-title"><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER_SUBSCRIPTION_TITLE');?></h4>
				<table id="payplans_grid" class="payplans_grid adminlist user-subscription-grid">
					<tr>
						<th><?php echo "#";?></th>
						<th><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER_SUBSCRIPTION_SUBSCRIPTION_PLAN');?></th>
						<th><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER_SUBSCRIPTION_SUBSCRIPTION_STATUS');?></th>
						<th><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER_SUBSCRIPTION_SUBSCRIPTION_DATE');?></th>
						<th><?php echo XiText::_('COM_PAYPLANS_USER_EDIT_ORDER_SUBSCRIPTION_SUBSCRIPTION_EXPIRATION_DATE');?></th>
					</tr>
					<?php endif;?>
					<tr class="<?php echo "row".$count%2; ?>">
						<td><?php echo XiHtml::link(XiRoute::_("index.php?option=com_payplans&view=subscription&task=edit&id=".$subscription->getId(), false), $subscription->getId());?></td>
						<td><?php echo PayplansHelperPlan::getName(current($subscription->getPlans()));?></td>
						<td><?php echo XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($subscription->getStatus()).'_SMALL');?></td>
						<td><?php echo XiDate::timeago($subscription->getSubscriptionDate()->toMysql());?></td>	
						<td><?php echo XiDate::timeago($subscription->getExpirationDate()->toMysql());?></td>
					</tr>
					<?php $count++;?>
				<?php endif;?>
			<?php endforeach;?>
			</table>