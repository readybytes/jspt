<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<div id="apps">
<div class="xippElements">
<form action="<?php echo $uri; ?>" method="post" name="adminForm" id="adminForm">

	<div class="elementColumn">
		<fieldset class="adminform">
			<legend> <?php echo XiText::_('COM_PAYPLANS_GROUP_EDIT_GROUP_DETAILS' ); ?> </legend>
			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_GROUP_EDIT_TOOLTIP_GROUP_TITLE') ?>">
						<?php echo XiText::_('COM_PAYPLANS_GROUP_EDIT_GROUP_TITLE') ?> 
					</span>
				 </div>
				<div class="paramValue"><input name="title"  class="required" type="text" size="40" value="<?php echo $group->getTitle(); ?>" /><span class="required">*</span></div>
			</div>

			<div>
				<input type="hidden" name="id" value="<?php echo $group->getId(); ?>" />
			</div>

			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_GROUP_EDIT_PARENT_DESC'); ?>" >
						<?php echo XiText::_( 'COM_PAYPLANS_GROUP_EDIT_PARENT' ); ?>
					</span>
				</div>
				<div class="paramValue">
					<?php 	echo XiHtml::_('elements.groups', 'parent', $group->getParent(), array('none' => 'COM_PAYPLANS_GROUP_SELECT_PARENT', 'unset' => array($group->getId()))); ?> 
				</div>
			</div>		
			
			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_GROUP_EDIT_TOOLTIP_GROUP_VISIBLE') ?>">
						<?php echo XiText::_('COM_PAYPLANS_GROUP_EDIT_GROUP_VISIBLE') ?>  
					</span>
				</div>
				<div class="paramValue"><?php echo XiHtml::_('select.booleanlist',  'visible', '', $group->getVisible());?></div>
			</div>

			<div class="elementParams">
				<div class="paramTitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_GROUP_EDIT_TOOLTIP_GROUP_PUBLISHED') ?>">
						<?php echo XiText::_('COM_PAYPLANS_GROUP_EDIT_GROUP_PUBLISHED') ?>  
					</span>
				</div>
				<div class="paramValue"><?php echo XiHtml::_('select.booleanlist',  'published', '', $group->getPublished());?></div>
			</div>
			
			<div id="planeditdesc">
				<div id="desctitle">
					<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_GROUP_EDIT_TOOLTIP_GROUP_DESCRIPTION') ?>">
						<?php echo XiText::_('COM_PAYPLANS_GROUP_EDIT_GROUP_DESCRIPTION') ?>
					</span>
				</div>
				<div>
				<?php
				echo $editor->display( 'description',  htmlspecialchars($group->getDescription(), ENT_QUOTES),
								'600', '300', '60', '20', array('pagebreak', 'readmore') ) ;
				?>
				</div>
			</div>
		</fieldset>
	</div>
	
	<div class="elementColumn">
		<fieldset class="adminform">
			<legend>
				<?php echo XiText::_( 'COM_PAYPLANS_GROUP_EDIT_GROUP_CHILD_PLANS' ); ?>
			</legend>
			<div class="elementParams">
				<div class="paramTitle">
				<span class="hasTip" title="<?php echo XiText::_('COM_PAYPLANS_GROUP_EDIT_GROUP_PLAN_TITLE_DESCRIPTION'); ?>" >
					<?php echo XiText::_( 'COM_PAYPLANS_GROUP_EDIT_GROUP_PLAN_TITLE' ); ?>
				</span>
				</div>
				<div class="paramValue">
					<?php $plans = $group->getPlans();
					echo XiHtml::_('elements.plans', 'plans', $plans, array('multiple'=>true));?>
				</div>
			</div>
		</fieldset>
	
		<fieldset class="adminform">
			<legend>
				<?php echo XiText::_( 'COM_PAYPLANS_GROUP_EDIT_GROUP_PARAMETERS' ); ?>
			</legend>
			<?php echo $group->getParamsHtml('params','params'); ?>
		</fieldset>
		
		<!-- Logs -->
		<?php echo $this->loadTemplate('edit_log');?>
	</div>

	<input type="hidden" name="task" value="save" />
</form>
</div>
</div>
<?php
