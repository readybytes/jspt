<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();?>
<?php echo $this->tabs->startPanel(XiText::_('COM_PAYPLANS_CONFIG_SETTINGS'),'settings'); ?>
	<div id="settings">
		<div id="advanceConfig">
			<div id="advanceSettings" class="medium" onClick="payplansAdmin.showAdvanceSettings()">
				<?php echo XiText::_('COM_PAYPLANS_CONFIG_SETTING_SHOW_ADVANCE_SETTINGS');?>
			</div>
			<div id="expertSetting" class="medium" onClick="payplansAdmin.showExpertSettings()">
				<?php echo XiText::_('COM_PAYPLANS_CONFIG_SETTING_SHOW_EXPERT_SETTINGS');?>
			</div>	
		</div>
		
		
		<div class="payplans_basic">
		<fieldset class="adminform">
			<legend> <?php echo XiText::_('COM_PAYPLANS_CONFIGURATION_SETTING_'.JString::strtoupper($config_obj['payplans_basic']->getTitle())); ?> </legend>
			<div>
				<?php $param = $configs['registrationType']; ?>
				<?php include 'default_renderparam.php'; ?>
			</div>			
		</fieldset>
		
		<fieldset class="adminform">
				<legend> <?php echo XiText::_('COM_PAYPLANS_CONFIG_CUSTOMIZATION_FEATURES');?> </legend>
				<div>							
					<?php $param = $configs['accessLoginBlock']; ?>
					<?php include 'default_renderparam.php'; ?>
					
					<?php $param = $configs['useGroupsForPlan']; ?>
					<?php include 'default_renderparam.php'; ?>					
				</div>
			</fieldset>
		</div>
	
		<div class="<?php echo $config_obj['payplans_advance']->getKey(); ?>">
			<fieldset class="adminform">
				<legend> <?php echo $config_obj['payplans_advance']->getTitle(); ?> </legend>
				<div>			
					<?php $param = $configs['https']; ?>
					<?php include 'default_renderparam.php'; ?>
					
					<?php $param = $configs['autoCompleteOrder']; ?>
					<?php include 'default_renderparam.php'; ?>
					
					<?php $param = $configs['expert_wait_for_payment']; ?>
					<?php include 'default_renderparam.php'; ?>
					
					<?php $param = $configs['blockLogging']; ?>
					<?php include 'default_renderparam.php'; ?>
					
					<?php $param = $configs['displayExistingSubscribedPlans']; ?>
					<?php include 'default_renderparam.php'; ?>
				</div>
			</fieldset>
		</div>
	
		<div class="<?php echo $config_obj['payplans_expert']->getKey(); ?>">
			<fieldset class="adminform">
			<legend> <?php echo $config_obj['payplans_expert']->getTitle(); ?> </legend>
				<div>
					<?php $param = $configs['cronFrequency']; ?>
					<?php include 'default_renderparam.php'; ?>
					
					<?php $param = $configs['cronSecret']; ?>
					<?php include 'default_renderparam.php'; ?>
					
					<?php $param = $configs['expert_encryption_key']; ?>
					<?php include 'default_renderparam.php'; ?>
					
					<?php $param = $configs['expert_useminjs']; ?>
					<?php include 'default_renderparam.php'; ?>
										
					<?php $param = $configs['cronAcessTime']; ?>
					<?php include 'default_renderparam.php'; ?>
					
					<?php $param = $configs['expert_run_automatic_cron']; ?>
					<?php include 'default_renderparam.php'; ?>
				</div>
			</fieldset>
	   </div>
</div>

<?php 
echo $this->tabs->endPanel();