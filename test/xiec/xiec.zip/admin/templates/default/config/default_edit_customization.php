<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();?>

<?php echo $this->tabs->startPanel(XiText::_('COM_PAYPLANS_CONFIG_CUSTOMIZATION'),'customization'); ?>
<div class="payplans-customization">
<div class="<?php echo $config_obj['payplans_invoice']->getkey(); ?>">
	<fieldset class="adminform">
		<legend> <?php echo XiText::_('COM_PAYPLANS_CONFIG_CUSTOMIZATION_'.JString::strtoupper($config_obj['payplans_invoice']->gettitle()));?> </legend>
		<div>
			<?php $param = $configs['companyName']; ?>
			<?php include 'default_renderparam.php'; ?>
			
			<?php $param = $configs['companyAddress']; ?>
			<?php include 'default_renderparam.php'; ?>	
			
			
			<?php $param = $configs['companyCityCountry']; ?>
			<?php include 'default_renderparam.php'; ?>	
			
			<?php $param = $configs['companyPhone']; ?>
			<?php include 'default_renderparam.php'; ?>	
			
			<?php $param = $configs['companyLogo']; ?>
			<?php include 'default_renderparam.php'; ?>			
			<a id="show-logo-image" href="#" style="float: left;" onclick='xi.jQuery( "#logo-image-show" ).slideToggle(); return false;'>View Here</a>
			<div id="logo-image-show" title="Company logo image" style="display: none;">
				<p><img src='<?php echo JURI::root().$param[4]; ?>' /></p>
			</div>
					
		</div>
	</fieldset>
</div>

<div class="payplans_template">
	<fieldset class="adminform">
		<legend><?php echo XiText::_('COM_PAYPLANS_CONFIG_CUSTOMIZATION_TEMPLATE'); ?></legend>
		<div>
			<div>
				<?php $param = $configs['theme']; ?>
				<?php include 'default_renderparam.php'; ?>
			</div>
			
			<div>
				<?php $param = $configs['layout']; ?>
				<?php include 'default_renderparam.php'; ?>
			</div>
			
			<div>
				<?php $param = $configs['row_plan_counter']; ?>
				<?php include 'default_renderparam.php'; ?>
			</div>		
		</div>
	</fieldset>
</div>
</div>
<?php 
echo $this->tabs->endPanel();
