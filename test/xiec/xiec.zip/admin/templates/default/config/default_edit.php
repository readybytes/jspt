<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<?php jimport('joomla.html.pane'); ?>
<form action="<?php echo $uri; ?>" method="post" name="adminForm" id="adminForm">
<?php $this->tabs = JPane::getInstance('tabs', array('startOffset'=>0)); ?>

<?php echo $this->tabs->startPane('config-tabs');	?>
	<?php echo $this->loadTemplate('edit_settings'); ?>
	<?php echo $this->loadTemplate('edit_customization'); ?>
	<?php echo $this->loadTemplate('edit_localization'); ?>
	<?php echo $this->loadTemplate('edit_log'); ?>
<?php echo $this->tabs->endPane(); ?>

	<?php foreach($config_obj as $key => $obj) : ?>
		<input type="hidden" name="<?php echo $key.'[path]';?>" value="<?php echo $obj->getPath();?>" />
	<?php endforeach;?>

	<input type="hidden" name="task" value="save" />
</form>
<?php
