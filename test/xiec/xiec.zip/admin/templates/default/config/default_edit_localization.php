<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();?>

<?php echo $this->tabs->startPanel(XiText::_('COM_PAYPLANS_CONFIG_LOCALIZATION'),'localization'); ?>

<?php $param = $configs['currency']; ?>
<?php include 'default_renderparam.php'; ?>

<?php $param = $configs['show_currency_as']; ?>
<?php include 'default_renderparam.php'; ?>

<?php $param = $configs['fractionDigitCount']; ?>
<?php include 'default_renderparam.php'; ?>	

<?php echo $this->tabs->endPanel();?>