<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();
?>
<div>
	<?php 
	echo XiText::_('COM_PAYPLANS_ORDER_TERMINATE_CONFIRM_WINDOW_MSG');
	?>
</div>
<?php 
