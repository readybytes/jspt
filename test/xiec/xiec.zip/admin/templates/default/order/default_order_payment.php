<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?>
<div class="paymentdetails">
<fieldset class="adminform">
	<legend> <?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_PAYMENT' ); ?> </legend>

	<div>
		<?php if($order->getId()) :?>
			<div class="order-edit-add-payment">
			<?php echo XiHtml::link(JURI::base().'index.php?option=com_payplans&view=payment&task=new&order_id='.$order->getId(),
									XiText::_('COM_PAYPLANS_ORDER_EDIT_PAYMENT_ADD_PAYMENT'),'class="button white medium"');?>
			</div>
		<?php else:?>
			<div class="info-msg">
			<?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_PAYMENT_NEW_PAYMENT_CAN_BE_ADDED_AFTER_SAVE');?>
			</div>
		<?php endif; ?>
		</div>

		<div class="order-edit-display-payment">
		<?php if(is_array($payment_records) && !empty($payment_records)) : ?>
			<?php echo $this->loadTemplate('order_payment_table');?>
		<?php else : ?>
			<div class="admin-edit-small-blank">
			<h3><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_PAYMENT_NO_PAYMENT');?></h3>
			<p><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_PAYMENT_NO_PAYMENT_DESC');?></p>
			</div>
		<?php endif;?>
	</div>
</fieldset>
</div>