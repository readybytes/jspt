<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?>
<table id="payplans_grid" class="payplans_grid adminlist order-payment-table">
	<thead>
	<!-- TABLE HEADER START -->
		<tr>
			<th><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_PAYMENT_GRID_PAYMENT_ID');?></th>
			<th><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_PAYMENT_GRID_PAYMENT_KEY');?></th>
			<th><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_PAYMENT_GRID_TYPE');?></th>
			<th><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_PAYMENT_GRID_AMOUNT');?></th>
			<th><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_PAYMENT_GRID_STATUS');?></th>
		</tr>
	<!-- TABLE HEADER END -->
	</thead>

	<tbody>
	<!-- TABLE BODY START -->
		<?php $count = 0;?>
		<?php ksort($payment_records);?>
		<?php foreach($payment_records as $record) :
			$payment->bind($record);?>
			<tr class="<?php echo "row".$count%2; ?>">
				<td><?php echo XiHtml::link(XiRoute::_("index.php?option=com_payplans&view=payment&task=edit&id=".$payment->getId(), false), $payment->getId());?></td>
				<td><?php echo $payment->getKey();?></td>
				<td><?php echo XiHtml::_('grid.app',$payment->getApp()); ?></td>
				<td><?php echo $payment->getAmount();?></td>
				<td><?php echo XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($payment->getStatus()));?></td>
			</tr>
		<?php $count++;?>
		<?php endforeach;?>
	<!-- TABLE BODY END -->
	</tbody>

	<tfoot>
		<tr>
			<td colspan="7">

			</td>
		</tr>
	</tfoot>
</table>
<?php
