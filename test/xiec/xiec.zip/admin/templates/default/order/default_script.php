<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();?>
<script type="text/javascript">
xi.jQuery(document).ready(function(){
	xi.jQuery("span#planSelecter").css("display", "none");
	xi.jQuery("span.payplansubstext").click(function(){
		var parentDiv = xi.jQuery(this).parent("div.actionWrapper");
		xi.jQuery("span#planSelecter").appendTo(parentDiv);
		xi.jQuery("span#planSelecter").css("display", "block");
	});
	
	xi.jQuery("span#planSelecter").children('select').change(function(){
		var planid = xi.jQuery(this).val();
		var orderid = xi.jQuery(this).parent().parent("div.actionWrapper").children("span.payplansubstext").attr('id'); 
		window.location.replace("<?php echo JURI::base().'index.php?option=com_payplans&view=subscription&task=edit&order_id=';?>" + orderid +'&plan_id='+planid);
	});
});
</script>
<?php 
