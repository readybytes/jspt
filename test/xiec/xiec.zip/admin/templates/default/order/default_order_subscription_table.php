<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?>

<table id="payplans_grid" class="payplans_grid adminlist" style="clear: both;">
	<thead>
	<!-- TABLE HEADER START -->
		<tr>
			<th><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_SUBSCRIPTION_GRID_SUBSCRIPTION_ID');?></th>			
			<th><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_SUBSCRIPTION_GRID_PLAN');?></th>
			<th><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_SUBSCRIPTION_GRID_STATUS');?></th>
			<th><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_SUBSCRIPTION_GRID_SUBSCRIPTION_DATE');?></th>
			<th><?php echo XiText::_('COM_PAYPLANS_ORDER_EDIT_SUBSCRIPTION_GRID_EXPIRATION_DATE');?></th>    
		</tr>
	<!-- TABLE HEADER END -->
	</thead>
	
	<tbody>
	<!-- TABLE BODY START -->		 
		<?php $count = 0;?> 
		<?php ksort($subscr_records);?>
		<?php foreach($subscr_records as $record) : 
			$subscription->bind($record);?>
			<tr class="<?php echo "row".$count%2; ?>">
				<td><?php echo XiHtml::link(XiRoute::_("index.php?option=com_payplans&view=subscription&task=edit&id=".$subscription->getId(), false), $subscription->getId());?></td>
				
				<td><?php echo PayplansHelperPlan::getName(array_shift($subscription->getPlans()));?></td>
				<td><?php echo XiText::_('COM_PAYPLANS_STATUS_'.XiStatus::getName($subscription->getStatus()));?></td>
				<td><?php echo XiDate::timeago($subscription->getSubscriptionDate()->toMysql());?></td>	
				<td><?php echo XiDate::timeago($subscription->getExpirationDate()->toMysql());?>		
			</tr>		
		<?php $count++;?> 
		<?php endforeach;?>		
	<!-- TABLE BODY END -->
	</tbody>
	
	<tfoot>
		<tr>
			<td colspan="7">

			</td>
		</tr>
	</tfoot>
</table>
<?php 
