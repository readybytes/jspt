<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();

jimport('joomla.html.pane');
?>
<div id="dashboard-left">
	<div id="cpanel">
		<?php echo $this->addIcon('config');?>
		<?php echo $this->addIcon('plan');?>
		<?php echo $this->addIcon('subscription');?>
		<?php echo $this->addIcon('app');?>
		<?php echo $this->addIcon('order');?>
		<?php echo $this->addIcon('payment');?>
		<?php echo $this->addIcon('user');?>
		<?php echo $this->addIcon('log');?>
	</div>
</div>

<div id="dashboard-right">
	<div class="top">
	<?php

		$tabs = JPane::getInstance('tabs', array('startOffset'=>0));
		echo $tabs->startPane('dashboard-right-tabs');

		// render module via xiNoTitle
		$modules = $this->_renderModules('payplans-admin-dashboard', array('style'=>'xiNoTitle'));

		foreach($modules as $title => $data){
			echo $tabs->startPanel($title,$title);
			echo $data;
			echo $tabs->endPanel();
		}
		echo $tabs->endPane();
	?>
	</div>

	<div class="bottom">
			<?php echo implode(' ', $this->_renderModules('payplans-admin-dashboard-bottom',array('style'=>'xiNoTitle')));?>
	</div>

</div>
<?php
