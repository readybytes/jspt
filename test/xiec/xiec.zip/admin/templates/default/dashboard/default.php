<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();

jimport('joomla.html.pane');
?>
<div id="dashboard-left">
	<?php $modules = $this->_renderModules('payplans-admin-dashboard-charts', array('style'=>'xiNoTitle'));?>
	<?php foreach($modules as $title => $data):?>
		<?php echo $data; ?>	
	<?php endforeach;?>	
</div>

<div id="dashboard-right">
	<div class="top">
	<?php

		$tabs = JPane::getInstance('tabs', array('startOffset'=>0));
		echo $tabs->startPane('dashboard-right-tabs');

		// render module via xiNoTitle
		$modules = $this->_renderModules('payplans-admin-dashboard', array('style'=>'xiNoTitle'));

		foreach($modules as $title => $data){
			echo $tabs->startPanel($title,$title);
			echo $data;
			echo $tabs->endPanel();
		}
		echo $tabs->endPane();
	?>
	</div>


</div>
<?php
