<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* Website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?>

<?php if(count($results) <=0) : ?> 
		<div class="dashboard-search-message"><?php echo XiText::_('COM_PAYPLANS_SEARCH_NO_RESULTS_FOUND'); ?></div>
		<?php return; ?>
<?php endif; ?>


<?php foreach($results as $record) :?>
	<div class="dashboard-search-result"><?php echo $record;?></div> 
<?php endforeach;?>
