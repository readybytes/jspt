<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		http://www.jpayplans.com
* Technical Support : Forum -	http://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?>
	<div class="icon">
		<a	href="<?php echo $url; ?>" <?php echo $new_window; ?> >
			<?php if(PAYPLANS_JVERSION_15):?>
			<?php echo XiHTML::_('image', 'components/com_payplans/media/images/icons/48/' . $image , NULL, NULL, $text ); ?>
			<?php else:?>
			<?php echo XiHTML::_('image', 'components/com_payplans/media/images/icons/48/' . $image , $text); ?>
			<?php endif;?>
			<span><?php echo XiText::_('COM_PAYPLANS_SM_'.JString::strtoupper($text)); ?></span>
		</a>
	</div>
<?php
