<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansadminViewOrder extends XiView
{
	protected function _adminGridToolbar()
	{
		XiHelperToolbar::searchpayplans();
		XiHelperToolbar::divider();
		//XiHelperToolbar::customX( 'copy', 'copy.png', 'copy_f2.png', 'Copy', true );
		XiHelperToolbar::delete();
		XiHelperToolbar::divider();
		XiHelperToolbar::editListX();
		XiHelperToolbar::addNewX('new');
	}
	
	function edit($tpl=null, $itemId=null)
	{
		$itemId = ($itemId === null) ? $this->getModel()->getState('id') : $itemId;
		$order	= PayplansOrder::getInstance( $itemId);
			
		// get all subscription/payment of this order id
		$subsRecords 	= XiFactory::getInstance('subscription', 'model')
									->loadRecords(array('order_id'=>$itemId));
		$paymentRecords = XiFactory::getInstance('payment', 'model')
									->loadRecords(array('order_id'=>$itemId));
		$userRecord 	= XiFactory::getInstance('user', 'model')
									->loadRecords(array('user_id'=>$order->getBuyer()), array('limit'));
		$logRecords	= XiFactory::getInstance('log', 'model')
								->loadRecords(array('object_id'=>$itemId, 'class'=>'PayplansOrder'));

		// get lib instance of subscription/payment
		$user		  = PayplansUser::getInstance();
		$payment	  = PayplansPayment::getInstance();
		$subscription = PayplansSubscription::getInstance();		
		$masterPayment = $order->getMasterPayment();

		// cancel option should be visible or not
		if($order->isRecurring() && $masterPayment){
			$app = $masterPayment->getApp(PAYPLANS_INSTANCE_REQUIRE);
			$status = $masterPayment->getstatus();
			if($status == XiStatus::PAYMENT_RECURRING_SIGNUP || $status == XiStatus::PAYMENT_RECURRING_FAILED){
				$this->assign('show_cancel_option', $app->getAppParam('allow_recurring_cancel', false));
			}
		}
			
		$this->assign('user', 		  	$user);
		$this->assign('order', 		  	$order);
		$this->assign('payment', 		$payment);
		$this->assign('subscription', 	$subscription);
		
		$this->assign('user_record',  	array_shift($userRecord));
		$this->assign('subscr_records',  	$subsRecords);
		$this->assign('payment_records', $paymentRecords);
		$this->assign('log_records', 	 $logRecords);
		return true;
	}
	
	public function terminate()
	{
		$itemId = $this->getModel()->getState('id');
	
		if($this->confirm == false){
			$this->setTpl(__FUNCTION__.'_confirm');
			$url = 'index.php?option=com_payplans&view=order&task=terminate&confirm=1&order_id='.$itemId;
			
			$this->_setAjaxWinTitle(XiText::_('COM_PAYPLANS_ORDER_TERMINATE_CONFIRM_WINDOW_TITLE'));
			$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_ORDER_TERMINATE_CONFRM_WINDOW_YES'), "xiajax.call('".$url."', Array()); ");
			$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_AJAX_CANCEL_BUTTON'),'xiWindowHide();');
			$this->_setAjaxWinAction();
			$this->_setAjaxWinHeight('150');
			return true;
		}
		
		$this->setTpl(__FUNCTION__);
		$this->_setAjaxWinTitle(XiText::_('COM_PAYPLANS_ORDER_TERMINATE_STATUS_WINDOW_TITLE'));
		$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_ORDER_TERMINATE_STATUS_WINDOW_CLOSE'),'xiWindowHide(); window.location.reload();');
		$this->_setAjaxWinAction();
		$this->_setAjaxWinHeight('150');
		
		return true;
	}
}

