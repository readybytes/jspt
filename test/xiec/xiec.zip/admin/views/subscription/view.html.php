<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansadminViewSubscription extends XiView
{
	protected function _adminGridToolbar()
	{
		XiHelperToolbar::searchpayplans();
		XiHelperToolbar::customX( 'extend', 'extend.png', 'extend.png', 'COM_PAYPLANS_SUBSCRIPTION_TOOLBAR_EXTEND', true );
		XiHelperToolbar::divider();
		XiHelperToolbar::delete();
		XiHelperToolbar::divider();
		XiHelperToolbar::editListX();
		XiHelperToolbar::openPopup('newSubscription','new','Create Subscription');
	}

	protected function _adminEditToolbar()
	{   
		$model = $this->getModel();
		XiHelperToolbar::save();
		XiHelperToolbar::apply();
		XiHelperToolbar::cancel();
		XiHelperToolbar::divider();
		//don't display delete button when creating new subscription
		if($model->getId() != null){
		   XiHelperToolbar::deleteRecord();
		 }
	}
	
	function edit($tpl=null)
	{
		$subscription = $this->get('subscription');		
		$logRecords	= XiFactory::getInstance('log', 'model')
								->loadRecords(array('object_id'=>$subscription->getId(), 'class'=>'PayplansSubscription'));		
		$this->assign('order', PayplansOrder::getInstance($subscription->getOrder()));
		$this->assign('user', PayplansUser::getInstance( $subscription->getBuyer()));
		$this->assign('log_records', 	 $logRecords);
		return true;
	}

	public function _getDynamicJavaScript()
	{
		$url	=	"index.php?option=com_{$this->_component}&view={$this->getName()}";
		ob_start(); ?>

		payplansAdmin.subscription_newSubscription = function()
		{
			xi.url.openInModal("<?php echo "$url&task=newSubscription"; ?>");
			return false;
		}

		payplansAdmin.subscription_extend = function()
		{
			var theurl = '<?php echo JURI::root()?>/administrator/index.php?option=com_payplans&view=subscription&task=extend&tmpl=component';
    		var ajaxCall = "xiajax.icall('"+theurl+"');";
			xiWindowShow(ajaxCall, '<?php echo XiText::_('COM_PAYPLANS_AJAX_SUBSCRIPTION_SELECT_EXTEND_TIME');?>', 500, 250);
    		var action = "<button onclick='xi.subscription.extend();'><?php echo XiText::_('COM_PAYPLANS_AJAX_APPLY_BUTTON');?></button>";
    		action += "<button onclick='xiWindowHide();'><?php echo XiText::_('COM_PAYPLANS_AJAX_CLOSE_BUTTON');?></button>";
    		xiWindowActions(action);
    		return false;
		}
		
		<?php
		$js = ob_get_contents();
		ob_end_clean();

		// atttach jquery file with document
		$url	=	"administrator/components/com_payplans/templates/default/subscription/";
		XiHtml::script('subscription.js', $url);

		return $js;
	}

	public function newSubscription()
	{
		$this->_setAjaxWinTitle(XiText::_('COM_PAYPLANS_SUBSCRIPTION_NEW_TEXT_POPUP_TITLE'));
		$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_AJAX_CANCEL_BUTTON'),'xiWindowHide();');
		$this->_setAjaxWinAction();
		$this->_setAjaxWinHeight('100');

		return true;
	}
	
	public function extend()
	{

		return true;
	}
}