<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();


class PayplansadminViewConfig extends XiView
{
	//xitodo : remove this function and convert it to class variable
	public function getJSValidActions()
    {
    	return array();
    }
	
    
	protected function _adminEditToolbar()
	{
		XiHelperToolbar::apply();
		XiHelperToolbar::cancel();
	}

	function edit($tpl=null)
	{
		//now record is always an array, pick all records
		$records 	= $this->getModel()->loadRecords(array(), array(), true);
		$recordKey 	= $this->getModel()->getTable()->getKeyName();
		$logRecords= XiFactory::getInstance('log', 'model')
								->loadRecords(array('class'=>'PayplansConfig'));
		$configs = array();
		// Call XiApp GetInstance as it will autoload all apps
		foreach($records as $record){
			$obj = PayplansConfig::getInstance($record->config_id, null, $record);
			$configs 	= array_merge($configs, $obj->renderToArray($obj->getKey().'[config]'));
			$configObj[$obj->getKey()]= $obj;
		}

		$this->assign('configs', $configs);
		$this->assign('config_obj', $configObj);
		$this->assign('log_records', $logRecords);
		return true;
	}
}