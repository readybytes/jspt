<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansadminViewLog extends XiView
{
	protected function _adminGridToolbar()
	{
		XiHelperToolbar::deleteList();
	}
	
	protected function _adminEditToolbar()
	{
		XiHelperToolbar::cancel();
	}
	
	function edit($tpl=null, $itemId=null)
	{
		$itemId = JRequest::getVar('record');
		$logRecords 	= XiFactory::getInstance('log', 'model')
									->loadRecords(array('log_id'=>$itemId));

		$log = array_shift($logRecords);
		//XITODO : move this code to common code
		$logData = unserialize(base64_decode($log->content));

		$classname = array_shift($logData);

		$this->_setAjaxWinTitle(XiText::_('COM_PAYPLANS_LOG_DISPLAY_DETAIL'));
		$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_AJAX_CLOSE_BUTTON'),'xiWindowHide();');

		$this->_setAjaxWinAction();
		$this->_setAjaxWinHeight('200');

		
		if(class_exists($classname))
		{
			$instance = new $classname();
			$content = $instance->reader($logData);
			
			if($content!= false)
				$data = $instance->formatter($content, $log->class);
				$this->assign('data', $data);
		}

		return true;
	}
}