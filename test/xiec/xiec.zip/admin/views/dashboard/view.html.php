<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die();

class PayplansadminViewDashboard extends XiView
{
	function _displayList()
	{
		return true;
	}

	function display($tpl=null)
	{
		return true;
	}

	function _basicFormSetup()
	{
		return true;
	}

	protected function _adminToolbar()
	{
		$this->_adminToolbarTitle();
	}

	protected function _adminToolbarTitle()
	{
		// Set the titlebar text
		XiHelperToolbar::title("PayPlans", "favicon.png");
	}

	function addIcon( $image , $url=null, $text=null , $newWindow = false )
	{
		$newWindow	= ( $newWindow ) ? ' target="_blank"' : '';

		$url = $url ? $url : 'index.php?option=com_payplans&view='.$image;
		$this->assign('url',$url);

		$text = $text ? $text: $image;
		$this->assign('text',$text);

		$this->assign('new_window',$newWindow);

		$image = $image.".png";
		$this->assign('image',$image);

		return $this->loadTemplate('addicon');
	}
	
	public function modsearch()
	{
		return true;
	}
	
	public function migrate()
	{
		$func = '_'.$this->get('action').'Migration';
		return $this->$func();
	}
	
	protected function _preMigration()
	{
		$this->_setAjaxWinTitle(XiText::_('PLG_PAYPLANS_'.JString::strtoupper($this->get('pluginKey')).'_MIGRATION_MESSAGE' ));

		$componentExist=false;
		foreach($this->get('results') as $ret){
			if($ret !== false){
				$componentExist=true;
				break;
			}	
		}
		
		if($componentExist === false){
			$this->assign('results', array(XiText::_('COM_PAYPLANS_MIGRATION_COMPONENT_NOT_AVAILABLE')));
			$this->_setAjaxWinHeight('150');
			return true;
		}
		
		$onClick = "xi.dashboard.doMigration('{$this->get('pluginKey')}');";
		$onClickText = XiText::_('PLG_PAYPLANS_'.JString::strtoupper($this->get('pluginKey')).'_MIGRATION_DO_BUTTON');
		$this->_addAjaxWinAction($onClickText, $onClick );
		$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_AJAX_CANCEL_BUTTON'),'xiWindowHide();');
		$this->_setAjaxWinAction();
		$this->_setAjaxWinHeight('240');
		return true;
	}
	
	protected function _doMigration()
	{
		$this->_setAjaxWinTitle(XiText::_('PLG_PAYPLANS_'.JString::strtoupper($this->get('pluginKey')).'_MIGRATION_PROGRESS'));
		$this->_setAjaxWinHeight('150');
		XiFactory::getAjaxResponse()->addScriptCall('xi.dashboard.updateMigration', $this->get('pluginKey'));
		return true;
	}
	
	protected function _postMigration()
	{
		$this->_setAjaxWinTitle(XiText::_('PLG_PAYPLANS_'.JString::strtoupper($this->get('pluginKey')).'_MIGRATION_COMPLETE'));
		$this->_addAjaxWinAction(XiText::_('COM_PAYPLANS_AJAX_DONE_BUTTON'),'xiWindowHide();');
		$this->_setAjaxWinAction();
		$this->_setAjaxWinHeight('100');
		return true;
	}
}