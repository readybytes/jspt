<?php

/**
* @copyright	Copyright (C) 2009 - 2012 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Migration
* @contact 		payplans@readybytes.in
*/

class Migrate14 extends PpinstallerModelMigrate
{


	protected  $action = Array(
							'mPlans', 
							'mSubscriptions',
							'mInvoices',
							'mOrders',
							'mDiscount_Modifier',
							'mTax_Modifier',
							'mPayments',
							'mTransaction',
							'mWallet',
							'mApps',
							'mFinalize'
						 );
						 
						 
						 
	function __construct($config=array()) 
	{
		foreach ($this->action as $index=>$fun ){
			// remove m and append 'MIGRATE_' and get msg from language file 
			$this->action[$fun] = JText::_('COM_PPINSTALLER_MIGRATE_'.substr($fun, 1));
			unset($this->action[$index]);  
		}
		
		parent::__construct($config);
		
	}

	// If old version is lower than latest 1.4 then first install 1.4.x latest
	// then install 2.0.X
	public function before() 
	{
		$this->migrate_from = 14 ;
		$this->migrate_file = 1.4 ;
		$this->sql_file 	= dirname(__FILE__).DS.'sql'.DS."{$this->migrate_file}.sql";
		

		$return_info = parent::before();

		//Remove duplicate subscriptions
		$query = '	SELECT *
					FROM `#__payplans_subscription` AS A
					INNER JOIN `#__payplans_subscription` AS B ON A.`order_id` = B.`order_id`
					WHERE A.`subscription_id` <> B.`subscription_id`
					ORDER BY `A`.`subscription_id` DESC
			    ';
		$db = JFactory::getDbo();
		$db->setQuery($query);
		$subscriptions = $db->loadObjectList('subscription_id');
		if(!empty($subscriptions)){
			// sort array into descending order
			krsort($subscriptions);
			// Array[order_id=>subs_id]
			$tem_orders = Array();
			$del_subs   = Array();
			// I'll consider last active subscription. { consider last subcription If dont have any active subs }  
			foreach ($subscriptions as $subs_id=>$subs){
				if(array_key_exists($subs->order_id,$tem_orders)){
					if(PPINSTALLER_SUBSCRIPTION_ACTIVE == $subs->status){
						$del_subs[] = $tem_orders[$subs->order_id];
						$tem_orders[$subs->order_id] = $subs_id;
					}
					else{
						$del_subs[] = $subs_id; 
					}
					continue;
				}
				$tem_orders[$subs->order_id] = $subs_id; 
			}
			
			
			//set order id to 0 and order_id will available into param as a migrated_order_id
			if(!empty($del_subs)){
				foreach ($del_subs as $subId) {
					$old_param 	  = (array) PpinstallerHelperUtils::stringToObject($subscriptions[$subId]->params);
					
					$old_param['migrated_order_id'] = $subscriptions[$subId]->order_id;
					
					$old_param = (object)$old_param;
					$old_param  = PpinstallerHelperUtils::objectToString($old_param);
			
					$query =  "	UPDATE  `#__payplans_subscription` 
					    		SET `params` 	= '$old_param',
					    			`order_id`  = 0
					    		WHERE `subscription_id`= $subId
					   		  ";
					$db->setQuery($query);
					$db->query();
				}
				PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_UPDATE_COLUMN','Subcription'),$del_subs);
			}
		}
		
		return $return_info;
	}
	
	public function mPlans()
	{
		$returnInfo = Array();
		$db = JFactory::getDbo();
		
		$query = 'SELECT * FROM  `#__payplans_plan`';
		$db->setQuery($query);
		$plans = $db->loadObjectList('plan_id');
		
		// Plans Migration start
		PpinstallerHelperLogger::log(JText::_('COM_PPINSTALLER_PLANS_MIGRATION_START'),$db->errorMsg()); 
		foreach($plans as $plan_id=>$plan){
			$time	 =  (array) PpinstallerHelperUtils::stringToObject($plan->time);
			$payment =  (array) PpinstallerHelperUtils::stringToObject($plan->payment);
			$detail	 =  array_merge($time, $payment);

			// if expirationtype is recurring and first price is not undefined
			// then set expirationtype to recurring_trial_1 other wise set it to 
			// recurring
			if('recurring' == $detail['expirationtype'] && 
				isset($detail['first_price']) && 'UNDEFINED' != $detail['first_price'] ){
				$detail['expirationtype']   = 'recurring_trial_1';
				$detail['trial_price_1']    = $detail['first_price'];
				$detail['trial_time_1']     = isset($detail['first_price_expiration'])? $detail['first_price_expiration'] : $detail['expiration'];
				$detail['recurrence_count'] = ($detail['recurrence_count'] > 1) ? --$detail['recurrence_count'] : $detail['recurrence_count'];
				
				// uset first price if set
				unset($detail['first_price']);
			}
			
			$detail  = (object) $detail;
			$detail  = PpinstallerHelperUtils::objectToString($detail,null);
			$detail  = (defined('PPINSTALLER_15')) ? $db->getEscaped($detail) : $db->escape($detail);

			$query =  "	UPDATE  `#__payplans_plan` 
					    SET `time` = '$detail'
					    WHERE `plan_id`= {$plan->plan_id}
					   ";
			$db->setQuery($query);
			$this->is_success &= $db->query();
			PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_UPDATE_COLUMN','plan'),$db->errorMsg());
		}
		
		//Drop payment column
		$query = 'ALTER TABLE `#__payplans_plan` DROP COLUMN `payment`';
		$db->setQuery($query);
		$this->is_success &= $db->query();
		PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_DROP_COLUMN','payment','plan'),$db->errorMsg());
		
		//Alter column name time to details
		$query = 'ALTER TABLE `#__payplans_plan` CHANGE `time` `details`  TEXT NOT NULL';
  		$db->setQuery($query);
  		$this->is_success &= $db->query();
  		PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_MODIFY_COLUMN','plan'),$db->errorMsg());
  		
  		// Plan migration done
		$this->msg = JText::_('COM_PPINSTALLER_PLANS_MIGRATION_DONE');
		return $returnInfo;			
	}
	
	public function mSubscriptions() 
	{
		$returnInfo = Array();
		$db 		= JFactory::getDbo();
	
		$plans = $this->loadData('#__payplans_plan', 'plan_id');
		
		foreach($plans as $plan_id=>$plan){
			$plan_details[$plan_id]	 		 =  (array) PpinstallerHelperUtils::stringToObject($plan->details);
			$plan_details[$plan_id]['title'] =   $plan->title;
		}

		// Before Migration :: When subscription table have multiple subs on single order then order ids will be zero (0) except last (active) subscription. 
		$this->query  = ' 
							SELECT  subs.`subscription_id`,
									subs.`order_id`,
									subs.`user_id`,
									subs.`plan_id`,
									subs.`params` as sub_params,
									orders.`params` as order_params
							FROM `#__payplans_subscription`  as subs 
							LEFT JOIN  `#__payplans_order`  as orders
									ON orders.`order_id` = subs.`order_id` 
							WHERE subs.`order_id` <> 0
							ORDER BY subs.`subscription_id` ASC
				  		';
		
		$limit = " LIMIT {$this->start}, ".PPINSTALLER_LIMIT;
		$db->setQuery($this->query . $limit);
		$subs = $db->loadObjectList('subscription_id');
		
		$migrate_keys = Array(
								'price',
								'discount',
								'first_price',
								'first_expiration_time',
								'expiration_time',
								'expirationtype',
								'recurrence_count',
								'title'
								);
		
		foreach ($subs as $sub_id=>$sub) {
			
			$plans_id = $sub->plan_id ;
			// Might be you have deleted plan bt subs data still exist 
			if(!array_key_exists ($plan_id,$plan_details)){continue; }

			$new_param	  = Array();
			$old_param 	  = (array) PpinstallerHelperUtils::stringToObject($sub->sub_params);
			$order_param  = (array) PpinstallerHelperUtils::stringToObject($sub->order_params);
			
			// XiTODO:: Pending :: { currency=>subs}
			$new_param['price'] 		= isset($old_param['price']) ? $old_param['price'] : $plan_details[$plans_id]['price']; 
			$new_param['discount']  	= isset($old_param['discount']) ? $old_param['discount']:0.00;
			
			// Ticket #1596
			$new_param['expiration'] = isset($old_param['expiration_time'])
												? $old_param['expiration_time']
												: $plan_details[$plans_id]['expiration'];
												
			$new_param['expirationtype'] =  isset($old_param['expirationtype'])
												? $old_param['expirationtype'] 
												: $plan_details[$plans_id]['expirationtype'];												
			
			// for trial
			$new_param['trial_price_1'] = 0.00;
			$new_param['trial_time_1']	= '000000000000';
			if(isset($old_param['first_price']) && $old_param['first_price'] !== 'UNDEFINED'){// It means You have recurring plan with free trial
				$new_param['trial_price_1'] = $old_param['first_price'];
				$new_param['trial_time_1']  = isset($old_param['first_expiration_time'])
													? $old_param['first_expiration_time']
													: $new_param['expiration'];
													
				$new_param['expirationtype'] = 'recurring_trial_1';
			}
			
			
			// Ticket #1594
			if( isset($order_param['upgrading_from']) &&
				!empty($order_param['upgrading_from']) &&  
			    'recurring' == $new_param['expirationtype'] ) {
					$new_param['expirationtype'] = 'recurring_trial_1';
			}
													   
			// I think ... trial-2 is not availble in 1.4 
			$new_param['trial_price_2'] = 0.00;
			$new_param['trial_time_2']  = '000000000000';
			
			$new_param['recurrence_count'] = isset($old_param['recurrence_count'])
														? (	($old_param['recurrence_count'] > 1) 
																? --$old_param['recurrence_count'] 
																: $old_param['recurrence_count']
														   )
														: $plan_details[$plans_id]['recurrence_count'];
			$new_param['notes'] = '';
			
			// You need it into invoice migration
			$new_param['title'] =  $plan_details[$plans_id]['title']; 
			
			// Just copied others param
			$old_param_keys = array_keys($old_param);
			$pending_keys = array_diff($old_param_keys,$migrate_keys);
			foreach($pending_keys as $key){
				$new_param[$key] = $old_param[$key];
			}
			
			
			// update status
			$new_param  = (object) $new_param;
			$new_param  = PpinstallerHelperUtils::objectToString($new_param,null);
			$new_param  = (defined('PPINSTALLER_15')) ? $db->getEscaped($new_param) : $db->escape($new_param);
			
			$query =  "	UPDATE  `#__payplans_subscription` 
					    		SET `params` = '$new_param'
					    WHERE `subscription_id`= $sub_id
					   ";
			$db->setQuery($query);
			$this->is_success &= $db->query();
			PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_UPDATE_COLUMN','Subcription'),"Subscription_Id=>$sub_id".$db->errorMsg());
		}	
		$this->msg 			 = JText::sprintf('COM_PPINSTALLER_MIGRATION_DONE','Subscription');
		return $returnInfo;
	}

	public function mInvoices()
	{
		$returnInfo = array();
		$db = JFactory::getDbo();
		// Get all payments (fixed+recurring)
		$this->query =  ' 
						SELECT payment.`payment_id`, payment.`order_id` , 
							   orders.`buyer_id`, orders.`subtotal` , 
							   orders.`total`, 	payment.`master`,
							   payment.`status`, payment.`created_date`,
							   payment.currency, payment.`modified_date`,
							   subs.`params`, payment.`amount`
						FROM `#__payplans_payment` AS payment
						INNER JOIN `#__payplans_order` AS orders 
						ON payment.`order_id` = orders.`order_id`
						INNER JOIN `#__payplans_subscription` AS subs 
						ON payment.`order_id` = subs.`order_id`
						ORDER BY `payment_id` ASC
						';

		$limit = " LIMIT {$this->start}, ".PPINSTALLER_LIMIT;
		$db->setQuery($this->query . $limit);
		$payments = $db->loadObjectList('payment_id');
		
		// I'm creating extra column payment_id . This column will be used into other migration. (transaction and orders) 
		// I'll delete this column after migration
			
		if(empty($this->start)){
			$query = ' ALTER TABLE `#__payplans_invoice` 
								   ADD (`m_payment_id` INT NOT NULL,
								   		INDEX (`m_payment_id`)
										)';
			$db->setQuery($query);
			$this->is_success = $db->query();
			PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_CREATE_COLUMN','m_payment_id','invoice'),$db->getErrorMsg());
		}
		
		// If we don't have payment then no need to create invoice
		if(empty($payments)){
			$this->query = null;
			$this->msg = JText::_('YOU_DONT_HAVE_ANY_PAYMENT');
			PpinstallerHelperLogger::log($this->msg);
			return $returnInfo;
		}
	
		// Get all master payments of recurring-payment.
		// having is used for getting only recurring master payment
		// becasue normal payment can be one only
		// but recurring will be more than one.	 
//		$query 	= '
//					SELECT `payment_id` , COUNT( * ) c
//					FROM `#__payplans_payment`
//					GROUP BY `order_id`
//					HAVING c >1
//				  ';
//		$db->setQuery($query);
//		$recurr_payments1 = $db->loadResultArray();
//		
//		$recurr_payments = $recurr_payments1;

		// Insert query for invoice
		// XiTODO::  pending migration:: checked_out,checked_out_time
		$migrate_param_keys = Array('title',
									'expirationtype',
									'price',
									'expiration',
									'recurrence_count',
									'trial_price_1',
									'trial_time_1',
									'trial_price_2',
									'trial_time_2'
									);

		$insert  = ' INSERT INTO  `#__payplans_invoice` 
						(	`object_id`,`object_type`,`user_id`,
							`subtotal`,`total`,`status`,
							`currency`,`created_date`,`modified_date`,
							`params`,`m_payment_id`,counter
						)';
		$value	= 'VALUES ';
		
		//non-considerable status
		$payment_status = Array (
									PPINSTALLER_PAYMENT_RECURRING_SIGNUP,
									PPINSTALLER_PAYMENT_RECURRING_CANCEL,
									PPINSTALLER_PAYMENT_RECURRING_EOT,
									PPINSTALLER_PAYMENT_RECURRING_FAILED,
									PPINSTALLER_PAYMENT_RECURRING_START
								);
		// Array ('order_id'=>counter)
		$counter = Array();
		// temp_order have Order_id only that case when expiration type is recurring_trial_1.
		$temp_orders= Array();
		foreach ($payments as $payment_id => $payment){
			// We don't create invoice for master payment ||
			// Might be multiple payment created with non-considerable status
			//if( in_array($payment_id, $recurr_payments) ||
			  if( in_array($payment->status, $payment_status))
			  	{ continue; }
			
			switch($payment->status){
				case PPINSTALLER_PAYMENT_COMPLETE			:
					// Status on Payment confirmation
					$status = PPINSTALLER_INVOICE_PAID;
					break;
				
				case PPINSTALLER_PAYMENT_HOLD				:
					// if you have any payment status 
					$status = PPINSTALLER_INVOICE_REFUNDED;
					break;
				// default case
				//case PPINSTALLER_PAYMENT_PENDING:
				default:
					// PPINSTALLER_PAYMENT_INITIATED
					// default invoice status
						$status = PPINSTALLER_INVOICE_CONFIRMED;				
			}
			
			$subs_param = (array) PpinstallerHelperUtils::stringToObject($payment->params);
			// Migrate Params
			$param				= Array();
			foreach ($migrate_param_keys as $key){
				if(!isset($subs_param[$key]))	{ continue;}
				$param[$key] = 	$subs_param[$key];
			}
			
			// Set sub-total
			$sub_total = $payment->subtotal;
			if('recurring_trial_1' == $param['expirationtype'] && !in_array($payment->order_id, $temp_orders)){
				$sub_total     = $param['trial_price_1'];
				$temp_orders[] = $payment->order_id;	
			}

			$param = (object)$param;
			$param = PpinstallerHelperUtils::objectToString($param);
			
			$param  = (defined('PPINSTALLER_15')) ? $db->getEscaped($param) : $db->escape($param);
			
			// Maintain counter Ticket #1588 
			$counter[$payment->order_id] = (array_key_exists($payment->order_id, $counter))?++$counter[$payment->order_id]:1;	
			
			$value .= "( {$payment->order_id},'PayplansOrder',{$payment->buyer_id},
						 {$sub_total},{$payment->amount},
						 $status,'{$payment->currency}',
						'{$payment->created_date}','{$payment->modified_date}',
						'$param',$payment_id,{$counter[$payment->order_id]}
						),";
		}

		// remove last char (,)
		$value = substr($value,0,strrpos($value,','));
	
		$db->setQuery($insert.$value);
		$this->is_success = $db->query();

		 // invoice migration done
		$this->msg = JText::sprintf('COM_PPINSTALLER_MIGRATION_DONE','Invoice');

		PpinstallerHelperLogger::log($this->msg ,$db->getErrorMsg());
		
		return $returnInfo;		
	}
	
	/**
	 * (non-PHPdoc)
	 * @see administrator/components/com_ppinstaller/models/PpinstallerModelMigrate::mOrders()
	 * Store payment id into order->params (its a master payment)
	 */
	public function mOrders()
	{
		$returnInfo = Array();
//		
//		$this->query = '
//						SELECT 	payment.`payment_id` , payment.`order_id` , orders.`params` , 
//								invoice.`invoice_id` , invoice.`object_type` , invoice.`object_id`
//						FROM `#__payplans_order` AS orders
//						INNER JOIN `#__payplans_payment` AS payment ON orders.`order_id` = payment.`order_id`
//						LEFT JOIN  `#__payplans_invoice` AS invoice ON orders.`order_id` = invoice.`object_id`
//						WHERE payment.`master` =1
//					   ';

		
		
		$this->query = ' 
							SELECT I.`object_id`, O.`order_id`,
								   I.`invoice_id`, I.`object_type`,
								   I.`m_payment_id`, O.`params` 
							FROM `#__payplans_order` AS O
							INNER JOIN `#__payplans_invoice` AS I
                    					ON O.`order_id` =  I.`object_id`
							GROUP BY I.`object_id`
						';
		
		$limit = " LIMIT {$this->start}, ".PPINSTALLER_LIMIT;
		
		$db = JFactory::getDbo();
		$db->setQuery($this->query . $limit);
		$orders = $db->loadObjectList('order_id');
		
		foreach($orders as $order){
			$order_params = PpinstallerHelperUtils::stringToObject($order->params);
			
			$order_params->payment_id = $order->m_payment_id;
			$order_params->first_invoice_id = 0;
			$order_params->last_master_invoice_id = 0;
			if($order->invoice_id && 'PayplansOrder' == $order->object_type){
				$order_params->first_invoice_id       = $order->invoice_id;
				$order_params->last_master_invoice_id = $order->invoice_id;
			}
			$order_params  = PpinstallerHelperUtils::objectToString($order_params,null);
			
			$order_params  = (defined('PPINSTALLER_15')) ? $db->getEscaped($order_params) : $db->escape($order_params);
						
			$query =  "	UPDATE  `#__payplans_order` 
					    SET `params` = '$order_params'
					    WHERE `order_id`= {$order->order_id}
					   ";
			$db->setQuery($query);
			$this->is_success &= $db->query();
			PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_UPDATE_COLUMN','order'),$db->errorMsg());
		}

		$this->msg = JText::sprintf('COM_PPINSTALLER_MIGRATION_DONE','Orders');
		
		PpinstallerHelperLogger::log($this->msg ,$db->getErrorMsg());
		return $returnInfo;		
	}
	
	/**
	 * Migrate all discount and tax data (Create modifier)
	 * @see administrator/components/com_ppinstaller/models/PpinstallerModelMigrate::mOrders()
	 */
	public function mDiscount_Modifier()
	{	
		$returnInfo = array();
		$this->msg = JText::sprintf('COM_PPINSTALLER_MIGRATION_DONE','Discount Modifiers');
			
		$this->query
				 = ' 
						SELECT S.`subscription_id`, I.`object_id` AS order_id,
						       GROUP_CONCAT(convert( I.`invoice_id` , CHAR )) AS invoice_id,
						       S.`params`,S.`user_id`
						FROM  `#__payplans_subscription` AS S
						INNER JOIN `#__payplans_invoice` AS I 
						 	  ON S.`order_id` = I.`object_id`
						GROUP BY I.`object_id`';
		
		$limit = " LIMIT {$this->start}, ".PPINSTALLER_LIMIT;

		$db = JFactory::getDbo();
		$db->setQuery($this->query . $limit);
		$records = $db->loadObjectList('order_id');
		
		if(empty($records)) {
			$this->msg = ($this->start)?$this->msg:JText::sprintf('COM_PPINSTALLER_NO_NEED_ANY_MIGRATION','Discount Modifiers');
			return $returnInfo;
		}

		// modifier should not be created if we dont have any discount   
		$insert = ' INSERT INTO `#__payplans_modifier`
									( `user_id`, `invoice_id`, `amount`, `type`, `percentage`, `frequency`, `serial`) ';
			
		$values = '';
		
		foreach($records as $order_id => $record)
		{
			$sub_params  = PpinstallerHelperUtils::stringToObject($record->params);
			$invoice_ids = explode(',', $record->invoice_id);
			// Set discount on first invoice id if discount frequency is one
			sort($invoice_ids);
			
			$append_value = '';
			if(isset($sub_params->discount) && $sub_params->discount > 0){
				foreach ($invoice_ids as $invoice_id){
							$append_value .= "( {$record->user_id}, $invoice_id , 
									  	 		-{$sub_params->discount} , 'discount',
									   	  		0,'".PPINSTALLER_FREQUENCY_EACH_TIME."',".PPINSTALLER_FIXED_DISCOUNT.'),';
						}
			}				
			elseif(isset($sub_params->first_price_discount) && $sub_params->first_price_discount > 0){
					$first_invoice = array_shift($invoice_ids);
					$append_value  = "( {$record->user_id}, $first_invoice , 
										-{$sub_params->first_price_discount} , 'discount',
										 0,'".PPINSTALLER_FREQUENCY_ONE_TIME."',".PPINSTALLER_FIXED_DISCOUNT.'),'; 
			}

			if(empty($append_value)){
				continue;
			}
			
			$values .= $append_value;
		}
		
		if(empty($values)){
			return $returnInfo;
		}
		// remove last character (,)
		$values = substr($values,0,strrpos($values,','));
		$insert_query = " $insert VALUES  $values ";
		$db->setQuery($insert_query);
		$this->is_success &=$db->query();
		
		$order_ids = implode(',', array_keys($records));
		PpinstallerHelperLogger::log("Record(Discount) inserted into modifier table. Modifier created for ORDERS_IDS {$order_ids}",$db->getErrorMsg());
		
		return $returnInfo;	
	}
	
	public function mTax_Modifier()
	{
		$returnInfo = array();
		$this->msg = JText::sprintf('COM_PPINSTALLER_MIGRATION_DONE','Tax Modifiers');
		
		$db = JFactory::getDbo();
		$sql 	= ' INSERT INTO `#__payplans_modifier` '.
				  ' (`user_id`,`invoice_id`,`amount`,`type`,`reference`,`percentage`,`serial`,`frequency`)'.
				  ' VALUE';
		$value	= '';

		//get all tax applicable orders {included: tax and euvat}
		// Dont required any limit
		$query = '	SELECT *
					FROM `#__payplans_order`
					INNER JOIN `#__payplans_invoice` 
						  ON `order_id` = `object_id`
					WHERE `tax` <> 0.00000
					';
		$db->setQuery($query);
		$tax_invoices = $db->loadObjectList('invoice_id');

		foreach ($tax_invoices as $invoice_id=>$invoice){
			// default values.
			// tax is always in percent
			$percentage = 1;
			$serial		= PPINSTALLER_PERCENT_TAX;
			$frequency	= PPINSTALLER_FREQUENCY_EACH_TIME;
			// XiTODO:: pending column=> {type,reference} 
			//(`user_id`,`invoice_id`,`amount`,`type`,`reference`,`percentage`,`serial`,`frequency`)'
			$value .= " (  {$invoice->user_id}, $invoice_id,$invoice->tax, 
							'','',
							$percentage , $serial , '$frequency'
						),";
		}
		//  if discount/tax does not exist then no need to fire query
		if(empty($value)) {
			// No need any tax
			$this->msg = JText::sprintf('COM_PPINSTALLER_NO_NEED_ANY_MIGRATION','Tax Modifiers');
			return $returnInfo;	
		}
		// remove last character (,)
		$value = substr($value,0,strrpos($value,','));
		$query = $sql . $value;
		$db->setQuery($query);
		$this->is_success &=$db->query();
		$invoice_ids = implode(',', array_keys($tax_invoices));
		PpinstallerHelperLogger::log("Record (TAX) inserted into modifier table. Modifier created for INVOICE_IDS {$invoice_ids}",$db->getErrorMsg());

		return $returnInfo;	
	}
	
	// Migrate Transaction
	// XiTODO:: Pending => gateway_subscr_id
	public function mTransaction()
	{	
		$returnInfo = array();
		$db = JFactory::getDbo();

		$this->query = 'SELECT * FROM `#__payplans_invoice`';
		$this->limit = PPINSTALLER_CRITICAL_LIMIT;
		$limit  	  	 = "LIMIT {$this->start} , {$this->limit}" ;
		$db->setQuery($this->query.$limit);
//		$invoices = $db->loadAssocList('invoice_id');
//		$invoice_ids = array_keys($invoices);
		$invoice_ids = $db->loadResultArray();
		
		if(empty($invoice_ids)){
			$this->query = null;
			$this->msg = JText::sprintf('COM_PPINSTALLER_TABLE_EMPTY','invoice');
			PpinstallerHelperLogger::log($this->msg);
			return $returnInfo;
		}
		$authorize_app = Array();
		$query = " SELECT `app_id` 
				   FROM `#__payplans_app`
				   WHERE `type` = 'authorize'
				 ";
		$db->setQuery($query);
		$authorize_app = $db->loadResultArray();

		$invoice_array = $invoice_ids;	
		$payments = $this->loadData('#__payplans_payment','payment_id',
										'`invoice_id` IN ('.implode(',', $invoice_array).
										') ORDER BY `payment_id` ASC');
		
		$payment_ids = array_keys($payments);
		
		// I want to all invoice id regrading payments. {required for current_invoice id}
		$invoices = $this->loadData( '#__payplans_invoice',
									 'm_payment_id',
									 '`m_payment_id` IN ('.implode(',', $payment_ids).')'
									);
		
		$query = ' INSERT INTO `#__payplans_transaction`
							( `user_id`, `invoice_id`,`current_invoice_id`,
							  `payment_id`,`gateway_txn_id`,`created_date`,
							  `amount`,`params`)
					VALUES 
				';
		
		$temp_invoice = Array();
		foreach($payments as $payment_id=>$payment){
			// We required 'Master payment'
			if(!isset($temp_invoice[$payment->invoice_id])){
				$temp_invoice[$payment->invoice_id] = $payment_id;
			}

			$amount = 0;
			//amount have data only that case when your payment is completed
			if( PPINSTALLER_PAYMENT_COMPLETE == $payment->status ){
			  	$amount = $payment->amount;
			  }
			$txn_id = '';
			if(!empty($payment->txn_id)){
				$txn_id = $payment->txn_id;
			}
			// if you have authorize app then you need to remove "appid_" from txn_id
			if(!empty($txn_id) && in_array($payment->app_id,$authorize_app)){
				$txn_id = JString::str_ireplace("{$payment->app_id}_",'',$txn_id);
			}
			$param  = (defined('PPINSTALLER_15')) 
							? $db->getEscaped($payment->transaction) 
							: $db->escape($payment->transaction);
							
			$current_invoice_id = 0;
			if(isset($invoices[$payment_id])){
				$current_invoice_id = $invoices[$payment_id]->invoice_id;
			}
			
			$query .= "
						( $payment->user_id,$payment->invoice_id,
						  $current_invoice_id,{$temp_invoice[$payment->invoice_id]},
						  '$txn_id','{$payment->created_date}', $amount,'$param'
						 ),";
		}
		// remove last occurence of (,) and space
		$query = substr($query,0,strrpos($query,','));
		$db->setQuery($query);
		$this->is_success &=$db->query();
		PpinstallerHelperLogger::log('Transaction has been created for few payments',$db->errorMsg());	

		$this->msg			 = JText::sprintf('COM_PPINSTALLER_MIGRATION_DONE','Transaction');

		PpinstallerHelperLogger::log($this->msg);
		return $returnInfo;
	}
	
	
	//XiTODO:: pending Migration::gateway_params
	public function mPayments() 
	{
		$returnInfo = Array();
		
		$db		= JFactory::getDBO();
		// Add required columns
		if(!$this->start){
			$query	=  ' ALTER TABLE `#__payplans_payment`
					  		ADD ( `invoice_id` INT NOT NULL DEFAULT 0,
					  			  `user_id` INT NOT NULL DEFAULT 0,
					  			  `gateway_params` TEXT NULL,
					  			   INDEX (`invoice_id`)
					  		  	)';
			
			$db->setQuery($query);
			$this->is_success &= $db->query();
			PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_ADD_COLUMN','payment'),$db->errorMsg());
		}
		// You can add "ORDER BY `object_id` ASC" for just confirmation  you have only use first invoice_id of recurring payment.  
		$this->query = 'SELECT * 
						FROM `#__payplans_invoice`
						GROUP BY `object_id`';
		
		$limit = " LIMIT {$this->start}, ".PPINSTALLER_LIMIT;
		$db->setQuery($this->query . $limit);
		$invoices = $db->loadObjectList('invoice_id');
		
		foreach ($invoices as $invoice_id=>$invoice) {
			$query = " 
						UPDATE `#__payplans_payment`
						SET `invoice_id` = $invoice_id,
							`user_id`= {$invoice->user_id}
						WHERE `order_id` = {$invoice->object_id}
					 ";
			$db->setQuery($query);
			$this->is_success &= $db->query();
			PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_UPDATE_COLUMN','payment'),$db->errorMsg());
		}
		
		$this->msg = JText::sprintf('COM_PPINSTALLER_MIGRATION_DONE','Payments');
		return $returnInfo;
	}
	

	public function mApps() 
	{
		$returnInfo = Array();
		
		$db		= JFactory::getDBO();		
		
		$query	= 'DROP TABLE IF EXISTS `#__payplans_appmetadata`';
		$db->setQuery($query);
		$this->is_success &= $db->query();
		PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_DROP_TABLE','Payplans appmetadata'),$db->errorMsg());
		
		// Now we don't use any payment-status. 
		$payment_status = Array(
								PPINSTALLER_PAYMENT_INITIATED,
								PPINSTALLER_PAYMENT_COMPLETE,
								PPINSTALLER_PAYMENT_HOLD,
								PPINSTALLER_PAYMENT_PENDING,
								PPINSTALLER_PAYMENT_RECURRING_SIGNUP,
								PPINSTALLER_PAYMENT_RECURRING_CANCEL,
								PPINSTALLER_PAYMENT_RECURRING_EOT,
								PPINSTALLER_PAYMENT_RECURRING_FAILED,
								PPINSTALLER_PAYMENT_RECURRING_START
								);
								
		$query	= 'SELECT * FROM `#__payplans_app` WHERE `type` ='."'email'";
		$db->setQuery($query);
		$apps = $db->loadObjectList('app_id');
		foreach ($apps as $app_id=>$app)
		{
			$app_params = (array)PpinstallerHelperUtils::stringToObject($app->app_params);
			
			if(	!isset($app_params['when_to_email']) ||
				'on_status' != $app_params['when_to_email']||
				!in_array($app_params['on_status'], $payment_status)
			  ) 
			{  continue; }
			
			$desc = JText::_('COM_PPINSTALLER_EMAIL_APP_DESC');
			$query = " UPDATE `#__payplans_app` 
					   SET `published`= 0 ,
					  	   `description` = '$desc'
					   WHERE `app_id`= $app_id ";
			
			$db->setQuery($query);
			$this->is_success &= $db->query();
			
			PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_APP_DISABLE','Payplans appmetadata'),$db->errorMsg());
		}
		PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_DROP_TABLE','Payplans appmetadata'),$db->errorMsg());
		
		$this->msg = $this->msg = JText::sprintf('COM_PPINSTALLER_MIGRATION_DONE','App');
		return $returnInfo;
	}
	
	//XiTODO:: Pending message column
	public function mWallet() 
	{
		$returnInfo = Array();
		
			
		$db				= JFactory::getDBO();		
		$this->query	= '
							SELECT T.`user_id`,T.`transaction_id`,
									T.`amount`, T.`created_date`,
									I.`invoice_id`, T.`current_invoice_id`
							FROM `#__payplans_transaction` as T
							INNER JOIN `#__payplans_invoice`as I
							ON I.`invoice_id`  = T.`invoice_id`
							WHERE I.`status` = '. PPINSTALLER_INVOICE_PAID
						  ;
		//$this->start 	  = JRequest::getVar('start',0);
		$limt  	  = " LIMIT {$this->start} ,".PPINSTALLER_LIMIT ; 
		$db->setQuery($this->query.$limt);
		$records = $db->loadObjectList('transaction_id');

		if(empty($records)){
			$this->query = null;
			$this->msg   = JText::sprintf('COM_PPINSTALLER_TABLE_EMPTY','Transaction');
			PpinstallerHelperLogger::log($this->msg);
			return $returnInfo;
		}
		$query = '
					INSERT INTO `#__payplans_wallet`
						(`user_id`,`transaction_id`,`amount`,`invoice_id`,`created_date`) 
					VALUES
				 ';
		
		foreach($records as $transaction_id => $record){
			//create +ive amount
			$query .="( {$record->user_id},{$record->transaction_id},
						{$record->amount},0,'{$record->created_date}'),";
			//create -ive amount
			$query .="( {$record->user_id},0, ".
						-1*$record->amount.",{$record->current_invoice_id},'{$record->created_date}'),";
		}
		
		$query = substr($query,0,strrpos($query,','));
		$db->setQuery($query);
		$this->is_success &=$db->query();
		PpinstallerHelperLogger::log('Wallet has been created',$db->errorMsg());	
		
		$this->msg = $this->msg = JText::sprintf('COM_PPINSTALLER_MIGRATION_DONE','Wallet');;
		return $returnInfo;
	}
	
	public function mFinalize() 
	{
		$returnInfo = array();
		$db		= JFactory::getDBO();
			
		//Remove Unwanted columns from order table
		// PayPlans 2.0  :: I'll remove total column and rename sub-total to total 
		$query	= 'ALTER TABLE `#__payplans_order` '.
					  'DROP `total`,'.
					  'DROP `discount`,'.
					  'DROP `shipping`,'.
					  'DROP `tax`,'.
					  'DROP `shipping_address`,'.
					  'DROP `billing_address`';
		
		$db->setQuery($query);
		$this->is_success &= $db->query();
				
		PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_DROP_COLUMNS','order'),$db->errorMsg());
		
		$query	= " ALTER TABLE `#__payplans_order` ".
				  " CHANGE subtotal total decimal(15,5) NOT NULL DEFAULT '0.00000' ";	
		
		$db->setQuery($query);
		$this->is_success &= $db->query();
				
		PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_CHANGE_COLUMNS','{subtotal to total}'),$db->errorMsg());
		
		// delete all children payments
		$query = 'DELETE FROM `#__payplans_payment` WHERE `master` = 0 ';
		$db->setQuery($query);
		$this->is_success &= $db->query();
		
		PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_DELETE_ROWS','payment'),$db->errorMsg());
		
		
		$query	= '	ALTER TABLE `#__payplans_payment` 
				      DROP 	`txn_id`,
					  DROP `amount`,
					  DROP `currency`,
					  DROP `status`,
					  DROP `is_refund`,
					  DROP `transaction`,
					  DROP `master`,
					  DROP `consumed`,
					  DROP `order_id`
				  ';
		$db->setQuery($query);
		$this->is_success &= $db->query();
		PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_DROP_COLUMNS','payment'),$db->errorMsg());
		
		// Drop columns which is created by Migrator
		$db->setQuery('DESCRIBE `#__payplans_invoice` ');
		$columns = $db->loadResultArray();
		if(in_array('m_payment_id', $columns)){
			$query = ' ALTER TABLE `#__payplans_invoice`
							DROP `m_payment_id`
					 ';
			$db->setQuery($query);
			$this->is_success &= $db->query();
			PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_DROP_COLUMN','m_payment_id','invoice'),$db->errorMsg());		 
		}
			
		// Migrate Resource Table :: Update `subscription_ids` column {change data type then Prepend and append comma (,) seperator}
		$query = " ALTER TABLE `#__payplans_resource` CHANGE `subscription_ids` `subscription_ids` TEXT ";
		$db->setQuery($query);
		$this->is_success &= $db->query();
		PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_MODIFY_COLUMN','Resource'),$db->errorMsg());
		
		$query = "UPDATE `#__payplans_resource` SET `subscription_ids`= CONCAT(',',`subscription_ids`,',')";
		$db->setQuery($query);
		$this->is_success &= $db->query();
		PpinstallerHelperLogger::log(JText::sprintf('COM_PPINSTALLER_UPDATE_COLUMN','Resource'),$db->errorMsg());
		
		// migration done
		$this->msg = JText::_('COM_PPINSTALLER_MIGRATE_FINALIZE');
		return $returnInfo;		
	}
	
	public function after()
	{	
		// unused patche
		$patches = Array(
							'patch_20_005_modified_discount_amount'  => 1,
							'patch_20_006_spell_correction'			 => 1,
							'patch_20_007_add_tax_type' 			 => 1,
							'patch_20_008_remove_data_redundancy'	 => 1,
							'patch_20_009_add_expiration_type'		 => 1,
							'patch_20_010_delete_unused_invoices'	 => 1,
							'patch_20_011_update_confirm_invoices'	 => 1,
							'patch_20_012_update_invoice_counter'	 => 1,
							'patch_20_013_add_expiration_time'		 => 1,
							'patch_20_014_update_modifier_frequency' => 1,
							'patch_20_015_utilize_wallet_balance'	 => 1,
							'patch_20_016_equate_wallet_balance'	 => 1,
							'patch_20_017_update_order_total'		 => 1,
							'patch_20_018_update_invoice_amount'	 => 1,
							'patch_20_019_make_transaction_date'  	 => 1
						);
		PpinstallerHelperPatch::insert($patches);
		return parent::after();
	}
	
}

