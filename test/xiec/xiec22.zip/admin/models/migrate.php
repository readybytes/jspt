<?php
/**
 * @package		Joomla.Administrator
 * @subpackage	com_ppinstaller
 * @copyright	Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access.
defined('_JEXEC') or die;

// Import library dependencies
jimport('joomla.application.component.model');


/**
 * Extension Manager Install Model
 *
 * @package		Joomla.Administrator
 * @subpackage	com_installer
 * @since		1.5
 */
//XiTODO:: improve Funtion names
class PpinstallerModelMigrate extends JModel
{
	//required joomla var
	protected $option		= 'com_ppinstaller';
	
	// migration variables
	protected $sql_file 	= null;
	protected $migrate_from = null ;
	protected $migrate_file = null ;
	protected $is_success 	= true;
	protected $query		= null;
	protected $start 		= 0;
	protected $limit 		= PPINSTALLER_LIMIT;
	protected $action		= Array();
	protected $msg			= null;
	
	
	function __construct($config=Array())
	{
		$this->start = JRequest::getVar('start',0);
		$before 	 = JText::_('COM_PPINSTALLER_BEFORE_MIGRATION');
		$after 		 = JText::_('COM_PPINSTALLER_AFTER_MIGRATION');
		$this->action 	= array_merge(array('before'=>$before),$this->action,array('after'=>$after));
		$config['name'] = __CLASS__;
		parent::__construct($config);
		
	}
	
	public function nextMigrateAction($currentAction)
	{
		if(!$this->is_success ){ return 'halt';}
			
		$next_action = null;
		$start_from = 0;
		if(!empty($this->query)){
			$db = JFactory::getDbo();
			$db->setQuery($this->query);
			$total	 = count($db->loadResultArray());
			$from 	 = $this->start;  
			$end   	 = $this->start+$this->limit;	
			if($end < $total){
				$start_from = $end;
				$next_action = $currentAction;
			}else{
				$end = $total;
			}
			$from   = "<span class='pp-bold'>$from</span>";
			$end 	= "<span class='pp-bold'>$end</span>";
			$total  = "<span class='pp-bold'>$total</span>";
			$this->msg = JText::sprintf('COM_PPINSTALLER_MIGRATION_LIMIT',$from,$end,$total);
		}
				
		if(empty($next_action)){
			//$start_from = 0;
			$keys 	  = array_keys($this->action);
			$position = array_search($currentAction, $keys);
			$position = (false === $position )? 0 : $position+1;
			$next_action = isset($keys[$position]) ? $keys[$position] : false; 
		}
		
		JRequest::setVar('start', $start_from);
		return $next_action;
	}
	
	/**
	 * Load a list of database objects
	 * If <var>key</var> is not empty then the returned array is indexed by the value
	 * the database key.  Returns <var>null</var> if the query fails.
	 * @param $table : table name 
	 * @param $key 
	 * @param $filters : where conditions Array('value'=>'column_name')
	 * @param $operator : OR/AND
	 */
	
	protected function loadData($table,$key = '', $filter = Array(), $operator = 'AND')
	{
		$db = JFactory::getDbo();
		$query = " SELECT * FROM `$table`";
		if(!empty($filter)){
			$query .= ' WHERE ';
			if(is_string($filter)){
				$query .= $filter;				
			}
			else {
				foreach ( $filter as $value => $column_name){
					$query .= (is_string($value))? " `$column_name`='$value'":" `$column_name`=$value";
					$query .= " $operator " ;
				}
				// XiTODO::In case of OR operator it will be misguiding
				$query .= 1;	
			}
		}
		$db->setQuery($query);
		return $db->loadObjectList($key);
	}
	
	public function before() 
	{
		$msg 			  = 'NOTHING_HAPPEN';
	
		// XiTODO:: need selenium test case
		//if payplans already exist then switch to latest {prev} version.
		if(JRequest::getVar('is_redirect',0) == 0)
		{
			//if payplans already exist then we'll unuinstall it
			$this->is_success &= PpinstallerHelperInstall::remove_component();

			$kit_name = 'PAYPLANS'.$this->migrate_from.'.'.PPINSTALLER_COMPRESSION_TYPE;
			//downlod kit through CURL
			$is_download = PpinstallerHelperInstall::zip_from_url($kit_name);	
			if(!$is_download){
				// XiTODO :: clean language code
				$msg = JText::sprintf('COM_PPINSTALLER_ISSUE_WITH_PREVIOUS_VESRION_DOWNLOADING',$kit_name);
				JFactory::getApplication()->redirect('index.php',$msg,'error');
			}
			$extract_dir  	= constant('PPINSTALLER_PAYPLANS'.$this->migrate_from);
			$archive_name	= $extract_dir.'.'.PPINSTALLER_COMPRESSION_TYPE;
			
			$controller		= new PpinstallerController;
			$model 			= $controller->getModel('install');
			$is_installed 	= $model->install(null,$archive_name,$extract_dir);
			
			$msg = 'Previous version successfully installed.';

			// redirect it when any kind of issue occure on installation
			if(!$is_installed){
				$msg = 'Issue with previous version installation.';
				JFactory::getApplication()->redirect('index.php',$msg,'error');
			}
			
			PpinstallerHelperLogger::log($msg."(Zip-Name:$kit_name)");
			
			include_once JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_payplans'.DS.'includes'.DS.'includes.php';
			//invoke patches
			PayplansHelperPatch::applyPatches();
			//	the last patch
			XiHelperPatch::updateVersion();

			// uninstall previous version
			$this->is_success &= PpinstallerHelperInstall::remove_modules();
			$this->is_success &= PpinstallerHelperInstall::remove_plugins();
			$this->is_success &= PpinstallerHelperInstall::remove_component();
			// PayPlans auto loaded on system start so that all system trigger will be availbled. When I'll uninstall PayPlans with system plugin 
			// then I'll face warnings about class not found. B'coz All System-trigger are losded and system don't have any payplans class(I have uninstalled it so I'll redirect it)

			//Don't display any {system,error and warning} msg. (set to null)
			JFactory::getApplication()->set('_messageQueue');
			JFactory::getApplication()->redirect('index.php?option=com_ppinstaller&task=migrate&is_redirect=1');
		}

		
		$returnInfo = Array();
		//import sql file
		if(JFile::exists($this->sql_file)){
			PpinstallerHelperMigrate::importSql($this->sql_file);	
		}
				
		
		if($this->migrate_from){
			$migration_order = PpinstallerHelperUtils::migrationOrder();
			$msg = JText::sprintf('COM_PPINSTALLER_MIGRATION_START_FROM_TO',$this->migrate_from, $migration_order[$this->migrate_from]);
			PpinstallerHelperLogger::log($msg);
			$this->is_success &= true;
		} else{
			$this->is_success &= false;
		}
		
		PpinstallerHelperMigrate::setKeyValue('migration_status',PPINSTALLER_MIGRATION_START);
		
		$this->msg 			 = $msg;
		return $returnInfo;
	}
	
	public function after() 
	{
		PpinstallerHelperMigrate::setKeyValue('migration_status',PPINSTALLER_MIGRATION_SUCCESS);
		
		$returnInfo = Array();
		$this->msg = JText::sprintf('COM_PPINSTALLER_MIGRATION_DONE','PayPlans');;
		return $returnInfo;
	}
	
	public function halt()
	{
		//XiTODO:: Stop Migration process
		$returnInfo = Array();
		$returnInfo['migrateAction'] = false;
		$this->msg = 'COM_PPINSTALLER_HALT_MIGRATION';
		return $returnInfo;
		;
	}
	
	public function mPlans() 
	{
		$returnInfo = Array();
		$returnInfo['migrateAction'] = 'migrateOrders';
		$this->msg = 'COM_PPINSTALLER_PLANS_MIGRATION_SUCCESSFULLY';
		return $returnInfo;			
	}
	
	public function mOrders() 
	{
		$returnInfo = Array();
		$returnInfo['migrateAction'] = 'migrateSubscriptions';
		$this->msg = 'COM_PPINSTALLER_ORDERS_MIGRATION_SUCCESSFULLY';
		return $returnInfo;
	}
	
	public function mSubscriptions() 
	{
		$returnInfo = Array();
		$returnInfo['migrateAction'] = 'migratePayments';
		$this->msg = 'COM_PPINSTALLER_SUBSCRIPTIONS_MIGRATION_SUCCESSFULLY';
		return $returnInfo;
	}
	
	public function mPayments() 
	{
		$returnInfo = Array();
		$returnInfo['migrateAction'] = 'migrateApps';
		$this->msg = 'COM_PPINSTALLER_PAYMENTS_MIGRATION_SUCCESSFULLY';
		return $returnInfo;
	}
	
	public function mApps() 
	{
		$returnInfo = Array();
		$returnInfo['migrateAction'] = 'afterMigrate';
		$this->msg = 'COM_PPINSTALLER_APP_MIGRATION_SUCCESSFULLY';
		return $returnInfo;
	}
}
