<?php 
// define where the Joomla is installed
define('JPATH_BASE',	dirname(dirname(__FILE__)));
