<?php
require_once 'PHPUnit/Framework.php';

class Stack2Test extends PHPUnit_Framework_TestCase
{
    public function testPushAndPop()
    {
        $this->assertEquals(1,1);
    }
}
?>             
